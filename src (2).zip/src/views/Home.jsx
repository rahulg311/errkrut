import React, { Component } from 'react';

import Header from '../Components/common/Header';

import CompaniesCard from '../Components/Cards/CompaniesCard';

import RightSidebar from '../Components/Sidebars/RightSidebar';

import TopCompaniesCard from '../Components/Cards/TopCompaniesCard';

class Home extends Component {

    render() {

        return (
            <div className="main-container position-relative">

                <Header>

                </Header>

                <div className="content-wrapper">

                    <div className="row mt-4">

                        {/* Content */}
                        <div className="col-md-9">

                            <TopCompaniesCard> </TopCompaniesCard>

                            {/* Top Jobs */}

                            <div className="bg-white br-5 pt-4 pb-4 pl-4 pr-4">
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="position-relative">
                                            <h4 className="font-bold float-left">Top Jobs</h4>
                                            <h6 className="float-right"><a href="">See All</a></h6>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-4">
                                                {/* Cards */}
                                                <div className="cards position-relative mt-2 w-100 br-5 p-3" style={{ backgroundImage: process.env.PUBLIC_URL + 'url("/assets/imgs/bg/box-pattern.png")', backgroundColor: "#4460ef" }}>
                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-4">
                                                            <img src="./assets/imgs/dummy-logo.png" className="img-fluid w-100 box-shadow br-5" />
                                                        </div>
                                                        <div className="col-md-8">
                                                            <div className="text-white position-absolute abs-center-y l-0">
                                                                <p className="font-bold m-0">UI/UX Developer</p>
                                                                <p className="m-0">Company Name</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {/* row */}

                                                    {/* container */}
                                                    <div className="mt-2 mb-2">

                                                    </div>
                                                    {/* container */}

                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-1 pr-0">
                                                            <i class="las la-briefcase text-white f-0-9"></i>
                                                        </div>
                                                        <div className="col-md-4">
                                                            <p className="text-white font-bold m-0 f-0-8">Experience</p>
                                                        </div>
                                                        <div className="col-md-7">
                                                            <p className="text-white m-0 f-0-8">0-5 Years</p>
                                                        </div>
                                                    </div>
                                                    {/* row */}

                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-1 pr-0">
                                                            <i class="las la-map-marker text-white f-0-9"></i>
                                                        </div>
                                                        <div className="col-md-4">
                                                            <p className="text-white font-bold m-0 f-0-8">Location</p>
                                                        </div>
                                                        <div className="col-md-7">
                                                            <p className="text-white m-0 f-0-8">Bangalore</p>
                                                        </div>
                                                    </div>
                                                    {/* row */}

                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-1 pr-0">
                                                            <i class="las la-pencil-alt text-white f-0-9"></i>
                                                        </div>
                                                        <div className="col-md-4">
                                                            <p className="text-white font-bold m-0 f-0-8">Skillset</p>
                                                        </div>
                                                        <div className="col-md-7">
                                                            <p className="text-white m-0 f-0-8">React, Laravel</p>
                                                        </div>
                                                    </div>
                                                    {/* row */}

                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-12">
                                                            <button className="btn btn-default btn-block mt-1">
                                                                Apply Now
                                                            </button>
                                                        </div>
                                                    </div>
                                                    {/* row */}
                                                </div>
                                                {/* Cards */}
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            {/* Top Jobs */}

                            {/* Recommended Jobs */}

                            <div className="bg-white br-5 pt-4 pb-4 pl-4 pr-4">
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="position-relative">
                                            <h4 className="font-bold float-left">Recommended Jobs</h4>
                                            <h6 className="float-right"><a href="">See All</a></h6>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-12">
                                                {/* Cards */}
                                                <div className="cards position-relative mt-2 w-100 br-5 pt-3 pb-3 pl-4 pr-4 blue-box-shadow ">
                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-2">
                                                            <img src="./assets/imgs/dummy-logo.png" className="img-fluid box-shadow br-5 h-60p" />
                                                        </div>
                                                        <div className="col-md-10">
                                                            <div className="position-absolute abs-center-y l-0">
                                                                <h5 className="font-bold">UI/UX Developer</h5>
                                                                <h6>Company Name</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {/* row */}

                                                    {/* sub details */}
                                                    <div className="pr-3">
                                                        {/* container */}
                                                        <div className="row mt-2 mb-2">
                                                            {/* row */}

                                                            <div className="col-md-4">
                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-6">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-briefcase  text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>
                                                                                Experience
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-6 pl-0">
                                                                        <p className="m-0 f-0-8">0-5 Years</p>
                                                                    </div>

                                                                    {/* row */}
                                                                </div>
                                                            </div>
                                                            {/* row */}

                                                            {/* row */}

                                                            <div className="col-md-4">
                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-6">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-map-marker  text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>
                                                                                Location
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-6 pl-0">
                                                                        <p className="m-0 f-0-8">Bangalore</p>
                                                                    </div>
                                                                </div>
                                                                {/* row */}
                                                            </div>

                                                            {/* row */}

                                                            {/* row */}

                                                            <div className="col-md-4">
                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-5">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-rupee-sign text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>
                                                                                Salary
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-7">
                                                                        <p className="m-0 f-0-8">Not Disclosed</p>
                                                                    </div>
                                                                </div>
                                                                {/* row */}
                                                            </div>
                                                            {/* row */}
                                                        </div>
                                                        {/* container */}

                                                        {/* container */}
                                                        <div className="row mt-2 mb-2">
                                                            {/* row */}

                                                            <div className="col-md-12">
                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-2">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-briefcase  text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>
                                                                                Skillset
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-9 pl-0">
                                                                        <p className="m-0 f-0-8">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design...</p>
                                                                    </div>

                                                                    {/* row */}
                                                                </div>
                                                            </div>
                                                            {/* row */}

                                                        </div>
                                                        {/* container */}

                                                        {/* container */}
                                                        <div className="row mt-2 mb-2">
                                                            {/* row */}

                                                            <div className="col-md-3">
                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-8">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-user-check  text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>
                                                                                Vacancy
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-4 pl-0">
                                                                        <p className="m-0 f-0-8">8</p>
                                                                    </div>

                                                                </div>
                                                                {/* row */}

                                                            </div>

                                                            <div className="col-md-6">

                                                                {/* row */}
                                                                <div className="row">

                                                                    <div className="col-md-6">
                                                                        <p className="font-bold m-0 f-0-8 text-sky-blue">
                                                                            <span className="mr-1 vertical-middle">
                                                                                <i class="las la-file-invoice  text-sky-blue f-1-1"></i>
                                                                            </span>
                                                                            <span>Candidates Applied</span>
                                                                        </p>
                                                                    </div>
                                                                    <div className="col-md-6 pl-0">
                                                                        <p className="m-0 f-0-8">42</p>
                                                                    </div>

                                                                </div>
                                                                {/* row */}
                                                            </div>
                                                            {/* row */}

                                                        </div>
                                                        {/* container */}
                                                    </div>
                                                    {/* sub details */}

                                                    {/* tags */}
                                                    <div className="row mt-2 mb-2">
                                                        <div className="col-md-12">
                                                            <span class="badge badge-default cursor">REACT</span>
                                                        </div>
                                                    </div>
                                                    {/* tags */}

                                                    {/* tags */}
                                                    <div className="row mt-2 mb-2">
                                                        <div className="col-md-1">
                                                            <img src="./assets/imgs/fire.png" />
                                                        </div>

                                                        <div className="col-md-3">
                                                            <span className="position-absolute abs-center-y text-dark-gray">Posted 3 days ago</span>
                                                        </div>

                                                        <div className="col-md-8">
                                                            <a href="" className="float-right">
                                                                View Details
                                                            </a>
                                                        </div>
                                                    </div>
                                                    {/* tags */}

                                                    {/* horizontal line */}
                                                    <div className="border-gray-line w-100 mb-3"></div>
                                                    {/* horizontal line */}

                                                    {/* row */}
                                                    <div className="row">
                                                        <div className="col-md-3">
                                                            <span>
                                                                <img src="./assets/imgs/like.png" className="icon-small mr-3" />
                                                            </span>
                                                            <span>
                                                                <img src="./assets/imgs/share.png" className="icon-small mr-3" />
                                                            </span>
                                                            <span>
                                                                <img src="./assets/imgs/save.png" className="icon-small" />
                                                            </span>
                                                        </div>

                                                        <div className="col-md-9">
                                                            <button className="btn btn-info float-right btn-md pl-4 pr-4">
                                                                Apply Now
                                                            </button>
                                                        </div>
                                                    </div>
                                                    {/* row */}


                                                </div>
                                                {/* Cards */}


                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            {/* Recommended Jobs */}

                            <CompaniesCard></CompaniesCard>

                        </div>
                        {/* Content */}

                        {/* Sidebar */}
                        <div className="col-md-3 pt-2 pb-2">
                            <RightSidebar></RightSidebar>
                        </div>
                        {/* Sidebar */}
                    </div>

                </div>

            </div>

        );
    }

}

export default Home;