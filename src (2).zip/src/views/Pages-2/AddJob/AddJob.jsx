import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { createErrors, errorPrettify, errorPrettifyObjArr, formatTitle, getLoggedInUser } from '../../../classes/index';
import { createJob, editJob, getJobDescriptions, jobTypeDetails, jobTypes, updateJob, getCompanyCategories, getCompanySubcategories, getCountry, getState, getCity, getCities } from '../../../store/actions/jobs';

import { validation } from '../../../classes/validation';
import { notification } from '../../../classes/messages';

import { connect } from "react-redux";
import JobPreview from '../JobPreview/JobPreview';
import JobForm from './JobForm';

import { routeChanged, routePushed } from '../../../classes/browserHistory';
import { getSingleTemplate, getTemplate } from '../../../store/actions/template';
import InterviewRounds from './InterviewRounds';
import SideBar from '../../../components/hoc/SideBar';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';

class AddJob extends Component {

    state = {
        feature_id: '',
        job_title: '',
        designation: '',
        nature_of_employment: '',
        job_description: '',
        skill_set: '',
        qualification: '',
        ctc_from: '',
        ctc_to: '',
        min_work_exp: '',
        max_work_exp: '',
        job_location: '',
        job_function: '',
        number_of_vaccancy: '',
        user_id: null,
        show_round: 0,
        errors: {},
        api_res: null,
        edit_id: 0,
        plans: [],
        template: [],
        company_id: null,
        show_hr_details: 0,
        show_hiring_agencies: 0,

        company_details: 0,
        job_posting_date: null,
        job_expiry_date: null,
        edit_id: null,
        job_types: [],
        job_type_details: null,
        plan_id: null,
        job_descriptions_options: [],
        companyCategoriesopt: [],
        companySubCategoriesopt: [],
        countryopt: [],
        stateopt: [],
        cityopt: [],
        citiesopt: [],
        jd_title: null,
        purpose: null,
        industry: null,
        job_responsibilities: null,
        preffered_skills: null,
        desired_qualification: null,
        summary: null,
        rounds: [],
        show_add_round_form: false,
        edit_round_index: null,
        step: 1,
        show_company_website_link: null,
        show_company_banner: null,
        show_company_logo: null,
        is_jd_form: false,

        hrName: null,
        hrDesignation: null,
        compName: null,
        compCategory: null,
        compSubcategory: null,
        compEmail: null,
        compPhone: null,
        compWebsite: null,
        compCountry: null,
        compState: null,
        compCity: null,
        logo: null,
    }


    componentWillMount() {
        this.getUserId();
        this.getJobDescriptions();
        
        if (this.props.match.params?.id) {
            this.setState({
                edit_id: this.props.match.params.id
            }, () => {
                this.editJobData();

            });
        }

    }

    setDescForm = () => {
        this.setState({ is_jd_form: !this.state.is_jd_form });
    }

    /* add round */
    addRound = (e) => {
        this.setState({
            show_add_round_form: !this.state.show_add_round_form
        });
    }
    /* add round */

    /* create round */
    createRound = (e) => {
        e.preventDefault();
        let round = {};
        Object.keys(e.target).map((index, ele) => {
            if (e.target[index].name)
                round[e.target[index].name] = e.target[index].value;
        });

        if (this.state.edit_round_index != null) {

            let roundss = [...this.state.rounds];

            roundss[this.state.edit_round_index] = round;

            this.setState({
                rounds: roundss,
                edit_round_index: null,
                show_add_round_form: false
            });

        } else {
            this.setState(prevState => ({
                rounds: [...prevState.rounds, ...[round]],
                show_add_round_form: false
            }), () => {
                console.log(this.state.rounds);
            });
        }


    }
    /* create round */

    /* edit round */
    editRound = (index) => {
        this.setState({
            show_add_round_form: true,
            edit_round_index: index
        })

    }
    /* edit round */

    deleteRound = (index) => {

        console.log(index);
        
        let deleteRound = this.state.rounds;
        deleteRound.splice(index,1);

        this.setState({rounds: deleteRound});
        
        console.log(this.state.rounds);
        //this.addRound(index)
    }

    /* edit job data */
    editJobData = async () => {
        /* edit job */
        await this.props.editJob(this.state.edit_id);
        let data = this.props.edit_job_data;

        if (data?.status == 'success') {
            Object.keys(data.data).map((key) => {
                this.setState({
                    [key]: data.data[key]
                });
            });
        }
        /* edit job */
    }
    /* edit job data */

    /* get job tyipes */
    getJobTypes = async () => {
        let fm = new FormData();
        fm.append('plan_id', (this.state?.plan_id) ? this.state?.plan_id : '');
        fm.append('user_id', (this.state?.user_id) ? this.state?.user_id : '');
        fm.append('company_id', (this.state?.company_id) ? this.state?.company_id : '');

        await this.props.jobTypes(fm);
        this.setState({ job_types: this.props.job_type_res?.data });
    }
    /* get job tyipes */

    /* get company category */

    getCompanyCategoriesop = async () => {
        await this.props.getCompanyCategories();
        this.setState({ companyCategoriesopt: this.props.comp_category_res?.data });
    }

    /* get company category */
    /* get company category */
    getCompanySubCategoriesop = async (id) => {
        await this.props.getCompanySubcategories(id);
        //console.log(this.props.comp_sub_category_res?.data);
        this.setState({ companySubCategoriesopt: this.props.comp_sub_category_res?.data });
    }
    /* get company category */
    
    /* get country list */
    getCountryOp = async () => {
        await this.props.getCountry();
        this.setState({ countryopt: this.props.country_res?.data });
    }
    
    getStateOp = async (id) => {
        await this.props.getState(id);
        this.setState({ stateopt: this.props.state_res?.data });
    }
    
    getCityOp = async (id) => {
        await this.props.getCity(id);
        this.setState({ cityopt: this.props.city_res?.data });
    }
    getCitiesOp = async (id) => {
        await this.props.getCities(id);
        this.setState({ citiesopt: this.props.citiesdata?.data });
    }


    /* get country list */

    /* job types details */
    jobTypeDetails = async (e) => {

        console.log(e);
        let id;
        Object.keys(e.target)?.map((i) => {

            if (e.target[i].value != '' && e.target[i].selected == true) {
                id = e.target[i].getAttribute("datatype");
            }
        });
        if (id) {
            await this.props.jobTypeDetails(id);
            this.setState({ job_type_details: this.props.job_type_details_res?.data });
        }


    }
    /* job types details */

    /* get template */
    getTemplate = async () => {
        await this.props.getTemplate(this.state.company_id);

        this.setState({ template: this.props.templatedata?.data });
    }
    /* get template */

    /* get user id */
    getUserId = async () => {
        const result = await getLoggedInUser();

        this.setState({
            user_id: parseInt(result.id),
            company_id: parseInt(result.company_id),
            plan_id: parseInt(result.plan_id)
        }, () => {
            this.getJobTypes();
            this.getTemplate();
            this.getCompanyCategoriesop();
            this.getCountryOp();
        });
    }
    /* get user id */

    /* handle validation */

    handleValidation = (obj) => {

        let error = this.state.errors;

        let valiRes = validation(obj);

        //email
        if (valiRes['error'] == 1) {

            error[obj.name] = valiRes['message'];

            this.setState({
                errors: error
            });

        } else {
            error[obj.name] = '';

            this.setState({
                errors: error
            });
        }

    }

    /* handle validation */

    /* select template */
    selectTemplate = async (e) => {
        if (e.target.value) {

            await this.props.getSingleTemplate(e.target.value);
            let tdata = this.props.single_template_data;

            if (tdata?.status == 'success') {
                Object.keys(tdata.data).map((k) => {

                    this.setState({ [k]: tdata.data[k] });
                });
            }


        }

    }
    /* select template */

    subCategory = async (e) => {
        
        this.getCompanySubCategoriesop(e.target.value);
    }

    stateDetails = async (e) => {
        
        this.getStateOp(e.target.value);
    }
    
    cityDetails = async (e) => {
        
        this.getCityOp(e.target.value);
    }

    jobcityDetails = async (e) => {
        
        //country by city
        this.getCitiesOp(e.target.value);
    }


    addLogo =  async (e) => {
        this.setState({ logo: e.target.files[0] });
        console.log(e.target.files[0])
    }
    // Handle fields change
    handleChange = async (e, valiType = '', valiMsg = '') => {

        console.log(e);

        if (e.target) {

            let ivalue = e.target.value;
            let iname = e.target.name;

            if (e.target.type == 'checkbox') {
                if (e.target.checked) {
                    ivalue = 1;
                } else {
                    ivalue = 0;
                }
            }

            if (valiType && valiMsg)
                this.handleValidation({ name: iname, type: valiType, value: ivalue, message: valiMsg });

            //this.setState({...this.state,[iname]: ivalue});

            this.setState({ [iname]: ivalue }, () => {

            });

        }
    }
    /* handle change */

    setStep = (step) => {
        this.setState({
            step: step
        })
    }

    step1Submit = (e) => {

        e.preventDefault();

        if (this.state.step == 1) {

            let formValid = true;

            let notify = null;

                if (this.state.job_description === '') {
                    formValid = false;
                    notify = notification({ message: 'Job Description field is required', type: 'error' });
                    notify();
                }else if (this.state.errors) {

                    Object.keys(this.state.errors).map((k, v) => {
    
                        if (this.state.errors[k] != "") {
                            formValid = false;
                            notify = notification({ message: 'Please fill all required fields correctly.', type: 'error' });
                            notify();
                        }
                    })
    
                }else{
                    formValid = true;
                }



            if (formValid == true) {
                this.setState({
                    step: 2
                })
            } 
        }
    }


    /* job descriptions */

    getJobDescriptions = async () => {
        let id = 0;
        await this.props.getJobDescriptions(id);

        if (this.props.job_desc_res?.data && this.props.job_desc_res?.status == 'success') {
            this.setState({
                job_descriptions_options: this.props.job_desc_res?.data
            });
        }

    }

    /* job descriptions */
    

    /* handle Submit */
    handleSubmit = async (e) => {

        console.log(this.state.skill_set);
        console.log(this.state.plan_id);

        let notify = null;

        let formData = {
            user_id: this.state.user_id,
            feature_id: this.state.feature_id,
            job_title: this.state.job_title,
            designation: this.state.designation,
            nature_of_employment: this.state.nature_of_employment,
            job_description: this.state.job_description,
            skill_set: this.state.skill_set.toString(),
            qualification: this.state.qualification,
            ctc_from: this.state.ctc_from,
            ctc_to: this.state.ctc_to,
            min_work_exp: this.state.min_work_exp,
            max_work_exp: this.state.max_work_exp,
            
            job_function: this.state.job_function,
            number_of_vaccancy: this.state.number_of_vaccancy,
            company_id: this.state.company_id, 

            company_details: this.state.company_details,
            job_posting_date: this.state.job_posting_date,
            job_expiry_date: this.state.job_expiry_date,
            jd_title: this.state.jd_title,
            purpose: this.state.purpose,
            industry: this.state.industry,
            job_responsibilities: this.state.job_responsibilities,
            preffered_skills: this.state.preffered_skills,
            desired_qualification: this.state.desired_qualification,
            summary: this.state.summary,
            rounds: JSON.stringify(this.state.rounds),
            show_company_website_link: this.state.show_company_website_link,
            show_company_banner: this.state.show_company_banner,
            show_company_logo: this.state.show_company_logo,
            plan_id: this.state.plan_id,

            hiring_agencies: this.state.show_hiring_agencies,
            
            job_country: this.state.jobCountryLoc,
            job_city: this.state.jobCityLoc,
            show_hr_details: this.state.show_hr_details,
            
            hr_name: this.state.hrName,
            hr_designation: this.state.hrDesignation,
            company_name: this.state.compName,
            category: this.state.compCategory,
            sub_category: this.state.compSubcategory,
            email: this.state.compEmail,
            phone: this.state.compPhone,
            website: this.state.compWebsite,
            country: this.state.compCountry,
            state: this.state.compState,
            city: this.state.compCity,
            logo: this.state.logo,
        };


        let res;
        if (this.state.edit_id) {
            await this.props.updateJob(formData);
            res = this.props.edit_job_data;
        } else {
            await this.props.createJob(formData);
            res = this.props.data;
        }

        if (res) {

            if (res.status == 'success') {
                notify = notification({ message: res.message, type: 'success' });

                routePushed('/successful', this.props, { message: 'Your Job Added Successfully.' });

                //routeChanged('/successful', this.props);

            } else {
                notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            }
        }

        if (notify)
            notify();

    }
    /* handle Submit */

    render() {

        let errs = this.state.errors && Object.keys(this.state.errors).map((k, v) => { return this.state.errors[k].length >= 1 && <li className="text-danger">{this.state.errors[k]}</li> }
        )

        return (
            <Section>
                <Main>

                    {errs &&
                        <ul>
                            {errs}
                        </ul>
                    }

                    {(this.state.api_res) && <p className="text-danger">{this.state.api_res}</p>}

                    {/* Job Form */}
                    {(this.state.step == 1) &&
                        <JobForm
                            handleChange={this.handleChange}
                            addLogo={this.addLogo}
                            errors={this.state.errors}
                            formData={this.state}
                            selectTemplate={this.selectTemplate}
                            jobTypeDetails={this.jobTypeDetails}
                            getJobDescriptions={this.getJobDescriptions}
                            setJDForm={this.setJDForm}
                            step1Submit={this.step1Submit}
                            is_jd_form={this.state.is_jd_form}
                            setDescForm={this.setDescForm}
                            subCategory={this.subCategory}
                            stateDetails={this.stateDetails}
                            cityDetails={this.cityDetails}
                            jobcityDetails={this.jobcityDetails}
                        />
                    }
                    {/* Job Form */}

                    {this.state.step == 2 &&
                        <InterviewRounds
                            rounds={this.state.rounds}
                            addRound={this.addRound}
                            show_add_round_form={this.state.show_add_round_form}
                            setStep={this.setStep}
                            createRound={this.createRound}
                            editRound={this.editRound}
                            deleteRound={this.deleteRound}
                            edit_round_index={this.state.edit_round_index}
                        />
                    }

                    {/* Preview Job */}
                    {this.state.step == 3 &&

                        <JobPreview
                            formData={this.state}
                            handleSubmit={this.handleSubmit}
                            setStep={this.setStep}
                        />

                    }
                    {/* Preview Job */}

                </Main>


                <SideBar>
                    <ProfileName />
                    <ActionButtons />
                    <Company />
                </SideBar>

            </Section>

        );

    }

}

const mapStateToProps = (state) => {
    const { data, templatedata, single_template_data, edit_job_data, update_job_data, job_type_res, job_type_details_res, job_desc_res, comp_category_res, comp_sub_category_res, country_res, state_res, city_res, citiesdata } = state.common;
    return {
        data,
        templatedata,
        single_template_data,
        edit_job_data,
        update_job_data,
        job_type_res,
        job_type_details_res,
        job_desc_res,
        comp_category_res,
        comp_sub_category_res,
        country_res,
        state_res,
        city_res,
        citiesdata,
    }
};

function mapDispatchToProps(dispatch) {
    return {
        createJob: (formData) => dispatch(createJob(formData)),
        jobTypes: (obj) => dispatch(jobTypes(obj)),
        getTemplate: (id) => dispatch(getTemplate(id)),
        getSingleTemplate: (id) => dispatch(getSingleTemplate(id)),
        editJob: (id) => dispatch(editJob(id)),
        updateJob: (formData) => dispatch(updateJob(formData)),
        jobTypeDetails: (id) => dispatch(jobTypeDetails(id)),
        getJobDescriptions: (id) => dispatch(getJobDescriptions(id)),
        getCompanyCategories: () => dispatch(getCompanyCategories()),
        getCompanySubcategories: (id) => dispatch(getCompanySubcategories(id)),
        getCountry: () => dispatch(getCountry()),
        getState: (id) => dispatch(getState(id)),
        getCity: (id) => dispatch(getCity(id)),
        getCities: (id) => dispatch(getCities(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AddJob);