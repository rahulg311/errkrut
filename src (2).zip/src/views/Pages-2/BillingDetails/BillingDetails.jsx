import React, { useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { saveBillingDetails } from '../../../store/actions/SaveBillingDetails';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { findAllInRenderedTree } from 'react-dom/test-utils';
import { getLoggedInUser } from '../../../classes';

const BillingDetails = ({ history }) => {
	const dispatch = useDispatch();
	const [formData, setFormData] = useState({
		user_id: {
			value: '',
			required: true,
			error: '',
		},
		name: {
			value: '',
			required: true,
			error: '',
		},
		company_name: {
			value: '',
			required: true,
			error: '',
		},
		gst_number: {
			value: '',
			required: false,
			error: '',
		},
		phone_number: {
			value: '',
			required: true,
			error: '',
		},
		email: {
			value: '',
			required: true,
			error: '',
		},
		address_line1: {
			value: '',
			required: true,
			error: '',
		},
		addressLineTwo: {
			value: '',
			required: true,
			error: '',
		},
		country: {
			value: '',
			required: true,
			error: '',
		},
		state: {
			value: '',
			required: true,
			error: '',
		},
		city: {
			value: '',
			required: true,
			error: '',
		},
		zip: {
			value: '',
			required: true,
			error: '',
		},
		additional_information: {
			value: '',
			required: true,
			error: '',
		},
	});

	const onValueChange = (e) => {
		if(e.target.name === "phone"){
		if (e.target.value.length > 10){
            e.target.value = e.target.value.slice(0, 10)}
		}
		const key = e.target.id;
		const value = e.target.value;
		let data = { ...formData };
		data[key].value = value;
		if (value !== '') {
			data[key].error = '';
		}
		setFormData(data);
	};

	const onSubmitForm = async (e) => {

		e.preventDefault();
		Object.keys(formData).forEach((key) => {
			if (formData[key].value == '' && formData[key].required) {
				let data = { ...formData };
				data[key].error = `please provide ${key}`;
				setFormData(data);
			}
		});

		let data = {};
		Object.keys(formData).forEach((key) => {
			data[key] = formData[key].value;
		});
		let user = await getLoggedInUser();
		if (user) {
			formData['user_id'] = user.id;
			if (Object.values(formData).some((e) => e.value)) {
				/* let oldStorageData = JSON.parse(localStorage.getItem('BILLING-ADRESS'));
				oldStorageData
					? localStorage.setItem('BILLING-ADRESS', JSON.stringify([...oldStorageData, data]))
					: localStorage.setItem('BILLING-ADRESS', JSON.stringify([data]));
					 */
				data['user_id'] = user.id;
				dispatch(saveBillingDetails(data, history));
			}
		}

	};
	console.log("phone",formData['phone_number'].value)

	return (
		<Section>
			<Main>
				<section className='py-2'>
					<div>
						<div class='d-flex justify-content-between text-primary mb-4'>
							<h5>Billing Details</h5>
							<h5><Link to="/checkout">Pick a Saved Address</Link></h5>
						</div>
						<form onSubmit={(e) => onSubmitForm(e)}>
							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Name
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='name'
										placeholder='John Doe'
										value={formData['name'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['name'].error}</small>
									</div>
								</div>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Company Name
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='company_name'
										placeholder='Enter your Company Name here'
										value={formData['company_name'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['company_name'].error}</small>
									</div>
								</div>
							</div>
							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										GTS Number(Optional)
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='gst_number'
										placeholder='Enter your GST Number here'
										value={formData['gst_number'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['gst_number'].error}</small>
									</div>
								</div>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Phone Number
									</label>
									<input
										type='number'
										name="phone"
										onChange={onValueChange}
										class='form-control'
										id='phone_number'
										placeholder='+91 1111 22 3333'
										value={formData['phone_number'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['phone_number'].error}</small>
									</div>
								</div>
							</div>

							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Email
									</label>
									<input
										onChange={onValueChange}
										type='email'
										class='form-control'
										id='email'
										placeholder='Johndoe@example.com'
										value={formData['email'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['email'].error}</small>
									</div>
								</div>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Address line 1
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='address_line1'
										placeholder='Enter your address line 1 here'
										value={formData['address_line1'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['address_line1'].error}</small>
									</div>
								</div>
							</div>
							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Address line 2
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='addressLineTwo'
										placeholder='Enter your address line 2 here'
										value={formData['addressLineTwo'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['addressLineTwo'].error}</small>
									</div>
								</div>
								<div class='col mb-md-0 mb-3'>
									<label htmlFor='' class='form-label fw-bold'>
										country
									</label>
									<select
										class='form-select'
										aria-label='Default select example'
										value={formData['country'].value}
										id='country'
										onChange={onValueChange}
									>
										<option selected>Select Your country</option>
										<option value='India'>India</option>
										<option value='2'>Two</option>
										<option value='3'>Three</option>
									</select>
									<div className='mt-1'>
										<small className='text-danger'>{formData['country'].error}</small>
									</div>
								</div>
							</div>
							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div className='col mb-md-0 mb-3'>
									<label htmlFor='' class='form-label fw-bold'>
										State
									</label>
									<select
										class='form-select'
										aria-label='Default select example'
										id='state'
										value={formData['state'].value}
										onChange={onValueChange}
									>
										<option selected>Select Your State</option>
										<option value='Up'>Up</option>
										<option value='2'>Two</option>
										<option value='3'>Three</option>
									</select>
									<div className='mt-1'>
										<small className='text-danger'>{formData['state'].error}</small>
									</div>
								</div>
								<div class='col mb-md-0 mb-3'>
									<label htmlFor='' class='form-label fw-bold'>
										Town / City
									</label>
									<select
										class='form-select w-100'
										aria-label='Default select example'
										value={formData['city'].value}
										id='city'
										onChange={onValueChange}
									>
										<option selected>Enter Your Town/City</option>
										<option value='1'>One</option>
										<option value='2'>Two</option>
										<option value='3'>Three</option>
									</select>
									<div className='mt-1'>
										<small className='text-danger'>{formData['city'].error}</small>
									</div>
								</div>
							</div>
							<div class='row row-cols-1 row-cols-md-2 mb-md-2'>
								<div class='col mb-md-0 mb-3'>
									<label for='exampleFormControlInput1' class='form-label fw-bold'>
										Postcode / ZIP
									</label>
									<input
										onChange={onValueChange}
										type='text'
										class='form-control'
										id='zip'
										placeholder='Select Your Postcode / ZIP here'
										value={formData['zip'].value}
									/>
									<div className='mt-1'>
										<small className='text-danger'>{formData['zip'].error}</small>
									</div>
								</div>
							</div>
							<div class='mb-3'>
								<label for='exampleFormControlTextarea1' class='form-label fw-bold'>
									Additional Information
								</label>
								<textarea
									class='form-control'
									id='additional_information'
									rows='3'
									value={formData['additional_information'].value}
									placeholder='Notes about the order'
									onChange={onValueChange}
								></textarea>
								<div className='mt-1'>
									<small className='text-danger'>
										{formData['additional_information'].error}
									</small>
								</div>
							</div>
							<div class='d-flex justify-content-end'>
								<button type='submit' class='btn btn-primary'>
									Save Address & Proceed
								</button>
							</div>
						</form>
					</div>
				</section>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<div className='my-2'>
					<p className='fs-18'>Want to reach out more candidates?</p>
					<Link to='#'>Click Here</Link>
				</div>
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default BillingDetails;
