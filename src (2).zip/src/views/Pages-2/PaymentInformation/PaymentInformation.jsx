import React, { useState, useEffect } from 'react';
import { getLoggedInUser } from '../../../classes';
import { END_POINT } from '../../../routes/api_routes';
import Company from '../../../components/Contact/Company';
import Loading from '../../../components/common/Loading';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import { useHistory } from 'react-router';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { NavLink } from 'react-router-dom';

function PaymentInformation() {
	const history = useHistory();

	const [user, setUser] = React.useState({});
	const [loading, setLoading] = React.useState(false);
	const [totalPrice, setTotalPrice] = useState(0);
	const [plan, setPlan] = useState({});
	const [billingaddress, setSelectedBillingAddress] = useState(null);
	

	function onScriptLoad(data) {
		var config = {
			root: '',
			flow: 'DEFAULT',
			data: {
				orderId: data.order_id,
				token: data.txnToken,
				tokenType: 'TXN_TOKEN',
				amount: data.amount,
			},
			handler: {
				notifyMerchant: function (eventName, data) {
					console.log('notifyMerchant handler function called');
					console.log('eventName => ', eventName);
					console.log('data => ', data);
				},
			},
		};
		if (window.Paytm && window.Paytm.CheckoutJS) {
			window.Paytm.CheckoutJS.init(config)
				.then(function onSuccess() {

					window.Paytm.CheckoutJS.invoke();
				})
				.catch(function onError(error) {
					console.log('Error => ', error);
				});
		}
	}

	// create a array of object values
	function getObjectValues(obj) {
		return Object.values(obj);
	}

	const handlePaymentInformation = async () => {
		const selected_plan_id = localStorage.getItem('selected_plan_id');
		setLoading(true);
		const user = await getLoggedInUser();
		var formdata = new FormData();
		const temp_id = localStorage.getItem('plan_temp_id');
		console.log(`user`, user);
		formdata.append('name', user?.name);
		formdata.append('email', user.email);
		formdata.append('mobile', user?.mobile);
		formdata.append('amount', totalPrice);
		formdata.append('user_id', user.id);
		formdata.append('temp_id', temp_id);
		formdata.append('selected_plan_id', String(selected_plan_id));

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
		};

		fetch(END_POINT + 'paytm', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				console.log('result :>> ', result);
				onScriptLoad(result);
				setLoading(false);
			})
			.catch((error) => {
				console.log('error', error);
				setLoading(false);
			});
	};

	useEffect(async () => {
		const user = await getLoggedInUser();
		if (user.user_type !== Recruiter_User_Type_ID) {
			history.push('/');
		}
		const toalPrice = localStorage.getItem('PLAN_TOTAL_PRICE');
		const plan = JSON.parse(localStorage.getItem('PLAN'));
		setUser(user);
		setTotalPrice(toalPrice);
		setPlan(plan);
		const add = JSON.parse(localStorage.getItem('SELECTED-BILLING-ADDRESS'));
		setSelectedBillingAddress(add);
	}, []);

	return (
		<div className='container'>
			<div className='row gx-6'>
				<div className='col-lg-9  '>
					<section className='bg-white container py-2 rounded-4'>
						<div className='d-flex justify-content-between my-4'>
							<h4 className='f-Poppins-Medium font-weight-bold '>Your Order</h4>
							<NavLink to="/plans" className='f-Poppins-Medium font-weight-bold float-end text-primary'>
								Edit
							</NavLink>
						</div>
						<div className='d-flex justify-content-between mb-4'>
							<h6 className='fw-normal'>{plan?.name} Plan</h6>
							<h6 className='fw-normal'>{plan?.name} Plan</h6>
						</div>
						<div className='d-flex justify-content-between mb-4'>
							<h6 className='fw-normal'>Expansion Pack</h6>
							<h6 className='fw-normal'>
								<h6 className='fw-normal'>
									<i class='las la-rupee-sign'></i>
									{totalPrice}
								</h6>
							</h6>
						</div>
						<div className='d-flex justify-content-between mb-4'>
							<h6 className='fw-normal'>Date:08/01/202</h6>
							<h6 className='fw-normal'>Time:(IST)10am</h6>
						</div>
						<div className='d-flex justify-content-between mb-4'>
							<h6 className='fw-normal'>Sub Total</h6>
							<h6 className='fw-normal'>
								<i class='las la-rupee-sign'></i> {totalPrice}
							</h6>
						</div>
						<div className='d-flex justify-content-between mb-4'>
							<h6 className='fw-normal'>Promocode Discount 10%</h6>
							<h6 className='fw-normal'>0</h6>
						</div>
						<hr />
						<div className='d-flex justify-content-between mt-1 mb-3'>
							<h3 className=''>Total</h3>
							<h3 className=''>
								<i class='las la-rupee-sign'></i>
								{totalPrice}
							</h3>
						</div>
					</section>
					<div className='container mt-4 bg-white rounded-4 mb-6'>
						<div className='row  pt-4 pb-1 '>
							<div className='col-md-12'>
								<h4 className='f-Poppins-Medium mt-2'>Payment Information</h4>
							</div>
						</div>
						<div className='d-flex justify-content-between my-4'>
							<h5 className='f-Poppins-Medium font-weight-bold '>Delivering to</h5>
							<NavLink to="/checkout" className='f-Poppins-Medium font-weight-bold float-end'>Edit</NavLink>
						</div>

						<div className='row'>
							<div className='col-md-6 col-12 '>

								<p className='pt-1 fw-normal'>
									<span className=' '>Name :</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold '>{billingaddress?.name}</span>
								</p>

								<p className='pt-1 fw-normal'>
									<span className=' '>Phone Number:</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold'>{billingaddress?.phone_number}</span>
								</p>
								<p className='pt-1 fw-normal'>
									<span className=' '>Email :</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold'>{billingaddress?.email}</span>
								</p>
							</div>
							<div className='col-md-6 col-12'>
								<p className='pt-1 fw-normal'>
									<span className=' '>Compnay Name :</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold'> {billingaddress?.company_name} </span>
								</p>
								<p className='pt-1 fw-normal'>
									<span className=' '>Gst Number:</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold'>{billingaddress?.gst_number}</span>
								</p>
							</div>
							<div className='col-md-6 col-12'>
								<p className='pt-1 fw-normal'>
									<span className=' '> Address :</span>
									<span className='f-Poppins-Light f-1 ps-1 fw-bold'> {billingaddress?.address_line1 + ' ' + (billingaddress?.address_line2 != null ? billingaddress?.address_line2 : '') }</span>
								</p>
							</div>
						</div>
						<div className='border-bottom-dotted mt-5 mb-5'></div>
						<div className='row'>
							<div class='form-check col-md-7 col-12 mt-1'>
								<input
									class='form-check-input'
									type='checkbox'
									value=''
									id='flexCheckChecked'
									checked
								/>
								<label class='form-check-label' for='flexCheckChecked'>
									I have read and agree to the website{' '}
									<span className='text-primary'> terms and conditions*</span>
								</label>
							</div>
							<div className='col-md-5 col-md-4 col-12 mb-4 text-end '>
								<button
									className='btn-primary     py-1 rounded-4 w-50'
									onClick={handlePaymentInformation}
								>
									{loading ? <Loading></Loading> : 'Proceed to Payment'}
								</button>
							</div>
						</div>
					</div>
				</div>

				{/* sidebar */}
				<div className='col-lg-3 pt-2 pb-2'>
					<div>
						<ProfileName />
						<ActionButtons />
						<Company></Company>
					</div>
				</div>
			</div>
		</div>
	);
}

export default PaymentInformation;
