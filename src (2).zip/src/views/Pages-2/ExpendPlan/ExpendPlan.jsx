import React, { useEffect, useState } from 'react';
import IntroSideBar from '../../../components/SelectPlan/introSide';
import { Link, NavLink } from 'react-router-dom';
import FeatureCard from '../../../components/ExpendPlan/FeatureCard';
import { END_POINT, Get_feature } from '../../../routes/api_routes';
import { useSelector } from 'react-redux';
import { notification } from '../../../classes/messages';
import { getLoggedInUser } from '../../../classes';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import { getCurrPlanFeatures } from '../../../store/actions/Plans';

const ExpendPlan = ({ match, history }) => {
	const [features, setFeatures] = useState([]);
	const [totalPrice, setTotalPrice] = useState(0);
	const [ISUpgrade, setISUpgrade] = useState(false);
	const [CurrPlanFeatures, setCurrPlanFeatures] = useState([]);
	const { SelectedFeature } = useSelector((state) => state.common);
	let [plan, setPlan] = useState({});

	useEffect(async () => {

		const localPlan = JSON.parse(localStorage.getItem('PLAN'));
		setPlan(localPlan);
		const user = await getLoggedInUser();
		if (user.user_type !== Recruiter_User_Type_ID) {
			history.push('/');
		}

		if (match.params?.current) {
			setISUpgrade(true);
			let fmdata = new FormData();
			fmdata.append('plan_id', match.params?.id);
			fmdata.append('user_id', user.id);
			let curr = await getCurrPlanFeatures(fmdata);

			if (curr.status == 'success') {
				setCurrPlanFeatures(JSON.parse(curr?.data));
			}
		}






		const response = await fetch(END_POINT + `${Get_feature}/${match.params.id}`);
		const json = await response.json();
		setFeatures(json.data);
	}, []);

	useEffect(() => {
		let newFeature = features.map((feature) => {
			if (feature.feature_id == SelectedFeature.feature_id) {
				return {
					...feature,
					selectedPriceIndex: SelectedFeature.selectedPriceIndex,
				};
			} else {
				let index = feature.selectedPriceIndex == undefined ? 0 : feature.selectedPriceIndex;
				return {
					...feature,
					selectedPriceIndex: index,
				};
			}
		});
		setFeatures(newFeature);
	}, [SelectedFeature]);

	useEffect(() => {
		let totalPrice =
			features.length >= 1 &&
			features.reduce((acc, current) => {
				let index = current.selectedPriceIndex == undefined ? 0 : current.selectedPriceIndex;
				if (current.pricing[index].price !== 'free') {
					return acc + Number(current.pricing[index].price);
				}
				return acc;
			}, 0);
		setTotalPrice(totalPrice);
	}, [features]);

	const onCheckout = async () => {
		const user = await getLoggedInUser();
		const featuresToSend = features.map((feature) => {
			const index = !feature.hasOwnProperty('selectedPriceIndex')
				? 0
				: feature.selectedPriceIndex;
			return {
				feature_id: feature.feature_id,
				feature_title: feature.feature_name,
				quantity: feature.pricing[index].max_range,
				ammount: feature.pricing[index].price,
			};
		});

		const formdata = new FormData();
		formdata.append('user_id', user.id);
		if (ISUpgrade)
			formdata.append('plan_id', match.params?.id);
		else
			formdata.append('plan_id', plan.id);
		formdata.append('amount', totalPrice);
		formdata.append('payment_status', '1');
		formdata.append('json_data', JSON.stringify(featuresToSend));

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
		};

		fetch(END_POINT + 'select_plan', requestOptions)
			.then((response) => response.json())
			.then((data) => {

				if (data.status == 'success') {
					console.log(data, 'dfsdfsdf');
					localStorage.setItem('plan_temp_id', data.data.temp_id);
					localStorage.setItem('selected_plan_id', data.data.id?.id);
					const notify = notification({ message: data.message, type: 'success' });
					notify();
					localStorage.setItem('PLAN_TOTAL_PRICE', totalPrice);
					/* save address */
					localStorage.setItem('BILLING-ADRESS', JSON.stringify(data.data?.billing_address));
					history.push('/checkout');
					/* save address */


				} else {
					data.message.forEach((e) => {
						const notify = notification({ message: e, type: 'error' });
						notify();
					});
				}
			})
			.catch((error) => { });
	};

	return (
		<div className='pe-lg-7 px-lg-0 px-md-8 px-sm-5 px-3 mt-26px'>
			<div className='row'>
				<div className='col-lg-4'>
					<div className>
						<IntroSideBar></IntroSideBar>
					</div>
				</div>
				<div className='col-lg-8 my-lg-0 my-4 ps-lg-5 pb-6'>
					<div className='bg-light-blue vh- bg-no-repeat bg-40-size'>
						<header className='d-flex justify-content-between mb-4'>
							<h4>Select Features to Expand</h4>
							<NavLink to='/plans' class='h5'>
								Select Plan
							</NavLink>
						</header>
						<div className='row'>
							<div className='row'>
								{features &&
									features.map((feature, i) => {
										return (
											<FeatureCard index={i} featuresArray={features} feature={feature} currentPlanFeature={CurrPlanFeatures[i]} ISUpgrade={ISUpgrade} />
										);
									})}
							</div>
						</div>
						<footer className='d-flex justify-content-between align-items-center mt-3'>
							<h4 className='text-primary fw-bold d-flex'>
								Total Ammount: <h6 className='ms-1'>₹</h6> {totalPrice}
							</h4>
							<button
								className='btn btn-primary'
								onClick={() => {
									onCheckout();
								}}
							>
								Proceed To Checkout
							</button>
						</footer>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ExpendPlan;
