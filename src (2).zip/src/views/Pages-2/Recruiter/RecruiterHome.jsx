import React, { useEffect } from 'react';
import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Jobs from '../../../components/Recruiter/Jobs';
import Quiz from '../../../components/Recruiter/Quiz';
import Questions from '../../../components/Recruiter/Questions';
import Testimonial from '../../../components/Recruiter/Testimonial';
import OfferLetters from '../../../components/Recruiter/OfferLetters';
import Members from '../../../components/Recruiter/Members';
import { Route, useHistory } from 'react-router';
import { NavLink } from 'react-router-dom';
import LetterOfIntent from '../../../components/Recruiter/LetterOfIntent';

const RecruiterHome = ({ match }) => {
	const history = useHistory();
	return (
		<div className='main-container position-relative'>
			<div className='container'>
				<div className='row gx-5'>
					<div className='col-lg-9'>
						<RecruiterHomeCard> </RecruiterHomeCard>
						<div className='bg-white mt-5 rounded-5 pt-3 pb-4  ps-4 pe-4'>
							<div className='row'>
								<div className='col-md-12 '>
									{/* Tabs */}
									<ul class='nav border-bottom py-1'>
										<li class='nav-item'>
											<NavLink className={`nav-link fs-20 px-0 me-5`} to='/recruiter' exact>
												Jobs
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/quiz'
												exact
											>
												Quiz
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/questions'
												exact
											>
												Questions
											</NavLink>
										</li>
										{/* <li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/testimonials'
												exact
											>
												Testimonials
											</NavLink>
										</li> */}
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/loi'
												exact
											>
												Letter of Intent
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5 `}
												to='/recruiter/offer-letters'
												exact
											>
												Offer Letters
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5 `}
												to='/recruiter/members'
												exact
											>
												Members
											</NavLink>
										</li>
									</ul>
								</div>

								<Route exact path='/recruiter' component={Jobs} />
								<Route path='/recruiter/quiz' component={Quiz} />
								<Route path='/recruiter/questions' component={Questions} />
								<Route path='/recruiter/loi' component={LetterOfIntent} />
								{/* <Route path='/recruiter/testimonials' component={Testimonial} /> */}
								<Route path='/recruiter/members' component={Members} />
								<Route path='/recruiter/offer-letters' component={OfferLetters} />
							</div>
						</div>
					</div>

					<div className='col-lg-3 pt-2 pb-2'>
						<ProfileName />
						<ActionButtons />
						<Company></Company>
					</div>
					{/* Sidebar */}
				</div>
			</div>
		</div>
	);
};

export default RecruiterHome;
