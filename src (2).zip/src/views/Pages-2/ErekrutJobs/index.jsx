import React, { Component } from 'react';
import { RouteWithSubRoutes } from '../../../classes';
import { Route, Switch } from 'react-router';
import { ErekrutJobsNestedRoutes } from '../../../routes/routes';

export default class index extends Component {
	render() {
		return (
			<div>
				<h1>erekrut jobs</h1>
			</div>
		);
	}
}
