import React, { useState, useEffect } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link, NavLink } from 'react-router-dom';
import { useHistory } from 'react-router';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import { getLoggedInUser } from '../../../classes';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { ADD_BILLING_DETAILS, END_POINT } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import { routePushed } from '../../../classes/browserHistory';

const CheckOut = (props) => {
	let [address, setAddress] = useState([]);

	let [totalPrice, setTotalPrice] = useState(0);
	let [plan, setPlan] = useState({});

	const [isSelected, setisSelected] = useState(null);
	const [selectedAddress, setSelectedAddress] = useState(null);

	const history = useHistory();

	useEffect(async () => {
		const user = await getLoggedInUser();
		if (user.user_type !== Recruiter_User_Type_ID) {
			// history.push('/');
		}

		const localPlan = JSON.parse(localStorage.getItem('PLAN'));
		const totalPrice = localStorage.getItem('PLAN_TOTAL_PRICE');
		setTotalPrice(totalPrice);
		setPlan(localPlan);

		const newAddress = JSON.parse(localStorage.getItem('BILLING-ADRESS'));
		if (newAddress) {
			setAddress(newAddress);
			selectAddress(newAddress[0])
		}
	}, []);

	const proceedToPayment = (e) => {
		
		if (selectedAddress) {
			let formdata = new FormData();
			formdata.append('billing_id', selectedAddress.id);
			formdata.append('selected_plan_id', plan?.id);

			var requestOptions = {
				method: 'POST',
				body: formdata,
				redirect: 'follow',
			};

			fetch(END_POINT + ADD_BILLING_DETAILS, requestOptions)
				.then((response) => response.json())
				.then((data) => {
					if (data.status == 'success') {
						localStorage.setItem('SELECTED-BILLING-ADDRESS', JSON.stringify(selectedAddress));
						history.push('/payment-information');
					} else {
						data.message.forEach((e) => {
							const notify = notification({ message: e, type: 'error' });
							notify();
						});
					}
				})
				.catch((error) => { });
		}

	}

	const selectAddress = (address) => {
		console.log(address);
		if (address) {
			setSelectedAddress(address);
			setisSelected(address.id);
		}

	}

	return (
		<Section>
			<Main>
				<section className='bg-white py-2 rounded-3'>
					<h4>Billing Details</h4>
					<section className='row my-4'>
						{address.length >= 1 &&
							address.map((address, i) => {
								let odd = i % 2 === 0;
								return (
									<div className={`col-md-5 col-12 mb-3 p-3 me-2 cursor  rounded ${isSelected == address.id ? 'bg-primary text-white' : 'border border-primary'
										}`} onClick={(e) => { selectAddress(address) }}>
										<div>
											<div className='d-flex mb-2 justify-content-between align-items-center'>
												<h5 className='d-flex justify-content-between'>Address {i + 1}</h5>
												<Link
													to='/billing-details'
													className={`btn btn-sm ${odd ? 'text-light' : 'text-dark'}`}
												>
													<i class='las la-edit h3'></i>
												</Link>
											</div>
											<p className='my-2'>
												<span className='fw-bold'>Company Name:</span> {address.company_name}
											</p>
											<p>
												<span className='fw-bold'>Address:</span> {address.address_line1}
											</p>
											<p>
												<span className='fw-bold'>Phone:</span> {address.phone_number}
											</p>
										</div>
									</div>
								);
							})}

						<div className='col-md-5 col-12 mb-3 border-blue rounded d-flex justify-content-center align-items-center cursor' onClick={(e) => { routePushed('/billing-details', props) }}>
							<h5 className='text-primary'>Add New Address +</h5>
						</div>
					</section>

					<div className='border-bottom-dotted h-1px mb-4'></div>


				</section>
				<section className='mt-5 rounded-3'>
					<h4 className='d-flex justify-content-between  mb-4'>Your Order</h4>
					<div className='d-flex justify-content-between mb-1'>
						<p>{plan?.name} Plan</p>
						<p>&#8377; {plan?.price}</p>
					</div>
					<div className='d-flex justify-content-between mb-1'>
						<p>Expansion Pack</p>
						<p>&#8377; 0</p>
					</div>
					<div className='border-bottom-dotted h-1px my-2'></div>
					<div className='d-flex justify-content-between'>
						<p>Sub total</p>
						<p>&#8377; {totalPrice}</p>
					</div>
					<div className='d-flex justify-content-between'>
						<p>Promocode Discount 10%</p>
						<p>&#8377; 0</p>
					</div>
					<div className='border-bottom-dotted h-1px my-2'></div>
					<div className='d-flex justify-content-between fw-bolder'>
						<h5>Total</h5>
						<h5>&#8377; {totalPrice} </h5>
					</div>
					<div class='text-end mt-5'>
						<button onClick={(e) => proceedToPayment(e)} class='btn btn-primary px-5' disabled={(isSelected == null) ? true : false}>
							Proceed to Payment
						</button>
					</div>
				</section>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default CheckOut;
