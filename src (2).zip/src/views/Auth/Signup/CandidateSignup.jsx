import React, { Component } from 'react';
import cloneDeep from 'lodash/cloneDeep';
import Step1 from '../../../components/CandidateSignup/Step1';
import Step2 from '../../../components/CandidateSignup/Step2';
import Step3 from '../../../components/CandidateSignup/Step3';

import { validateOTPSignup, submitSignup, getSignupOTP } from '../../../store/actions/signup';

import { Candidate_User_Type_ID } from '../../../config/constants';

import { connect } from 'react-redux';

import { notification } from '../../../classes/messages';

import { routeChanged } from '../../../classes/browserHistory';
import { APP_Prefix } from '../../../config/constants';

import { validation } from '../../../classes/validation';
import { resendOTP } from '../../../store/actions/otp';

class CandidateSignup extends Component {
	state = {
		step: 1,
		email: '',
		password: '',
		confirmPassword: '',
		otp: '',
		otp_id: '',
		user_id: '',
		token: '',
		formDataField: null,
		step3: { user_type: Candidate_User_Type_ID },
		errors: { step1: {}, step2: {}, step3: {} },
		user_type: Candidate_User_Type_ID
	};

	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
	}

	nextStep = () => {
		const step = this.state.step;
		this.setState({
			step: step + 1,
		});
	};

	prevStep = () => {
		const step = this.state.step;
		this.setState({
			step: step - 1,
		});
	};

	// Handle fields change
	handleChange = (e, regex = '', type = '') => {
		const that = this;

		if (e.target) {
			let ivalue = e.target.value;
			let iname = e.target.name;

			if (type == 'dynamic') {
				//this.state.step3[iname] = ivalue;
				this.setState({
					step3: { ...that.state.step3, [iname]: ivalue },
				});
				if(e.target.type == "file"){
					this.setState({
						step3: { ...that.state.step3, [iname]: e.target.files },
					});
				}
			} else {
				this.setState({ [iname]: ivalue }, () => {
					console.log(that.state);

					if (type == 'confirm_password') {
						that.validateConfPass();
					}
				});
			}
		}
	};

	validateConfPass = () => {
		const that = this;

		if (this.state.password != this.state.confirmPassword) {
			let error = { confirmPassword: 'Please confirm password' };

			this.setState({
				errors: { ...that.state.errors, step1: error },
			});
		} else {
			this.setState({
				errors: { ...that.state.errors, step1: { confirmPassword: '' } },
			});
		}
	};

	handleSubmit = async () => {
		
		let notify;
		/*send data to server*/
		let step3Data = cloneDeep(this.state.step3);
		console.log(step3Data);
		
		step3Data['user_id'] = this.state.user_id;
		
		await this.props.submitSignup(step3Data);

		console.log(this.props.data);

		if (this.props.data?.status == 'success') {

			routeChanged('/login', this.props);
			notify = notification({ message: 'Signup Successful...', type: 'success' });
		} else {
			notify = notification({ message: this.props.data ? JSON.stringify(this.props.data.message).replace(/"/g, '').replace(/]/g, '').replace(/\[/g, '') : '', type: 'error' });
		}
		/*send data to server*/

		notify();

	};

	/** Signup **/

	signup = async () => {

		let notify;
		let passRes = validation({ type: 'password', value: this.state.password, message: 'Invalid Password' });
		if (this.state.password == this.state.confirmPassword && passRes['error'] != 1) {
			let formData = {};
			formData['text'] = this.state.email;
			formData['password'] = this.state.password;
			formData['user_type'] = Candidate_User_Type_ID;

			await this.props.getSignupOTP(formData);

			let otpResp = this.props.data;

			if (otpResp.status === 'success') {

				notify = notification({ message: otpResp.message, type: 'success' });

				alert(otpResp.data.otp);

				this.setState({
					otp_id: otpResp.data.otp_id,
					//otp: otpResp.data.otp,
					user_id: otpResp.data.user_id,
				});

				this.nextStep();
			} else {
				notify = notification({ message: JSON.stringify(otpResp.message), type: 'error' });
			}

		} else {
			notify = notification({ message: passRes['error'] ? passRes['message'] : 'Please confirm password.', type: 'error' });
		}

		notify();
	};

	/** Validate OTP **/
	validateOtpSignup = async () => {

		let notify;

		if (this.state.otp) {
			let formData = new FormData();
			formData.append('text', this.state.email);
			formData.append('otp', this.state.otp);
			formData.append('otp_id', this.state.otp_id);
			formData.append('user_type', this.state.user_type);

			//this.state.otpFrmData = formData;
			await this.props.validateOTPSignup(formData)

			let jsonres = this.props.data;

			if (jsonres.status == "success") {
				document.cookie = "id= " + jsonres.data.id;
				document.cookie = "token= " + jsonres.data.token;
				this.setState({ id: jsonres.data.id, token: jsonres.data.token });
				this.state.formDataField = jsonres.data.attributes;

				notify = notification({ message: 'OTP Confirmed', type: 'success' });
				this.nextStep();
			}
			else {
				notify = notification({ message: JSON.stringify(jsonres.message), type: 'error' });
			}
		} else {
			notify = notification({ message: 'Please Enter OTP', type: 'error' });
		}

		notify();

	}
	/* validate otp */

	/*try signup */
	trySignup = async () => {
		const { email, password } = this.state;
		await this.signup();
	};

	/**try validate**/

	tryValidate = async () => {
		await this.validateOtpSignup();
	};

	/*render*/
	componentDidMount() {
		let authToken = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_token'));
		if (authToken) {
			this.props.history.push('/');
		}
	}

	/* resend otp */
	resendOTP = async () => {

		let data = { otp_id: this.state.otp_id, text: this.state.email };

		await this.props.resendOTP(data);

		let notify;

		let json = this.props.data;

		if (json.status === 'success') {

			alert(json.data.otp);

			notify = notification({ message: json.message, type: 'success' });
		} else {
			notify = notification({ message: JSON.stringify(json.message), type: 'error' });
		}

		notify();

	}
	/* resend otp */

	render() {
		const { formDataField } = this.state;

		return (
			<div>
				{this.state.step == 1 && (
					<Step1
						nextStep={this.nextStep}
						prevStep={this.prevStep}
						handleChange={this.handleChange}
						trySignup={this.trySignup}
						errors={this.state.errors.step1}
						props={this.props}
					/>
				)}

				{this.state.step == 2 && (
					<Step2
						nextStep={this.nextStep}
						prevStep={this.prevStep}
						handleChange={this.handleChange}
						tryValidate={this.tryValidate}
						resendOTP={this.resendOTP}
					/>
				)}

				{this.state.step == 3 && (
					<Step3
						nextStep={this.nextStep}
						prevStep={this.prevStep}
						handleChange={this.handleChange}
						formDataField={formDataField}
						handleSubmit={this.handleSubmit}
						currentStateData={this.state.step3}
					/>
				)}
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { data } = state.common;
	return {
		data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		validateOTPSignup: (formData) => dispatch(validateOTPSignup(formData)),
		submitSignup: (step3Data) => dispatch(submitSignup(step3Data)),
		resendOTP: (data) => dispatch(resendOTP(data)),
		getSignupOTP: (formData) => dispatch(getSignupOTP(formData))
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(CandidateSignup);
