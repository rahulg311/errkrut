import React, { Component } from 'react';
import Step1 from '../../../components/RecruiterSignup/Step1';
import Step2 from '../../../components/RecruiterSignup/Step2';
import Step3 from '../../../components/RecruiterSignup/Step3';
import { validation } from '../../../classes/validation';
import { APP_Prefix, FILES_SELECTED } from '../../../config/constants';

import { notification } from '../../../classes/messages';

import { validateOTPSignup, submitSignup, getSignupOTP } from '../../../store/actions/signup';

import { Campus_User_Type_ID } from '../../../config/constants';

import { connect } from "react-redux";

import { routeChanged } from '../../../classes/browserHistory';
import { resendOTP } from '../../../store/actions/otp';

class CampusSignup extends Component {

    errors = [];

    state = {
        step: 1,
        email: '',
        password: '',
        confirmPassword: '',
        step3: { user_type: Campus_User_Type_ID },
        otp: "",
        otp_id: "",
        user_id: "",
        token: "",
        user_type: Campus_User_Type_ID,
        formDataField: null,
        comp_category_res: null
    };

    constructor(props) {
        super(props);
    }

    nextStep = () => {
        const step = this.state.step;
        this.setState({
            step: step + 1,
        });
    };

    /* Step 1 */
    step1 = async () => {
        await this.completeStep1();
    }
    /* Step 1 */

    /* complete step 1 */
    completeStep1 = async () => {

        let notify;
        let passRes = validation({ type: 'password', value: this.state.password, message: 'Invalid Password' });
        if (this.state.password == this.state.confirmPassword && passRes['error'] != 1) {

            let formData = { 'text': this.state.email, 'password': this.state.password, 'user_type': this.state.user_type };

            await this.props.getSignupOTP(formData);

            let otpRes = this.props.data;

            if (otpRes.status == 'success') {

                notify = notification({ message: otpRes.message, type: 'success' });

                alert(otpRes.data.otp);

                this.setState({
                    otp_id: otpRes.data.otp_id,
                    //otp: otpRes.data.otp,
                    user_id: otpRes.data.user_id
                });

                this.nextStep();

            } else {

                notify = notification({ message: JSON.stringify(otpRes.message).replace(/"/g, '').replace(/]/g, '').replace(/\[/g, ''), type: 'error' });

            }

        } else {
            notify = notification({ message: passRes['error'] ? passRes['message'] : 'Please confirm password.', type: 'error' });
        }

        notify();

    }
    /* complete step 1 */

    prevStep = () => {
        const step = this.state.step;
        this.setState({
            step: step - 1,
        });
    };

    // Handle fields change
    handleChange = (e, regex = '', type = '') => {

        const { dispatch } = this.props;

        const that = this;

        if (e.target) {

            let ivalue = e.target.value;
            let iname = e.target.name;
            let ftype = e.target.type;

            if (ftype == 'file') {
                if (e.target.files.length > 0) {
                    ivalue = e.target.files;
                }
            }

            if (type == 'dynamic') {

                //this.state.step3[iname] = ivalue;

                this.setState({
                    step3: { ...that.state.step3, [iname]: ivalue }
                });

            } else {
                //this.setState({ [iname]: ivalue });

                this.setState({ [iname]: ivalue }, () => {

                    //that.validate(valiObj);

                });
            }

        }

    };


    /* validate object */
    validate(valiObj) {

        if (valiObj.type == 'confirm_password') {

            console.log(this.state.password);
            console.log(this.state.confirmPassword);

            if (this.state.password != this.state.confirmPassword) {

                this.errors['confirmPassword'] = 'Please confirm password';
                //this.setState({...that.state.errors, ['confirmPassword']: '' });

                console.log(this.errors);

            } else {
                //this.setState({...that.state.errors, ['confirmPassword']: '' });
                //this.errors['confirmPassword'] = '';
            }
        }

        let valiRes = validation(valiObj);

        console.log(valiRes);
        if (valiRes.error == 1) {
            this.errors[valiObj.name] = valiRes.message;
            //this.setState({...that.state.errors, [iname]: valiRes.message });
        } else {
            this.errors[valiObj.name] = '';
            //this.setState({...that.state.errors, [iname]: '' });
        }
    }


    /** Validate OTP **/
    validateOtpSignup = async () => {

        let notify;

        if (this.state.otp) {
            let formData = new FormData();
            formData.append('text', this.state.email);
            formData.append('otp', this.state.otp);
            formData.append('otp_id', this.state.otp_id);
            formData.append('user_type', this.state.user_type);

            //this.state.otpFrmData = formData;
            await this.props.validateOTPSignup(formData)

            let jsonres = this.props.data;

            if (jsonres.status == "success") {
                document.cookie = "id= " + jsonres.data.id;
                document.cookie = "token= " + jsonres.data.token;
                this.setState({ id: jsonres.data.id, token: jsonres.data.token });
                this.setState({ formDataField: jsonres.data.attributes });

                notify = notification({ message: 'OTP Confirmed', type: 'success' });
                this.nextStep();
            }
            else {
                notify = notification({ message: JSON.stringify(jsonres.message), type: 'error' });
            }
        } else {
            notify = notification({ message: 'Please Enter OTP', type: 'error' });
        }

        notify();

    }
    /* validate otp */

    tryValidate = async () => {
        await this.validateOtpSignup();
    }

    handleSubmit = async () => {

        let notify;

        /*send data to server*/
        let step3Data = this.state.step3;
        step3Data['user_id'] = this.state.user_id;
        await this.props.submitSignup(step3Data);
        let json = this.props.data;
        if (json?.status == 'success') {
            routeChanged('/login', this.props);
            notify = notification({ message: 'Signup Successful...', type: 'success' });
        } else {
            notify = notification({ message: JSON.stringify(json.message).replace(/"/g, '').replace(/]/g, '').replace(/\[/g, ''), type: 'error' });
        }
        /*send data to server*/
        notify();

    }


    /* resend otp */
    resendOTP = async () => {

        let data = { otp_id: this.state.otp_id, text: this.state.email };

        await this.props.resendOTP(data);

        let notify;

        let json = this.props.data;

        if (json.status === 'success') {

            alert(json.data.otp);

            notify = notification({ message: json.message, type: 'success' });
        } else {
            notify = notification({ message: JSON.stringify(json.message), type: 'error' });
        }

        notify();

    }
    /* resend otp */


    render() {

        const { formDataField } = this.state;

        return (
            <div>

                {this.state.step == 1 && (
                    <Step1
                        userType={this.state.user_type}
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                        handleChange={this.handleChange}
                        step1={this.step1}
                        props={this.props}

                    />
                )}

                {this.state.step == 2 && (
                    <Step2
                        userType={this.state.user_type}
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                        handleChange={this.handleChange}
                        tryValidate={this.tryValidate}
                        resendOTP={this.resendOTP}
                    />
                )}

                {this.state.step == 3 && (
                    <Step3
                        userType={this.state.user_type}
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                        handleChange={this.handleChange}
                        handleSubmit={this.handleSubmit}
                        formDataField={formDataField}
                        currentStateData={this.state.step3}
                    />
                )}

            </div>

        );
    }

}

const mapStateToProps = (state) => {
    const { data, comp_category_res } = state.common
    return {
        data,
        comp_category_res
    }
};

function mapDispatchToProps(dispatch) {
    return {
        validateOTPSignup: (formData) => dispatch(validateOTPSignup(formData)),
        submitSignup: (step3Data) => dispatch(submitSignup(step3Data)),
        resendOTP: (data) => dispatch(resendOTP(data)),
        getSignupOTP: (formData) => dispatch(getSignupOTP(formData))
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CampusSignup);