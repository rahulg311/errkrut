import React from "react";

import IntroStep1 from '../../../components/Intros/Signup/IntroStep1';

import { validation } from '../../../classes/validation';

import { notification } from '../../../classes/messages';

import { forgot_password, validateOTP, change_password } from '../../../store/actions/forgotPassword';

import { connect } from "react-redux";

import ForgotPasswordStep1 from '../../../components/Login/ForgotPasswordStep1';
import ForgotPasswordStep2 from '../../../components/Login/ForgotPasswordStep2';
import ForgotPasswordStep3 from '../../../components/Login/ForgotPasswordStep3';

import { routeChanged } from '../../../classes/browserHistory';

import { APP_Prefix } from '../../../config/constants';
import { errorPrettify, setLoggedInToken, setLoggedInUser } from "../../../classes";

class ForgotPassword extends React.Component {

    state = {
        step: 1,
        email: '',
        password: '',
        otp: '',
        otp_id: '',
        user_id: '', 
        password_hash: '',  
        new_password: '', 
        confirm_password: '',
        errors: {}
    }

    nextStep = () => {
        const step = this.state.step;

        console.log(this.step);

        //if (this.errors.length == 0) {
        this.setState({
            step: step + 1,
        });
        //}

    };

    prevStep = () => {
        const step = this.state.step;
        this.setState({
            step: step - 1,
        });
    };



    // Handle fields change
    handleChange = (e) => {

        if (e.target) {

            let ivalue = e.target.value;
            let iname = e.target.name;

            this.setState({ [iname]: ivalue }, () => {

                console.log(this.state);

            });

        }

    };

    handleValidation() {
        
        let errors = {};
        let formIsValid = true;

        let valiRes = validation({ type: 'emailormobile', value: this.state.email, message: 'Invalid Email or Mobile' });

        //email
        if (valiRes['error'] == 1) {
            formIsValid = false;
            errors["email"] = valiRes['message'];
        }

        return formIsValid;

    }

    stepOne_handler = async () => {

        console.log(this.state);

        if (this.handleValidation()) {

            let sendData = { text: this.state.email };

            await this.props.forgot_password(sendData);

            let res = this.props.data;

            console.log(res);

            if (res?.status == 'success') {
                alert(res.data.otp)

                this.setState({ ['otp_id']: res.data.otp_id });

                let notify = notification({ message: res.message, type: 'success' });
                notify();

                this.nextStep();
            } else {
                let notify = notification({ message: res.message, type: 'error' });
                notify();
            }

        }

    }

    tryValidate = async () => {

        let otpData = { text: this.state.email, otp_id: this.state.otp_id, otp: this.state.otp, password_otp: 1  };

        await this.props.validateOTP(otpData);

        let res = this.props.data;

        console.log(res);

        if (res.status == 'success') {

            this.setState({ 'user_id': res.data.user_id, 'password_hash': res.data.password_hash  });

            let notify = notification({ message: res.message, type: 'success' });
            notify();

            this.nextStep();
        } else {
            let notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            notify();
        }
    }

    changePassword_handler = async () => {
        let pwdData = { user_id: this.state.user_id, password_hash: this.state.password_hash, new_password : this.state.new_password, confirm_password : this.state.confirm_password };
        
        await this.props.change_password(pwdData);

        let res = this.props.data;

        if (res.status == 'success') {
            let notify = notification({ message: res.message, type: 'success' });
            notify();

            setTimeout(() => {
                this.props.history.push('/login');
            }, 1000);
        }else{
            let notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            notify();
        }

    }


    componentDidMount() {
       
    }


    /* resend otp */
    resendOTP = async () => {

        let sendData = { text: this.state.email };

        await this.props.forgot_password(sendData);

        let notify;

        let res = this.props.data;
        
        if (res?.status == 'success') {
            alert(res.data.otp)

            this.setState({ ['otp_id']: res.data.otp_id });

            let notify = notification({ message: res.message, type: 'success' });
            notify();
            
        } else {
            let notify = notification({ message: res.message, type: 'error' });
            notify();
        }

    }
    /* resend otp */

    render() {
        return <>
            <div className="container vh-100">

                <div className="row">
                    <div className="col-md-6 p-0">
                        <IntroStep1></IntroStep1>
                    </div>
                    <div className="col-md-6 p-0">
                        <div className="bg-light-blue vh-100 bg-no-repeat bg-40-size" style={{ backgroundImage: process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-right.png')", backgroundPosition: "bottom right" }}>
                            <div className="pt-5 pb-5 pl-2 pr-6 w-65 ms-auto me-auto vh-100">

                                <ul>
                                    {Object.keys(this.state.errors).map((k, v) => <li className="text-danger">{this.state.errors[k]}</li>)}
                                </ul>

                                {this.state.step == 1 && (
                                    <ForgotPasswordStep1
                                        prevStep={this.prevStep}
                                        handleChange={this.handleChange}
                                        step1={this.step1}
                                        stepOne_handler={this.stepOne_handler}
                                    />
                                )}

                                {this.state.step == 2 && (
                                    <ForgotPasswordStep2
                                        prevStep={this.prevStep}
                                        handleChange={this.handleChange}
                                        tryValidate={this.tryValidate}
                                        resendOTP = {this.resendOTP}
                                    />
                                )}

                                {this.state.step == 3 && (
                                    <ForgotPasswordStep3
                                        prevStep={this.prevStep}
                                        handleChange={this.handleChange}
                                        changePassword_handler={this.changePassword_handler}
                                    />
                                )}


                            </div>
                        </div>
                    </div>
                </div>

            </div >
        </>;
    }
}

const mapStateToProps = (state) => {
    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        validateOTP: (otpData) => dispatch(validateOTP(otpData)),
        forgot_password: (sendData) => dispatch(forgot_password(sendData)),
        change_password: (pwdData) => dispatch(change_password(pwdData))
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);