import React from "react";

import IntroStep1 from '../../../components/Intros/Signup/IntroStep1';

import { validation } from '../../../classes/validation';

import { notification } from '../../../classes/messages';

import { login, validateOTP } from '../../../store/actions/login';

import { connect } from "react-redux";

import Step1 from '../../../components/Login/Step1';

import Step2 from '../../../components/Login/Step2';

import { routeChanged } from '../../../classes/browserHistory';

import { APP_Prefix } from '../../../config/constants';
import { resendOTP } from "../../../store/actions/otp";
import { errorPrettify, setLoggedInToken, setLoggedInUser } from "../../../classes";

class Login extends React.Component {

    state = {
        step: 1,
        email: '',
        password: '',
        otp: '',
        otp_id: '',
        errors: {}
    }

    nextStep = () => {
        const step = this.state.step;

        console.log(this.step);

        //if (this.errors.length == 0) {
        this.setState({
            step: step + 1,
        });
        //}

    };

    prevStep = () => {
        const step = this.state.step;
        this.setState({
            step: step - 1,
        });
    };



    // Handle fields change
    handleChange = (e) => {

        if (e.target) {

            let ivalue = e.target.value;
            let iname = e.target.name;

            this.setState({ [iname]: ivalue }, () => {

                console.log(this.state);

            });

        }

    };

    handleValidation() {
        let errors = {};
        let formIsValid = true;

        let valiRes = validation({ type: 'emailormobile', value: this.state.email, message: 'Invalid Email or Mobile' });

        //email
        if (valiRes['error'] == 1) {
            formIsValid = false;
            errors["email"] = valiRes['message'];
        }

        let passRes = validation({ type: 'password', value: this.state.password, message: 'Invalid Password' });

        //password
        if (passRes['error'] == 1) {
            formIsValid = false;
            errors["password"] = passRes['message'];
        }

        this.setState({ errors: errors });

        return formIsValid;

    }

    loginUser = async () => {

        console.log(this.state);

        if (this.handleValidation()) {

            let loginData = { text: this.state.email, password: this.state.password };

            await this.props.login(loginData);

            let res = this.props.data;

            console.log(res);

            if (res?.status == 'success') {
                alert(res.data.otp)

                this.setState({ ['otp_id']: res.data.otp_id });

                let notify = notification({ message: res.message, type: 'success' });
                notify();

                this.nextStep();
            } else {
                let notify = notification({ message: res.message, type: 'error' });
                notify();
            }

        }

    }

    tryValidate = async () => {

        let otpData = { text: this.state.email, otp_id: this.state.otp_id, otp: this.state.otp, user_type: 1 };

        await this.props.validateOTP(otpData);

        let res = this.props.data;

        console.log(res);

        if (res.status == 'success') {

            let auth_profile = {
                name: res.data.name,
                email: res.data.email,
                mobile: res.data.mobile,
                id: res.data.id,
                company_id: res.data.company_id,
                user_type: res.data.user_type,
                plan_id: res.data.plan_id,
                company_name: res.data.company_name,
                logo: res.data.logo,
                recruitment_agency: res.data.recruitment_agency
            };

            console.log(auth_profile);

            setLoggedInUser(auth_profile);

            setLoggedInToken(res?.data?.token);

            /* login token storage */

            let notify = notification({ message: res.message, type: 'success' });
            notify();

            routeChanged('/', this.props, 1);


        } else {
            let notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            notify();
        }


    }

    componentDidMount() {
        let authToken = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_token'));
        if (authToken) {
            this.props.history.push('/');
        }
    }


    /* resend otp */
    resendOTP = async () => {

        let data = { otp_id: this.state.otp_id, text: this.state.email };

        await this.props.resendOTP(data);

        let notify;

        let json = this.props.data;
        console.log(json, "goldy")
        if (json.status === 'success') {

            alert(json.data.otp);

            notify = notification({ message: json.message, type: 'success' });
        } else {
            notify = notification({ message: errorPrettify(json.message), type: 'error' });
        }

        notify();

    }
    /* resend otp */

    render() {
        return <>
            <div className="container vh-100">

                <div className="row">
                    <div className="col-md-6 p-0">
                        <IntroStep1></IntroStep1>
                    </div>
                    <div className="col-md-6 p-0">
                        <div className="bg-light-blue vh-100 bg-no-repeat bg-40-size" style={{ backgroundImage: process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-right.png')", backgroundPosition: "bottom right" }}>
                            <div className="pt-5 pb-5 pl-2 pr-6 w-65 ms-auto me-auto vh-100">

                                <ul>
                                    {Object.keys(this.state.errors).map((k, v) => <li className="text-danger">{this.state.errors[k]}</li>)}
                                </ul>

                                {this.state.step == 1 && (
                                    <Step1
                                        prevStep={this.prevStep}
                                        handleChange={this.handleChange}
                                        step1={this.step1}
                                        loginUser={this.loginUser}
                                    />
                                )}

                                {this.state.step == 2 && (
                                    <Step2
                                        prevStep={this.prevStep}
                                        handleChange={this.handleChange}
                                        tryValidate={this.tryValidate}
                                        resendOTP = {this.resendOTP}
                                    />
                                )}


                            </div>
                        </div>
                    </div>
                </div>

            </div >
        </>;
    }
}

const mapStateToProps = (state) => {
    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        validateOTP: (otpData) => dispatch(validateOTP(otpData)),
        login: (loginData) => dispatch(login(loginData)),
        resendOTP: (data) => dispatch(resendOTP(data)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);