import React, { Component } from 'react';
import { getLoggedInUser } from '../../../classes';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import Header from './Header';


class CreatePage extends Component {

    state = {
        show: false,
        shows: false
    }

    async componentDidMount() {
        const user = await getLoggedInUser();
        if (user?.user_type !== Recruiter_User_Type_ID) {
            this.props.history.push('/');
        }

        this.togal = this.togal.bind(this);
        this.togall = this.togall.bind(this);
    }
    togal = () => {
        this.setState({
            show: !this.state.show
        })
    }
    togall = () => {
        this.setState({
            shows: !this.state.shows
        })
    }
    render() {
        return (
            <div className='container companytemplate'>

                <Header />

                <div className='row mb-2'>
                    <div className='col-md-3 col-12'>

                        <div className="company-template-sidebar">
                            <div className='bg-white shadow br-5 mb-2 p-2'>
                                <p className='text-primary'>Page Name </p>
                                <div className='d-flex align-items-center'>
                                    <h5 className='font-bold'>Enter Page Name
                                    </h5>
                                    <i class="lar la-edit text-primary h3 ms-auto"></i>
                                </div>
                            </div>
                            {/*  <!-- Links --> */}
                            
                            
                            <div className='bg-white shadow br-5 mb-2 p-2'>
                                <div className='d-flex align-items-center'>
                                    <h4 className='font-bold'>Edit</h4>
                                    <i class="las la-angle-down font-bold fs-4 ms-auto" onClick={this.togal} ></i>
                                </div>
                                {
                                    this.state.show ?
                                        <div className='col-md-12 '>
                                            <div class="">
                                                {/* dropdown-menu */}
                                                <ul class="" aria-labelledby="navbarDropdown">
                                                    <div className='m-1'>
                                                        <div className='row'>
                                                            <div className='col-md-12 '>
                                                                <form>
                                                                    <div className="mb-3">
                                                                        <label for="exampleInputEmail1" className="form-label font-bold text-primary">Text</label>
                                                                        <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder='Name' />
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='m-1'>
                                                        <div className='row'>
                                                            <div className='col-md-12 '>
                                                                <div className="mb-3">
                                                                    <div className='row'>
                                                                        <div className='col-md-9 col-9'>
                                                                            <label for="exampleInputEmail1" className="form-label font-bold text-dark float-left">Link Text</label>
                                                                        </div>
                                                                        <div className='col-md-3 col-3'>
                                                                            <div class="form-check form-switch float-right">
                                                                                <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className='border'>
                                                                        <div class="dropdown">
                                                                            <p class="dropdown-toggle p-1" type="" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                Link Page
                                                                            </p>
                                                                            <div class="dropdown-menu w-100" aria-labelledby="">
                                                                                <ul className='list-unstyled ms-1'>
                                                                                    <li className='pt-1'>about us</li>
                                                                                    <li className='pt-1'>our jobs</li>
                                                                                    <li className='pt-1'>contect us</li>
                                                                                    <li className='pt-1'>extrnal url</li>
                                                                                </ul>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='m-1'>
                                                        <div className='row'>
                                                            <div className='col-md-12 '>
                                                                <form>
                                                                    <div className="mb-3">
                                                                        <label for="exampleInputEmail1" className="form-label font-bold text-dark">Font Family</label>
                                                                        <div class="dropdown border p-1">
                                                                            <p class=" dropdown-toggle" type="" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                Poppins
                                                                            </p>
                                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                                <a class="dropdown-item" href="#">Action</a>
                                                                                <a class="dropdown-item" href="#">Another action</a>
                                                                                <a class="dropdown-item" href="#">Something else here</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='m-1'>
                                                        <div className='row'>
                                                            <div className='col-md-6 '>
                                                                <form>
                                                                    <div className="mb-3">
                                                                        <label for="exampleInputEmail1" className="form-label font-bold text-dark">Font Size</label>
                                                                        <div class="dropdown border p-1">
                                                                            <p class=" dropdown-toggle" type="" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                16
                                                                            </p>
                                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                                <a class="dropdown-item" href="#">Action</a>
                                                                                <a class="dropdown-item" href="#">Another action</a>
                                                                                <a class="dropdown-item" href="#">Something else here</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div className='col-md-6 '>
                                                                <form>
                                                                    <div className="mb-3 ">
                                                                        <label for="exampleInputEmail1" className="form-label font-bold text-primary">Font color</label>
                                                                        <div className='row m-0'>
                                                                            <div className='col-md-12 border p-1'>
                                                                                <p className='float-start'>#fffff</p>
                                                                                <input className='float-end w-25 h-75' type="color" name="" id="" placeholder='color' />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </ul>
                                            </div>
                                        </div>
                                        : null
                                }
                            </div>
                            <div>
                            </div>
                        </div>

                    </div>
                    <div className='col-lg-9 col-12'>

                        <div className='bg-white br-5 shadow pt-2 pb-2'>

                            {/* header section */}
                            {/* <div className='container mb-3'>
                                <div className='d-flex mb--12'>
                                    <i className="lar la-window-close text-danger f-1-5 me-auto shadow bg-white ml--10"></i>
                                    <i className="lar la-edit text-primary f-1-5 ms-auto shadow bg-white mr--10"></i>
                                </div>
                                <div className='border-blue1 d-flex justify-content-center align-items-center p-2'>
                                    <img src="../assets/imgs/accenture.png" className='h-60px' alt="" />
                                    <ul className='d-flex list-unstyled'>
                                        <li><a className='ms-1 f-0-8' href="">HOME</a></li>
                                        <li><a className='ms-1 f-0-8' href="">ABOUT US</a></li>
                                        <li><a className='ms-1 f-0-8' href="">OUR JOBS</a></li>
                                        <li><a className='ms-1 f-0-8' href="">CONTECT</a></li>
                                    </ul>
                                    <div className='d-flex ms-auto'>
                                        <p className='text-warning font-bold f-0-8 me-1'>Phone: <span className='text-dark'>9670888935</span ></p>
                                        <p className='text-warning font-bold f-0-8'>Email: <span className='text-dark'>rahulgupta@gmail.com</span></p>
                                    </div>
                                </div>
                            </div> */}

                            <div className='container mb-3'>
                                <div className='d-flex justify-content-center align-items-center new3 p-3'>
                                    <i class="las la-plus f-2 text-primary"></i>
                                    <h5>
                                        Add Header
                                    </h5>
                                </div>
                            </div>
                            {/* header section */}

                            {/* sections */}
                            <div className='container mb-3'>
                                <div className='d-flex flex-column align-items-center new3 justify-content-center p-5'>
                                    <i class="las la-plus f-2 text-primary"></i>
                                    <h6>
                                        Add  Section
                                    </h6>
                                </div>
                            </div>
                            {/* sections */}

                            <div className='container mb-3'>
                                <div className='d-flex justify-content-center align-items-center new3 p-3'>
                                    <i class="las la-plus f-2 text-primary"></i>
                                    <h5>
                                        Add Footer
                                    </h5>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        );
    }
}
export default CreatePage;