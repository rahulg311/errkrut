import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class TemplateNav extends Component {


    render() {
        return (
            <>

                <nav class="navbar">

                    <ul class="navbar-nav">
                        <li class="nav-item mb-3">
                            <NavLink to="/template/home" activeClassName='text-primary' className={`fw-bold h5 ${(window.location.pathname != '/template/home')?'text-black':''}`}>
                                Home
                            </NavLink>
                        </li>
                        <li class="nav-item mb-3">
                            <NavLink to="/template/pages" activeClassName='text-primary' className={`fw-bold h5 ${(window.location.pathname != '/template/pages')?'text-black':''}`}>
                                Pages
                            </NavLink>
                        </li>
                        <li class="nav-item mb-3">
                            <NavLink to="/template/logo" activeClassName='text-primary' className={`fw-bold h5 ${(window.location.pathname != '/template/logo')?'text-black':''}`}>
                                Logo
                            </NavLink>
                        </li>
                        <li class="nav-item mb-3">
                            <NavLink to="/template/media"  className={`fw-bold h5 ${(window.location.pathname != '/template/media')?'text-black':''}`}  activeClassName='text-primary'>
                                Media
                            </NavLink>
                        </li>
                        <li class="nav-item mb-3">
                            <NavLink to="/template/settings" activeClassName='text-primary' className={`fw-bold h5 ${(window.location.pathname != '/template/settings')?'text-black':''}`}>
                                Settings
                            </NavLink>
                        </li>
                    </ul>

                </nav>

            </>
        );
    }
}
export default TemplateNav;