import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';


class Header extends Component {

    render() {
        return (

            <div className='d-flex align-items-center mt-2'>
                <NavLink to="/" className={`me-auto`}><img className='mb-2 h-40px' src="../assets/imgs/logo.png" alt="" /></NavLink>
                <input type="text" class="form-control input-border w-auto" name="page_name" placeholder="Page Name"/>
                <div className=''>
                    <button type="button" class="btn btn-link"> Save as draft</button>
                    <button type="button" class="btn btn-link">Preview</button>
                    <button type="button" class="btn btn-primary">Publish</button>
                </div>

            </div>
        );

    }

}

export default Header;