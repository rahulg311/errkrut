import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes';
import Header from '../../../components/common/Header';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import TemplateNav from './TemplateNav';


class Settings extends Component {

    async componentDidMount() {
        const user = await getLoggedInUser();
        if (user?.user_type !== Recruiter_User_Type_ID) {
            this.props.history.push('/');
        }
    }

    render() {
        return (
            <>
                <Header />

                <div className='container mt-5 pt-5'>

                    <div className='row mt-2 mb-5'>
                        <div className='col-md-3 col-12'>
                            {/* <SideBar> */}

                            <div className="bg-white shadow rounded-3 pt-4 pb-4">

                                <div className='container'>

                                    <h5 className='mb-2 font-bold'>
                                        Welcome To Erekrut <br />
                                        Website Builder
                                    </h5>

                                    <p>Pick a Predefine Layout or start with a blank page</p>


                                    <div className='new2 mt-2 mb-4'></div>

                                    {/*  <!-- Links --> */}

                                    <TemplateNav />

                                </div>

                            </div>

                            {/* </SideBar >  */}
                        </div>

                        <div className='col-lg-9'>
                            <div className='bg-white shadow rounded-3 pt-3 pb-3'>

                                <div className='container'>

                                    <div className='row'>
                                        <div className='col-md-12 col-12'>
                                            <h4 className='float-start'>Settings</h4>

                                        </div>
                                    </div>
                                    <div className='border-blue1 mt-2 mb-4'></div>

                                    <div className='border-blue-line mt-2 mb-4'></div>

                                    <div className='w-90'>
                                        <div className='row '>
                                            <div className='col-md-12'>
                                                <h5 className='float-start'>Upload Website Icon</h5>

                                                <h5 className=' float-end text-primary'> Upload <i class="fas fa-upload ms-2 text-primary"></i></h5>
                                            </div>
                                        </div>

                                        <div className="row mt-2 mb-2">
                                            <div className="col-md-6">
                                                <label className="mt-2">
                                                    Website Title
                                                </label>
                                                <input
                                                    type='text'
                                                    className='form-control input-border'

                                                    name='text'
                                                    validateType='emailormobile'
                                                    validateMsg='Please Enter Correct Email or Mobile'
                                                    placeholder="Enter  Website Title"
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="mt-2">
                                                    Website Tagline
                                                </label>
                                                <input
                                                    type='text'
                                                    className='form-control input-border'

                                                    name='email'
                                                    validateType='emailormobile'
                                                    validateMsg='Please Enter Correct Email or Mobile'
                                                    placeholder="Enter Website Tagline"
                                                />
                                            </div>
                                        </div>
                                        <div className='new2 mt-4 mb-4'></div>
                                        <div className="row mt-2 mb-4">
                                            <div className="col-md-6">
                                                <label className="mt-2">
                                                    Website Address
                                                </label>
                                                <input
                                                    type='text'
                                                    className='form-control input-border'

                                                    name='text'
                                                    validateType='emailormobile'
                                                    validateMsg='Please Enter Correct Email or Mobile'
                                                    placeholder="Enter  Website Title"
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="mt-2">
                                                    Time Zone
                                                </label>
                                                <select class="form-select" aria-label="Default select example">
                                                    <option selected>Noida</option>
                                                    <option value="1">Lucknow</option>
                                                    <option value="2">Delhi</option>
                                                    <option value="3">mumbai</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div className='container-fluid p-0'>
                                            <div className='shadow br-5 p-1'>
                                                <div className='row'>
                                                    <div className='col-md-8'>
                                                        <h6 className='m-1 mt-3'>Launch Website</h6>
                                                        <p className='m-1 text-muted'>A paragraph is a series of related sentences developing a central idea, called the topic. Try to think about </p>
                                                    </div>
                                                    <div className='col-md-4 d-flex justify-content-center align-items-center'>
                                                        <button type="button" class="btn btn-primary ps-5 pe-5 fs-5 shadow">Launch website</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className='new2 mt-4 mb-4'></div>

                                        <div className='container-fluid p-0'>
                                            <div className='shadow br-5 p-1'>
                                                <div className='row'>
                                                    <div className='col-md-8'>
                                                        <h6 className='m-1 mt-3 '>Delete Content</h6>
                                                        <p className='m-1 text-muted'>A paragraph is a series of related sentences developing a central idea, called the topic. Try to think about </p>
                                                    </div>
                                                    <div className='col-md-4 d-flex justify-content-center align-items-center'>
                                                        <button type="button" class="btn btn-white font-bold ps-5 pe-5 fs-5 text-danger">Delete Content</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        <div className='row mt-4 mb-5'>
                                            <div className='col-md-12 '>
                                                <button type="button" class="btn btn-primary ps-5 pe-5 fs-5 float-end col-12 col-md-4 shadow btn-lg">Save Changes</button>

                                            </div>
                                        </div>

                                    </div>


                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </>
        );
    }
}
export default Settings;