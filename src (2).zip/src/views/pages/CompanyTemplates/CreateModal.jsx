import React, { Component } from 'react';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { getAuthToken } from '../../../classes';
import { SITE_DATA } from '../../../config/constants';
import { CREATE_SITE, END_POINT } from '../../../routes/api_routes';
import { checkSite } from '../../../store/actions/signup';
import {
    FacebookShareButton,
    TwitterShareButton,
    LinkedinShareButton,
    WhatsappShareButton,
    FacebookIcon,
    TwitterIcon,
    LinkedinIcon,
    WhatsappIcon,
    PinterestIcon,
    VKIcon,
} from "react-share";
class CreateModal extends Component {

    componentDidMount() {
        this.props.checkSite();
    }

    constructor(props) {
        super(props);
        this.state = {
            domain_name: '',
            password: '',
            error: '',
            success: ''
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        const name = event.target.name;
        console.log(this.props.site_data)
        if (name == 'domainName') {
            this.setState({ domain_name: event.target.value });
        } else {
            this.setState({ password: event.target.value })
        }
        event.preventDefault();
    }


    handleSubmit = async (event) => {
        event.preventDefault();

        let token = await getAuthToken();

        if (token) {

            const response = await fetch(END_POINT + CREATE_SITE, {
                method: 'POST',
                body: JSON.stringify({ domain_name: this.state.domain_name, password: this.state.password }),
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                }
            });
            const json = await response.json();
            if (json.status == 'error') {
                this.setState({ error: json })
            } else {
                this.setState({ success: 'Please Wait. Site creation is in progress.' })
                await new Promise(r => setTimeout(r, 10000));
                this.props.checkSite();
            }
        }

    }

    render() {
        return (
            <>
                <div className="modal fade-in d-block" >
                    <div className="modal-dialog modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-body">
                                <p className='f-2 cursor text-end' onClick={(e) => this.props.closeModal()}>&times;</p>
                                <div className='Backgroundimg'>
                                    <div className=''>
                                        <div className='container bg-white  '>
                                            <div className='container'>
                                                <div className='row'>
                                                    <div className='col-lg-6 d-none d-lg-block'>
                                                        <img src="../assets/imgs/create-website.jpg" alt="" />
                                                    </div>
                                                    {typeof this.props.site_data !== 'undefined' && !this.props.site_data.data.site_url && (
                                                        <div className='col-md-6'>
                                                            <div className='d-flex flex-column align-items-start  justify-content-center vh-50'>
                                                                <h4>Create site in minutes.</h4>
                                                                <form onSubmit={this.handleSubmit} className='mt-3'>
                                                                    <div className="form-group mb-3">
                                                                        <label for="domainName">Enter Domain Name</label>
                                                                        <div className="input-group align-items-center">
                                                                            <div className="custom-file">
                                                                                <input type="text" name="domainName" value={this.state.domain} onChange={this.handleChange} className="form-control" id="domainName" aria-describedby="domainName" placeholder="Enter domain" />
                                                                            </div>
                                                                            <div className="input-group-append ms-1">
                                                                                <span>.companies.erekrut.in </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-group">
                                                                        <label for="password">Please confirm your Password</label>
                                                                        <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" id="password" placeholder="Password" />
                                                                    </div>
                                                                    {typeof this.state.error.status !== 'undefined' && this.state.error.status == 'error' && this.state.success == '' && (
                                                                        <small className='text-danger'> {this.state.error.message[0]} </small>
                                                                    )}
                                                                    {this.state.success != '' && (
                                                                        <small className='text-success'> {this.state.success} </small>
                                                                    )}
                                                                    <button type="submit" className="btn btn-primary mt-5 ps-6 pe-6 fs-5">Create Website</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    )}
                                                    {typeof this.props.site_data !== 'undefined' && this.props.site_data.data.site_url && (
                                                        <div className='col-md-6'>

                                                            <div className="h-100 d-flex justify-content-center flex-column">
                                                                <div className='mb-2'>
                                                                    <h5>Congrats, your site is ready to use.</h5>
                                                                </div>
                                                                <div className=''>
                                                                    <a href={'http://' + this.props.site_data.data.site_url} target="_blank" className='btn btn-sm btn-primary'>Open Site</a>
                                                                    <a href={'http://' + this.props.site_data.data.admin_url} target="_blank" className='btn btn-sm ps-4 pe-4 me-2 btn-border ms-3'>Manage Site</a>
                                                                </div>
                                                                <div className='mt-4'>
                                                                    <h6>Tell world about your new site</h6>
                                                                    <div className='d-flex flex-row w-100 mb-2 mt-1'>
                                                                        <FacebookShareButton className='me-2'
                                                                            url={'http://' + this.props.site_data.data.site_url}
                                                                        >
                                                                            <FacebookIcon
                                                                                size={'25'}
                                                                            />

                                                                        </FacebookShareButton>
                                                                        <TwitterShareButton className='me-2'
                                                                            title='Hey, checkout my site'
                                                                            url={'http://' + this.props.site_data.data.site_url}
                                                                        >
                                                                            <TwitterIcon
                                                                                size={'25'}
                                                                            />
                                                                        </TwitterShareButton>

                                                                        <WhatsappShareButton className='me-2'
                                                                            title='Hey, checkout my site'
                                                                            separator=":: "
                                                                            url={'http://' + this.props.site_data.data.site_url}
                                                                        >
                                                                            <WhatsappIcon size={'25'} />
                                                                        </WhatsappShareButton>
                                                                        <LinkedinShareButton
                                                                            title='Hey, checkout my site'
                                                                            url={'http://' + this.props.site_data.data.site_url}
                                                                            windowWidth={750}
                                                                            windowHeight={600}
                                                                        >
                                                                            <LinkedinIcon
                                                                                size={'25'}

                                                                            />
                                                                        </LinkedinShareButton>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="modal-backdrop fade show blur-container"></div>
            </>

        );
    }

}

const mapStateToProps = (state) => {

    const { site_data } = state.common;

    return {
        site_data
    }
};


function mapDispatchToProps(dispatch) {
    return {
        checkSite: () => dispatch(checkSite()),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CreateModal);
