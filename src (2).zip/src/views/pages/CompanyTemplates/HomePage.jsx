import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes';
import Header from '../../../components/common/Header';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import TemplateNav from './TemplateNav';


class HomePage extends Component {

    async componentDidMount() {
        const user = await getLoggedInUser();
        if (user?.user_type !== Recruiter_User_Type_ID) {
            this.props.history.push('/');
        }
    }

    render() {
        return (
            <>
                <Header />

                <div className='container mt-5 pt-5'>

                    <div className='row mt-2 mb-5'>
                        <div className='col-md-3 col-12'>
                            {/* <SideBar> */}

                            <div className="bg-white shadow rounded-3 pt-4 pb-4">

                                <div className='container'>

                                    <h5 className='mb-2 font-bold'>
                                        Welcome To Erekrut <br />
                                        Website Builder
                                    </h5>

                                    <p>Pick a Predefine Layout or start with a blank page</p>


                                    <div className='new2 mt-2 mb-4'></div>

                                    {/*  <!-- Links --> */}

                                    <TemplateNav />

                                </div>

                            </div>

                            {/* </SideBar >  */}
                        </div>

                        <div className='col-lg-9'>
                            <div className='bg-white shadow rounded-3 pt-3 pb-3'>

                                <div className='container'>

                                    <div className='row'>
                                        <div className='col-md-12 col-12'>
                                            <h4 className='float-start'>Home</h4>
                                            <button type="button" class="btn btn-primary float-end">Publish Website</button>
                                        </div>
                                    </div>
                                    <div className='border-blue1 mt-2 mb-4'></div>


                                    <div className='row'>
                                        <div className='col-md-2 col-12 show-on-hover'>
                                            <div className='position-relative'>
                                                <img className='w-100 min-height-175 shadow br-5' src="../assets/imgs/page-demo.jpg" alt="" />
                                                <div className='d-flex flex-column bg-black z-9 position-absolute t-0 r-0 b-0 l-0 text-white p-1 br-5 bg-opacity-75' style={{ visibility: "hidden" }}>
                                                    <p className='mb-auto'>Homepage</p>
                                                    <p className='text-center mb-1'><i class="las la-eye"></i> Preview</p>
                                                    <button type="button" class="btn btn-primary btn-sm">Edit Page</button>
                                                </div>
                                            </div>

                                        </div>


                                        <div className='col-md-2 col-12'>
                                            <NavLink to="/template/create-page">
                                                <div className='shadow min-height-175 br-5 d-flex flex-column align-items-center justify-content-center'>
                                                    <i class="las la-plus display-5 text-primary"></i>
                                                    <h6 className='text-black'>
                                                        Add Page
                                                    </h6>
                                                </div>
                                            </NavLink>
                                        </div>


                                    </div>
                                    <div className='new2 mt-4 mb-4'></div>


                                    <div className='row mb-5' >
                                        <div className='col-md-6 col-12'>

                                            {/* <div className='d-flex shadow align-items-center p-3 br-5'>
                                                <img className='h-70' src="../assets/imgs/accenture.png" alt="" />
                                                <div className='ms-2'>
                                                    <h4>Company </h4>
                                                    <p>Name</p>
                                                </div>
                                            </div> */}

                                            <NavLink to="/template/settings">
                                                <div className='shadow br-5 d-flex align-items-center justify-content-around p-3 min-height-80'>
                                                    <h6 className='me-auto text-black'>
                                                        Give Your Site Name
                                                    </h6>
                                                    <i class="las la-plus f-2 text-primary"></i>
                                                </div>
                                            </NavLink>

                                        </div>
                                        <div className='col-md-6 col-12'>

                                            {/*  <div className='d-flex shadow align-items-center p-3 br-5'>
                                                <img className='h-70 ' src="../assets/imgs/accenture.png" alt="" />
                                                <div className='ms-2'>
                                                    <h4 className=''>Company </h4>
                                                    <p className=''>Name</p>
                                                </div>

                                            </div> */}

                                            <NavLink to="/template/logo" >
                                                <div className='shadow br-5 d-flex flex-column align-items-center justify-content-center p-2 min-height-80'>
                                                    <i class="las la-plus f-2 text-primary"></i>
                                                    <h6 className='text-black'>
                                                        Add Company Logo
                                                    </h6>
                                                </div>
                                            </NavLink>

                                        </div>

                                    </div>

                                    <div className='new2 mt-4 mb-4'></div>


                                    <div className='row'>
                                        <div className='col-md-2 col-12'>
                                            <NavLink to="/template/media">
                                                <div className='shadow min-height-150 br-5 d-flex flex-column align-items-center justify-content-center'>
                                                    <i class="las la-plus display-5 text-primary"></i>
                                                    <h6 className='text-black'>
                                                        Upload Media
                                                    </h6>
                                                </div>
                                            </NavLink>
                                        </div>
                                        <div className='col-md-2 col-12'>
                                            <img className='shadow w-100 br-5  min-height-150' src="../assets/imgs/media-demo.jpg" alt="" />
                                        </div>
                                    </div>




                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </>
        );
    }
}
export default HomePage;