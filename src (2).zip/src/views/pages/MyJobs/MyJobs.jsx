import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';

import { connect } from 'react-redux';
import Loading from '../../../components/common/Loading';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import CandidateJobsCard from '../../../components/Cards/CandidateJobsCard';
import { errorPrettify, getLoggedInUser } from '../../../classes';
import { changeJobStatus, getAllJobsStatus, getAppliedJobs } from '../../../store/actions/jobs';
import { Candidate_User_Type_ID } from '../../../config/constants';
import { notification } from '../../../classes/messages';

class CandidatesApplied extends Component {

	state = {
		jobs: [],
		page_num: 1,
		per_page: 500,
		request_type: 'applied',
		loading: false,
		no_data: false,
		job_status: [],
		active_status: 'Saved Jobs',
		user_id: null
	}

	componentWillMount = async() => {

		let user = await getLoggedInUser();

		if(user){
			this.setState({
				user_id: user.id
			})
		}

		this.getJobs();
		//this.getJobsStatus();
	}

	handleChange = (obj) => {
		this.setState({
			[obj.name]: obj.value,
			page_num: 1,
			per_page: this.state.per_page,
			jobs: [],
			no_data: false,
			active_status: obj.title
		}, () => {
			this.getJobs();
		});
	}


	changeJobStatus = async (job, is_reject = false) => {

		let notify;

		let obj = {};
		obj['round_id'] = job.round_id;
		obj['user_id'] = this.state.user_id;
		obj['job_id'] = job.job_id;
		obj['owner'] = Candidate_User_Type_ID;
		obj['status'] = job.current_status;
		if(is_reject){
			obj['is_reject'] = job.is_reject;
		}

		await this.props.changeJobStatus(obj);

		if (this.props.change_job_status_res?.status == 'success') {
			notify = notification({ type: 'success', message: 'Status has been changed successfully!' });
			//this.getJobs();
			setTimeout(() => {
				//window.location.reload();
			},1000);
		} else {
			notify = notification({ type: 'error', message: errorPrettify(this.props.change_job_status_res?.message) });
		}
		if (notify)
			notify();

	}


	/* load more jobs */
	loadMore = () => {
		let page = this.state.page_num;
		this.setState({
			page_num: page + 1
		}, () => {
			this.getJobs();
		});
	}
	/* load more jobs */


	/* get jobs status */
	getJobsStatus = async () => {

		let uri = 'candidate';

		await this.props.getAllJobsStatus(uri);

		if (this.props.job_status_res?.status == 'success') {

			if (this.props.job_status_res?.data.length > 0) {

				this.setState(
					{ job_status: this.props.job_status_res?.data }
				);
			}

		}

	}
	/* get jobs status */

	/* get jobs */
	getJobs = async () => {

		let user = await getLoggedInUser();

		if (user) {

			this.setState({
				loading: true
			});

			let obj = {};
			obj['user_id'] = user.id;
			obj['request_type'] = this.state.request_type;
			obj['page_num'] = this.state.page_num;
			obj['per_page'] = this.state.per_page;

			await this.props.getAppliedJobs(obj);

			if (this.props.applied_jobs_res?.status) {

				this.setState({
					loading: false
				});

				if (this.props.applied_jobs_res?.data.length > 0) {

					if (this.props.applied_jobs_res?.data.length < this.state.per_page) {
						this.setState({
							no_data: true
						})
					}

					this.setState(prevState => ({
						jobs: [...prevState.jobs, ...this.props.applied_jobs_res.data],
					}));

				} else {
					this.setState({
						no_data: true
					})
				}

			}

		}

	}
	/* get jobs */



	render() {

		return (
			<div>
				<Section>
					<Main>

						{/* filters */}
						<div className='d-flex mt-3 mb-4 align-items-center p-2'>
							<div className=''>
								<h5 className="text-blue f-r-14">My Jobs</h5>
							</div>
							<div className='align-items-start d-flex flex-wrap ms-auto'>

								<div className="position-relative filter-btn">

									<div class="dropdown shadow  p-0">
										<button class="btn btn-default text-primary ps-2 pe-2 btn-sm dropdown-toggle btn-toggle w-200pxx btn-block w-200px" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<span className='f-r-10' >Filter By Job Status</span>

										</button>
										<div class="dropdown-menu  shadow p-0" aria-labelledby="dropdownMenuButton">
											<div className=" me-auto ms-auto border-bottom-blue"></div>

											<a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ name: 'request_type', value: 'save', title: 'Saved Jobs' })}>Saved Jobs</a>

											<a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ name: 'request_type', value: 'like', title: 'Liked Jobs' })}>Liked Jobs</a>

											<a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ name: 'request_type', value: 'applied', title: 'Applied Jobs' })}>Applied Jobs</a>

											{/* job status */}

											{/* {this.state.job_status.length > 0 &&
												this.state.job_status.map((status) => {

													return <a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ name: 'request_type', value: status.id, title: status.title })}>{status.title}</a>

												})
											} */}
											{/* job status */}

										</div>
									</div>
								</div>


							</div>
						</div>
						{/* filters */}

						{/* jobs list */}
						{this.state.loading &&
							<div className='mt-2'>
								<Loading />
							</div>
						}

						{(this.state.jobs.length > 0) ?
							<CandidateJobsCard 
							title='' 
							jobs={this.state.jobs} 
							changeJobStatus={this.changeJobStatus} />
							:
							<h5 className="text-blue text-center">No Jobs Found.</h5>
						}

						{/* jobs list */}


						{/* load more */}
						{this.state.no_data == false &&
							<button className="btn btn-primary btn-sm d-block me-auto ms-auto mt-2 mb-2" onClick={() => { this.loadMore() }}>
								<i class="las la-angle-double-down"></i> Load More
							</button>
						}
						{this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}
						{/* load more */}

					</Main>
					<SideBar>
						<ProfileName />
						<ActionButtons />
						<CandidateCards />
						<Skills />
						<FeaturedCompanies />
						<Designations />
						<Locations />
						<Company />
					</SideBar>
				</Section>
			</div>
		);
	}
}


const mapStateToProps = (state) => {

	const { applied_jobs_res, job_status_res, change_job_status_res } = state.common;

	return {
		applied_jobs_res,
		job_status_res,
		change_job_status_res
	}
};

function mapDispatchToProps(dispatch) {
	return {
		getAppliedJobs: (data) => dispatch(getAppliedJobs(data)),
		getAllJobsStatus: (data) => dispatch(getAllJobsStatus(data)),
		changeJobStatus: (data) => dispatch(changeJobStatus(data))
	};
}


export default connect(mapStateToProps, mapDispatchToProps)(CandidatesApplied);