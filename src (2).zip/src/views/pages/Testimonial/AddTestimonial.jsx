import React, { useEffect, useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link } from 'react-router-dom';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';

import { useHistory } from 'react-router-dom';

import { getAuthToken, getLoggedInUser } from '../../../classes/index';
import { END_POINT } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';

const AddTestimonial = () => {
	const history = useHistory();
	const [name, setName] = useState('');
	const [content, setContent] = useState('');
	const [companyName, setCompanyName] = useState('');
	const [loading, setLoading] = useState(false);

	const handleOnSave = async () => {
		setLoading(true);
		const result = await getLoggedInUser();

		// const formdata = new FormData();
		// formdata.append('user_id', result.id);
		// formdata.append('name', title);
		// formdata.append('description', content);
		// formdata.append('company_name', companyName);
		let formdata = {
			'user_id': result.id,
			'name': name,
			'description': content,
			'company_name': 'Erekrut'
		}

		let token = await getAuthToken();
		const requestOptions = {
			method: 'POST',
			body: JSON.stringify(formdata),
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token,
				'Content-Type': 'application/json'
			}
		};

		fetch(END_POINT + 'create_testimonial', requestOptions)
			.then((response) => response.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({ message: data.message, type: 'success' });
					notify();
					setLoading(false);
					history.push('/recruiter/testimonials');
				} else {
					data.message.forEach((element) => {
						let notify = notification({ message: element, type: 'error' });
						notify();
						setLoading(false);
					});
				}
			})
			.catch((error) => console.log('error', error));
	};
	useEffect(async () => {
		const result = await getLoggedInUser();
		setName(result.name);
	}, [name]);

	return (
		<Section className="bg-white br-5">
			<Main>
				<header className='border-bottom border-primary py-2 border-2'>
					<h4>Add Testimonial </h4>
				</header>
				<main className='mt-4'>
					<div class='mb-3'>
						<label for='exampleFormControlInput1' class='form-label'>
							Name
						</label>
						<input
							type='email'
							class='form-control'
							id='exampleFormControlInput1'
							value={name}
							onChange={(e) => setName(e.target.value)}
						/>
					</div>
					<div class='mb-3 d-none'>
						<label for='exampleFormControlInput1' class='form-label'>
							Company Name
						</label>
						<input
							type='email'
							class='form-control'
							id='exampleFormControlInput1'
							value={companyName}
							onChange={(e) => setCompanyName(e.target.value)}
						/>
					</div>
					<div class='mb-3'>
						<label for='exampleFormControlTextarea1' class='form-label'>
							Description
						</label>
						<textarea
							class='form-control'
							id='exampleFormControlTextarea1'
							rows='3'
							value={content}
							onChange={(e) => setContent(e.target.value)}
						></textarea>
					</div>
					<div className='text-end mt-5'>
						<button
							className='btn bg-primary text-white px-5'
							disabled={loading}
							onClick={() => handleOnSave()}
						>
							{loading ? (
								<div className='spinner-border spinner-border-sm' role='status'></div>
							) : (
								'Save'
							)}
						</button>
					</div>
				</main>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default AddTestimonial;
