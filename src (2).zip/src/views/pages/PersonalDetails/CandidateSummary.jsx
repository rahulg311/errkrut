import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, shuffleArray } from '../../../classes';
import { getProfile } from '../../../store/actions/profile';

class CandidateSummary extends Component {

    state = {
        user_data: null
    }

    async componentDidMount() {

        const result = await getLoggedInUser();

        if (result) {
            this.setState({
                user_id: result.id,
                email: result.email,
                mobile: result.mobile
            }, async () => {
                await this.props.getProfile(result.id);
                if (this.props.data?.user_data) {
                    this.setState({
                        user_data: this.props.data
                    });
                }
            });
        }

    }

    render() {
        const { card } = this.props;

        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink'];
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">

                    {card.values.length > 0 && card.values.map((res) => {
                        return <>
                            <div className="row mt-2 ">
                                <div className="col-md-11 col-10 ">
                                    <h4 className="f-Poppins-Medium mt-2">{res.title}</h4>
                                </div>

                            </div>
                            <div className="row">
                                <div className="col-md-12">

                                    {(res.title == 'Key Skill' || res.title == 'Software Skill' || res.title == 'Key Skills') ?

                                        res?.value.split(',').map((badge) => {
                                           return <span class="badge badge-default cursor me-1">{badge}</span>
                                        })

                                        : <p>{res.value}</p>
                                    }


                                </div>
                            </div>
                        </>
                    })}
                </div>
            </>
        );

    }
}


const mapStateToProps = (state) => {

    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        getProfile: (id) => dispatch(getProfile(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CandidateSummary);