import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, shuffleArray } from '../../../classes';
import { getProfile } from '../../../store/actions/profile';

class ProfileStrength extends Component {

    state = {
        user_data: null
    }

    async componentDidMount() {

        const result = await getLoggedInUser();

        if (result) {
            this.setState({
                user_id: result.id,
                email: result.email,
                mobile: result.mobile
            }, async () => {
                await this.props.getProfile(result.id);
                if (this.props.data?.user_data) {
                    this.setState({
                        user_data: this.props.data
                    });
                }
                console.log(this.props.data);
            });
        }

    }

    render() {
        const { card } = this.props;
        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink'];
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">
                    <div className="row ">
                        <div className="col-md-12  mt-2 p-0  ">
                            <h4>
                                <span className="font-bold mr-2 f-r-17 p-0  ms-2 f-Poppins-Medium float-start">Profile Strength(Average)</span>
                                <span className="font-bold text-blue f-r-17 float-end me-2">{this.state.user_data?.user_data?.strength}%</span>
                            </h4>
                        </div>
                        <div className="row mt-1">
                            <div className="col-md-12">
                                <div class="progress mt-1">
                                    <div class="progress-bar bg-info bg-primary" style={{ width: `${this.state.user_data?.user_data?.strength}%` }}>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {this.state.user_data?.user_data?.strength < 100 &&
                        <div className="row mt-4  ">
                            <div className="col-md-12 ">
                                <h6>Complete Your Profile</h6>
                            </div>
                        </div>
                    }

                    <div className="row mt-4  pb-2">
                        <div className="col-md-3 mt-1 mb-1">
                            <div className="cards position-relative bg-blue br-5 text-white p-2 mr-2 h-90">
                                <NavLink to="/edit-profile">
                                    <h6 className="f-Poppins-Regular position-abs t-2 l-2 m-0 h-25vh text-center p-2 text-white">Upload Portfolio</h6>
                                </NavLink>
                            </div>
                        </div>
                        <div className="col-md-3 mt-1 mb-1">
                            <div className="cards position-relative bg-greenesh-blue  br-5 text-white p-2 mr-2 h-90">
                                <NavLink to="/edit-profile">
                                    <h6 className="f-Poppins-Regular position-abs t-2 l-2 m-0 h-25vh text-center p-2 text-white">Update Skill </h6>
                                </NavLink>
                            </div>
                        </div>
                        <div className="col-md-3 mt-1 mb-1 ">
                            <div className="cards position-relative bg-dark-pink br-5 text-white p-2 mr-2 h-90">
                                <NavLink to="/edit-profile">
                                    <h6 className="f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2 text-white">Add Education </h6>
                                </NavLink>
                            </div>
                        </div>
                        <div className="col-md-3 mt-1 mb-1">
                            <div className="cards position-relative  bg-blue br-5 text-white p-2 mr-2 h-90">
                                <NavLink to="/edit-profile">
                                    <h6 className="f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2 text-white">Add Employment  </h6>
                                </NavLink>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );

    }
}


const mapStateToProps = (state) => {

    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        getProfile: (id) => dispatch(getProfile(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileStrength);