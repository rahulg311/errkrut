import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class CandidateEmployment extends Component {

    render() {
        const { card } = this.props;
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">
                    <div className="row  mb-2  ">
                        <div className="col-md-12">
                            <h4 className="f-Poppins-Medium mt-2">{card.CardTitle}</h4>
                        </div>
                    </div>

                    <div className="row">
                        {card.values && card.values?.map((v, k) => {

                            return v.value && JSON.parse(v.value).map((edu_card, edu_key) => {

                                return <>
                                    <div className="col-12 col-md-6">
                                        <div className="shadow mt-2 p-2 br-5">
                                            <div className="d-flex">
                                                <header className='d-flex'>
                                                    <div>
                                                        {Object.keys(edu_card).map((k, index) => {
                                                            return <p>
                                                                <label className="me-2 text-capitalize">{k.replace(/_/g, " ")}</label>
                                                                <span>{edu_card[k]}</span>
                                                            </p>;
                                                        })}
                                                    </div>
                                                </header>

                                            </div>
                                        </div>
                                    </div>


                                </>

                            })
                        })}

                    </div>

                </div>
            </>
        );

    }
}

export default CandidateEmployment;