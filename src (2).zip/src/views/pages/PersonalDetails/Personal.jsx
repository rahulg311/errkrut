import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, shuffleArray } from '../../../classes';

class Personal extends Component {

    state = {
        user_id: null,
        email: null,
        mobile: null,
        userName: null
    }

    async componentDidMount() {

        const result = await getLoggedInUser();

        if (result) {
            this.setState({
                user_id: result.id,
                email: result.email,
                mobile: result.mobile,
                userName: result.name
            }, async () => {
                //await this.props.getProfile(result.id);

                //console.log(this.props.data);
            });
        }

    }

    render() {
        const { card } = this.props;


        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink', 'bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink'];
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">
                    <div className="row mt-1 ">
                        <div className="col-md-11 col-10">
                            <h4 className="f-Poppins-Medium f-r-17 ">{card.CardTitle}</h4>
                        </div>
                        <div className="col-md-1 col-2" >
                            <h3>
                                <NavLink to="/edit-profile">
                                    <i class="las la-edit text-blue cursor  "></i>
                                </NavLink>
                            </h3>
                        </div>
                    </div>
                    <header className='d-flex'>
                        <div className='me-3 mt-2'>
                            <img
                                src='/assets/imgs/dummy-logo.png'
                                className='img-fluid box-shadow br-5 h-60p'
                            />
                        </div>
                        <div>
                            <h4 className='font-bold mb-1 mt-2 f-Poppins-Medium'>
                                {this.state.userName}
                            </h4>
                            <h6>{card?.values[1]?.value}</h6>
                        </div>
                    </header>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="row mt-2">


                                <div className="col-md-4">
                                    <div className={`card border-0 shadow-sm position-relative mt-2 br-5 text-white p-2 mr-2 h-70 ${colors[0]}`}>
                                        <p className=" f-Poppins-Regular  text-break position-abs t-2 l-2 m-0 h-20px"><span className="float-start">Email:</span>
                                            <span className="float-end text-break fs-10 mt-1"> {this.state?.email} </span></p>
                                    </div>
                                </div>

                                {this.state?.mobile &&
                                    <div className="col-md-4">
                                        <div className={`card border-0 shadow-sm position-relative mt-2 br-5 text-white p-2 mr-2 h-70 ${colors[1]}`}>
                                            <p className=" f-Poppins-Regular  text-break position-abs t-2 l-2 m-0 h-20px"><span className="float-start">Mobile:</span>
                                                <span className="float-end text-break"> {this.state?.mobile} </span></p>
                                        </div>
                                    </div>
                                }


                                {card.values.length > 0 && card.values.map((v, k) => {

                                    return (
                                        <>
                                            {k > 1 && <div className="col-md-4">
                                                <div className={`card border-0 shadow-sm position-relative mt-2 br-5 text-white p-2 mr-2 h-70 ${colors[k]}`}>
                                                    <p className=" f-Poppins-Regular text-break position-abs t-2 l-2 m-0 h-20px">
                                                        <span className="float-start">
                                                            {v.title}
                                                        </span>
                                                        <span className="float-end text-break">
                                                            {v.value}
                                                        </span>
                                                    </p>
                                                </div>
                                            </div>
                                            }
                                        </>)
                                })}

                            </div>

                        </div>
                    </div>
                </div>
            </>
        );

    }
}

export default Personal;