import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';

import { getLoggedInUser, setLoggedInUser } from '../../../classes';

import { editProfile, updateProfile } from '../../../store/actions/profile';

import { connect } from 'react-redux';

import { validation } from '../../../classes/validation';

import { notification } from '../../../classes/messages';
import EditPersonalDetailForm from './EditPersonalDetailForm';
import SideBar from '../../../components/hoc/SideBar';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';

class EditPersonalDetails extends Component {

    state = {
        errors: {},
        user_id: 0,
        email: null,
        mobile: null,
        edit_profile_data: null,
        personal_detail_form: {},
        campus_profile_form: {},
        recruitment_head_profile_form: {},
        summary_form: null,
        career_profile_form: null,
        employment_form: null,
        education_form: null,
        language_form: null,
        files: null,
        is_loader: false,
        edit_id: null,
        empKey: 'employment',
        eduKey: 'education',
        careerKey: 'linked-profiles',
        langKey: 'language',
        empEditIndex: null,
        eduEditIndex: null,
        langEditIndex: null,
        loaderType: null,
        empDeleteIndex: null,
        eduDeleteIndex: null,
        carDeleteIndex: null,
        langDeleteIndex: null,
        is_delete: false,
        curlinkedprofile: "",
    }


    componentWillMount() {
        this.initializeData();
    }


    /* initialize basic data */

    initializeData = async () => {

        let user = await getLoggedInUser();

        if (user) {

            let user_id = user.id;
            this.setState({
                user_id: user_id,
                email: user.email,
                mobile: user.mobile,
                userName: user.name
            });

            /* get profile from api */

            await this.props.editProfile(user_id);

            if (this.props.edit_profile_data) {

                console.log(this.props.edit_profile_data)

                let pfObj = {};

                this.props.edit_profile_data?.map((v) => {
                    /* set Edit Campus Profile data */
                    if (v.CardTitle == "Edit Campus Profile") {

                        let x = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {

                            x = {
                                ...x,
                                [obj.name]: (obj.name == 'name') ? this.state.userName : obj.value
                            };
                        });

                        pfObj['campus_profile_form'] = x;

                    }
                    /* set Edit Campus Profile data */
                    /* set Edit Recruitment Head Profile data */
                    if (v.CardTitle == "Edit Recruitment Head Profile") {

                        let x = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {

                            x = {
                                ...x,
                                [obj.name]: (obj.name == 'name') ? this.state.userName : obj.value
                            };
                        });

                        pfObj['recruitment_head_profile_form'] = x;

                    }
                    /* set Edit Recruitment Head Profile data */

                    /* set personal profile data */
                    if (v.CardTitle == "Edit Personal Details") {

                        let x = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {

                            x = {
                                ...x,
                                [obj.name]: (obj.name == 'name') ? this.state.userName : obj.value
                            };
                        });

                        pfObj['personal_detail_form'] = x;

                    }
                    /* set personal profile data */

                    /* set summary data */
                    if (v.CardTitle == "Edit Summary") {

                        let y = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {
                            y = {
                                ...y,
                                [obj.name]: obj.value
                            };
                        });

                        pfObj['summary_form'] = y;

                    }
                    /* set summary data */

                    /* set career data */
                    if (v.CardTitle == "Edit Career Profile") {

                        let z = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {
                            z = {
                                ...z,
                                [obj.name]: (obj.value) ? obj.value : []
                            };
                        });

                        pfObj['career_profile_form'] = z;

                    }
                    /* set career data */

                    /* set employment data */
                    if (v.CardTitle == "Add or Edit Employment") {

                        let a = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {
                            a = {
                                ...a,
                                [obj.name]: (obj.value) ? obj.value : []
                            };
                        });

                        pfObj['employment_form'] = a;

                    }
                    /* set employment data */

                    /* set education data */
                    if (v.CardTitle == "Add or Edit Education") {

                        let b = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {
                            b = {
                                ...b,
                                [obj.name]: (obj.value) ? obj.value : []
                            };
                        });

                        pfObj['education_form'] = b;

                    }
                    /* set education data */

                    /* set language data */
                    if (v.CardTitle == "Language") {

                        let c = { group_id: v.values[0].group_id, user_id: user_id };

                        v?.values?.map((obj) => {
                            c = {
                                ...c,
                                [obj.name]: obj.value
                            };
                        });

                        pfObj['language_form'] = c;

                    }
                    /* set language data */

                });


                this.setState(pfObj);

                if (this.props.edit_profile_data?.length > 0)
                    this.setState({
                        edit_profile_data: this.props.edit_profile_data
                    }, () => {
                        console.log(this.state);
                    });

            }

            /* get profile from api */

        }

    }

    /* initialize basic data */


    /*  handle change */
    handleChange = (e, valiType = '', valiMsg = '', ftype) => {

        if (e.target) {


            let ivalue = e.target.value;

            let iname = e.target.name;
            let filetype = e.target.type;
            if (iname == "linked-profiles") {
                iname = "curlinkedprofile";
                this.setState({ "curlinkedprofile": ivalue });
            }
            /* file input */
            if (filetype == 'file') {
                let reader = new FileReader();
                if (e.target.files.length > 0) {
                    ivalue = e.target.files;
                    //console.log(e.target.files)
                }
            }
            /* file input */

            /* checkbox input */
            if (e.target.type == 'checkbox') {
                if (e.target.checked) {
                    ivalue = 1;
                } else {
                    ivalue = 0;
                }
            }
            /* checkbox input */


            if (valiType && valiMsg)
                this.handleValidation({ name: iname, type: valiType, value: ivalue, message: valiMsg });


            if (filetype == 'file') {
                /* file input */
                this.setState({
                    files: {
                        [ftype]: {
                            //...this.state[ftype],
                            [iname]: ivalue,
                            group_id: this.state[ftype].group_id,
                            user_id: this.state[ftype].user_id
                        }
                    }
                }, () => {
                    if (ftype != 'campus_profile_form')
                        this.handleSubmit(null, ftype, 1);
                });
                /* file input */
            } else {
                if (iname == "job_profile" && ivalue.length > 500) {
                    let notify = notification({ message: "Job Profile Character Limit Exceeds", type: 'error' });
                    notify();
                }
                else {
                    this.setState({
                        [ftype]: {
                            ...this.state[ftype],
                            [iname]: ivalue
                        }
                    });
                }

            }

        }
    }
    /* handle Change */


    /* handle validation */

    handleValidation = (obj) => {

        let error = this.state.errors;

        let valiRes = validation(obj);

        //email
        if (valiRes['error'] == 1) {

            error[obj.name] = valiRes['message'];

            this.setState({
                errors: error
            });

        } else {
            error[obj.name] = '';

            this.setState({
                errors: error
            });
        }

    }

    /* handle validation */

    /* handle required */

    handleRequired = (event) => {
        if (event) {
            let target = event.target;
            for (let i = 0; i < target.length; i++) {
                if (target.elements[i].required) {
                    if (target.elements[i].value == '') {
                        return false;
                    }
                }

            }
        }
        return true;
    }
    /* handle required */


    /* handle submit */

    handleSubmit = async (e, ftype, is_upload = 0) => {

        if (e)
            e.preventDefault();
        this.setState({
            loaderType: ftype
        });
        let notify = null;
        let formValid = true;
        formValid = this.handleRequired(e);
        if (this.state.errors) {
            Object.keys(this.state.errors).map((k, v) => {
                if (this.state.errors[k] != "") {
                    formValid = false;
                }
            })

        }
        if (formValid == true) {
            let formData;
            if (this.state.is_delete == true) {
                /* delete lanaguage */
                if (ftype == 'language_form') {

                    if (this.state.langDeleteIndex != null) {

                        let arr = JSON.parse(this.state[ftype][this.state.langKey]);
                        let delIndex = this.state.langDeleteIndex;
                        let newArr = arr.filter(function (value, index) {
                            if (delIndex != null)
                                if (index != delIndex) return value;
                        });

                        formData = { group_id: this.state[ftype].group_id, user_id: this.state[ftype].user_id };

                        formData[this.state.langKey] = JSON.stringify(newArr);

                    }

                }
                /* delete lanaguage */
                /* education lanaguage */
                if (ftype == 'education_form') {
                    if (this.state.eduDeleteIndex != null) {
                        let arr = JSON.parse(this.state[ftype][this.state.eduKey]);
                        let delIndex = this.state.eduDeleteIndex;
                        let newArr = arr.filter(function (value, index) {
                            if (delIndex != null)
                                if (index != delIndex) return value;
                        });
                        formData = { group_id: this.state[ftype].group_id, user_id: this.state[ftype].user_id };
                        formData[this.state.eduKey] = JSON.stringify(newArr);
                    }
                }
                /* education lanaguage */
                if (ftype == 'career_profile_form') {
                    if (this.state.carDeleteIndex != null) {
                        let arr = JSON.parse(this.state[ftype][this.state.careerKey]);
                        let delIndex = this.state.carDeleteIndex;
                        let newArr = arr.filter(function (value, index) {
                            if (delIndex != null)
                                if (index != delIndex) return value;
                        });
                        formData = { group_id: this.state[ftype].group_id, user_id: this.state[ftype].user_id };
                        formData[this.state.careerKey] = JSON.stringify(newArr);
                    }
                }
                /* employment lanaguage */
                if (ftype == 'employment_form') {
                    if (this.state.empDeleteIndex != null) {
                        let arr = JSON.parse(this.state[ftype][this.state.empKey]);
                        let delIndex = this.state.empDeleteIndex;
                        let newArr = arr.filter(function (value, index) {
                            if (delIndex != null)
                                if (index != delIndex) return value;
                        });
                        formData = { group_id: this.state[ftype].group_id, user_id: this.state[ftype].user_id };
                        formData[this.state.empKey] = JSON.stringify(newArr);
                    }
                }
                /* employment lanaguage */

            } else {



                /* insert update starts here */
                if (is_upload) {
                    formData = this.state.files[ftype];
                } else {
                    formData = this.state[ftype];
                }
                if (ftype == 'campus_profile_form' && this.state.files != null) {
                    formData['logo[]'] = this.state.files[ftype]['logo[]'];
                }

                this.setState({
                    is_loader: true
                });

                /*  language form */

                if (ftype == 'language_form') {
                    let obj = {};
                    let emp = [];
                    let group_id, user_id;
                    Object.keys(formData).map((k) => {
                        if (k == this.state.langKey && formData[k] != "") {
                            emp = JSON.parse(formData[k]);
                        }
                        if (k == 'group_id')
                            group_id = formData[k];
                        if (k == 'user_id')
                            user_id = formData[k];
                        if (k != 'user_id' && k != 'group_id' && k != this.state.langKey) {
                            obj[k] = formData[k];
                        }
                    });

                    if (this.state.langEditIndex != null) {
                        emp[this.state.langEditIndex] = obj;
                    } else {
                        emp.push(obj);
                    }
                    formData = { user_id: user_id, group_id: group_id };
                    formData[this.state.langKey] = JSON.stringify(emp);
                }

                /* language form */

                /* employment form */

                if (ftype == 'employment_form') {
                    let obj = {};
                    let emp = [];
                    let group_id, user_id;
                    Object.keys(formData).map((k) => {

                        if (k == this.state.empKey && formData[k] != "" /* && Object.prototype.toString.call(formData[k]) === '[object Array]' */) {
                            emp = JSON.parse(formData[k]);
                        }

                        if (k == 'group_id')
                            group_id = formData[k];

                        if (k == 'user_id')
                            user_id = formData[k];

                        if (k != 'user_id' && k != 'group_id' && k != this.state.empKey) {
                            obj[k] = formData[k];
                        }

                    });

                    if (this.state.empEditIndex != null) {
                        emp[this.state.empEditIndex] = obj;
                    } else {
                        emp.push(obj);
                    }
                    formData = { user_id: user_id, group_id: group_id };
                    formData[this.state.empKey] = JSON.stringify(emp);

                }

                /* employment form */


                /* education form */

                if (ftype == 'education_form') {
                    let obj = {};
                    let emp = [];
                    let group_id, user_id;
                    Object.keys(formData).map((k) => {
                        if (k == this.state.eduKey && formData[k] != '' /* && Object.prototype.toString.call(formData[k]) === '[object Array]' */) {
                            if (formData[k].length > 0)
                                emp = JSON.parse(formData[k]);
                        }
                        if (k == 'group_id')
                            group_id = formData[k];

                        if (k == 'user_id')
                            user_id = formData[k];

                        if (k != 'user_id' && k != 'group_id' && k != this.state.eduKey) {
                            obj[k] = formData[k];
                        }

                    });
                    if (this.state.eduEditIndex != null) {
                        emp[this.state.eduEditIndex] = obj;
                    } else {
                        emp.push(obj);
                    }
                    formData = { user_id: user_id, group_id: group_id };
                    formData[this.state.eduKey] = JSON.stringify(emp);

                }

                /* education form */
                if (ftype == 'career_profile_form' && is_upload == 0) {
                    let obj = {};
                    let emp = [];
                    let group_id, user_id;
                    let linkedpro = (this.state.career_profile_form[this.state.careerKey].length > 0 ? JSON.parse(this.state.career_profile_form[this.state.careerKey]) : []);
                    Object.keys(formData).map((k) => {
                        if (k == this.state.careerKey && (formData[k] != "" || formData[k].length <= 0)) {
                            linkedpro.push({ linked_profiles: this.state.curlinkedprofile });
                        }
                        if (k == 'group_id')
                            group_id = formData[k];
                        if (k == 'user_id')
                            user_id = formData[k];
                        if (k != 'user_id' && k != 'group_id' && k != this.state.careerKey) {
                            obj[k] = formData[k];
                        }
                    });
                    formData = { user_id: user_id, group_id: group_id };
                    formData[this.state.careerKey] = JSON.stringify(linkedpro);
                }

            }
            await this.props.updateProfile(formData);

            let res = this.props.update_profile_res;

            if (res) {

                this.setState({
                    is_loader: false
                });

                if (res.status == 'success') {
                    notify = notification({ message: res.message, type: 'success' });

                    /* change auth profile */
                    if (ftype == 'personal_detail_form') {
                        let user = await getLoggedInUser();
                        user['name'] = formData.name;
                        setLoggedInUser(user);
                    }
                    /* change auth profile */

                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    console.log(res.message)
                    notify = notification({ message: JSON.stringify(res.message), type: 'error' });
                }
            }

        } else {
            notify = notification({ message: 'Please fill the required fields correctly', type: 'error' });
        }

        if (notify)
            notify();

        return false;

    }

    /* handle submit */


    /* delete json */
    deleteJsonForm = (e, data, ftype, cardKey) => {

        if (ftype == 'education_form') {
            this.setState({
                eduDeleteIndex: cardKey,
                is_delete: true
            }, () => {
                this.handleSubmit(null, ftype, 1);
            })
        }
        if (ftype == 'career_profile_form') {
            this.setState({
                carDeleteIndex: cardKey,
                is_delete: true
            }, () => {
                this.handleSubmit(null, ftype, 1);
            })
        }


        if (ftype == 'employment_form') {
            this.setState({
                empDeleteIndex: cardKey,
                is_delete: true
            }, () => {
                this.handleSubmit(null, ftype, 1);
            })
        }

        if (ftype == 'language_form') {
            this.setState({
                langDeleteIndex: cardKey,
                is_delete: true
            }, () => {
                this.handleSubmit(null, ftype, 1);
            })
        }


    }
    /* delete json */

    /* edit json form */
    editJsonForm = (e, data, ftype, cardKey) => {

        console.log(cardKey);

        if (ftype == 'education_form') {
            this.setState({
                eduEditIndex: cardKey
            })
        }

        if (ftype == 'employment_form') {
            this.setState({
                empEditIndex: cardKey
            })
        }

        if (ftype == 'language_form') {
            this.setState({
                langEditIndex: cardKey
            })
        }

        let i = this.state[ftype];

        Object.keys(data).map((key) => {

            console.log(key);

            console.log(data[key]);

            i = {
                ...i,
                [key]: data[key]
            };

        });

        this.setState({
            [ftype]: i
        }, () => {
            console.log(this.state[ftype]);
        });

    }
    /* edit json form */

    render() {
        return (

            <div className="container">
                <div className="row">
                    <div className="col-md-9 p-0">
                        <EditPersonalDetailForm
                            handleSubmit={this.handleSubmit}
                            handleChange={this.handleChange}
                            editProfileData={this.state.edit_profile_data}
                            email={this.state.email}
                            //userName={this.state.userName}
                            mobile={this.state.mobile}
                            currentStateData={this.state}
                            is_loader={this.state.is_loader}
                            editJsonForm={this.editJsonForm}
                            deleteJsonForm={this.deleteJsonForm}
                            loaderType={this.state.loaderType}
                        />
                    </div>
                    {/* sidebar */}
                    <SideBar>
                        <ProfileName />
                        <ActionButtons />
                        <CandidateCards hello={{ hello: 'yes' }} />
                        <Skills />
                        <FeaturedCompanies />
                        <Designations />
                        <Locations />
                        <Company />
                    </SideBar>
                    {/* sidebar */}
                </div>
            </div>


        );
    }
}

/* state to props */
const mapStateToProps = (state) => {
    const { edit_profile_data, update_profile_res } = state.common;
    return {
        edit_profile_data,
        update_profile_res
    };
};
function mapDispatchToProps(dispatch) {
    return {
        updateProfile: (formData) => dispatch(updateProfile(formData)),
        editProfile: (id) => dispatch(editProfile(id)),
    };
}
/* state to props */

export default connect(mapStateToProps, mapDispatchToProps)(EditPersonalDetails);