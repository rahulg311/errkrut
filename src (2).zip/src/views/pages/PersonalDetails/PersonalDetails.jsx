import React, { Component } from "react";
import Header from "../../../components/common/Header";
import RecruiterHomeCard from "../../../components/Cards/RecruiterHomeCard";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import { getProfileCards } from "../../../store/actions/profile";
import { getLoggedInUser } from "../../../classes";
import { connect } from "react-redux";
import Personal from "./Personal";
import ProfileStrength from "./ProfileStrength";
import Summary from "./Summary";
import CareerProfile from "./CareerProfile";
import SideBar from "../../../components/hoc/SideBar";
import CandidateCards from "../../../components/Sidebars/Candidate/CandidateCards";
import Skills from "../../../components/Sidebars/Candidate/Skills";
import FeaturedCompanies from "../../../components/Sidebars/Candidate/FeaturedCompanies";
import Designations from "../../../components/Sidebars/Candidate/Designations";
import Locations from "../../../components/Sidebars/Candidate/Locations";
import Employment from "./Employment";
import Education from "./Education";
import Language from "./Language";
import { Recruiter_User_Type_ID } from "../../../config/constants";
import { routeChanged } from "../../../classes/browserHistory";
import Section from "../../../components/hoc/Section";
import Main from "../../../components/hoc/Main";
import Stats from "./Stats";
import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css"; // Import css
import { deleteAccount } from "../../../store/actions/signup";
import { APP_Prefix } from "../../../config/constants";
import DeleteAccount from "../../../components/Login/DeleteAccount";
import CampusProfile from "./CampusProfile";
import RecruimentHeadProfile from "./RecruitmentHeadProfile";

class PersonalDetails extends Component {
  state = {
    user_id: null,
    cards: null,
  };

  async componentWillMount() {
    const result = await getLoggedInUser();

    if (result?.user_type == Recruiter_User_Type_ID) {
      routeChanged("/company-profile", this.props, 1);
    }
    

    this.setState(
      {
        user_id: parseInt(result.id),
      },
      async () => {
        
        await this.props.getProfileCards(this.state.user_id);
        this.setState({
          cards: this.props.cand_cards,
        });
        console.log(this.props.cand_cards, "+++cand cards");
      }
    );
  }

  render() {
    const deleteAccount = async () => {
      confirmAlert({
        customUI: ({ onClose }) => {
          return (
            <div className="card shadow p-3">
              <div className="card-header bg-transparent">
                <h6>Please Confirm</h6>
              </div>
              <div className="card-body">
                <p>
                  {" "}
                  Please confirm if you want to delete your account? You will
                  loose access to the all your data.{" "}
                </p>
              </div>
              <div className="bg-transparent card-footer d-flex justify-content-end">
                <button className="btn btn-primary me-3" onClick={onClose}>
                  No
                </button>
                <button
                  className="btn btn-danger text-white"
                  onClick={() => {
                    handleClickDelete();
                    onClose();
                  }}
                >
                  Yes, Delete account!
                </button>
              </div>
            </div>
          );
        },
      });
    };

    const handleClickDelete = async () => {
      let user = await getLoggedInUser();

      if (user) {
        let obj = {};
        obj["user_id"] = user.id;

        await this.props.deleteAccount(user.id);
        localStorage.setItem(APP_Prefix + "auth_token", null);
        localStorage.setItem(APP_Prefix + "auth_profile", null);
        window.location.reload();
      }
    };

    return (
      <Section>
        <Main>
          {/* Content */}
          <div className="col-md-12">
            {/* <CampusProfile/> */}
            {/* attributes details */}
            {this.state.cards &&
              this.state.cards?.map((value, key) => {
                /* recruitement head profile details */
                if (value.CardTitle == "Campus Profile") {
                  return (
                    <>
                      <CampusProfile card={value} />
                    </>
                  );
                }
                /* recruitement head profile details */
                if (value.CardTitle == "Recruitment Head Profile") {
                  return (
                    <>
                      <RecruimentHeadProfile card={value} />
                    </>
                  );
                }

                /* personal details */
                if (value.CardTitle == "Candidate Stats") {
                  return (
                    <>
                      <Stats card={value} />
                    </>
                  );
                }

                {
                  /* personal details */
                  if (value.CardTitle == "Personal Details") {
                    return (
                      <>
                        <Personal card={value} />
                        <ProfileStrength />
                      </>
                    );
                  }

                  /* summary */
                  if (value.CardTitle == "Summary") {
                    return <Summary card={value} />;
                  }

                  /* career profile */
                  if (value.CardTitle == "Career Profile") {
                    return <CareerProfile card={value} />;
                  }

                  /* employment */
                  if (value.CardTitle == "Employment") {
                    return <Employment card={value} />;
                  }

                  /* education */
                  if (value.CardTitle == "Education") {
                    return <Education card={value} />;
                  }

                  /* language */
                  if (value.CardTitle == "Language") {
                    return <Language card={value} />;
                  }
                }
              })}

            <DeleteAccount></DeleteAccount>

            {/* attributes details */}
          </div>
          {/* Content */}
        </Main>
        {/* Sidebar */}

        <SideBar>
          <ProfileName />
          <CandidateCards hello={{ hello: "yes" }} />
          <Skills />
          <FeaturedCompanies />
          <Designations />
          <Locations />
          <Company />
        </SideBar>

        {/* Sidebar */}
      </Section>
    );
  }
}

const mapStateToProps = (state) => {
  const { cand_cards, delete_user } = state.common;
  return {
    cand_cards,
    delete_user,
  };
};

function mapDispatchToProps(dispatch) {
  return {
    getProfileCards: (id) => dispatch(getProfileCards(id)),
    deleteAccount: (user_id) => dispatch(deleteAccount(user_id)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(PersonalDetails);
