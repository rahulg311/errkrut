import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, getAuthToken } from '../../../classes/index';
import { getValueFromArr } from '../../../classes';

class CampusProfile extends Component {
  state = {
    user_id: '',
    mobile: null,
    email: null,
  }

  async componentDidMount() {
    const user = await getLoggedInUser();
    this.setState({
      user_id: user.id,
      email: user.email,
      mobile: user.mobile,
    });
  }

  render() {
    const card = this.props.card.values;
    console.log(card)
    return (

      <div className="container   ">
        <div className="row mt-2 ">
          <div className="col-md-11 col-10">
            <h5 className="f-Poppins-Medium">Campus Profile</h5>
          </div>
          <div className="col-md-1 col-2">
            <h3>
              <NavLink to={`/edit-profile/${this.state.user_id}`}>
                <i class="las la-edit text-blue"></i>
              </NavLink>
            </h3>
          </div>
        </div>
        <header className="d-flex">
          <div className="me-3 mt-2">
            <img
              src={(card[7].value) ? getValueFromArr(card[7].value, 0) : `/assets/imgs/dummy-logo.png`}
              className="img-fluid shadow br-5 h-60p"
            />
          </div>
          <div>
            <h4 className="font-bold  mt-2 f-Poppins-Medium">
              {card[0].value}
            </h4>
            <p>Location</p>
            <p>{card[3].title + " : " + card[3].value}</p>
          </div>
        </header>
        <div className="row">
          <div className="col-md-8">
            <div className="row  mt-2">
              <div className="col-md-6">
                <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                  <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                    <span className="f-1-1 m-0  p-0"> Education Type</span>{" "}
                  </p>
                  <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                    {" "}
                    <span className="">{card[4].value}</span>
                  </p>
                </div>
              </div>
              <div className="col-md-6">
                <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                  <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                    <span className="f-1-1 m-0  p-0"> Email</span>{" "}
                  </p>
                  <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                    {" "}
                    <span className="">{this.state.email}</span>
                  </p>
                </div>
              </div>
            </div>
            <div className="row mb-2 mt-2">
              <div className="col-md-6 ">
                <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                  <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                    <span className="f-1-1 m-0  p-0"> Website</span>{" "}
                  </p>
                  <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                    {" "}
                    <span className="">{card[5].value}</span>
                  </p>
                </div>
              </div>
              <div className="col-md-6">
                <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                  <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                    <span className="f-1-1 m-0  p-0"> Phone No</span>{" "}
                  </p>
                  <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                    {" "}
                    <span className="">{this.state.mobile}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4 mt-4">
            <div
              className="cards position-relative  bg-dark-pink
                             br-5 text-white p-2 h-172  mr-2"
            >
              <p className="position-abs t-2 l-2 m-0  f-Poppins-Regular ">
                Address
              </p>
              <p className="f-Poppins-Regular ">
                {card[1].value}
              </p>
              <p className="f-Poppins-Regular ">
                {card[2].value}
              </p>
              <p className="f-Poppins-Regular ">
                {card[10].value + ", " + card[9].value + ", " + card[8].value}
              </p>
            </div>
          </div>
        </div>
        <div className="mt-2 bg-white pb-4">
          <div className="row mt-2 ">
            <div className="col-md-11 col-10 ">
              <h5 className="f-Poppins-Medium mt-2">Summary</h5>
            </div>
            <div className="col-md-1 col-2 mt-2 ">
              <h3>

              </h3>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              <p className=" fs-17 f-Poppins-thin mt-2">
                {card[6].value}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

export default CampusProfile;
