import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class Language extends Component {

    render() {
        const { card } = this.props;

        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink', 'bg-info'];
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">
                    <div className="row mb-2">
                        <div className="col-md-11 col-10">
                            <h4 className="f-Poppins-Medium mt-2">{card.CardTitle}</h4>
                        </div>

                    </div>
                    <div>

                        <div className="row">
                            {
                                card.values && card.values?.map((fv, fk) => {
                                return fv.value && JSON.parse(fv.value).map((cardValue, cardKey) => {
                                    let lang = [];
                                    let car = "";
                                    if (cardValue.read_language == 1) lang.push("Read");
                                    if (cardValue.speak_language == 1) lang.push("Speak");
                                    if (cardValue.write_language == 1) lang.push("Write");
                                    if (cardValue.language_name == "English") car = "a";
                                    if (cardValue.language_name == "Hindi") car = "अ";
                                    if (cardValue.language_name == "Marathi") car = "अ";
                                    if (cardValue.language_name == "Tamil") car = "க்";
                                    return <div className="col-12 col-md-3 mt-3 text-white"><div className={`container shadow p-2 br-5 ${colors[cardKey%6]}`}>
                                        {/* <NavLink className="ms-auto language-edit" to="/edit-profile">
                                            <h4><i class="lar la-edit text-white cursor"></i></h4>
                                        </NavLink> */}
                                        <div >
                                            <header >
                                                <div className='text-center'>
                                                    <h5 className='font-bold'>{cardValue.language_name}</h5>
                                                    <h1>{car}</h1>
                                                    <p> {lang.join()}</p>
                                                </div>
                                            </header>
                                        </div>
                                    </div>
                                    </div>
                                });
                            })}

                        </div>

                    </div>
                </div>
            </>
        );

    }
}

export default Language;