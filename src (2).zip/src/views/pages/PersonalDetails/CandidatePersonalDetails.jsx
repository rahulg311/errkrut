import React, { Component } from 'react';
import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { getProfileCards } from '../../../store/actions/profile';
import { getLoggedInUser } from '../../../classes';
import { connect } from 'react-redux';
import Personal from './Personal';
import ProfileStrength from './ProfileStrength';
import CandidateSummary from './CandidateSummary';
import CandidateCareerProfile from './CandidateCareerProfile';
import SideBar from '../../../components/hoc/SideBar';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import CandidateEmployment from './CandidateEmployment';
import CandidateEducation from './CandidateEducation';
import CandidateLanguage from './CandidateLanguage';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import { routeChanged } from '../../../classes/browserHistory';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import CandidateStats from './CandidateStats';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { APP_Prefix } from '../../../config/constants';

class PersonalDetails extends Component {

   state = {
      user_id: this.props.match.params?.id,
      cards: null
   }

   async componentWillMount() {

      this.setState(
         {
            user_id: parseInt(this.props.match.params?.id)
         },
         async () => {
             await this.props.getProfileCards(this.props.match.params?.id);
            this.setState({
               cards: this.props.cand_cards
            })
         },
      );

   }


   render() {

      return (

         <Section>

            <Main>
               {/* Content */}
               <div className='col-md-12'>

                  {/* attributes details */}
                  {this.state.cards && this.state.cards?.map((value, key) => {

                     /* personal details */
                     if (value.CardTitle == 'Candidate Stats') {
                        return <><CandidateStats
                           card={value}
                        />
                        </>
                     }

                     {
                        /* summary */
                        if (value.CardTitle == 'Summary') {
                           return <CandidateSummary
                              card={value}
                           />
                        }

                        /* career profile */
                        if (value.CardTitle == "Career Profile") {
                           return <CandidateCareerProfile
                              card={value}
                           />
                        }

                        /* employment */
                        if (value.CardTitle == "Employment") {
                           return <CandidateEmployment
                              card={value}
                           />
                        }

                        /* education */
                        if (value.CardTitle == "Education") {
                           return <CandidateEducation
                              card={value}
                           />
                        }

                        /* language */
                        if (value.CardTitle == "Language") {
                           return <CandidateLanguage
                              card={value}
                           />
                        }


                     }
                  })}

                  {/* attributes details */}

               </div>
               {/* Content */}
            </Main>
            {/* Sidebar */}

            <SideBar>
						<ProfileName />
						<ActionButtons />
						<CandidateCards />
						<Skills />
						<FeaturedCompanies />
						<Designations />
						<Locations />
						<Company />
					</SideBar>

            {/* Sidebar */}
         </Section>
      );
   }
}

const mapStateToProps = (state) => {

   const { cand_cards, delete_user } = state.common
   return {
      cand_cards, delete_user
   }
};

function mapDispatchToProps(dispatch) {
   return {
      getProfileCards: (id) => dispatch(getProfileCards(id))
   };
}

export default connect(mapStateToProps, mapDispatchToProps)(PersonalDetails);
