import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { FileNameFromURL, getLoggedInUser, shuffleArray } from '../../../classes';
import { getProfile } from '../../../store/actions/profile';

class CandidateCareerProfile extends Component {

    state = {
        user_data: null
    }

    async componentDidMount() {

        const result = await getLoggedInUser();

        if (result) {
            this.setState({
                user_id: result.id,
                email: result.email,
                mobile: result.mobile
            }, async () => {
                await this.props.getProfile(result.id);
                if (this.props.data?.user_data) {
                    this.setState({
                        user_data: this.props.data
                    });
                }

            });
        }

    }

    render() {
        const { card } = this.props;


        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink', 'bg-info'];
        return (
            <>
                <div className="container p-4 bg-white rounded-5 shadow mb-3">

                    <div className="row mt-2">
                        <div className="col-md-11 col-10 ">
                            <h4 className="f-Poppins-Medium mt-2">{card.CardTitle}</h4>
                        </div>

                    </div>

                    <div className="row">
                        {card.values.length > 0 && card.values.map((res, k) => {
                            return <>


                                <div className="col-md-4 mt-4">
                                    <div className={`card border-0 shadow h-100 position-relative br-5 text-white p-2 mr-2 ${colors[k]}`}>

                                        <div className="d-flex align-items-start flex-column ">
                                            <div className="">
                                                <h6 className="f-Poppins-Regular">{res.title}</h6>

                                                <div class="d-grid gap-2">

                                                </div>
                                            </div>

                                            {res.value && JSON.parse(res.value)?.map((file) => {
                                                return <p className="mt-1 mb-0"><a className="btn btn-light text-primary mt-auto btn-sm mb-2" href={file} target="_blank">Download {res.title}</a></p>
                                            })}
											{!res.value
											&&
											<span>N/A</span>
											}
                                        </div>
                                    </div>
                                </div>
                            </>
                        })}

                    </div>
                </div>
            </>
        );

    }
}


const mapStateToProps = (state) => {

    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        getProfile: (id) => dispatch(getProfile(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CandidateCareerProfile);