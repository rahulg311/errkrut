import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { MimeIcon } from '../../../classes';
import { parseArrayToHTML } from '../../../classes/handleHtml';
import { connect } from "react-redux";
import Loading from '../../../components/common/Loading';
import {
	getCountryCategory,
	getStateCategory,
	getCityCategory,
	getCountryPCategory,
	getStatePCategory,
	getCityPCategory,
  } from "../../../store/actions/signup";

import { getValueFromArr } from '../../../classes';

class EditPersonalDetailForm extends Component {
    state = {
        statecount : true,
        citycount : true,
        statePcount : true,
        cityPcount : true,
    }
    componentDidMount() {
		this.props.getCountryCategory();
		this.props.getCountryPCategory();
	  }
	
	  getStateCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getStateCategory(id);
		}
	  }
      callgetStateCategory (ids){
        this.props.getStateCategory(ids); 
      }
	
	  getCityCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getCityCategory(id);
		}
	  }
      callgetCityCategory(ids){
        this.props.getCityCategory(ids); 
      }

      getStatePCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getStatePCategory(id);
		}
	  }
      callgetStatePCategory (ids){
        this.props.getStatePCategory(ids); 
      }
	
	  getCityPCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getCityPCategory(id);
		}
	  }
      callgetCityPCategory(ids){
        this.props.getCityPCategory(ids); 
      }


    render() {

        const { handleChange, handleSubmit, editProfileData, email, mobile, visibility, currentStateData, is_loader, editJsonForm, deleteJsonForm, userName, loaderType } = this.props;

        const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink', 'bg-info'];
        //console.log(currentStateData)

        return (

            <>

                <div className="mb-5">


                    {(editProfileData?.length > 0 && editProfileData != null) && editProfileData.map((value, key) => {
                        /* Personal Details Starts Here */
                        if (value.CardTitle == "Edit Campus Profile")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div>
                                        <h5 className="f-Poppins-Medium mt-2 mb-2">
                                            {value.CardTitle}
                                        </h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>
                                        <form method="POST" onSubmit={(e) => { handleSubmit(e, 'campus_profile_form') }} name="editcampusprofileForm">

                                            <div className="w-90 w-xs-100">
                                                <div className="row mt-2 mb-2">

                                                    {value.values?.length > 0 && value.values?.map((fv, fk) => {

                                                        let fieldObj = {
                                                            name: fv.name,
                                                            type: fv.type,
                                                            class: 'form-control',
                                                            attr_options: fv.attr_options,
                                                            title: fv.title,
                                                            id: fv.id,
                                                            value: fv.value
                                                        };
                                                        if(fv.name == "country"){
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => {handleChange(e, '', '', 'campus_profile_form'); this.getStatePCategory(e);}}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select Country--
                                                                        </option>
                                                                        {this.props.country_category_p_res?.data &&
                                                                            this.props.country_category_p_res?.data.map((opt) => {
                                                                                
                                                                                if((opt.name.toLowerCase() === fv.value.toLowerCase()) && this.state.statePcount){
                                                                                    this.setState({statePcount: false});
                                                                                    this.callgetStatePCategory(opt.id)
                                                                                    
                                                                                }
                                                                            return <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>;
                                                                        })}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }
                                                        if(fv.name == "state"){
                                                            
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => {handleChange(e, '', '', 'campus_profile_form'); this.getCityPCategory(e);}}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select State--
                                                                        </option>
                                                                        {this.props.state_category_p_res?.data &&
                                                                        this.props.state_category_p_res?.data.map((opt) => {
                                                                            if((opt.name.toLowerCase() === fv.value.toLowerCase()) && this.state.cityPcount){
                                                                                this.setState({cityPcount: false});
                                                                                this.callgetCityPCategory(opt.id)
                                                                                
                                                                            }
                                                                            return <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>;
                                                                        })}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }
                                                        if(fv.name == "city"){
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => handleChange(e, '', '', 'campus_profile_form')}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select City--
                                                                        </option>
                                                                        {this.props.city_category_p_res?.data &&
                                                                        this.props.city_category_p_res?.data.map(
                                                                        (opt) => {
                                                                            return (
                                                                            <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>
                                                                            );
                                                                        }
                                                                        )}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }

                                                        return (
                                                            <>
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                        <div class='col-md-12'>
                                                                            <label className='f-1 text-blue'>{fv.title}</label>
                                                                        </div>
                                                                        <div class='col-md-12'>


                                                                            {
                                                                                parseArrayToHTML(
                                                                                    fieldObj,
                                                                                    (e) => handleChange(e, '', '', 'campus_profile_form'),
                                                                                    currentStateData?.campus_profile_form ? currentStateData?.campus_profile_form[fv.name] : ''
                                                                                )
                                                                            }
                                                                            {fv.type == "File" ? <span className='ps-1'>{currentStateData.files ? currentStateData.files.campus_profile_form[fv.name][0]?.name: ''}</span> : ''}
                                                                            {fv.type == "File" && fv.value ? <img className="img-fluid shadow br-5 h-60p ms-2" src={getValueFromArr(fv.value, 0)} alt=""/> : ''}
                                                                            
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </>
                                                        );
                                                    })}

                                                    {/* Email */}
                                                    {!email &&
                                                        <div class='col-md-6'>
                                                            <div class='row mb-2'>
                                                                <div class='col-md-12'>
                                                                    <label className='f-1 text-blue'>Email</label>
                                                                </div>
                                                                <div class='col-md-12'>
                                                                    <input type="email" className="form-control" name="u_email " defaultValue={email}
                                                                        onChange={(e) => { handleChange(e, '', '', 'campus_profile_form') }}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    }
                                                    {/* Email */}

                                                    {/* Mobile */}
                                                    {!mobile &&
                                                        <div class='col-md-6'>
                                                            <div class='row mb-2'>
                                                                <div class='col-md-12'>
                                                                    <label className='f-1 text-blue'>Mobile</label>
                                                                </div>
                                                                <div class='col-md-12'>
                                                                    <input type="number" className="form-control" name="u_mobile" defaultValue={mobile}
                                                                        onChange={(e) => { handleChange(e, '', '', 'campus_profile_form') }}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    }
                                                    {/* Mobile */}

                                                    {/* Profile Visibility */}

                                                    {/* <div class='col-md-6'>
                                                        <div class='row mb-2'>
                                                            <div class='col-md-12'>
                                                                <label className='f-1 text-blue'>Profile Visibility</label>
                                                            </div>
                                                            <div class='col-md-12'>
                                                                <select name="visibility" name="visibility" className='form-control input-border' defaultValue={visibility} onChange={(e) => { handleChange(e, '', '', 'personal_detail_form') }}>
                                                                    <option value="">Select Profile Visibility</option>
                                                                    <option value="1">Visible To Recruiters</option>
                                                                    <option value="0">Hide from Recruiters</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div> */}

                                                    {/* Mobile */}

                                                </div>

                                                {/* submit button */}
                                                <div className="d-flex mt-2 mb-2">
                                                    <div className="me-auto">
                                                        <NavLink to="/profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
                                                    </div>
                                                    <div className="ms-auto">
                                                        <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                        {(is_loader && loaderType == 'campus_profile_form') && <Loading />}
                                                    </div>
                                                </div>
                                                {/* submit button */}
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </>;

                        /* Edit Campus Profile Ends Here */


                        /* Edit Recruitment Head Profile Starts Here */
                        if (value.CardTitle == "Edit Recruitment Head Profile")
                            
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div>
                                        <h5 className="f-Poppins-Medium mt-2 mb-2">
                                            {value.CardTitle}
                                        </h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>
                                        <form method="POST" onSubmit={(e) => { handleSubmit(e, 'recruitment_head_profile_form') }} name="editrecruitmentheadprofileForm">

                                            <div className="w-90 w-xs-100">
                                                <div className="row mt-2 mb-2">

                                                    {value.values?.length > 0 && value.values?.map((fv, fk) => {

                                                        let fieldObj = {
                                                            name: fv.name,
                                                            type: fv.type,
                                                            class: 'form-control',
                                                            attr_options: fv.attr_options,
                                                            title: fv.title,
                                                            id: fv.id,
                                                            value: fv.value
                                                        };

                                                        if(fv.name == "rh_country"){
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => {handleChange(e, '', '', 'recruitment_head_profile_form'); this.getStateCategory(e);}}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select Country--
                                                                        </option>
                                                                        {this.props.country_category_res?.data &&
                                                                            this.props.country_category_res?.data.map((opt) => {
                                                                                
                                                                                if((opt.name.toLowerCase() === fv.value.toLowerCase()) && this.state.statecount){
                                                                                    this.setState({statecount: false});
                                                                                    this.callgetStateCategory(opt.id)
                                                                                    
                                                                                }
                                                                            return <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>;
                                                                        })}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }
                                                        if(fv.name == "rh_state"){
                                                            
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => {handleChange(e, '', '', 'recruitment_head_profile_form'); this.getCityCategory(e);}}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select State--
                                                                        </option>
                                                                        {this.props.state_category_res?.data &&
                                                                        this.props.state_category_res?.data.map((opt) => {
                                                                            if((opt.name.toLowerCase() === fv.value.toLowerCase()) && this.state.citycount){
                                                                                this.setState({citycount: false});
                                                                                this.callgetCityCategory(opt.id)
                                                                                
                                                                            }
                                                                            return <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>;
                                                                        })}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }
                                                        if(fv.name == "rh_city"){
                                                            return(
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                    <div class='col-md-12'>
                                                                        <label className='f-1 text-blue'>{fv.title}</label>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <select
                                                                        className="form-control"
                                                                        name={fv.name}
                                                                        onChange={(e) => handleChange(e, '', '', 'recruitment_head_profile_form')}
                                                                        >
                                                                        <option value="" selected disabled>
                                                                            --Select City--
                                                                        </option>
                                                                        {this.props.city_category_res?.data &&
                                                                        this.props.city_category_res?.data.map(
                                                                        (opt) => {
                                                                            return (
                                                                            <option id={opt.id} value={opt.name} selected={(opt.name.toLowerCase() == fv.value.toLowerCase()) ? true : false}>{opt.name}</option>
                                                                            );
                                                                        }
                                                                        )}
                                                                        </select>
                                                                    </div>
                                                                    </div>    
                                                                </div>    
                                                            )
                                                        }
                                                        return (
                                                            <>
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                        <div class='col-md-12'>
                                                                            <label className='f-1 text-blue'>{fv.title}</label>
                                                                        </div>
                                                                        <div class='col-md-12'>


                                                                            {
                                                                                parseArrayToHTML(
                                                                                    fieldObj,
                                                                                    (e) => handleChange(e, '', '', 'recruitment_head_profile_form'),
                                                                                    currentStateData?.recruitment_head_profile_form ? currentStateData?.recruitment_head_profile_form[fv.name] : ''
                                                                                )
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </>
                                                        );
                                                    })}

                                                </div>

                                                {/* submit button */}
                                                <div className="d-flex mt-2 mb-2">
                                                    <div className="me-auto">
                                                        <NavLink to="/profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
                                                    </div>
                                                    <div className="ms-auto">
                                                        <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                        {(is_loader && loaderType == 'recruitment_head_profile_form') && <Loading />}
                                                    </div>
                                                </div>
                                                {/* submit button */}
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </>;

                        /* Edit Recruitment Head Profile Ends Here */
                        /* Personal Details Starts Here */
                        if (value.CardTitle == "Edit Personal Details")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div>
                                        <h5 className="f-Poppins-Medium mt-2 mb-2">
                                            {value.CardTitle}
                                        </h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>
                                        <form method="POST" onSubmit={(e) => { handleSubmit(e, 'personal_detail_form') }} name="editPersonalDetailsForm">

                                            <div className="w-90 w-xs-100">
                                                <div className="row mt-2 mb-2">

                                                    {value.values?.length > 0 && value.values?.map((fv, fk) => {

                                                        let fieldObj = {
                                                            name: fv.name,
                                                            type: fv.type,
                                                            class: 'form-control',
                                                            attr_options: fv.attr_options,
                                                            title: fv.title,
                                                            id: fv.id,
                                                        };

                                                        return (
                                                            <>
                                                                <div class='col-md-6'>
                                                                    <div class='row mb-2'>
                                                                        <div class='col-md-12'>
                                                                            <label className='f-1 text-blue'>{fv.title}</label>
                                                                        </div>
                                                                        <div class='col-md-12'>


                                                                            {
                                                                                parseArrayToHTML(
                                                                                    fieldObj,
                                                                                    (e) => handleChange(e, '', '', 'personal_detail_form'),
                                                                                    currentStateData?.personal_detail_form ? currentStateData?.personal_detail_form[fv.name] : ''
                                                                                )
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </>
                                                        );
                                                    })}

                                                    {/* Email */}
                                                    {email &&
                                                        <div class='col-md-6'>
                                                            <div class='row mb-2'>
                                                                <div class='col-md-12'>
                                                                    <label className='f-1 text-blue'>Email(Can not be updated)</label>
                                                                </div>
                                                                <div class='col-md-12'>
                                                                    <input type="text" readOnly className="form-control" name="email" defaultValue={email}
                                                                        onChange={(e) => { handleChange(e, '', '', 'personal_detail_form') }}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    }
                                                    {/* Email */}

                                                    {/* Mobile */}
                                                    {mobile &&
                                                        <div class='col-md-6'>
                                                            <div class='row mb-2'>
                                                                <div class='col-md-12'>
                                                                    <label className='f-1 text-blue'>Mobile</label>
                                                                </div>
                                                                <div class='col-md-12'>
                                                                    <input type="text" readOnly className="form-control" name="mobile" defaultValue={mobile}
                                                                        onChange={(e) => { handleChange(e, '', '', 'personal_detail_form') }}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    }
                                                    {/* Mobile */}

                                                    {/* Profile Visibility */}

                                                    {/* <div class='col-md-6'>
                                                        <div class='row mb-2'>
                                                            <div class='col-md-12'>
                                                                <label className='f-1 text-blue'>Profile Visibility</label>
                                                            </div>
                                                            <div class='col-md-12'>
                                                                <select name="visibility" name="visibility" className='form-control input-border' defaultValue={visibility} onChange={(e) => { handleChange(e, '', '', 'personal_detail_form') }}>
                                                                    <option value="">Select Profile Visibility</option>
                                                                    <option value="1">Visible To Recruiters</option>
                                                                    <option value="0">Hide from Recruiters</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div> */}

                                                    {/* Mobile */}

                                                </div>

                                                {/* submit button */}
                                                <div className="d-flex mt-2 mb-2">
                                                    <div className="me-auto">
                                                        <NavLink to="/profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
                                                    </div>
                                                    <div className="ms-auto">
                                                        <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                        {(is_loader && loaderType == 'personal_detail_form') && <Loading />}
                                                    </div>
                                                </div>
                                                {/* submit button */}
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </>;

                        /* Personal Details Ends Here */

                        /* summary starts here */
                        if (value.CardTitle == "Edit Summary")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <h5 className="f-Poppins-Medium mt-2 mb-2">
                                        {value.CardTitle}
                                    </h5>
                                    <div className="border-gray-line mt-2 mb-2"></div>
                                    <div className="bg-white mt-5 w-xs-100 w-90">
                                        <div>
                                            <form method="POST" onSubmit={(e) => { handleSubmit(e, 'summary_form') }} name="editSummaryForm">

                                                {value.values?.length > 0 && value.values?.map((fv, fk) => {

                                                    let fieldObj = {
                                                        name: fv.name,
                                                        type: fv.type,
                                                        class: 'form-control',
                                                        attr_options: fv.attr_options,
                                                        title: fv.title,
                                                    };

                                                    return (
                                                        <>
                                                            <div class='row mb-2'>
                                                                <div class='col-md-12'>
                                                                    <label className='f-1 text-blue'>{fv.title}</label>
                                                                </div>
                                                                <div class='col-md-12'>
                                                                    {parseArrayToHTML(
                                                                        fieldObj,
                                                                        (e) => handleChange(e, '', '', 'summary_form'),
                                                                        currentStateData?.summary_form ? currentStateData?.summary_form[fv.name] : ''
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </>
                                                    );
                                                })}

                                                {/* submit button */}
                                                <div className="d-flex mt-2 mb-2">
                                                    <div className="me-auto">
                                                        <NavLink to="/profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
                                                    </div>
                                                    <div className="ms-auto">
                                                        <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                        {(is_loader && loaderType == 'summary_form') && <Loading />}
                                                    </div>
                                                </div>
                                                {/* submit button */}

                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </>
                        /* summary ends here */


                        /* edit career profile starts here */
                        if (value.CardTitle == "Edit Career Profile")
                            return <>
                                <div className="bg-white p-4  mb-3">
                                    <div className="bg-white mt-4">

                                        <h5 className="f-Poppins-Medium">{value.CardTitle}</h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>

                                        <div className="bg-white mt-5 w-xs-100 w-90">

                                            <form method="POST" onSubmit={(e) => { handleSubmit(e, 'career_profile_form') }} name="editCareerProfileForm">
                                                {value.values?.length > 0 && value.values?.map((fv, fk) => {
                                                    let fieldObj = {
                                                        name: fv.name,
                                                        type: fv.type,
                                                        class: 'form-control',
                                                        attr_options: fv.attr_options,
                                                        title: fv.title,
                                                    };
                                                    return (
                                                        <>
                                                            {fv.type == "File" && <>
                                                                <div className="row">
                                                                    <div className="col-md-10 col-9">
                                                            <div className='d-flex flex-row'>
                                                                        <h6 className="align-middle"><p>{fv.title}&nbsp;&nbsp;</p></h6>
                                                                        {(fv.title != 'Resume') &&
                                                                        <small>(Please add all your {fv.title} in 1 file and upload)</small>
                                                                        }
                                                                        </div>
                                                                        {fv.value != '' &&
                                                                            <>
                                                                                {/* Download Files Starts here */}
                                                                                <div className="d-flex flex-wrap">
                                                                                    {(typeof fv.value === 'object' ||
                                                                                        !Array.isArray(fv.value)) &&
                                                                                        fv.value !== null && JSON.parse(fv.value).map((k) => {
                                                                                            return <a href={k} target="_blank" className="font-bold me-2">
                                                                                                <p className="m-0 text-center">
                                                                                                    <span className="f-4 d-block">
                                                                                                        {MimeIcon(k)}
                                                                                                    </span>
                                                                                                    <span className="d-block">View</span>
                                                                                                </p>
                                                                                            </a>


                                                                                        })}

                                                                                </div>

                                                                                {/* Download Files Ends here */}
                                                                            </>
                                                                        }

                                                                    </div>
                                                                    <div className="col-md-2 col-3">

                                                                        <label className="text-primary cursor" for={`file_${fv.name}`}>
                                                                            <span className="align-top align-middle">Upload</span>
                                                                            <i class="las la-file-import align-middle"></i>

                                                                            {/* loader stars here */}
                                                                            {(is_loader && loaderType == 'career_profile_form') && <Loading />}
                                                                            {/* loader ends here */}
                                                                        </label>

                                                                        {/* show file name */}
                                                                        {
                                                                            currentStateData.files != null &&
                                                                            Object.keys(currentStateData?.files?.career_profile_form)?.map((fileKey) => {
                                                                                return Object.keys(currentStateData?.files?.career_profile_form[fileKey]).map((k) => {
                                                                                    if (fv.name == fileKey)
                                                                                        return <p>{currentStateData?.files?.career_profile_form[fileKey][k].name}</p>
                                                                                })
                                                                            })
                                                                        }
                                                                        {/* show file name */}

                                                                        <input type="file" id={`file_${fv.name}`} style={{ display: "none" }} name={fv.name} multiple onChange={(e) => {
                                                                            handleChange(e, '', '', 'career_profile_form')
                                                                        }} />

                                                                    </div>
                                                                </div>

                                                                <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                                                            </>
                                                            }
                                                            {
                                                                fv.type == "Text" && <>
                                                                    <div class='col-md-12'>
                                                                        <div class='row mb-2'>
                                                                            <div class='col-md-12'>
                                                                                <label className='f-1 text-blue'>{fv.title}</label>
                                                                            </div>
                                                                            <div class='row col-md-12'>

                                                                                <input type="text" name={fieldObj.name} onChange={(e) => handleChange(e, '', '', 'career_profile_form')} class={" linked col-md-6 " + fieldObj.class} id={`id_${fieldObj.id}`} />
                                                                                <button type="submit" className="col-md-2 btn btn-primary d-block btn-sm">Add</button>

                                                                                </div>

                                                                                {
                                                                                    fv.value && JSON.parse(fv.value).map((profile, cardKey) => {
                                                                                        return <>
                                                                                            <p>
                                                                                                <span onClick={(e) => deleteJsonForm(e, profile, 'career_profile_form', cardKey)}><i class="las la-times text-danger cursor"></i></span>
                                                                                                {profile.linked_profiles}
                                                                                            </p></>
                                                                                    })
                                                                                }

                                                                        </div>
                                                                    </div></>
                                                            }
                                                        </>
                                                    );

                                                })}



                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </>
                        /* edit career profile ends here */

                        {/* employment  starts here */ }

                        if (value.CardTitle == "Add or Edit Employment")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div className="bg-white mt-4">

                                        <h5 className="f-Poppins-Medium">{value.CardTitle}</h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>

                                        {/* Edit Form Starts Here */}
                                        <div className="bg-white w-xs-100 w-90">
                                            <form method="POST" onSubmit={(e) => { handleSubmit(e, 'employment_form') }} name="editEmploymentForm">

                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Company Name
                                                        </label>
                                                        <input
                                                            type='text'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='company_name'
                                                            placeholder="Enter your Company Name"
                                                            defaultValue={currentStateData['employment_form']?.company_name}
                                                            value={currentStateData['employment_form']?.company_name}
                                                            required={true}
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Designation
                                                        </label>
                                                        <input
                                                            type='text'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='designation'
                                                            placeholder="UX Designer"
                                                            defaultValue={currentStateData['employment_form']?.designation}
                                                            required={true}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2 ">
                                                            Joining Date
                                                        </label>
                                                        <input
                                                            type='date'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='joining_date'
                                                            placeholder="Select Joining Date"
                                                            defaultValue={currentStateData['employment_form']?.joining_date}
                                                            required={true}
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Leaving Date
                                                        </label>
                                                        <input
                                                            type='date'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='leaving_date'
                                                            placeholder="Select Leaving Date"
                                                            defaultValue={currentStateData['employment_form']?.leaving_date}
                                                            required={true}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2 ">
                                                            Notice Period(in days)
                                                        </label>
                                                        <input
                                                            type='number'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='notice_period'
                                                            placeholder="Select Notice Period"
                                                            defaultValue={currentStateData['employment_form']?.notice_period}
                                                            required={true}
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Curent Salary (in lakhs per annum)
                                                        </label>
                                                        <input
                                                            type='number'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')}
                                                            name='current_salary'
                                                            defaultValue={currentStateData['employment_form']?.current_salary}
                                                            placeholder="Current Salary"
                                                            required={true}
                                                        />

                                                    </div>
                                                    <div className="row w-100 p-0 m-0">
                                                        <div className="col-md-12">
                                                            <label className="mt-2">
                                                                Job Profile (500 words)
                                                            </label>
                                                            <textarea className="w-100 h-100p p-2" name="job_profile" onChange={(e) => handleChange(e, 'required', 'This field is required', 'employment_form')} required={true}>
                                                                {currentStateData['employment_form']?.job_profile}
                                                            </textarea>
                                                        </div>
                                                    </div>
                                                    {/* ADD BUTTON  */}

                                                    <div className="d-flex mt-2 mb-2">
                                                        <div className="me-auto">
                                                            <NavLink to="/profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
                                                        </div>
                                                        <div className="ms-auto">
                                                            <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                            {(is_loader && loaderType == 'employment_form') && <Loading />}
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>

                                            {/* Edit Form Ends Here */}

                                            {console.log('employmentttt: ', value.values)}

                                            {/* card starts here */}

                                            {
                                                value.values != '' && value.values?.map((fv, fk) => {



                                                    return fv.value && JSON.parse(fv.value).map((card, cardKey) => {

                                                        return <div className="container shadow mt-5 p-2 br-5">

                                                            <div className="d-flex">
                                                                <header className='d-flex'>
                                                                    <div>
                                                                        <h5 className='font-bold'>{card.company_name}</h5>
                                                                        <p>{card.company_name}</p>
                                                                        <p>{card.joining_date}</p>
                                                                    </div>
                                                                </header>

                                                                <div className="ms-auto">
                                                                    <h4 onClick={(e) => editJsonForm(e, card, 'employment_form', cardKey)}><i class="lar la-edit text-primary cursor"></i></h4>

                                                                    <h4 onClick={(e) => deleteJsonForm(e, card, 'employment_form', cardKey)}><i class="las la-trash text-danger cursor"></i></h4>
                                                                </div>
                                                            </div>


                                                        </div>


                                                    });

                                                })
                                            }

                                            {/* card ends here */}

                                        </div>

                                    </div>
                                </div>
                            </>

                        {/* employment ends here */ }


                        {/* education  starts here */ }

                        if (value.CardTitle == "Add or Edit Education")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div className="bg-white mt-4">

                                        <h5 className="f-Poppins-Medium">{value.CardTitle}</h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>

                                        {/* Edit Form Starts Here */}
                                        <div className="bg-white w-xs-100 w-90">
                                            <form method="POST" onSubmit={(e) => { handleSubmit(e, 'education_form') }} name="editEducationForm">

                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Education Level
                                                        </label>

                                                        <select name="education_level" className='form-control input-border' defaultValue={currentStateData['education_form']?.education_level} onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')} value={currentStateData['education_form']?.education_level} required>

                                                            <option value="">Education Level</option>
                                                            <option value="12th">12th</option>
                                                            <option value="Under Graduate">Under Graduate</option>
                                                            <option value="Graduate">Graduate</option>
                                                            <option value="Post Graduate">Post Graduate</option>

                                                        </select>

                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Course
                                                        </label>
                                                        <select name="course" className='form-control input-border' defaultValue={currentStateData['education_form']?.course} value={currentStateData['education_form']?.course} onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')} required>
                                                            <option value="">Course</option>
                                                            <option value="BCA">BCA</option>
                                                            <option value="MCA">MCA</option>
                                                            <option value="BBA">BBA</option>
                                                            <option value="MBA">MBA</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2 ">
                                                            Specialization
                                                        </label>
                                                        <input
                                                            type='text'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')}
                                                            name='specialization'
                                                            placeholder="Enter Your Specialization"
                                                            defaultValue={currentStateData['education_form']?.specialization}
                                                            required
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            University / Institute
                                                        </label>
                                                        <input
                                                            type='text'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')}
                                                            name='university_institute'
                                                            placeholder="University Institute"
                                                            defaultValue={currentStateData['education_form']?.university_institute}
                                                            required
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row mt-2 mb-2">
                                                    <div className="col-md-6">
                                                        <label className="mt-2 ">
                                                            Year of Passing
                                                        </label>
                                                        <input
                                                            type='number'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')}
                                                            name='year_of_passing'
                                                            placeholder="Year of Passing"
                                                            defaultValue={currentStateData['education_form']?.year_of_passing}
                                                            required
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <label className="mt-2">
                                                            Grades
                                                        </label>
                                                        <input
                                                            type='text'
                                                            className='form-control input-border'
                                                            onChange={(e) => handleChange(e, 'required', 'This field is required', 'education_form')}
                                                            name='grades'
                                                            placeholder="Grades"
                                                            defaultValue={currentStateData['education_form']?.grades}
                                                            required
                                                        />

                                                    </div>
                                                    {/* ADD BUTTON  */}

                                                    <div className="d-flex mt-2 mb-2">
                                                        <div className="me-auto">

                                                        </div>
                                                        <div className="ms-auto">
                                                            <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                            {(is_loader && loaderType == 'education_form') && <Loading />}
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>

                                            {/* Edit Form Ends Here */}

                                            {/* card starts here */}

                                            {value.values != '' && value.values?.map((fv, fk) => {


                                                return fv.value && JSON.parse(fv.value).map((card, cardKey) => {

                                                    return <div className="container shadow mt-5 p-2 br-5">

                                                        <div className="d-flex">
                                                            <header className='d-flex'>
                                                                <div>
                                                                    <h5 className='font-bold'>{card.education_level}</h5>
                                                                    <p>{card.course}</p>
                                                                    <p>{card.specialization}</p>
                                                                </div>
                                                            </header>

                                                            <div className="ms-auto">

                                                                <h4 onClick={(e) => editJsonForm(e, card, 'education_form', cardKey)}><i class="lar la-edit text-primary cursor"></i></h4>

                                                                <h4 onClick={(e) => deleteJsonForm(e, card, 'education_form', cardKey)}><i class="las la-trash text-danger cursor"></i></h4>
                                                            </div>
                                                        </div>


                                                    </div>


                                                });

                                            })}

                                            {/* card ends here */}

                                        </div>

                                    </div>
                                </div>
                            </>

                        {/* education ends here */ }


                        {/* language  starts here */ }

                        if (value.CardTitle == "Language")
                            return <>
                                <div className="bg-white p-4 mb-3">
                                    <div className="bg-white mt-4">

                                        <h5 className="f-Poppins-Medium">{value.CardTitle}</h5>
                                        <div className="border-gray-line mt-2 mb-2"></div>

                                        {/* Edit language_form Starts Here */}
                                        <div className="bg-white w-xs-100 w-90">
                                            <form method="POST" onSubmit={(e) => { handleSubmit(e, 'language_form') }} name="editLanguageForm">

                                                <div className="row mt-2 mb-2">

                                                    <div className="col-md-12 mt-2 mb-2">

                                                        <label className="mt-2">
                                                            Select Language
                                                        </label>

                                                        <select name="language_name" className='form-control input-border' defaultValue={currentStateData['language_form']?.education_level} onChange={(e) => handleChange(e, 'required', 'This field is required', 'language_form')} value={currentStateData['language_form']?.language_name} required>

                                                            <option value="">Select Language</option>
                                                            <option value="English">English</option>
                                                            <option value="Hindi">Hindi</option>
                                                            <option value="Marathi">Marathi</option>
                                                            <option value="Tamil">Tamil</option>

                                                        </select>

                                                    </div>

                                                    <div className="col-md-12">

                                                        {/* access starts here */}

                                                        <label className="text-dark">
                                                            Read
                                                        </label>

                                                        <div className="ms-auto d-table mt-auto mb-auto float-end">
                                                            <div class="form-check form-switch ms-auto">
                                                                <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="read_language" onChange={(e) => handleChange(e, 'required', '', 'language_form')}
                                                                    checked={(currentStateData['language_form']?.read_language) ? true : false}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {/* access ends here */}


                                                    {/* access starts here */}
                                                    <div className="col-md-12">
                                                        <label className="text-dark">
                                                            Write
                                                        </label>

                                                        <div className="ms-auto d-table mt-auto mb-auto float-end">
                                                            <div class="form-check form-switch ms-auto">
                                                                <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="write_language" onChange={(e) => handleChange(e, 'required', '', 'language_form')}
                                                                    checked={(currentStateData['language_form']?.write_language) ? true : false}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {/* access ends here */}

                                                    {/* access starts here */}
                                                    <div className="col-md-12">
                                                        <label className="text-dark">
                                                            Speak
                                                        </label>

                                                        <div className="ms-auto d-table mt-auto mb-auto float-end">
                                                            <div class="form-check form-switch ms-auto">
                                                                <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="speak_language" onChange={(e) => handleChange(e, 'required', '', 'language_form')}
                                                                    checked={(currentStateData['language_form']?.speak_language) ? true : false}
                                                                />
                                                            </div>
                                                        </div>

                                                    </div>

                                                    {/* access ends here */}
                                                </div>

                                                <div className="row mt-2 mb-2">
                                                    <div className="d-flex mt-2 mb-2">
                                                        <div className="me-auto">

                                                        </div>
                                                        <div className="ms-auto">
                                                            <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Save</button>
                                                            {(is_loader && loaderType == 'language_form') && <Loading />}
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>

                                            {/* Edit Form Ends Here */}

                                            {/* card starts here */}

                                            <div className="row">

                                                {value.values != '' && value.values?.map((fv, fk) => {
                                                    return fv.value && JSON.parse(fv.value).map((card, cardKey) => {
                                                        let lang = [];
                                                        let car = "";
                                                        if (card.read_language == 1) lang.push("Read");
                                                        if (card.speak_language == 1) lang.push("Speak");
                                                        if (card.write_language == 1) lang.push("Write");
                                                        if (card.language_name == "English") car = "a";
                                                        if (card.language_name == "Hindi") car = "अ";
                                                        if (card.language_name == "Marathi") car = "अ";
                                                        if (card.language_name == "Tamil") car = "க்";
                                                        return <div className="col-12 col-md-4 text-white"><div className={`container shadow mt-5 p-2 br-5 ${colors[cardKey % 6]}`}>
                                                            <div className="d-flex">
                                                                <header >
                                                                    <div className='text-center'>
                                                                        <h5 className='font-bold'>{card.language_name}</h5>
                                                                        <h1>{car}</h1>
                                                                        <p> {lang.join()}</p>
                                                                    </div>
                                                                </header>
                                                                <div className="ms-auto">
                                                                    <h4 onClick={(e) => editJsonForm(e, card, 'language_form', cardKey)}><i class="lar la-edit text-white cursor"></i></h4>
                                                                    <h4 onClick={(e) => deleteJsonForm(e, card, 'language_form', cardKey)}><i class="las la-trash text-danger cursor"></i></h4>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    });
                                                })}

                                                {/* card ends here */}

                                            </div>

                                        </div>
                                        {/* Edit language_form End Here */}

                                    </div>
                                </div>
                            </>

                        {/* language ends here */ }


                    })}




                    {/* submit button */}
                    {/* form ends here */}
                </div>


            </>

        );

    }

}

const mapStateToProps = (state) => {
	const {
	  country_category_res,
	  state_category_res,
	  city_category_res,
	  country_category_p_res,
	  state_category_p_res,
	  city_category_p_res,
	} = state.common;
	return {
	  country_category_res,
	  state_category_res,
	  city_category_res,
	  country_category_p_res,
	  state_category_p_res,
	  city_category_p_res,
	};
  };
  
  function mapDispatchToProps(dispatch) {
	return {
	  getCountryCategory: () => dispatch(getCountryCategory()),
	  getStateCategory: (id) => dispatch(getStateCategory(id)),
	  getCityCategory: (id) => dispatch(getCityCategory(id)),
	  getCountryPCategory: () => dispatch(getCountryPCategory()),
	  getStatePCategory: (id) => dispatch(getStatePCategory(id)),
	  getCityPCategory: (id) => dispatch(getCityPCategory(id)),
	};
  }

export default connect(mapStateToProps, mapDispatchToProps)(EditPersonalDetailForm);