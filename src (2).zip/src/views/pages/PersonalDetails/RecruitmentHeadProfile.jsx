import React, { Component } from 'react';

import { getLoggedInUser, getAuthToken } from '../../../classes/index';
import { END_POINT, GET_ACCESS_LEVEL, GET_ALL_MEMBERS } from '../../../routes/api_routes';
import { NavLink } from 'react-router-dom';

class RecruimentHeadProfile extends Component {
  state = {
    member: [],
  }
  async componentDidMount() {
    const user = await getLoggedInUser();
    this.setState({ user_id: user.id });
    this.getMember()
  }

  getMember = async () => {
    const result = await getLoggedInUser();
    let token = await getAuthToken();
    fetch(END_POINT + GET_ALL_MEMBERS + "/" + result.id, {
      method: 'GET',
      headers: { 'Authorization': 'Bearer ' + token }
    })
      .then((response) => response.json())
      .then((data) => {
        this.setState({ member: data.data });
      });
  }

  render() {

    const card = this.props.card.values;

    return (
      <>
        <div className="container mt-4 br-5 bg-white pb-4">
          <div className="row pt-4 mb-4 ">
            <div className="col-md-11 col-10 ">
              <h5 className="f-Poppins-Medium">Recruitment Head Profile</h5>
            </div>
            <div className="col-md-1 col-2">
              <h3>
                <NavLink to={`/edit-profile/${this.state.user_id}`}>
                  <i class="las la-edit text-blue"></i>
                </NavLink>
              </h3>
            </div>
          </div>
          <header className="d-flex">
            <div className="me-3 mt-1">
              <img
                src="/assets/imgs/dummy-logo.png"
                className="img-fluid box-shadow br-5 h-80p"
              />
            </div>
            <div>
              <h5 className="font-bold mb-1 mt-2 f-Poppins-Medium">{card[0].value}</h5>
              <h5>Recruiment Head</h5>
            </div>
          </header>
          <div className="row">
            <div className="col-md-8">
              <div className="row  mt-2">
                <div className="col-md-6">
                  <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                    <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                      <span className="f-1-1 m-0  p-0"> Email</span>{" "}
                    </p>
                    <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                      {" "}
                      <span className="">{card[2].value}</span>
                    </p>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                    <p className=" position-abs t-2 l-2 m-0  mt-2  h-20px f-Poppins-Regular ">
                      <span className="f-1-1 m-0  p-0"> Experience</span>{" "}
                      <span className="float-end fs-5">{card[5].value}</span>
                    </p>
                  </div>
                </div>
              </div>
              <div className="row mb-2 mt-2">
                <div className="col-md-6 ">
                  <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                    <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                      <span className="f-1-1 m-0  p-0"> Email 2</span>{" "}
                    </p>
                    <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                      {" "}
                      <span className="">{card[3].value}</span>
                    </p>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                    <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular ">
                      <span className="f-1-1 m-0  p-0"> Phone No</span>{" "}
                    </p>
                    <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular ">
                      {" "}
                      <span className="">{card[4].value}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 mt-4">
              <div
                className="cards position-relative  bg-dark-pink
                            br-5 text-white p-2 h-172  mr-2"
              >
                <p className="position-abs t-2 l-2 m-0  f-Poppins-Regular ">
                  Address
                </p>
                <p className="f-Poppins-Regular "> {card[6].value} </p>
                <p className="f-Poppins-Regular "> {card[7].value} </p>
                <p className="f-Poppins-Regular "> {card[10].value + " " + card[9].value + " " + card[8].value + " " + card[11].value} </p>
              </div>
            </div>
          </div>
        </div>

        <div className="container br-5 mt-3 bg-white pb-7 mb-3">
          <div className="row pt-4 ">
            <div className="col-md-11 col-10 ">
              <h5 className="f-Poppins-Medium">Recruitment Coordinators</h5>
            </div>
            <div className="col-md-1 col-2">
              <h3>
                <NavLink to="/add-coordinator">
                  <i class="las la-edit text-blue"></i>
                </NavLink>
              </h3>
            </div>
            <div className="container mt-1">
              {(Object.keys(this.state.member).length != 0 && this.state.member?.map((member) => {
                return <div className="row mt-2">
                  <div className="col-md-12">
                    <p className="float-start fs-5 ">{member.name}</p>
                    <p className="float-end s-5">{member.access_level}</p>
                  </div>
                  <div className="border-dashed1 mt-1 "></div>
                </div>
              }))}
            </div>
          </div>
        </div>
      </>
    );
  }
};

export default RecruimentHeadProfile;
