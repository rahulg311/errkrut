import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

class Employment extends Component {

    render() {
        const { card } = this.props;
        return (
            <>
                <div className="container  pt-1 pb-2 bg-white rounded-5 shadow mb-3">
                    <div className="row  mb-2  ">
                        <div className="col-md-12">
                            <h4 className="f-Poppins-Medium mt-2">{card.CardTitle}</h4>
                        </div>
                    </div>

                    <div className="row">
                        {card.values && card.values?.map((v, k) => {

                            return v.value && JSON.parse(v.value).map((edu_card, edu_key) => {

                                return <>
                                    <div className="col-12 col-md-6">
                                        <div className="shadow mt-2 p-2 br-5">
                                            <div className="d-flex">
                                                <header className='d-flex'>
                                                    <div>
                                                        {Object.keys(edu_card).map((k, index) => {
                                                            return <p>
                                                                <label className="me-2 text-capitalize">{k.replace(/_/g, " ")}</label>
                                                                <span>{edu_card[k]}</span>
                                                            </p>;
                                                        })}
                                                    </div>
                                                </header>

                                                <div className="ms-auto">
                                                    <NavLink to="/edit-profile">
                                                        <i class="lar la-edit text-primary cursor f-1-5"></i>
                                                    </NavLink>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </>

                            })
                        })}

                    </div>

                    <div class="d-grid ">
                        <NavLink class="btn btn-primary w-50 w-xs-100 mt-4" type="button" to="/edit-profile">+</NavLink>
                    </div>
                </div>
            </>
        );

    }
}

export default Employment;