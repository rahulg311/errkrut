import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';

class Stats extends Component {

	state = {
		user_id: null,
		email: null,
		mobile: null,
		userName: null
	}


	render() {
		const { card } = this.props;

		const colors = ['bg-greenesh-blue', 'bg-blue', 'bg-warning', 'bg-purple', 'bg-dark-pink'];
		return (
			<>
				<div className="container bg-white mb-3 rounded-5 shadow card border-0 pb-3">
					<div className="row mt-2 mb-3">
						<div className="col-md-11 col-10">
							<h4 className="f-Poppins-Medium">Stats</h4>
						</div>

					</div>
					<div className='row'>
						<div className='col-3'>
							<div className='container'>
								<div className='row'>
									<div className='col-12'>

										<div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>{card.values[0].assessment_taken}</p>
											<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end   font-bold pb-1 '><span className='ms-4 '>   Assessment </span><br /> <span className='float-end'>Taken</span> </p>
										</div>

									</div>
								</div>
								<div className='row mt-3'>
									<div className='col-12'>

										<div className='cards   bg-greenesh-blue br-5 text-white ps-1  h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>{card.values[0].total_companies_applied}</p>
											<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end   font-bold pb-1 '><span className='ms-4 '> Companies </span><br /> <span className='float-end'>Applied</span> </p>
										</div>

									</div>
								</div>
								<div className='row mt-3'>
									<div className='col-12'>

										<div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>{card.values[0].offer_letters}</p>
											<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '> <span className='float-end mt-4'>Offer Letters</span> </p>
										</div>

									</div>
								</div>
							</div>
						</div>
						<div className='col-9 rounded-4 shadow'>

							<div className='d-flex justify-content-between mt-3' >

								<div className="">
									<h5>Companies Applied</h5>
								</div>

							</div>

							<div className='row mt-2' >

								<div className="col-md-12 col-12 ">

									<table className="table m-0 p-0	">
										<thead className="shadow-none bg-primary text-white">
											<tr>
												<th className='fs-12' scope="col">Company Name</th>
												<th className='fs-12' scope="col">Designations</th>
												<th className='fs-12' scope="col">Status</th>
												<th className='fs-12' scope="col">Assessment Taken</th>
												<th className='fs-12' scope="col">Offer Letter</th>

											</tr>
										</thead>
										<tbody>
											{card.values[0].companies_applied.length > 0 && card.values[0].companies_applied.map((v, k) => {
												return (
													<>
														{k < 5 && <tr className={k%2 == 0 ? '' : 'bg-light-blue`'}>
															<td className='fs-12 text-capitalize' scope="col">{v.company_name}</td>
															<td className='fs-12 text-capitalize' scope="col">{v.job_title}</td>
															<td className='fs-12 text-capitalize' scope="col">{v.status}</td>
															<td className='fs-12 text-capitalize' scope="col">{v.assessment_taken}</td>
															<td className='fs-12 text-capitalize' scope="col">{v.offer_letter}</td>
														</tr>
														}
													</>)
											})}
										</tbody>
									</table>


								</div>


							</div>
						</div>
					</div>

				</div>
			</>
		);

	}
}

export default Stats;