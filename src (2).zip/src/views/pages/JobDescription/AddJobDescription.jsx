import React, { Component } from 'react';
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import Company from "../../../components/Contact/Company";
import Option from "../../../components/Cart/Option";
import { Link } from "react-router-dom";
import { getLoggedInUser, getAuthToken } from "../../../classes/index";
import {
  END_POINT,
  GET_JD_DETAILS,
  JOB_DESCRIPTION,
  IMPORT_JOB_DESCRIPTION
} from "../../../routes/api_routes";
import { getJobDescriptions } from '../../../store/actions/jobs';
import { connect } from "react-redux";

import { notification } from "../../../classes/messages";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import Section from "../../../components/hoc/Section";
import Main from "../../../components/hoc/Main";
import SideBar from "../../../components/hoc/SideBar";
import Loading from "../../../components/common/Loading";
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { EditorState, convertToRaw, convertFromRaw, ContentState, convertFromHTML } from 'draft-js';
import draftToHtml from 'draftjs-to-html';

import ImportJDModal from './ImportJDModal';

class AddJobDescription extends Component {
  state = {
    formData: [],
    job_descriptions: '',
    instructionState: EditorState.createEmpty(),
    loading: true,
    edit_id: false,
    title: '',
    purpose: '',
    industry: '',
    summary: '',
    preffered_skills: '',
    desired_qualification: '',
    job_responsibilities: '',
    jdModal: false,
	}
  
  onInstructionChange = (neweditorState) => {
		this.setState({ instructionState: neweditorState });
		let htmlmsg = draftToHtml(convertToRaw(neweditorState.getCurrentContent()));
		this.handleChange({ target: { name: 'job_responsibilities', value: htmlmsg } }, 'required', 'job_responsibilities is required')
	};
  
  componentWillMount(){
    this.getJobDescriptions();
  }

  changeEditor = () => {
    if (this.state.job_responsibilities != null) {
      let n = EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(this.state.job_responsibilities)));
      this.setState({ instructionState: n });
    }
  }


  getJobDescriptions = async () => {
    let user = await getLoggedInUser();
    let id = user.company_id;
    await this.props.getJobDescriptions(id);

    if (this.props.job_desc_res?.data && this.props.job_desc_res?.status == 'success') {
      this.setState({
        job_descriptions: this.props.job_desc_res?.data.filter(el => el.company_id != null), loading: false
      });
      
    }
  }

  handleChange = (e) => {
    let ivalue = e.target.value;
    let iname = e.target.name;

    this.setState({ [iname]: ivalue });
  }

  editJobDescription = async (id) => {

    let token = await getAuthToken();

    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
      }
    };

    fetch(END_POINT + GET_JD_DETAILS + '/' + id, requestOptions)
      .then((response) => response.json())
      .then((result) => {
        let editData = result.data[0];

        this.setState({ 
          edit_id: id,
          title: editData.title,
          purpose: editData.purpose,
          industry: editData.industry,
          summary: editData.summary,
          preffered_skills: editData.preffered_skills,
          desired_qualification: editData.desired_qualification,
          job_responsibilities: editData.job_responsibilities,
        }, () => this.changeEditor() )
            
        
      })
      .catch((error) => console.log('error', error));
  }

  cancelHandler = () => {
    this.setState({
      edit_id: false,
      title: '',
      purpose: '',
      industry: '',
      summary: '',
      preffered_skills: ' ',
      desired_qualification: '',
      job_responsibilities: '',
    }, ()=> {
      this.changeEditor();
    });
  }

  saveHandler = async() => {
    this.setState({postloading : true});
		const user = await getLoggedInUser();
		let token = await getAuthToken();
    const formdata = new FormData();

    if(this.state.edit_id){
      formdata.append('id', this.state.edit_id);
    }

    formdata.append('jd_title', this.state.title);
    formdata.append('purpose', this.state.purpose);
    formdata.append('industry', this.state.industry);
    formdata.append('summary', this.state.summary);
    formdata.append('preffered_skills', this.state.preffered_skills);
    formdata.append('desired_qualification', this.state.desired_qualification);
    formdata.append('job_responsibilities', this.state.job_responsibilities);

    var requestOptions = {
      method: 'POST',
      body: formdata,
      redirect: 'follow',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
      }
    };

    fetch(END_POINT + JOB_DESCRIPTION , requestOptions)
      .then((response) => response.json())
      .then((result) => {
        if (result.status == 'success') {
					let notify = notification({ message: result.message, type: 'success' });
					notify();
          this.cancelHandler();
        }else {
          result.message.forEach((element) => {
            let notify = notification({ message: element, type: 'error' });
            notify();
          });
        }  
        this.setState({postloading : false});
        this.getJobDescriptions();
      })
      .catch((error) => console.log('error', error));

  }

  handleImportSubmit = async (file) => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		const formData = new FormData();
    
		formData.append("file", file);
		const requestOptions = {
			method: "POST",
      body: formData,
			headers: { "Content-Type": "application/json" },
			headers: { 'Authorization': 'Bearer ' + token }

		};

    fetch(END_POINT + IMPORT_JOB_DESCRIPTION , requestOptions)
      .then((response) => response.json())
      .then((result) => {
        if (result.status == "success") {
          let notify = notification({ message: result.message, type: 'success' });
					notify();
        }
        else {
          let notify = notification({ type: 'error', message: 'Something went wrong', });
          notify();
        }
        this.closeImportModal();
        this.getJobDescriptions();
      })
      .catch((error) => console.log('error', error));
		
	}

  closeImportModal = () => {
    this.setState({jdModal: false});
  }

  render() {

    return (
      <>
      <ImportJDModal
				is_modal={this.state.jdModal}
				closeModal={this.closeImportModal}
				handleSubmit={this.handleImportSubmit}
			/>
      
      <Section>
        <Main>
          <header className="border-bottom border-primary py-2 border-2 d-flex align-items-center justify-content-between">
            <h4>Add Job Description </h4>
            <button type='button' className='btn btn-primary' onClick={() => this.setState({jdModal: true})}> Import File</button>
          </header>
          <main className="mt-4">
            <div className="row mt-2 w-80" >

              <div className="col-md-12">
                <label className="text-dark">
                  JD Title
                </label>
              </div>
              <div className="col-md-12">

                <input
                  type='text'
                  className='form-control input-border'
                  onChange={(e) => this.handleChange(e, "required", "Title is required")}
                  name='title'
                  defaultValue={this.state.title}
                  required
                />
              </div>

            </div>

            <div className="row mt-2 w-80" >

              <div className="col-md-7">

                {/* prupose */}
                <div className="col-md-12">
                  <label className="text-dark">
                    Purpose
                  </label>
                </div>
                <div className="col-md-12">

                  <input
                    type='text'
                    className='form-control input-border'
                    onChange={(e) => this.handleChange(e, "required", "Purpose is required")}
                    name='purpose'
                    defaultValue={this.state.purpose}
                    required
                  />
                </div>
                {/* prupose */}
              </div>

              <div className="col-md-5">

                <div className="col-md-12">
                  <label className="text-dark">
                    Industry
                  </label>
                </div>
                <div className="col-md-12">

                  <input
                    type='text'
                    className='form-control input-border'
                    onChange={(e) => this.handleChange(e, "required", "Industry is required")}
                    name='industry'
                    defaultValue={this.state.industry}
                    required
                  />
                </div>

              </div>

            </div>

            {/* Job Summary */}
            <div className="row mt-2 w-80" >

              <div className="col-md-12">
                <label className="text-dark">
                  Job Summary
                </label>
              </div>
              <div className="col-md-12">
                <textarea
                  className='form-control input-border'
                  onChange={(e) => this.handleChange(e, "", "")}
                  name='summary'
                  defaultValue={this.state.summary}
                  required
                ></textarea>
              </div>

            </div>
            {/* Job Summary */}

            {/* preferred skills */}
            <div className="row mt-2 w-80" >

              <div className="col-md-12">
                <label className="text-dark">
                  Preferred Skills
                </label>
              </div>
              <div className="col-md-12">
                <textarea className='form-control input-border'
                  onChange={(e) => this.handleChange(e, "required", "Preffered Skills is required")}
                  name='preffered_skills' defaultValue={this.state.preffered_skills} required></textarea>
              </div>

            </div>
            {/* preferred skills */}


            {/* Desired Qualifications */}
            <div className="row mt-2 w-80" >

              <div className="col-md-12">
                <label className="text-dark">
                  Desired Qualification
                </label>
              </div>
              <div className="col-md-12">

                <input
                  type='text'
                  className='form-control input-border'
                  onChange={(e) => this.handleChange(e, "", "")}
                  name='desired_qualification'
                  defaultValue={this.state.desired_qualification}
                  required
                />
              </div>

            </div>
            {/* Desired Qualification */}

            {/* job responsibilites */}
            <div className="row mt-2 w-80" >

              <div className="col-md-12">
                <label className="text-dark">
                  JD Responsibilities
                </label>
              </div>

              <div className='col-md-12'>
                <Editor
                  editorState={this.state.instructionState} defaultEditorState={this.state.instructionState} wrapperClassName="demo-wrapper" editorClassName="editer-content"
                  onEditorStateChange={this.onInstructionChange}
                />
              </div>

            </div>
            {/* job responsibilties */}
            <div className="row mt-5 w-80" >

              <div className="text-end">
                {this.state.edit_id && (
                  <button
                    type="button"
                    className="btn btn-outline-primary px-4 mr-10"
                    onClick={(e) => { this.cancelHandler(e) }}
                  >
                    Cancel
                  </button>
                )}
                <button
                  className="btn bg-primary text-white px-5"
                  disabled={this.state.postloading}
                  onClick={(e) => this.saveHandler(e)}
                >
                  {this.state.postloading ? (
                    <div
                      className="spinner-border spinner-border-sm"
                      role="status"
                    ></div>
                  ) : this.state.edit_id ? (
                    "Save"
                  ) : (
                    "Add"
                  )}
                </button>
              </div>
            </div>

            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-3 mb-3 f-0-9"></div>

            {/* Member lists */}
            <h4 className="text-primary f-r-16">Edit Job Description</h4>

            {this.state.loading == true && <Loading />}


            {Object.keys(this.state.job_descriptions).length != 0 &&
              this.state.job_descriptions?.map((jd) => {
                return (
                  <div className=" mt-2">
                    <div class="mb-1 d-flex">
                      <h5 class=" f-r-14 mt-1">{jd.title}</h5>
                      <button
                        type="button"
                        className="btn btn-outline-primary f-r-12 btn-sm px-5 ms-auto float-end"
                        onClick={(e) => { this.editJobDescription(jd.id); }}
                      >
                        Edit
                      </button>
                    </div>
                    <div class="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mb-3 f-0-9"></div>
                  </div>
                );
              })}

            {/* Member lists */}
          </main>
        </Main>
        <SideBar>
          <ProfileName></ProfileName>
          <ActionButtons />
          <Company></Company>
        </SideBar>
      </Section>

      </>
    );
  }

};

const mapStateToProps = (state) => {
  const { job_desc_res, } = state.common;
  return {
    job_desc_res,
  }
};

function mapDispatchToProps(dispatch) {
  return {
    getJobDescriptions: (id) => dispatch(getJobDescriptions(id)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AddJobDescription);
