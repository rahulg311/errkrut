import { useEffect, useState } from "react";
import { END_POINT, GET_ASSESSMENT, SEND_ASSESSMENT, DOWNLOAD_RESUME, DOWNLOAD_EXCEL } from '../../../routes/api_routes';
import useFetch from "../../../hooks/useFetch";
import { notification } from '../../../classes/messages';
import { useRef } from "react";
import { getLoggedInUser } from "../../../classes";
import usePost from "../../../hooks/usePost";
import { getAuthToken } from '../../../classes/index';



const ExcelModal = ({ is_modal, closeModal, alluserlist }) => {
    const { response, isLoading, error, doPost } = usePost();
    const [isChecked, setisChecked] = useState([]);

    const handleOnChange = (e) => {
        
        if (isChecked.includes(e.target.value)) {
            var myIndex = isChecked.indexOf(e.target.value);
            if (myIndex !== -1) {
                isChecked.splice(myIndex, 1);
                setisChecked([...isChecked]);
            }
        }
        else {
            setisChecked([...isChecked, e.target.value]);
        }
    };

    const handleSubmit = async () => {
        const user = await getLoggedInUser();
		let token = await getAuthToken();

        const formData = new FormData();
        if (alluserlist.length != 0 && isChecked.length != 0) {
            formData.append("company_id", user.company_id);
            formData.append("user_ids", "[" + alluserlist + "]");
            formData.append("columns", JSON.stringify(isChecked));
            const requestOptions = {
                method: "POST",
                headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			    }
            };
            doPost(`${DOWNLOAD_EXCEL}`, formData, requestOptions).then((response) => {
                if (response.status == "success") {
                    const link = document.createElement('a');
                    link.download = "";
                    let str = response.excel_url.replace(/[\\]/g, '');
                    link.href = str;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            });
        }
        else {
            const notify = notification({ message: "Please Select Valid Data", type: 'error' });
            notify();
        }

    }
    useEffect(() => {
        if(is_modal == false){
            setisChecked([]);
        }
    }, [is_modal]);
    return (
        is_modal && (
            <>
                <div className="modal fade-in" style={{ display: "block" }}>
                    <div
                        className="modal-dialog modal-dialog-centered modal-lg"
                        role="document"
                    >
                        <div className="modal-content">
                            <form
                                onSubmit={(e) => {

                                    e.preventDefault();
                                    handleSubmit();
                                }}
                            >
                                <div className="modal-header align-items-center d-flex justify-content-between border-0">
                                    <h2>
                                        Download Excel File
                                    </h2>
                                    <span
                                        classNameName="f-2 cursor"
                                        onClick={(e) => closeModal()}
                                    >
                                        &times;
                                    </span>
                                </div>
                                <div className="modal-body">
                                    <div className='bg-white px-2 rounded-4 mt-2'>
                                        <div className='container'>
                                            <div className='w-75 w-100-xs'>
                                                <div className='row'>
                                                    <div className='col-12'>
                                                        <label for="exampleInputEmail1" class="form-label text-primary">Select the Information you want to Download</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='name' /> <label>Name</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='job_history' /> <label>Job History</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='email' /> <label>Email</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='skills' /> <label>Skills</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='mobile' /> <label>Mobile</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='location' /> <label>Location</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='education_qualification' /> <label>Education Qualification</label>
                                                    </div>
                                                    <div className="col-6">
                                                        <input type="checkbox" className="form-check-input p-1" onChange={handleOnChange} value='summary' /> <label>Summary</label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer border-0">
                                    <button
                                        type="button"
                                        className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                                        onClick={(e) => closeModal()}
                                    >
                                        Close
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                                    >
                                        Download Excel
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="modal-backdrop fade show"></div>
            </>
        )
    );
};

export default ExcelModal;
