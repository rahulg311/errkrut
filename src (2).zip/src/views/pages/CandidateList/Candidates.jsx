import usePost from "../../../hooks/usePost";
import { getLoggedInUser } from "../../../classes";
import { END_POINT, DOWNLOAD_RESUME } from "../../../routes/api_routes";
const Candidates = ({ candidate, handleSingleCheck, isChecked }) => {
    const { response, isLoading, error, doPost } = usePost();
    const handleSingleCV = async () => {
        const user = await getLoggedInUser();
        const formData = new FormData();
        formData.append("company_id", user.company_id);
        formData.append("user_id", "[" + candidate.id + "]");
        const requestOptions = {
            method: "POST",
            headers: { "Content-Type": "application/json" },
        };
        doPost(`${DOWNLOAD_RESUME}`, formData, requestOptions).then((response) => {
            if (response.status == "success") {
                const link = document.createElement('a');
                link.download = "";
                let str = response.url.replace(/[\\]/g, '');
                link.href = str;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        })
    };
    return (<>
        <div className=" shadow">
            <div className="container ">
                <div className="row p-2">
                    <div className="col-md-11 col-10 p-0 d-flexd-flexd-flexd-flexd-flex">
                        <header className='d-flex '>
                            <div className='me-3 mt-1'>
                                <img
                                    src='/assets/imgs/dummy-logo.png'
                                    className='img-fluid box-shadow br-5 h-60p'
                                />
                            </div>
                            <div>
                                <h5 className='font-bold mb-1 mt-2 f-Poppins-Medium'>{candidate.name}</h5>
                                <p className="f-Poppins-Regular  fw-bold text-primary fs-14">Applied For : UI/UX Designer
                                </p>
                            </div>
                        </header>
                    </div>
                    <div className="col-md-1 col-2 mt-1 d-flex">

                        <div class="form-check ">
                            <input className="form-check-input p-1" type="checkbox" checked={isChecked.includes(parseInt(candidate.id))} name={candidate.id} value={candidate.id} onChange={handleSingleCheck} id="flexCheckDefault" />
                        </div>

                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12 col-12">
                        <h6 className="text-primary f-r-12">Status : Applied for Interview | Badge Recieved : 0
                        </h6>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12 col-12 d-flex mt-2">
                        <p className="text-primary pe-1 f-Poppins-Regular">Portfolio
                        </p><p className="text-primary f-Poppins-Regular">SamDoe.pdf
                        </p>
                    </div>
                </div>
                <div className="row  w-100-xs mt-1 ">
                    <div className="col-md-3 col-12 d-flex">
                        <i class='las la-briefcase  text-sky-blue f-1-4 f-r-12 pe-1 ' />
                        <p className=" f-0-8 f-r-12   "><span className="text-primary f-Poppins-Medium   fs-15 f-r-12 me-2">Experience</span><span className=" f-Poppins-Light  f-0-8   ">{candidate.experience}</span> </p>
                    </div>
                    <div className="col-md-3  col-12 d-flex">
                        <i class='las la-map-marker   text-sky-blue f-1-4 f-r-12 ' />
                        <p className=" f-0-8 f-r-12   "><span className="text-primary f-Poppins-Medium  fs-15 f-r-12 me-2">Locations</span><span className="f-Poppins-Light  ">{candidate.location}</span> </p>
                    </div>
                    <div className="col-md-4   col-12 d-flex">
                        <i class='las la-rupee-sign  text-sky-blue f-1-4 f-r-12 1' />
                        <p className=" f-0-8  f-r-12  "><span className="text-primary f-Poppins-Medium  fs-15 f-r-12 me-2"> Current Salary</span><span className="f-Poppins-Light  ">Not Disclosed</span> </p>
                    </div>
                </div>
                <div className="row mt-1">
                    <div className="col-md-12 col-12 d-flex ">
                        <i class='las la-briefcase  text-sky-blue f-1-4 f-r-12  pe-1' />
                        <p className=" f-0-8 f-r-12   "><span className="text-primary f-Poppins-Medium  fs-15 f-r-12 me-2">Skill Set</span><span className="f-Poppins-Light  ">{candidate.skill_set}</span> </p>
                    </div>
                </div>
                <div className="row mt-1">
                    <div className='col-1'>
                        <p className='text-primary f-r-12'>Summary</p>
                    </div>
                    <div className='col-11 '>
                        <p className='ps-2 fs-12'>{candidate.summary}</p>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-12'>
                        <p className='text-primary float-end pt-1 pb-1 f-r-12'>Know More</p>
                    </div>
                </div>

                <div className="border mt-2 mb-4"></div>
                <div className="row mb-4 pb-3">
                    <div className="col-md-8 col-12 d-flex mb-2 ">

                    </div>
                    <div className="col-md-4 m-0 p-0 col-12 ">
                        {candidate.resume ? (<button type="button" onClick={handleSingleCV} class="btn btn-primary ps-4 pe-4 float-end f-r-14">Download CV</button>) : (<></>)}
                    </div>
                </div>
            </div>
        </div>
    </>);

}
export default Candidates