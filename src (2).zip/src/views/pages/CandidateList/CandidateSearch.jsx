import React, { useState, useEffect } from 'react';

import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes';
import { Route, useHistory } from 'react-router-dom';

import usePost from "../../../hooks/usePost";
import useFetch from "../../../hooks/useFetch";
import UserList from "../../../components/Recruiter/CandidateList";
import { getAuthToken } from '../../../classes/index';
import { notification } from '../../../classes/messages';
import AddExcelModal from '../CandidateList/SearchCandidateExcelModal';
import AddTagModal from '../CandidateList/SearchCandidateTagModal';

import {
	END_POINT,
	GET_ALL_CANDIDATES,
	DOWNLOAD_RESUME,
	GET_ALL_TAGS
} from "../../../routes/api_routes";

const CandidateSearch = () => {

	const [allChecked, setAllChecked] = useState(false);
	const [searchtype, setSearchtype] = useState('all');
	const [searchtext, setSearchtext] = useState();
	const [searchtag, setSearchtag] = useState();
	const [isChecked, setIsChecked] = useState([]);
	const [tagsOpt, setTagsOpt] = useState([]);
	const { response, isLoading, error, doPost } = usePost();
	const [resdata, setResData] = useState(0);
	const history = useHistory();


	const [ExcelModal, setExcelModal] = useState(false);
	const showExcelModal = () => setExcelModal(true);
	const closeExcelModal = () => setExcelModal(false);

	const [TagModal, setTagModal] = useState(false);
	const showTagModal = () => setTagModal(true);
	const closeTagModal = () => setTagModal(false);


	const studentCvListAPI = useFetch();
	const studentDeleteAPI = usePost();
	const resendInvitationAPI = usePost();

	const getUserList = async () => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};
		studentCvListAPI.doFetch(END_POINT + `${GET_ALL_CANDIDATES}`, requestOptions);

	};

	const getfilterdata = async (e) => {

		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};
		e.preventDefault();
		if (searchtag != '') {
			let filter = '?filter={"tag_id":"' + searchtag + '", "' + searchtype + '":"' + searchtext + '"}';
			studentCvListAPI.doFetch(END_POINT + `${GET_ALL_CANDIDATES + filter}`, requestOptions);
		} else if (searchtype != 'all') {
			let filter = '?filter={"' + searchtype + '":"' + searchtext + '"}';

			studentCvListAPI.doFetch(END_POINT + `${GET_ALL_CANDIDATES + filter}`, requestOptions);
		} else {
			getUserList();
		}
	}

	const handleDownloadCV = async () => {

		if (isChecked.length != 0) {
			let token = await getAuthToken();
			const user = await getLoggedInUser();
			const formData = new FormData();
			formData.append("company_id", user.company_id);
			formData.append("user_id", "[" + isChecked + "]");
			const requestOptions = {
				method: "POST",
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token
				}
			};
			doPost(`${DOWNLOAD_RESUME}`, formData, requestOptions).then((response) => {
				if (response.status == "success") {
					const link = document.createElement('a');
					link.download = "";
					let str = response.url.replace(/[\\]/g, '');
					link.href = str;
					document.body.appendChild(link);
					link.click();
					document.body.removeChild(link);
				} else {
					let notify = notification({ message: response.message, type: 'error' });
					notify();

				}
			})
		}
		else {
			let notify = notification({ message: "Please Select Candidate List", type: 'error' });
			notify();
		}

	};



	const handleSingleCheck = e => {
		if (isChecked.includes(parseInt(e.target.value))) {
			var myIndex = isChecked.indexOf(parseInt(e.target.value));
			if (myIndex !== -1) {
				isChecked.splice(myIndex, 1);
				setIsChecked([...isChecked]);
			}
		}
		else {
			setIsChecked([...isChecked, parseInt(e.target.value)]);
		}
	};

	const handleAllCheck = e => {
		if (!allChecked) {
			setIsChecked(studentCvListAPI?.data?.data.map((user) => user.id));
			setAllChecked(true);
		}
		else {
			setIsChecked([]);
			setAllChecked(false);
		}
	};
	async function getTags(e) {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + GET_ALL_TAGS + '/' + user.company_id, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				console.log(result)
				let tagsOpt = result.data.map(row => {
					return (
						<option value={row.id}> {row.title} </option>
					)
				});
				setTagsOpt(tagsOpt);
			})
			.catch((error) => console.log('error', error));
	}
	const getAllTagData = () => {
		setResData(1);
	}

	useEffect(() => {
		getUserList();
		getTags();
	}, [response, resdata]);

	return (
		<>
			<AddExcelModal
				is_modal={ExcelModal}
				closeModal={closeExcelModal}
				alluserlist={isChecked}
			/>
			<AddTagModal
				is_modal={TagModal}
				closeModal={closeTagModal}
				alluserlist={isChecked}
				getAllTagData={getAllTagData}
			/>
			<div className="container">
				<div className="row">
					<div className="col-md-9 p-0">
						<div className="p-1  ">
							<div className=" ">
								{/* submit button */}
								{/* start Edit hr profile  */}
								<div className=" row bg-white mt-2   ">
									<div className="col-md-4  col-12 mt-1 ">
										<h3 className="text-primary   f-Poppins-Medium ms-1 mt-2 "> Candidates Search</h3>
									</div>
									<div className="col-md-8 p-0 m-0 mt-2 ">
										<form onSubmit={(e) => getfilterdata(e)}>
											<select class="text-primary form-select form-select-md d-inline-block mb-3 input-border w-30 " aria-label="Default select example"
												onChange={(e) => setSearchtag(e.target.value)} name='tag_id'
											>
												<option value="" selected>select tag</option>
												{tagsOpt}
											</select>

											<select class="text-primary form-select form-select-md d-inline-block mb-3 input-border w-30 ms-1" aria-label="Default select example"
												onChange={(e) => setSearchtype(e.target.value)} name='searchtype'
											>
												<option value="all" selected>All</option>
												<option value="name">Name</option>
												<option value="email">Email</option>
												<option value="mobile">Mobile</option>
												<option value="location">Location</option>
											</select>

											<input
												type='text'
												className='form-control d-inline-block input-border w-25 ms-1'
												onChange={(e) => setSearchtext(e.target.value)}
												name='searchtext'
												placeholder='Search'

											/>

											<button type="submit" class="btn btn-primary fs-12 ps-4 pe-4 pt-1 pb-1 ms-1 ">Fliter</button>

										</form>
									</div>

									<div className="border-blue1 mt-1 mb-1  "></div>


									<div className='container'>
										<div className='bg-white pt-4 pb-4 px-2 rounded-4'>
											<div className='row'>
												<div className="d-flex bg-white justify-content-end align-items-center mt-3 rounded-4">

													<button
														onClick={showExcelModal}
														className="btn btn-primary btn-sm ps-4 pe-4 f-r-10 font-bold poppins-bold"

													>Download In Excel
													</button>
													<button
														//onClick={showAssessmentModal}
														onClick={handleDownloadCV}
														className="btn ms-1 btn-primary btn-sm ps-4 pe-4 f-r-10 font-bold poppins-bold"

													>
														Download In PDF
													</button>
													<button
														onClick={showTagModal}
														className="btn ms-1 btn-primary btn-sm ps-4 pe-4 f-r-10 font-bold poppins-bold"

													>
														Tag Candidate
													</button>
												</div>

												<div className="p-2">
													<UserList
														data={studentCvListAPI?.data?.data}
														loading={studentCvListAPI.loading}
														handleSingleCheck={handleSingleCheck}
														handleAllCheck={handleAllCheck}
														isChecked={isChecked}
													/>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
							{/* submit button */}
							{/* form ends here */}
						</div>
					</div>
					{/* sidebar */}
					<div className="col-md-3">
						<ProfileName />
						<ActionButtons />
						<Company />
					</div>
					{/* sidebar */}
				</div>
			</div>
		</>
	);

}
export default CandidateSearch;