
import React, { useEffect, useState } from "react";
import { END_POINT, CREATE_TAG_USER, CREATE_TAGS, GET_ALL_TAGS } from '../../../routes/api_routes';
import useFetch from "../../../hooks/useFetch";
import { notification } from '../../../classes/messages';
import { useRef } from "react";
import { getLoggedInUser } from "../../../classes";
import usePost from "../../../hooks/usePost";
import { getAuthToken } from '../../../classes/index';



const SearchCandidateTagModal = ({ is_modal, closeModal, alluserlist, getAllTagData }) => {
    const { response, isLoading, error, doPost } = usePost();
    const [isChecked, setisChecked] = useState([]);
    const [tag_title, setTag_title] = useState();
    const [new_tag_title, setNew_tag_title] = useState();
    const [tagsOpt, setTagsOpt] = useState([]);
    const [showCreateTag, setShowCreateTag] = useState(false);

    React.useEffect(async () => {
        getTags();

    }, [])

    async function getTags(e) {
        const user = await getLoggedInUser();
        let token = await getAuthToken();
        var requestOptions = {
            method: 'GET',
            redirect: 'follow',
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        };

        fetch(END_POINT + GET_ALL_TAGS + '/' + user.company_id, requestOptions)
            .then((response) => response.json())
            .then((result) => {
                console.log(result)
                let tagsOpt = result.data.map(row => {
                    return (
                        <option value={row.id}> {row.title} </option>
                    )
                });
                setTagsOpt(tagsOpt);
            })
            .catch((error) => console.log('error', error));
    }

    async function createTags(e) {
        const user = await getLoggedInUser();
        let token = await getAuthToken();

        if (new_tag_title != undefined) {

            var formdata = new FormData();
            formdata.append('title', new_tag_title);
            formdata.append('company_id', user.company_id);

            var requestOptions = {
                method: 'POST',
                body: formdata,
                redirect: 'follow',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token
                }
            };

            fetch(END_POINT + CREATE_TAGS, requestOptions)
                .then((response) => response.json())
                .then((result) => {
                    console.log(result);
                    setShowCreateTag(false);
                    getTags();
                    const notify = notification({ message: "Tag Created", type: 'success' });
                    notify();
                    getAllTagData();
                })
                .catch((error) => console.log('error', error));
        } else {
            const notify = notification({ message: "Enter Tag Title.", type: 'error' });
            notify();
        }
    }

    const handleSubmit = async () => {
        const user = await getLoggedInUser();
        let token = await getAuthToken();
        const formData = new FormData();
        if (alluserlist.length != 0 && tag_title.length != 0) {
            formData.append("tag_id", tag_title);
            formData.append("user_ids", "[" + alluserlist + "]");
            const requestOptions = {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token
                }
            };
            doPost(`${CREATE_TAG_USER}`, formData, requestOptions).then((response) => {
                if (response.status == "success") {
                    console.log(response);
                    const notify = notification({ message: "User tag Added", type: 'success' });
                    notify();
                    closeModal();
                }
            });
        }
        else {
            const notify = notification({ message: "Please Select Valid Data", type: 'error' });
            notify();
        }

    }
    return (
        is_modal && (
            <>
                <div className="modal fade-in" style={{ display: "block" }}>
                    <div
                        className="modal-dialog modal-dialog-centered modal-lg"
                        role="document"
                    >
                        <div className="modal-content">
                            <form
                                onSubmit={(e) => {

                                    e.preventDefault();
                                    handleSubmit();
                                }}
                            >
                                <div className="modal-header align-items-center d-flex justify-content-between border-0">
                                    <h2>
                                        Tag Candidate
                                    </h2>
                                    <span
                                        classNameName="f-2 cursor"
                                        onClick={(e) => closeModal()}
                                    >
                                        &times;
                                    </span>
                                </div>
                                <div className="modal-body">
                                    <div className='bg-white px-2 rounded-4 mt-2'>
                                        <div className='container'>
                                            <div className='w-75 w-100-xs'>
                                                <div className='row'>
                                                    <div className='col-md-12'>
                                                        <label className='text-dark'>Tag Title</label>

                                                        <select
                                                            className='form-select form-select-md input-border'
                                                            onChange={(e) => setTag_title(e.target.value)}
                                                            name='tag_title'
                                                            required
                                                        >
                                                            <option value=''>--Select Tag Title--</option>
                                                            {tagsOpt}
                                                        </select>
                                                    </div>
                                                    <a href="#" className='mt-1' onClick={() => setShowCreateTag(true)}>Create New Tag</a>
                                                    {showCreateTag == true &&
                                                        <div className="row">
                                                            <div className='col-md-7 mt-1'>
                                                                <input
                                                                    className='form-control input-border'
                                                                    onChange={(e) => setNew_tag_title(e.target.value)}
                                                                    name='new_tag_title'
                                                                    required
                                                                />
                                                            </div>
                                                            <div className='col-md-5 mt-1'>
                                                                <button type="button" className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                                                                    onClick={(e) => createTags()} >
                                                                    Create
                                                                </button>
                                                                <a href="#" className='mt-1 ms-2' onClick={() => setShowCreateTag(false)}>Close</a>
                                                            </div>
                                                        </div>
                                                    }
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer border-0">
                                    <button
                                        type="button"
                                        className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                                        onClick={(e) => closeModal()}
                                    >
                                        Close
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                                    >
                                        Add Tag User
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="modal-backdrop fade show"></div>
            </>
        )
    );
};

export default SearchCandidateTagModal;
