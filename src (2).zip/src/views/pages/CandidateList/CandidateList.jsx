import React, { useState, useEffect } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Summary from '../../../components/CompanyProfile/Summary';
import AddExcelModal from './ExcelModal';
import Candidates from './Candidates';
import useFetch from "../../../hooks/useFetch";
import usePost from "../../../hooks/usePost";
import { END_POINT, GET_CANDIDATES, GET_SKILLS, GET_LOCATIONS, DOWNLOAD_RESUME } from "../../../routes/api_routes";
import { getLoggedInUser } from "../../../classes";
import { notification } from '../../../classes/messages';
import { getAuthToken } from '../../../classes/index';
const CandidateList = () => {

    const { data, loading, errors, doFetch } = useFetch();
    const { response, isLoading, error, doPost } = usePost();
    const [ExcelModal, setExcelModal] = useState(false);
    const showExcelModal = () => setExcelModal(true);
    const closeExcelModal = () => setExcelModal(false);
    const [allChecked, setAllChecked] = useState(false);
    const [isChecked, setIsChecked] = useState([]);
    const [filters, setfilters] = useState({});
    const handlefilter = e => {
        setfilters({
            ...filters,
            [e.target.name]: e.target.value
        });

    };
    const CandidateList = useFetch();
    const getCandidateList = async () => {
        CandidateList.doFetch(END_POINT + `${GET_CANDIDATES}`);
    };
    const LocationList = useFetch();
    const getLocationList = async () => {
        LocationList.doFetch(END_POINT + `${GET_LOCATIONS}`);
    };
    const [Skills, setSkills] = useState({});
    const getSkills = async () => {
        try {
            let token = await getAuthToken();
            if (token) {

                const response = await fetch(END_POINT + GET_SKILLS, {
                    method: 'POST',
                    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
                });
                const json = await response.json();
                setSkills(Object.entries(json.data));
            }
        } catch (e) {
            console.log(e);
        }
    };
    const handleAllCheck = e => {
        if (!allChecked) {
            setIsChecked(CandidateList?.data?.map((Candidate) => Candidate.id));
            setAllChecked(true);
        }
        else {
            setIsChecked([]);
            setAllChecked(false);
        }
    };
    const handleSingleCheck = e => {
        if (isChecked.includes(parseInt(e.target.value))) {
            var myIndex = isChecked.indexOf(parseInt(e.target.value));
            if (myIndex !== -1) {
                isChecked.splice(myIndex, 1);
                setIsChecked([...isChecked]);
            }
        }
        else {
            setIsChecked([...isChecked, parseInt(e.target.value)]);
        }
    };
    const handleDownloadCV = async () => {
        if (isChecked.length != 0) {
            let token = await getAuthToken();
            const user = await getLoggedInUser();
            const formData = new FormData();
            formData.append("company_id", user.company_id);
            formData.append("user_id", "[" + isChecked + "]");
            const requestOptions = {
                method: "POST",
                headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
            };
            doPost(`${DOWNLOAD_RESUME}`, formData, requestOptions).then((response) => {
                if (response.status == "success") {
                    const link = document.createElement('a');
                    link.download = "";
                    let str = response.url.replace(/[\\]/g, '');
                    link.href = str;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            })
        }
        else {
            const notify = notification({ message: "Please Select Candidate List", type: 'error' });
            notify();
        }

    };
    const getfilterdata = () => {
        let experience = filters.experience == undefined ? "" : filters.experience;
        let location = filters.location == undefined ? "" : filters.location
        let skill = filters.skills == undefined ? "" : filters.skills
        let filter = {
            "experience": experience,
            "location": location,
            "skill": skill
        }
        CandidateList.doFetch(END_POINT + `${GET_CANDIDATES}?filter=` + JSON.stringify(filter));
    };
    useEffect(() => {
        getCandidateList();
        getSkills();
        getLocationList();
    }, []);

    return (
        <>
            <AddExcelModal
                is_modal={ExcelModal}
                closeModal={closeExcelModal}
                alluserlist={isChecked}
            />

            <div className="container ">
                <div className="row">
                    <div className="col-md-9 p-0 bg-white br-5">
                        <div className="">
                            <div className="container">


                                <div className="row mt-3 mb-4">
                                    <div className="col-md-4  col-12 mt-1 ">
                                        <h3 className="text-primary  mb-2 f-Poppins-Medium ms-1 "> Candidates List</h3>
                                    </div>
                                    <div className="col-md-8 p-0 m-0 mt-1 ">

                                        <select name="experience" onChange={handlefilter} selected={filters.experience} class="p-1 mb-1 text-primary ms-1 col-5 fs-12 col-md-3" aria-label="Default select example">

                                            <option value="" >Experience</option>
                                            <option value='1-3 Years'>1-3 Years</option>
                                            <option value='4-6 Years'>4-6 Years</option>
                                            <option value='7-10 Years'>7-10 Years</option>
                                            <option value='11-15 Years'>11-15 Years</option>
                                            <option value='15+ Years'>15+ Years</option>
                                        </select>

                                        <select selected={filters.location} name="location" onChange={handlefilter} class="p-1 text-primary ms-1 fs-12 col-md-2 mb-1 col-5" aria-label="Default select example">

                                            <option value="" >Location</option>
                                            {
                                                (LocationList?.data?.data == undefined)
                                                    ? <h1>Loading</h1>
                                                    : (Object.entries(LocationList?.data?.data).map((location, id) => {
                                                        return (
                                                            <option value={location[1]}>
                                                                {location[1]}
                                                            </option>
                                                        );
                                                    })

                                                    )
                                            }
                                        </select>

                                        <select selected={filters.skills} name="skills" onChange={handlefilter} class="p-1 mb-1   text-primary ms-1 fs-12 col-lg-2 col-10" aria-label="Default select example">
                                            <option value="" >Skills</option>
                                            {
                                                Skills.length != undefined ?
                                                    (
                                                        Skills.map((element) => {
                                                            return (<option value={element[1]}>{element[1]}</option>)
                                                        })
                                                    )
                                                    : (<></>)
                                            }
                                        </select>

                                        <select class="p-1 text-primary ms-1 fs-12 col-md-2 mb-1 col-6 " aria-label="Default select example">
                                            <option selected>Featured</option>
                                            <option value="1">Call For Interview</option>
                                            <option value="2">Letter of Intent sent</option>
                                            <option value="3">Offer Letter Sent</option>
                                            <option value="1">Rejected By Me</option>
                                            <option value="2">Rejected By Candidates </option>
                                            <option value="3">Saves Candidates</option>
                                        </select>
                                   <button onClick={getfilterdata} type="button" class="btn btn-primary mt-1 mb-1 fs-12 ps-4 pe-4 pt-1 pb-1 ms-1 col-12  col-md-2">Fliter</button>

                                    </div>
                                    <div className="border-blue1  "></div>
                                </div>











                                <div className='row mb-2'>

                                    <div className='col-12  col-lg-6 p-0'>
                                        <div className='row ps-1'>
                                        <button onClick={handleDownloadCV} type="button" class="btn col-lg-5 me-2 col-5 mb-1 f-r-12 btn-outline-secondary  fs-13">Download CV</button>
                                        <button type="button" class="btn f col-lg-6 f-r-12 btn-outline-secondary col-5 mb-1  me-1 fs-13">Download CVs</button>
                                       
                                    </div></div>
                                    <div className='col-12  col-lg-6  m-0 p-0 '>
                                        <div className='row'>
                                    <button onClick={showExcelModal} type="button" class="btn  mb-1 ms-1  col-lg-5 col-7 f-r-12 btn-outline-secondary fs-13">Download Profiles in Excel</button>
                                        <p className='text-primary col-lg-5 col-3 p-0'>
                                            <a onClick={handleAllCheck}><label for="selectAllCheck" className='f-r-12 float-end mt-1 '>Select all</label></a>
                                        </p>
                                        </div>

                                    </div>
                                </div>

                                {
                                    CandidateList?.loading ? (
                                        <h1>Loading</h1>
                                    ) :
                                        CandidateList?.data?.map((candidate, id) => {
                                            return (
                                                <Candidates candidate={candidate} isChecked={isChecked} handleSingleCheck={handleSingleCheck}></Candidates>
                                            );
                                        })
                                }




                            </div>
                            {/* submit button */}
                            {/* form ends here */}
                        </div>
                    </div>
                    {/* sidebar */}
                    <div className="col-md-3">
                        <ProfileName />
                        <ActionButtons />
                        <Company />
                    </div>
                    {/* sidebar */}
                </div>
            </div>
        </>
    );
}
export default CandidateList;