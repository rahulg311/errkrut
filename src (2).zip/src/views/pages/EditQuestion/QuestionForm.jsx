import React, { useState } from 'react';
import MultiSelect from './MultiSelect';
import { getAuthToken, getLoggedInUser } from '../../../classes/index';
import { END_POINT } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import { useHistory } from 'react-router-dom';
import { Link, NavLink } from 'react-router-dom';

const QuestionForm = ({ Question, allAttributes, Qtags }) => {

	const [question, setQuestion] = useState('');
	const [Difficulty, setDifficulty] = useState('');
	const [Quiz, setQuiz] = useState('');
	const [category, setCategory] = useState('');
	const [subject, setSubject] = useState('');
	const [hint, setHint] = useState('');
	const [questionType, setQuestionType] = useState('');
	const [explanation, setExplanation] = useState('');
	const [accessType, setAccessType] = useState();
	const [options, setOptions] = useState([]);
	const [optionsError, setOptionsError] = useState('');
	const history = useHistory();
	const [multiSelectTags, setMultiSelectTags] = useState([]);
	const [optiondata, setOptionData] = useState([{
		value: 'true',
		is_correct: 0,
		weightage: '',
		id: new Date().getMilliseconds(),
	}, {
		value: 'false',
		is_correct: 0,
		weightage: '',
		id: new Date().getMilliseconds(),
	}]);
	const optionsData = Qtags?.options.split(',');
	const handleMultiSelect = (data) => {
		setMultiSelectTags(data);
	}
	React.useEffect(async () => {
		console.log(Question);
		setQuestion(Question?.question);
		setHint(Question?.hint);
		setQuestionType(Question?.question_type);
		setExplanation(Question?.explanation);
		setAccessType(Question?.access_type);
		setOptions(Question?.options);
		if (Question?.question_type == "True-False")
			setOptionData(Question?.options);
		setDifficulty(Question?.Difficulty);
		setQuiz(Question?.Complexity);
		setCategory(Question?.Quiz);
		setSubject(Question?.Subject);
	}, [Question]);

	const handleSubmit = async (e) => {
		e.preventDefault();
		let token = await getAuthToken();

		if (questionType != "Subjective" && questionType != "Small Text" && questionType != "Large Text") {

			if (questionType != "True-False") {
				if (options.length == 0) {
					setOptionsError('Please add some options');
					return;
				} else if (options.every((item) => item.value === '')) {
					setOptionsError('please fill all the options');
					return;
				}

				if (!options.some((e) => e.is_correct == 1) && options.length >= 1) {
					setOptionsError('Please select one correct answer');
					return;
				}
			}
			else {
				if (optiondata.length == 0) {
					setOptionsError('Please add some options');
					return;
				} else if (optiondata.every((item) => item.value === '')) {
					setOptionsError('please fill all the options');
					return;
				}

				if (!optiondata.some((e) => e.is_correct == 1) && optiondata.length >= 1) {
					setOptionsError('Please select one correct answer');
					return;
				}
			}
		}

		if (question && questionType && explanation && accessType && Difficulty && subject) {
			const formData = {
				question: question,
				hint: hint,
				question_type: questionType,
				explanation: explanation,
				access_type: accessType,
				options: JSON.stringify((questionType == "True-False") ? optiondata : options),
				qid: Question.id,
				Difficulty: Difficulty,
				Quiz: category,
				Subject: subject,
				question_tags: multiSelectTags,
			};

			fetch(END_POINT + 'update_question', {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					Accept: 'application/json',
					Authorization: 'Bearer ' + token,
					'Content-Type': 'application/json',
				},
			})
				.then((res) => {
					return res.json();
				})
				.then((data) => {
					if (data.status == 'success') {
						let notify = notification({ message: data.message, type: 'success' });
						notify();
						history.push('/recruiter/questions');
					} else {
						data.message.forEach((e) => {
							let notify = notification({ message: e, type: 'error' });
							notify();
						});
					}
				})
				.catch((err) => console.log(err));
		}
	};


	return (
		<>
			<form method='POST' className='px-4' onSubmit={handleSubmit}>
				<div>
					<h4 className='text-dark'>Edit Question</h4>
					<div className='border-gray-line mt-2 mb-2'></div>
					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Question title</label>
						</div>
						<div className='col-md-12'>
							<input
								type='text'
								value={question}
								onChange={(e) => setQuestion(e.target.value)}
								className='form-control'
								name='question_title'
								required
							/>
						</div>
					</div>
					{allAttributes?.map((items) => {
						if (items.name == 'Difficulty' && items.type.toLowerCase() == 'radio') {
							return (
								<>
									<div>
										<label className='text-dark'>{items.title}</label>
									</div>

									<div className='d-flex'>
										{items.options.split(',').map((option, index) => {
											return (
												<div class='form-check my-1	 me-2 '>
													<input
														class='form-check-input'
														type='radio'
														name={items.name}
														id={items.name + index}
														value={option}
														onChange={(e) => setDifficulty(e.target.value)}
														checked={option === Difficulty ? true : false}
													/>
													<label class='form-check-label' for={items.name + index}>
														{option}
													</label>
												</div>
											);
										})}
									</div>
								</>
							);
						}
					})}

					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Question Tags</label>
						</div>
						<div className='col-md-12'>
							<MultiSelect options={optionsData} handleMultiSelect={handleMultiSelect} selectedOptions={JSON.stringify(Question.question_tags?.split(','))} />
						</div>
					</div>
					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Subject</label>
						</div>
						<div className='col-md-12'>
							{allAttributes?.map((items) => {
								if (items.name == 'Subject') {
									return (<input type='text' className='form-control' name={items.name} value={subject} onChange={(e) => setSubject(e.target.value)} />);
								}
							})}
						</div>
					</div>


					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Question Type</label>
						</div>
						<div className='col-md-12'>
							<select
								value={questionType}
								onChange={(e) => {
									setQuestionType(e.target.value); setOptionData([{
										value: 'true',
										is_correct: 0,
										weightage: '',
										id: new Date().getMilliseconds(),
									}, {
										value: 'false',
										is_correct: 0,
										weightage: '',
										id: new Date().getMilliseconds(),
									}]); setOptions([]);
								}}
								className='form-control f-0-9'
								name='question_type'
								required
							>
								<option disabled selected value=''>
									--Select Question Type--
								</option>
								{allAttributes?.map((items) => {
									if (items.name == 'question_type') {
										return items?.options.split(',').map((option) => (<option value={option}>{option}</option>))
									}
								})}
								{/* {attribute?.options.split(',').map((option) => (<option value={option}>{option}</option>))} */}
							</select>
						</div>
					</div>
					{/* <div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Question Category</label>
						</div>
						<div className='col-md-12'>
							<select
								value={category}
								onChange={(e) => setCategory(e.target.value)}
								className='form-control f-0-9'
								name='question_category'
								required
							>
								<option disabled selected value=''>
									--Select Question Category--
								</option>
								{allAttributes?.map((items) => {
									if (items.name == 'Quiz') {
										return items?.options.split(',').map((option) => (<option value={option}>{option}</option>))
									}
								})}
							</select>
						</div>
					</div> */}
					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Hint</label>
						</div>
						<div className='col-md-12'>
							<textarea
								value={hint}
								onChange={(e) => setHint(e.target.value)}
								className='form-control'
								name='hint'
								required
							></textarea>
						</div>
					</div>

					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Explanation</label>
						</div>
						<div className='col-md-12'>
							<textarea
								value={explanation}
								onChange={(e) => setExplanation(e.target.value)}
								className='form-control'
								name='explanation'
								required
							></textarea>
						</div>
					</div>

					<div className='row mt-2 w-100'>
						{[].map((ele, index) => (
							<div className='col-md-6'>
								<div className='col-md-12'>
									<label className='text-dark'>Option {index + 1}</label>
								</div>
								<div className='col-md-12'>
									<input type='text' className='form-control' name={`option${index}`} />
								</div>
							</div>
						))}
					</div>
					{
						(questionType.toLowerCase().replaceAll(" ", "") == 'true-false' &&
							<>
								{optiondata.map((val, i) => {
									return <><section key={i} className='row mb-2 align-items-center'>
										<div className='col-3'>
											<span className='mt-2px'>{String.fromCharCode(i + 97)}</span>
											<input
												class='form-check-input mx-2'
												type='radio'
												name='flexRadioDefault'
												id='flexRadioDefault1'
												value={val}
												checked={val.is_correct === 1}
												onChange={(e) => {
													const newOptions = [...optiondata].map((e) => {
														return {
															...e,
															is_correct: 0,
														};
													});
													newOptions[i].is_correct = e.target.checked ? 1 : 0;
													setOptionData(newOptions);
												}}
											/>
										</div>
										<div className='col-6 justify-content-between align-items-center'>
											<input
												type='text'
												className='form-control me-2'
												value={val.value}
												onChange={(e) => {
													const newOptions = [...optiondata];
													setOptionData[i].value = e.target.value;
													setOptions([...newOptions]);
												}} readOnly
											/>
										</div>
									</section>
										<small className='text-danger mt-2'>{optionsError}</small>
									</>;
								})}
							</>

						)
					}
					{(questionType.toLowerCase().replaceAll(" ", "") == 'mcq' || questionType.toLowerCase().replaceAll(" ", "") == 'singlechoice' || questionType.toLowerCase().replaceAll(" ", "") == 'sortanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'multiplechoicequestion' || questionType.toLowerCase().replaceAll(" ", "") == 'matchanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'fillintheblank' || questionType.toLowerCase().replaceAll(" ", "") == 'dropdownselect' || questionType.toLowerCase().replaceAll(" ", "") == 'surveytype') && <div className='row mt-2 w-100'>
						<p
							className='text-dark mb-1 cursor'
							onClick={() => {
								setOptions([
									...options,
									{
										value: '',
										is_correct: 0,
										weightage: '',
										id: new Date().getMilliseconds(),
									},
								]);
								setOptionsError('');
							}}
						>
							<button type="button" className='btn btn-primary btn-sm'>
								<span>Add Option</span>
								<span>
									<i className='las la-plus'></i>
								</span>
							</button>
						</p>
						{options.length >= 1 && options.map((option, i) => {
							return (
								<section key={option.id} className='d-flex align-items-center mb-2'>
									<span className='mt-2px'>{String.fromCharCode(i + 97)}</span>
									<input
										class='form-check-input mx-2'
										type='radio'
										name='flexRadioDefault'
										id='flexRadioDefault1'
										value={option.value}
										checked={option.is_correct === 1}
										onChange={(e) => {
											const newOptions = [...options].map((e) => {
												return {
													...e,
													is_correct: 0,
												};
											});
											newOptions[i].is_correct = e.target.checked ? 1 : 0;
											setOptions(newOptions);
										}}
									/>
									<div className='d-flex justify-content-between w-100 align-items-center'>
										<input
											type='text'
											className='form-control me-2'
											value={option.value}
											onChange={(e) => {
												const newOptions = [...options];
												newOptions[i].value = e.target.value;
												setOptions([...newOptions]);
											}}
										/>
										<button
											type='button'
											class='btn-close'
											aria-label='Close'
											onClick={() => {
												const newOptions = [...options].filter((e) => e.id !== option.id);
												setOptions([...newOptions]);
												setOptionsError('');
											}}
										></button>
									</div>
								</section>
							);
						})}
						<small className='text-danger mt-2'>{optionsError}</small>
					</div>}

					<div className='row mt-3'>
						<div className='col-md-6'>
							<Link to={'/add-question'} className={`btn btn-sm text-dark`}>
								<button
									className='btn btn-outline-primary ml-auto mr-auto d-block '
								>
									Add Questions
								</button>
							</Link>

						</div>
						<div className='col-md-6'>
							<button type='submit' className='btn btn-primary ms-auto d-block'>
								Save
							</button>
						</div>
					</div>
				</div>
			</form>
		</>
	);
};

export default QuestionForm;
