import React, { useState, useEffect } from 'react';
import Loading from '../../../components/common/Loading';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { END_POINT } from '../../../routes/api_routes';
import { getAuthToken } from '../../../classes';
import QuestionForm from './QuestionForm';

const EditQuestion = ({ match }) => {
	const [atypelist, setQuestionTypeList] = useState(null);
	const [qtags, setQuestionTags] = useState(null);
	const [allAttributes, setAllAttributes] = useState(null);
	const [question, setQuestion] = useState({});
	const [loading, setLoading] = useState(true);

	const getQuestionList = async () => {
		let token = await getAuthToken();
		fetch(END_POINT + 'get_question_attr', {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		}).then((res) => res.json()).then((resu) => { setAllAttributes(resu?.data); setQuestionTypeList(resu?.data[3]); setQuestionTags(resu?.data[2]); });

	}

	useEffect(async () => {
		getQuestionList();
		var formdata = new FormData();
		formdata.append('qid', match.params.id);
		let token = await getAuthToken();
		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: { 'Authorization': 'Bearer ' + token }
		};

		fetch(END_POINT + 'edit_question', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				setQuestion(result);
				setLoading(false);
			})
			.catch((error) => setLoading(false));
	}, [match.params.id])


	return (
		<div className='container'>
			<div className='row gx-md-6 mt-3'>
				<div className='col-md-9 bg-white rounded-4  py-5'>

					{(loading || allAttributes == null) ? (
						<Loading className='text-center'></Loading>
					) : (
						<QuestionForm Question={question} allAttributes={allAttributes} Qtags={qtags}></QuestionForm>
					)}
				</div>
				<div className='col-md-3'>
					<ProfileName />
					<ActionButtons />
					<Company />
				</div>
			</div>
		</div>
	);
};

export default EditQuestion;