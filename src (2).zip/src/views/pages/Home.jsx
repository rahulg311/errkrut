import React, { useEffect } from 'react';

import { getLoggedInUser, RouteWithSubRoutes } from '../../classes';
import { Campus_User_Type_ID, Recruiter_User_Type_ID } from '../../config/constants';

const Home = (props) => {

	useEffect(async () => {
		const user = await getLoggedInUser();
		if (user?.user_type !== null && user?.user_type == Recruiter_User_Type_ID) {
			props.history.push('/recruiter');
		} else if (user?.user_type !== null && user?.user_type == Campus_User_Type_ID) {
			props.history.push('/campus');
		}
		else {
			props.history.push('/');
		}
		
	}, []);

	return (
		<div>

		</div>
	);
};

export default Home;
