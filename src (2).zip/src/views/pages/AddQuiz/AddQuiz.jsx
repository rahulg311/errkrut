import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { getLoggedInUser } from '../../../classes/index';

import { validation } from '../../../classes/validation';
import { notification } from '../../../classes/messages';

import QuizForm from './QuizForm';

import { routeChanged, routePushed } from '../../../classes/browserHistory';

import { createQuiz, editQuiz } from '../../../store/actions/quiz';

import { connect } from "react-redux";
import QuizeStep2 from './QuizStep2';
import SideBar from '../../../components/hoc/SideBar';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';
import QuizPreview from './QuizPreview';

class AddQuiz extends Component {

    state = {
        step: 1,
        company_id: null,
        title: null,
        type: null,
        duration: null,
        evaluation: null,
        quiz_retake: 'none',
        name: null,
        instruction: null,
        quiz_failed_message: null,
        per_page_questions: null,
        randomize_section_questions: null,
        quiz_instructions: null,
        quiz_success_message: null,
        show_result: null,
        check_answer: null,
        dynamic_quiz: 0,
        partial_marking: null,
        passing_marks: null,
        randomize_questions: null,
        randomize_question_bs: null,
        randomize_section: null,
        randomize_options: null,
        negative_marking: null,
        correct_marks: null,
        incorrect_marks: null,
        question_id: null,
        errors: {},
        api_res: null,
        //category: null,
        errors: [],
        sections: [],
        multiSelectTags: null,
        user_id: null,
        questions: [],
        sectionCount: 1,
        show_save_section: [true],
        edit_id: 0
    };

    componentWillMount() {

        this.getUserId();

        /* initialize section */

        [...Array(this.state.sectionCount)].map((e, i) => {

            this.setState({ sections: [{ section_title: '', number_of_questions: 0, added_questions: [], filter_questions: [], points: [] }] });

        });

        /* initialize section */

        /* edit id */
        let id = this.props.match.params?.id;
        if (id) {
            this.setState({ edit_id: id }, () => {
                this.editQuizData();
            });

        }
        /* edit id */

    }

    /* edit quiz data */
    editQuizData = async () => {

        await this.props.editQuiz(this.state.edit_id);
        let data = this.props.data;

        console.log(data);

        if (data?.status == 'success') {
            Object.keys(data.data).map((key) => {
                this.setState({
                    [key]: data.data[key]
                });
            });
        }
    }
    /* edit quiz data */

    getUserId = async () => {

        const result = await getLoggedInUser();

        console.log(result);

        this.setState({
            user_id: parseInt(result.id),
            company_id: parseInt(result.company_id)
            //user_id: 1
        });

        console.log(this.state);
    }

    /* handle validation */

    /* remove section */
    removeSection = (newOptions) => {
        this.setState({ sections: newOptions }, () => {
            //console.log(this.props.formData.sections);

            let newcount = this.state.sectionCount - 1;

            this.setState({ sectionCount: newcount });

        });
    }
    /* remove section */

    /* set sections */
    setSection = (a) => {

        this.setState({ sections: a });

    }
    /* set sections */

    /* add filters */
    addFilters = (quiz_sections) => {
        this.setState({ sections: quiz_sections });
    }
    /* add filters */

    /* add questions */
    addQuestions = (quiz_sections) => {
        console.log(quiz_sections)
        this.setState({ sections: quiz_sections }, () => {
            console.log(this.state.sections)
        });
    }
    /* add questions */


    /* handle validation */
    handleValidation = (obj) => {

        let error = this.state.errors;

        let valiRes = validation(obj);

        //email
        if (valiRes['error'] == 1) {

            error[obj.name] = valiRes['message'];

            this.setState({
                errors: error
            });

        } else {
            error[obj.name] = '';

            this.setState({
                errors: error
            });
        }

    }

    /* handle validation */

    // Handle fields change
    handleChange = async (e, valiType = '', valiMsg = '', isResetSection = false) => {
        if (e.target) {
            if (isResetSection) {
                let sec = [];
                sec[0] = { section_title: '', number_of_questions: 0, added_questions: [], filter_questions: [], points: [] };
                this.setState({ sections: sec });

                let showSave = [];
                showSave[0] = true;
                this.setState({ show_save_section: showSave });
                this.setState({ sectionCount: 1 });
            }

            let ivalue = e.target.value;
            let iname = e.target.name;

            if (e.target.type == 'checkbox') {
                if (e.target.checked) {
                    ivalue = 1;
                } else {
                    ivalue = 0;
                }
            }

            if (valiType && valiMsg)
                this.handleValidation({ name: iname, type: valiType, value: ivalue, message: valiMsg });

            this.setState({ [iname]: ivalue }, () => {
            });


        }
    }
    /* handle change */

    /* switch steps */
    changeStep = (value) => {
        this.setState({ step: value });
    }


    /* get validation state */
    getValidationState() {
        var errors = this.state.errors;

        var firstErr = '';
        var lastErr = '';
        errors.forEach((error) => {
            console.log("error:", error.name);

            if (error.message.indexOf('firstName') != -1) {
                firstErr = error.message;
            }
            if (error.message.indexOf('lastName') != -1) {
                lastErr = error.message
            }

        });

        console.log(firstErr)

        this.setState({
            firstNameErr: firstErr,
            lastNameErr: lastErr,
        });


    }
    /* get validation state */


    setSaveSection = (s) => {

        this.setState({ show_save_section: s });

    }


    nextStepView = (e) => {

        e.preventDefault();

        let formValid = true;

        let notify = null;

        if (this.state.errors) {

            Object.keys(this.state.errors).map((k, v) => {
                console.log(k);
                if (this.state.errors[k] != "") {
                    formValid = false;
                }
            })

        }

        if (this.state.negative_marking == null || this.state.negative_marking == 0) {
            if (this.state.incorrect_marks == 0 || this.state.incorrect_marks == null) {
                formValid = true;
            }
            else {
                formValid = false;
                notify = notification({ message: "Enable Negative Marking", type: 'error' });
            }
        }


        if (formValid == true) {
            this.changeStep(2);
        } else {
            if (!notify) {
                notify = notification({ message: 'Please fill the form correctly.', type: 'error' });
            }


        }

        if (notify)
            notify();

    }

    /* Update Questions */
    updateQuestions = (ques) => {

        this.setState({ questions: ques });

    }
    /* Update Questions */
    editSection = (i) => {
        let sec = this.state.show_save_section;
        sec[i] = true;
        this.setState({ show_save_section: sec });

    }

    /* Update Questions */
    addSectionCount = () => {

        let currentSection = this.state.sections[this.state.sectionCount - 1];

        console.log(currentSection);

        let sectionOk = true;

        if (currentSection.section_title.length > 0 && currentSection.number_of_questions.length > 0) {

            if (this.state.dynamic_quiz == 0) {

                if (currentSection.added_questions.length == 0) {
                    sectionOk = false;
                }

            } else {
                if (currentSection.filter_questions.length == 0) {
                    sectionOk = false;
                }
            }

            if (sectionOk) {
                let count = this.state.sectionCount + 1;

                console.log(count);

                this.setState({ sectionCount: count }, () => {

                    let sec = this.state.sections;
                    sec.push({ section_title: '', number_of_questions: 0, added_questions: [], filter_questions: [], points: [] });
                    this.setState({ sections: sec });

                    let showSave = this.state.show_save_section;
                    showSave.push(true);
                    this.setState({ show_save_section: showSave });

                    console.log(this.state.sections)
                    console.log(this.state.show_save_section)
                });
            } else {
                let notify = notification({ message: 'Please fill section', type: 'error' });
                notify();
            }


        } else {
            let notify = notification({ message: 'Please fill section', type: 'error' });
            notify();
        }
    }
    /* Update Questions */



    /* handle Submit */
    handleSubmit = async (e) => {

        let notify = null;

        let formData = {
            company_id: this.state.company_id,
            title: this.state.title,
            type: this.state.type,
            duration: this.state.duration,
            evaluation: this.state.evaluation,
            quiz_retake: this.state.quiz_retake,
            name: this.state.name,
            // instruction: this.state.instruction,
            quiz_failed_message: this.state.quiz_failed_message,
            per_page_questions: this.state.per_page_questions,
            quiz_instructions: this.state.quiz_instructions,
            quiz_success_message: this.state.quiz_success_message,
            show_result: this.state.show_result,
            check_answer: this.state.check_answer,
            dynamic_quiz: this.state.dynamic_quiz,
            partial_marking: this.state.partial_marking,
            passing_marks: this.state.passing_marks,
            randomize_questions: this.state.randomize_questions,
            randomize_question_bs: this.state.randomize_question_bs,
            randomize_section_questions: this.state.randomize_section_questions,
            randomize_section: this.state.randomize_section,
            randomize_options: this.state.randomize_options,
            negative_marking: this.state.negative_marking,
            correct_marks: this.state.correct_marks,
            incorrect_marks: this.state.incorrect_marks,
            //question_id: this.state.question_id,
            //category: this.state.category,
            sections: this.state.sections,
            //multiSelectTags: this.multiSelectTags,
            user_id: this.state.user_id
        };

        if (this.state.dynamic_quiz == 0) {

            let question_ids = this.state.questions.map((value) => {
                console.log(value)
                return value.id;
            });

            formData['question_id'] = question_ids;

            console.log(question_ids)

        }

        console.log(formData);

        await this.props.createQuiz(formData);

        let resp = this.props.data;

        console.log(resp);

        if (resp) {

            if (resp.status == 'success') {

                notify = notification({ message: resp.message, type: 'success' });

                routePushed('/successful', this.props, { message: 'Your Quiz Added Successfully.' });

                //routeChanged('/recruiter', this.props);

            } else {
                this.setState({ api_res: JSON.stringify(resp.message) });
                notify = notification({ message: JSON.stringify(resp.message), type: 'error' });
                console.log(this.state.api_res);
            }
        }

        notify();


    }
    /* handle Submit */

    render() {

        let errs = this.state.errors && Object.keys(this.state.errors).map((k, v) => { return this.state.errors[k].length >= 1 && <li className="text-danger">{this.state.errors[k]}</li> }
        )

        return (
            <Section>
                <Main>
                    <ul>{errs}</ul>
                    {this.state.api_res && <p className='text-danger'>{this.state.api_res}</p>}
                    {this.state.step == 1 && (
                        <QuizForm
                            handleChange={this.handleChange}
                            nextStepView={this.nextStepView}
                            errors={this.state.errors}
                            formData={this.state}
                            getValidationState={this.getValidationState}
                        />
                    )}
                    {/* Quiz Form */}

                    {/* Step 2 */}
                    {this.state.step == 2 && (
                        <QuizeStep2
                            handleChange={this.handleChange}
                            errors={this.state.errors}
                            formData={this.state}
                            handleSubmit={this.handleSubmit}
                            updateQuestions={this.updateQuestions}
                            addSectionCount={this.addSectionCount}
                            editSection={this.editSection}
                            changeStep={this.changeStep}
                            removeSection={this.removeSection}
                            setSection={this.setSection}
                            addFilters={this.addFilters}
                            addQuestions={this.addQuestions}
                            show_save_section={this.state.show_save_section}
                            setSaveSection={this.setSaveSection}
                        />

                    )}

                    {this.state.step == 3 && (
                        <QuizPreview
                            handleSubmit={this.handleSubmit}
                            formData={this.state}
                            changeStep={this.changeStep}
                        />
                    )}
                </Main>
                <SideBar>
                    <ProfileName />
                    <ActionButtons />
                    <Company />
                </SideBar>
            </Section>
        );

    }

}

const mapStateToProps = (state) => {
    //console.log(state);
    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        createQuiz: (formData) => dispatch(createQuiz(formData)),
        editQuiz: (id) => dispatch(editQuiz(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AddQuiz);