import React, { Component } from 'react';
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { EditorState, convertToRaw, convertFromRaw, ContentState, convertFromHTML } from 'draft-js';
import draftToHtml from 'draftjs-to-html';

class QuizForm extends Component {
	state = {
		editorState: EditorState.createEmpty(),
		FailedState: EditorState.createEmpty(),
		instructionState: EditorState.createEmpty(),
	}
	onChange = (neweditorState) => {
		this.setState({ editorState: neweditorState });
		let htmlmsg = draftToHtml(convertToRaw(neweditorState.getCurrentContent()));
		this.props.handleChange({ target: { name: 'quiz_success_message', value: htmlmsg } }, 'required', 'Quiz Success Message is required')
	};
	onFailedStateChange = (neweditorState) => {
		this.setState({ FailedState: neweditorState });
		let htmlmsg = draftToHtml(convertToRaw(neweditorState.getCurrentContent()));
		this.props.handleChange({ target: { name: 'quiz_failed_message', value: htmlmsg } }, 'required', 'Quiz Failed Message is required')
	};
	onInstructionChange = (neweditorState) => {
		this.setState({ instructionState: neweditorState });
		let htmlmsg = draftToHtml(convertToRaw(neweditorState.getCurrentContent()));
		this.props.handleChange({ target: { name: 'quiz_instructions', value: htmlmsg } }, 'required', 'Quiz Instruction is required')
	};



	componentWillMount() {
		//console.log(formData)
		// this.props.fetchUser(this.props.params.id);
		if (this.props.formData.quiz_success_message != null) {

			let n = EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(this.props.formData.quiz_success_message)));
			this.setState({ editorState: n });
		}
		if (this.props.formData.quiz_failed_message != null) {
			let n = EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(this.props.formData.quiz_failed_message)));
			this.setState({ FailedState: n });
		}
		if (this.props.formData.quiz_instructions != null) {
			let n = EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(this.props.formData.quiz_instructions)));
			this.setState({ instructionState: n });
		}

	}


	render() {

		const { handleChange, nextStepView, errors, formData, getValidationState } = this.props;


		return (
			<form method='post' onSubmit={(e) => nextStepView(e)}>
				<div className='bg-white br-5 '>
					<div>
						<h4 className='text-primary'>Add Quiz</h4>
						{/* border */}
						<div className="border-bottom-blue mb-2 mt-2"></div>
						{/* border */}

						{/* form starts here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-5'>
								<div className='row mb-2'>
									<div className='col-md-12'>
										<label className='text-dark'>Quiz Type</label>

										<select
											className='form-select form-select-md input-border text-primary'
											onChange={(e) =>
												handleChange(e, 'required', 'Quiz type is required')
											}
											name='type'
											required
										>
											<option value=''>--Select Quiz type--</option>
											<option
												value='1'
												selected={formData.type == '1' ? true : false}
											>
												Candidate Quiz
											</option>
											<option
												value='2'
												selected={formData.type == '2' ? true : false}
											>
												Recruiter Quiz
											</option>
										</select>
									</div>
								</div>
							</div>
							<div className='col-md-12'>
								<label className='text-dark'>Quiz title
								</label>
							</div>
							<div className='col-md-12'>
								<input
									type='text'
									className='form-control input-border'
									onChange={(e) => handleChange(e, 'required', 'Quiz Title is required')}
									name='title'
									defaultValue={formData.title}
									required
								/>

								{formData.valid && <h3 className='error'> Valid </h3>}
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here*/}
						{/* <div className="row mt-2 ">
                            <div className="col-md-12">
                                <label className="text-dark">
                                    Quiz Name
                                </label>
                            </div>
                            <div className="col-md-12">
                                <input
                                    type='text'
                                    className='form-control input-border'
                                    onKeyUp={(e) => handleChange(e, "required", "Quiz Name is required")}
                                    name='name'
                                    defaultValue={formData.name}
                                    required
                                />
                            </div>
                        </div> */}
						{/* fields ends here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-7'>
								<div className='row mt-2'>
									<div className='col-md-12'>
										<label className='text-dark'>Quiz Duration(In Minutes)</label>
									</div>
									<div className='col-md-12'>
										<input
											type='number'
											className='form-control input-border mt-0'
											onChange={(e) => {
												e.target.value = (e.target.value < 0) ? 0 : e.target.value;
												handleChange(e, 'numbers_only', 'Duration Should be Number');
											}
											}
											name='duration'
											min={0}
											defaultValue={formData.duration}
											required
										/>
									</div>
								</div>
							</div>
							<div className='col-md-5'>
								<div className='row mt-2'>
									<div className='col-md-12'>
										<label className='text-dark'>Evaluation</label>

										<select
											className='form-select form-select-md input-border'
											onChange={(e) =>
												handleChange(e, 'required', 'Evaluation is required')
											}
											name='evaluation'
											required
										>
											<option value=''>--Select Evaluation--</option>
											<option
												value='1'
												selected={formData.evaluation == '1' ? true : false}
											>
												Automatic
											</option>
											<option
												value='2'
												selected={formData.evaluation == '0' ? true : false}
											>
												Manual
											</option>
										</select>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here*/}
						{/* <div className='row mt-2 '>
							<div className='col-md-12'>
								<div className='row mt-2'>
									<div className='col-md-12'>
										<label className='text-dark'>Quiz Instruction
											<i title='Quiz Instruction' class="fas fa-info-circle ms-1 text-primary"></i>
										</label>
									</div>
									<div className='col-md-12'>
										<textarea
											className='form-control input-border'
											onChange={(e) =>
												handleChange(e, 'required', 'Quiz Instruction is required')
											}
											name='quiz_instructions'
											defaultValue={formData.quiz_instructions}
											required
										></textarea>
									</div>
								</div>
							</div>
						</div> */}
						{/* fields ends here */}

						{/* fields starts here*/}
						{/* <div className="row mt-2 ">
                            <div className="col-md-12">
                                <div className="row mt-2">
                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Instruction
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <textarea
                                            className='form-control input-border'
                                            onKeyUp={(e) => handleChange(e, "required", " Instruction is required")}
                                            name='instruction'
                                            defaultValue={formData.instruction}
                                            required
                                        ></textarea>
                                    </div>
                                </div>
                            </div>

                        </div> */}
						{/* fields ends here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-12'>
								<label className='text-dark'>Quiz Instruction
									<i title='Quiz Success Message' class="fas fa-info-circle ms-1 text-primary"></i>
								</label>
							</div>
							<div className='col-md-12'>

								<Editor
									editorState={this.state.instructionState} defaultEditorState={this.state.instructionState} wrapperClassName="demo-wrapper" editorClassName="editer-content"
									onEditorStateChange={this.onInstructionChange}
								/>

								{/* <textarea
									type='text'
									className='form-control input-border'
									onChange={(e) =>
										handleChange(e, 'required', 'Quiz Success Message is required')
									}
									name='quiz_success_message'
									defaultValue={formData.quiz_success_message}
									required
								></textarea> */}
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-12'>
								<label className='text-dark'>Quiz Success Message
									<i title='Quiz Success Message' class="fas fa-info-circle ms-1 text-primary"></i>
								</label>
							</div>
							<div className='col-md-12'>

								<Editor
									editorState={this.state.editorState} wrapperClassName="demo-wrapper" editorClassName="editer-content"
									onEditorStateChange={this.onChange}
								/>

								{/* <textarea
									type='text'
									className='form-control input-border'
									onChange={(e) =>
										handleChange(e, 'required', 'Quiz Success Message is required')
									}
									name='quiz_success_message'
									defaultValue={formData.quiz_success_message}
									required
								></textarea> */}
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-12'>
								<label className='text-dark'>Quiz Failed Message
									<i title='Quiz Failed Message' class="fas fa-info-circle ms-1 text-primary"></i>
								</label>
							</div>
							<div className='col-md-12'>
								<Editor
									editorState={this.state.FailedState} wrapperClassName="demo-wrapper" editorClassName="editer-content"
									onEditorStateChange={this.onFailedStateChange}
								/>
								{/* <textarea
									type='text'
									className='form-control input-border'
									onChange={(e) =>
										handleChange(e, 'required', 'Quiz Failed Message is required')
									}
									name='quiz_failed_message'
									defaultValue={formData.quiz_failed_message}
									required
								></textarea> */}
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-12'>
								<label className='text-dark'>Per Page Questions</label>
							</div>
							<div className='col-md-12'>
								<input
									type='number'
									className='form-control input-border'
									onChange={(e) => {
										e.target.value = (e.target.value < 0) ? 0 : e.target.value;
										handleChange(e, 'required', 'Per Page Questions is required');
									}
									}
									name='per_page_questions'
									min={0}
									defaultValue={formData.per_page_questions}
									required
								/>
							</div>
						</div>
						{/* fields ends here */}



						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-6'>
								<div className='col-md-12'>
									<label className='text-dark'>Correct Marks</label>
								</div>
								<div className='col-md-12'>
									<input
										type='number'
										className='form-control input-border'
										onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, 'required', 'Quiz Marks is required'); }}
										name='correct_marks'
										min={0}
										defaultValue={formData.correct_marks}
										required
									/>
								</div>
							</div>

							<div className='col-md-6'>
								<div className='col-md-12'>
									<label className='text-dark'>Incorrect Marks</label>
								</div>
								<div className='col-md-12'>
									<input
										type='text'
										className='form-control input-border'
										onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, 'required', 'Incorrect Marks is required'); }
										}
										name='incorrect_marks'
										defaultValue={formData.incorrect_marks}
										required
									/>
								</div>
							</div>
						</div>
						{/* fields ends here */}
						{/* fields starts here*/}
						<div className='row mt-2 '>
							<div className='col-md-12'>
								<label className='text-dark'>Passing Marks
									<i title='Passing Marks' class="fas fa-info-circle ms-1 text-primary"></i>
								</label>
							</div>
							<div className='col-md-12'>
								<input
									type='number'
									className='form-control input-border'
									onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, 'required', 'Passing Marks is required'); }}
									name='passing_marks'
									min={0}
									defaultValue={formData.passing_marks}
									required
								/>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2'>
							<div className='col-md-4'>
								<label className='text-dark'>Retake Quiz</label>

								<select
									className='form-select form-select-md input-border'
									onChange={(e) => handleChange(e, 'required', 'Retake Quiz is required')}
									name='quiz_retake'
									required
								>
									<option value='none'>None</option>
									<option value='1' selected={formData.quiz_retake == '1' ? true : false}>
										1
									</option>
									<option value='2' selected={formData.quiz_retake == '2' ? true : false}>
										2
									</option>
								</select>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Show Result<i title='Show Result' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='show_result'
											onChange={(e) => handleChange(e)}
											checked={(formData.show_result) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Check Answer<i title='Check Answer' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='check_answer'
											onChange={(e) => handleChange(e)}
											checked={(formData.check_answer) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Partial Markings<i title='Partial Markings' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='partial_marking'
											onChange={(e) => handleChange(e)}
											checked={(formData.partial_marking) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Randomize Questions<i title='Randomize Questions' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='randomize_questions'
											onChange={(e) => handleChange(e)}
											checked={(formData.randomize_questions) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Randomize Question Between Section<i title='Randomize Question Between Section' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='randomize_question_bs'
											onChange={(e) => handleChange(e)}
											checked={(formData.randomize_question_bs) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Randomize Section Questions<i title='Randomize Section Questions' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='randomize_section_questions'
											onChange={(e) => handleChange(e)}
											checked={(formData.randomize_section_questions) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}



						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Randomize Section<i title='Randomize Section' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='randomize_section'
											onChange={(e) => handleChange(e)}
											checked={(formData.randomize_section) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Randomize Options<i title='Randomize Options' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											onChange={(e) => handleChange(e)}
											name='randomize_options'
											checked={(formData.randomize_options) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* fields starts here */}
						<div className='row mt-2 '>
							<div className='col-md-6 col-6'>
								<label className='text-dark'>Negative Marking<i title='Negative Marking' class="fas fa-info-circle ms-1 text-primary"></i></label>
							</div>
							<div className='col-md-6 col-6'>
								<div className='ms-auto d-table mt-auto mb-auto'>
									<div class='form-check form-switch ms-auto'>
										<input
											class='form-check-input'
											type='checkbox'
											id='flexSwitchCheckChecked'
											name='negative_marking'
											onChange={(e) => handleChange(e)}
											checked={(formData.negative_marking) ? true : false}
										/>
									</div>
								</div>
							</div>
						</div>
						{/* fields ends here */}

						{/* dotted border */}

						<div className='border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9'></div>

						{/* dotted border */}

						{/* submit button */}
						<div className='row'>
							<div className='col-md-2'>
								<button type='submit' className='btn btn-primary d-block w-100'>
									Next
								</button>
							</div>
						</div>
					</div>
					{/* submit button */}

					{/* form ends here */}
				</div>
			</form>
		);

	}

}

export default QuizForm;