import React, { Component } from 'react';
import { sumArray } from '../../../classes';
import Parser from 'react-html-parser';

class QuizPreview extends Component {


    componentWillMount() {
        //console.log(formData)
        // this.props.fetchUser(this.props.params.id);
    }


    render() {

        const { formData, handleSubmit, changeStep } = this.props;

        return (

            <div className='bg-white br-5 p-4'>

                <div className="row">
                    <div className="col-md-12 col-12">
                        <h5 className="text-primary">Quizes</h5>
                    </div>

                </div>
                {/* border */}
                <div className="border-bottom-blue mb-2 mt-2"></div>
                {/* border */}

                <h4>Quiz Title: {formData?.title}</h4>
                <h5 className='mt-3 mb-3'>Quiz Instruction</h5>
                <p className='mb-3'>{Parser(formData.quiz_instructions)}</p>
                <div className='d-flex'>
                    <h5>Quiz Duration</h5>
                    <h5 className='ms-auto'>{formData.duration} Mins</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>


                <div className='d-flex'>
                    <h5>Quiz Evaluation</h5>
                    <h5 className='ms-auto'>{(formData.evaluation) ? 'Automatic' : 'Manual'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>


                <h5>Success Message</h5>
                <p className='ms-auto'>{Parser(formData.quiz_success_message)}</p>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Passing Marks</h5>
                    <h5 className='ms-auto'>{formData.passing_marks}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Correct Marks</h5>
                    <h5 className='ms-auto'>{formData.correct_marks}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Incorrect Marks</h5>
                    <h5 className='ms-auto'>{formData.incorrect_marks}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Retake Quiz</h5>
                    <h5 className='ms-auto'>{(formData.quiz_retake) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Show Result</h5>
                    <h5 className='ms-auto'>{(formData.show_result) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Check Answer Hint</h5>
                    <h5 className='ms-auto'>{(formData.check_answer) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Partial Marking</h5>
                    <h5 className='ms-auto'>{(formData.partial_marking) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Randomize Questions</h5>
                    <h5 className='ms-auto'>{(formData.randomize_questions) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Randomize Questions between Sections</h5>
                    <h5 className='ms-auto'>{(formData.randomize_question_bs) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Randomize Section Questions</h5>
                    <h5 className='ms-auto'>{(formData.randomize_section_questions) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Randomize Options</h5>
                    <h5 className='ms-auto'>{(formData.randomize_options) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div className='d-flex'>
                    <h5>Negative Marking</h5>
                    <h5 className='ms-auto'>{(formData.negative_marking) ? 'Yes' : 'No'}</h5>
                </div>
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>

                <div>
                    <h5>Quiz Sections</h5>

                    <div className='row m-0'>
                        {[...Array(formData.sectionCount)].map((e, i) => {
                            return <div className='col-md-3 mt-2 border-blue rounded me-1'>
                                <div className="d-flex align-items-start flex-column min-height-230">
                                    <h5 className='pt-2 text-primary fw-bolder'>
                                        {formData.sections[i]?.section_title}
                                    </h5>
                                    <p className="text-black">Total Questions: {formData.sections[i]?.added_questions ? formData.sections[i].added_questions.length : 0}</p>
                                    <h6 className='pt-0 text-primary fw-bolder'>

                                        <p className="mt-2 text-black">Points : {formData.sections[i]?.points ? sumArray(formData.sections[i].points) : 0}</p>

                                    </h6>
                                    <button class="btn btn-primary mt-auto mb-2 me-auto ms-auto d-block w-100" type="button" onClick={(e) => changeStep(2)}>View Questions</button>
                                </div>
                            </div>
                        })}
                    </div>
                </div>

                {/* submit button */}
                <div className='border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2'></div>
                <div className='d-flex'>
                    <button className='btn btn-outline-primary' onClick={(e) => changeStep(1)}>
                        Edit
                    </button>
                    <button className='btn btn-primary ms-auto' onClick={(e) => handleSubmit()}>
                        Save Quiz
                    </button>
                </div>

            </div>

        );

    }

}

export default QuizPreview;