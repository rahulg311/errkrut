import React, { Component } from 'react';
import Header from '../../../components/common/Header';

//import "react-select/dist/react-select.css";
import Select from "react-select";
import { getFilterQuestions, getQuestion, getQuestionAttr } from '../../../store/actions/questions';
import { getAuthToken } from "../../../classes/index";
import {END_POINT } from "../../../routes/api_routes";

import { connect } from 'react-redux';
import MultiSelect from '../AddQuestion/MultiSelect';
import { notification } from '../../../classes/messages';
import { Link } from 'react-router-dom';
import { sumArray } from '../../../classes';


class QuizeStep2 extends Component {

    state = {
        //questions: [],
        //sections: [],
        //sectionCount: 1,
        filters: null,
        quesAttrs: [],
        //multiSelectTags: null,
        currentSectionIndex: 0,
        showFilter: 0,
        showQuestion: 0,
        showSection: 1
    }

    componentWillMount() {

        this.getQuestionAttr();

        this.getFilterQuestions({ user_id: this.props.formData.user_id });

        this.get_question_subject(this.props.formData.user_id);

    }

    handleMultiSelect = (data, fieldname) => {
        //console.log(data);
        //console.log(fieldname);
        //this.setState({ multiSelectTags: data });
        //setMultiSelectTags(data);

        let filter = (this.state.filters) ? this.state.filters : {};

        filter[fieldname] = data;

        this.setState({ filters: filter }, () => {
            this.getFilterQuestions({ [fieldname]: data, user_id: this.props.formData.user_id });
        });
    }


    /* set sections */
    setSection = (e, i, type) => {

        let quiz_sections = this.props.formData.sections[i];

        if (!quiz_sections) {
            quiz_sections = { section_title: '', number_of_questions: '', added_questions: [], filter_questions: [], points: [] };
        }

        quiz_sections[type] = e.target.value;

        //let a = [];
        //a[i] = quiz_sections;

        let qs = this.props.formData.sections;
        qs[i] = quiz_sections;

        this.props.setSection(qs);

        //this.setState({ sections: a });

    }
    /* set sections */

    /* current Section */
    currentSection = (i, type) => {

        let notify;

        //console.log(i);
        //console.log(type);

        let section = this.props.formData.sections[i];

        if (section.section_title != '' && section.number_of_questions > 0) {

            if (type == 'add_filter') {
                this.setState({ showFilter: 1 });
                notify = notification({ message: 'Please Add Filter Below', type: 'success' });
                this.setState({ showSection: 0 });
            }

            if (type == 'add_question') {
                this.setState({ showQuestion: 1 });
                notify = notification({ message: 'Please Add Questions Below', type: 'success' });
                this.setState({ showSection: 0 });
            }

            this.setState({ currentSectionIndex: i });

        } else {
            notify = notification({ message: 'Please Fill Section', type: 'error' });
        }

        notify();

    }
    /* current Section */

    saveSection = (i, value) => {
        if (this.props.formData.sections[i].section_title != '' && this.props.formData.sections[i].number_of_questions != 0) {
            let s = this.props.show_save_section;
            s[i] = value;
            this.props.setSaveSection(s);
        } else {
            let notify = notification({ message: 'Please Fill Section', type: 'error' });
            notify();
        }
    }
    /* get question Subject */
    get_question_subject = async (id) => {
		let token = await getAuthToken();

        fetch(END_POINT + "get_question_subject/" + id, {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		})
        .then((response) => response.json())
        .then((result) => {
            let subjectOption = result.data.map(row => {
                if(row.subject != null)
                return <option value={row.subject}>{row.subject}</option> 
            })
            this.setState({subjectOption: subjectOption});

        });
    }

    /* get filter questions */
    getFilterQuestions = async (data) => {

        //console.log(data)

        await this.props.getFilterQuestions(data);

        //console.log(this.props.data);
        this.props.updateQuestions(this.props.data?.data);

        //this.setState({ questions: this.props.data?.data });

    }
    /* get filter questions */

    /* set filters */
    setFilters = (e) => {
        //console.log(e.target.value);
        let iname = e.target.name;
        let ivalue = e.target.value;

        let filter = (this.state.filters) ? this.state.filters : {};

        filter[iname] = ivalue;

        this.setState({ filters: filter }, () => {
            this.getFilterQuestions({ [iname]: ivalue, user_id: this.props.formData.user_id });
        });
    }
    /* set filters */

    /* back to sections */
    backToSection = () => {
        this.setState({ showSection: 1 });
        this.setState({ showFilter: 0 });
        this.setState({ showQuestion: 0 });
    }
    /* back to sections */

    /* add section filter */

    setSectionFilter = (e) => {

        //console.log(this.state.filters);


        /* set filers in state */
        //this.addFilters();
        /* set filters in state */

        let values = this.state.filters && Object.keys(this.state.filters).map((k, v) => {
            return this.state.filters[k];
        })

        this.addFilters(values);

        this.setState({ showSection: 1 });
        this.setState({ showFilter: 0 });

        let notify = notification({ message: 'Filters Added to Section', type: 'success' });
        notify();

    }
    /* add section filter */

    /* add filters */
    addFilters = (value) => {

        let quiz_sections = this.props.formData.sections[this.state.currentSectionIndex];

        quiz_sections['filter_questions'] = value;

        let qs = this.props.formData.sections;
        qs[this.state.currentSectionIndex] = quiz_sections;

        this.props.addFilters(qs);

        //this.setState({ sections: quiz_sections });

    }
    /* add filters */

    /* add questions */
    addQuestions = (id, points = 0) => {

        let quiz_sections = this.props.formData.sections[this.state.currentSectionIndex];

        let notify;

        if (quiz_sections.number_of_questions > quiz_sections.added_questions.length) {

            quiz_sections['added_questions'].push(id);

            quiz_sections['points'].push(points);

            let qs = this.props.formData.sections;
            qs[this.state.currentSectionIndex] = quiz_sections;

            this.props.addQuestions(qs);

            //this.setState({ sections: quiz_sections });
            if (quiz_sections['added_questions'].length == quiz_sections.number_of_questions) {
                this.setState({ showSection: 1 });
                this.setState({ showQuestion: 0 });
            }
        } else {

            notify = notification({ message: 'Can not add more than number of questions entered', type: 'error' });
        }

        if (notify)
            notify();

    }
    /* add questions */

    /* is disable question */
    isDisableQuestion = (id) => {

        let quiz_sections = this.props.formData.sections[this.state.currentSectionIndex];

        let quizArr = quiz_sections['added_questions'];

        if (quizArr.indexOf(id) !== -1) {
            return true;
        } else {
            return false;
        }

    }
    /* is disable question */

    /* get question attributes */
    getQuestionAttr = async () => {

        await this.props.getQuestionAttr();

        //console.log(this.props.data);

        this.setState({ quesAttrs: this.props.data.data });

    }
    /* get question attributes */

    /* delete section */

    removeSection = (removeIndex) => {
        //console.log(this.props.formData.sections)

        if(this.props.formData.sections.length > 1){
            
            const newOptions = [...this.props.formData.sections].filter((e, i) => {
                console.log(e)
                console.log(i)
                return i !== removeIndex;
            });
    
            console.log(newOptions);
    
            this.props.removeSection(newOptions);
        }


        /* this.setState({sections: newOptions}, () => {
            console.log(this.props.formData.sections);
        }); */


    }
    /* delete section */



    render() {

        const { changeStep, handleSubmit, handleChange, formData, addSectionCount, editSection } = this.props;

        console.log(this.props.formData.questions)

        return (
            <div className='main-container position-relative'>
                <Header />
                <div className='content-wrapper'>
                    <div className="container">
                        {/* Content */}
                        <div className="container bg-white br-5 mb-2 pt-5 pb-5">
                            <div className="row">
                                <div className="col-md-12 col-12">
                                    <h5 className="text-primary">Quizes</h5>
                                </div>

                            </div>
                            {/* border */}
                            <div className="border-bottom-blue mb-2 mt-2"></div>
                            {/* border */}

                            <div className="row">

                                <div className="col-12">
                                    <div className="mt-1 mb-2">
                                        <h6 class="font-bold text-dark">{formData.title}</h6>
                                    </div>
                                </div>

                                {/* add section */}

                                {this.state.showSection == 1 &&

                                    <>

                                        <div className="col-md-7 col-10">
                                            <div className="mt-auto mb-auto">
                                                <p className="f-Poppins-Medium text-dark">Dynamic Quiz</p>
                                                <p className="mt-1 f-0-7">Lorem ipsum sitamet, consectetuer adipiscing elit, seddiam</p>
                                            </div>
                                        </div>
                                        <div className="col-md-2 col-2">
                                            <div className="mt-auto mb-auto">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" onChange={(e) => handleChange(e, '', '', true)} name="dynamic_quiz" />
                                                </div>
                                            </div>
                                        </div>

                                        {[...Array(formData.sectionCount)].map((e, i) => {

                                            return <div className="col-md-6 col-2 mt-2">
                                                <section class="card border-blue1 rounded py-3 px-4 min-height-230">
                                                    <header class="d-flex">

                                                        <div class="mt-auto mb-auto w-100">

                                                            <div className="row">
                                                            {(this.props.show_save_section[i] == false && formData.dynamic_quiz == 0) && 
                                                                <div class="dropdown d-flex justify-content-end">
                                                                    <p class="" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="las la-ellipsis-v f-1-1 text-primary cursor vertical-middle"></i>
                                                                    </p>
                                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                        <a class="dropdown-item" href="#" onClick={(e) => editSection(i)}>Edit</a>
                                                                        <a class="dropdown-item" href="#" onClick={(e) => this.removeSection(i)}>Delete</a>
                                                                    </div>
                                                                </div>
            
                                                            }

                                                                <div className="col-md-12">

                                                                    {this.props.show_save_section[i] == true &&
                                                                        <input type="text" className="form-control mt-1" onChange={(e) => this.setSection(e, i, 'section_title')} placeholder="Section Title"
                                                                            value={this.props.formData.sections[i]?.section_title}
                                                                        />
                                                                    }

                                                                    {this.props.show_save_section[i] == false && <h5 className="text-primary">{this.props.formData.sections[i]?.section_title}</h5>}
                                                                </div>

                                                                <div className="col-md-12">

                                                                    {this.props.show_save_section[i] == true &&
                                                                        <input type="number" className="form-control mt-1" onChange={(e) => this.setSection(e, i, 'number_of_questions')} placeholder="Number of Questions" defaultValue="0" min={0}
                                                                            value={this.props.formData.sections[i]?.number_of_questions}
                                                                        />
                                                                    }

                                                                    <p className="mt-2">Number of Questions : {this.props.show_save_section[i] == false && <label className="text-dark">{this.props.formData.sections[i]?.number_of_questions}</label>}</p>
                                                                </div>

                                                            </div>
                                                            {formData.dynamic_quiz == 0 &&
                                                                <>
                                                                    <p className="mt-2">Questions Added : {this.props.formData.sections[i]?.added_questions ? this.props.formData.sections[i].added_questions.length : 0}</p>

                                                                    <p className="mt-2">Points : {this.props.formData.sections[i]?.points ? sumArray(this.props.formData.sections[i].points) : 0}</p>
                                                                </>
                                                            }
                                                        </div>
                                                    </header>
                                                    <hr class="mt-md-3 mt-0" />
                                                    <footer>
                                                        <div class="d-flex align-items-center w-100 me-auto">

                                                            {this.props.show_save_section[i] == true &&
                                                                <div class="d-flex justify-content-start w-100">
                                                                    <a href="javascript:void(0)" class="btn btn-primary btn-sm text-light px-4" onClick={(e) => this.saveSection(i, false)}>Save Section
                                                                    </a>
                                                                </div>
                                                            }

                                                            {(this.props.show_save_section[i] == false && formData.dynamic_quiz == 0) &&
                                                                <div class="d-flex justify-content-start w-100">
                                                                    <a href="javascript:void(0)" class="btn btn-primary btn-sm text-light px-4" onClick={(e) => this.currentSection(i, 'add_question')}>Add Questions
                                                                    </a>
                                                                </div>

                                                            }

                                                            {(this.props.show_save_section[i] == false && formData.dynamic_quiz == 1) &&
                                                                <div class="d-flex justify-content-start w-100">
                                                                    <a href="javascript:void(0)" class="btn btn-info btn-sm text-light px-4" onClick={(e) => this.currentSection(i, 'add_filter')}>Add Filters
                                                                    </a>
                                                                </div>
                                                            }

                                                            {i != 0 &&
                                                                <div class="d-flex justify-content-end">
                                                                    <a href="javascript:void(0)" class="btn btn-danger btn-sm text-light px-1" onClick={(e) => this.removeSection(i)}>
                                                                        <i class="la la-trash f-1 cursor"></i>
                                                                    </a>
                                                                </div>
                                                            }
                                                        </div>
                                                    </footer>
                                                </section>
                                            </div>
                                        }

                                        )

                                        }

                                        {
                                            <div class="col-md-6 mt-2 cursor" onClick={(e) => {
                                                addSectionCount()
                                            }}>
                                                <div className='card border-blue1 rounded py-3 px-4 min-height-230 d-flex align-items-center'>
                                                    <h4 class="text-primary mt-auto mb-auto">Add Quiz Section +</h4>
                                                </div>

                                            </div>
                                        }

                                    </>

                                }

                                {/* add section */}

                            </div>


                            {/* filter section starts here */}
                            {/* <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-4 mb-4"></div> */}

                            {(this.state.showFilter == 1 || this.state.showQuestion == 1) &&
                                <>
                                    <div className='row mt-2 w-100'>
                                        <h5 className="text-dark mb-2">Filters</h5>
                                        {this.state.quesAttrs.length > 0 && this.state.quesAttrs.map((field) => {
                                            if (field.type.toLowerCase() == 'radio') {
                                                return (
                                                    <>
                                                        <div>
                                                            <label className='text-dark'>{field.title}</label>
                                                        </div>

                                                        <div className='d-flex'>
                                                            {field.options.split(',').map((option, index) => {
                                                                return (
                                                                    <div class='form-check mt-1 me-2'>
                                                                        <input
                                                                            class='form-check-input'
                                                                            type='radio'
                                                                            name={field.name}
                                                                            id={index}
                                                                            value={option}
                                                                            onChange={(e) => this.setFilters(e)}
                                                                        />
                                                                        <label class='form-check-label' for={index}>
                                                                            {option}
                                                                        </label>
                                                                    </div>
                                                                );
                                                            })}
                                                        </div>
                                                    </>
                                                );
                                            } else if (field.type.toLowerCase() === 'text') {
                                                if(field.title.toLowerCase() == 'subject'){
                                                    return (
                                                        <div className='mt-2'>
                                                            <div>
                                                                <label className='text-dark'>{field.title}</label>
                                                            </div>
                                                            <div>
                                                                <select
                                                                    class='form-select px-4 mt-1'
                                                                    aria-label='Default select example'
                                                                    name={field.name}
                                                                    onChange={(e) => this.setFilters(e)}
    
                                                                >
                                                                    <option value="">--subject--</option>
                                                                    {this.state.subjectOption}
                                                                </select>
                                                            </div>
                                                        </div>
                                                    );
    
                                                }
                                                return (
                                                    <div className='mt-4'>
                                                        <div>
                                                            <label className='text-dark'>{field.title}</label>
                                                        </div>
                                                        <div className=''>
                                                            <input type='text' className='form-control' name={field.name} onChange={(e) => this.setFilters(e)} />
                                                        </div>
                                                    </div>
                                                );
                                            } else if (field.type == 'MultiSelect') {
                                                const options = field.options.split(',');
                                                return (
                                                    <div className='mt-4'>
                                                        <div className='w-100'>
                                                            <div>
                                                                <label className='text-dark'>{field.title}</label>
                                                            </div>
                                                            <div>
                                                                <MultiSelect options={options} handleMultiSelect={this.handleMultiSelect} fieldname={field.name} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            } else if (
                                                field.type.toLowerCase() == 'dropdown' ||
                                                field.type.toLowerCase() == 'select'
                                            ) {
                                                return (
                                                    <div className='mt-2'>
                                                        <div>
                                                            <label className='text-dark'>{field.title}</label>
                                                        </div>
                                                        <div>
                                                            <select
                                                                class='form-select px-4 mt-1'
                                                                aria-label='Default select example'
                                                                name={field.name}
                                                                onChange={(e) => this.setFilters(e)}

                                                            >
                                                                {field.options.split(',').map((option) => {
                                                                    return <option value={option}>{option}</option>;
                                                                })}
                                                            </select>
                                                        </div>
                                                    </div>
                                                );
                                            } else if (field.type.toLowerCase() == 'number') {
                                                return (
                                                    <div>
                                                        <div className='mt-4'>
                                                            <label className='text-dark'>{field.title}</label>
                                                        </div>
                                                        <div className=''>
                                                            <input
                                                                type='number'
                                                                className='form-control'
                                                                name={field.name}
                                                                onChange={(e) => this.setFilters(e)}

                                                            />
                                                        </div>
                                                    </div>
                                                );
                                            }
                                        })}
                                    </div>

                                    <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-4 mb-4"></div>
                                    {/* border */}

                                    {this.state.showFilter == 1 && <button className="btn btn-primary" onClick={(e) => { this.setSectionFilter(e) }}>Save Filter</button>}

                                </>
                            }

                            {/* filter section ends here */}

                            {/* questions table start here */}
                            {this.state.showQuestion == 1 &&
                                <>
                                    <div className="row mt-2">
                                        <div className="col-md-12 col-12 table-responsive">

                                            {this.state.showQuestion == 1 &&

                                                <table className="w-100 table table-primary table-striped">

                                                    <thead>
                                                        <tr>
                                                            <td className="bg-blue br-top-left-10">

                                                            </td>
                                                            <td className="bg-blue col-3">
                                                                <p className="text-white f-0-8 mt-auto mb-auto">
                                                                    <span>Title</span>
                                                                    <span className="float-end"><i class="las la-sort cursor"></i></span>
                                                                </p>
                                                            </td>
                                                            <td className="bg-blue">
                                                                <p className="text-white f-0-8 mt-auto mb-auto">
                                                                    <span>Type</span>
                                                                    <span className="float-end"><i class="las la-sort cursor"></i></span>
                                                                </p>
                                                            </td>
                                                            <td className="bg-blue">
                                                                <p className="text-white f-0-8 mt-auto mb-auto">
                                                                    <span>Date</span>
                                                                    <span className="float-end"><i class="las la-sort cursor"></i></span>
                                                                </p>
                                                            </td>
                                                            {formData.dynamic_quiz == 0 &&
                                                                <td className="bg-blue br-top-right-10">
                                                                    <p className="text-white"> Action </p>
                                                                </td>
                                                            }
                                                        </tr>
                                                    </thead>

                                                    <tbody>

                                                        {this.props.formData.questions && this.props.formData.questions?.map((v, k) => {

                                                            return (

                                                                <tr>
                                                                    <td className="align-middle">
                                                                        <input class="form-check-input f-0-7 mt-auto mb-auto align-middle" type="radio" name="flexRadioDefault" id="flexRadioDefault2" onClick={(e) => { this.addQuestions(v.id, v.points) }} />
                                                                    </td>

                                                                    <td className="align-middle col-md-2">

                                                                        <p className="text-black f-0-8">{v.question}</p>

                                                                    </td>

                                                                    <td className="align-middle col-md-3">

                                                                        <p className="text-black f-0-8">{v.question_type}</p>
                                                                    </td>

                                                                    <td className="align-middle col-md-4">
                                                                        <p className="text-black f-0-8"> {v.date} </p>
                                                                    </td>


                                                                    {formData.dynamic_quiz == 0 && <td className="align-middle">
                                                                        <button className={`btn btn-outline-primary f-0-8 ${(this.isDisableQuestion(v.id)) ? `disabled` : ``}`} onClick={(e) => {
                                                                            this.addQuestions(v.id, v.points)
                                                                        }}> Select</button>
                                                                    </td>
                                                                    }

                                                                </tr>

                                                            );

                                                        })}

                                                    </tbody>
                                                </table>

                                            }
                                        </div>

                                    </div>

                                    {/* add more question */}
                                    <div className="row mb-2 mt-2">
                                        <div className="col-md-12 col-12">
                                            <Link to="/add-question" target="_blank"> Want to Add More Questions? </Link>
                                        </div>
                                    </div>
                                    {/* add more question */}

                                </>
                            }
                            {/* questions table ends here*/}

                            {/* submit button */}
                            <div className="row mb-2 mt-2">
                                <div className="col-md-6 col-6">

                                    {this.state.showSection == 1 &&
                                        <button className="btn btn-outline-primary ml-auto mr-auto d-block me-auto" onClick={(e) => changeStep(1)}>Previous</button>
                                    }

                                    {this.state.showSection == 0 &&
                                        <button className="btn btn-outline-primary ml-auto mr-auto d-block me-auto" onClick={(e) => { this.backToSection(1) }}>Previous</button>
                                    }
                                </div>
                                <div className="col-md-6 col-6 ">
                                    <button className="btn btn-primary ms-auto d-block" onClick={(e) => changeStep(3)}>Preview Quiz</button>
                                </div>
                            </div>

                            {/* submit button */}

                        </div>
                    </div>
                    {/* Content */}

                </div>
            </div >
        );
    }
}


const mapStateToProps = (state) => {
    const { data } = state.common;
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        getQuestion: (id) => dispatch(getQuestion(id)),
        getQuestionAttr: () => dispatch(getQuestionAttr()),
        getFilterQuestions: (options) => dispatch(getFilterQuestions(options))
    };
}


export default connect(mapStateToProps, mapDispatchToProps)(QuizeStep2);