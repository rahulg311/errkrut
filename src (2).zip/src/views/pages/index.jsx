import React, { Component } from 'react';
import { Switch } from 'react-router';
import { Route } from 'react-router';
import Header from '../../components/common/Header';
import { APP_Prefix, Campus_User_Type_ID, Recruiter_User_Type_ID } from '../../config/constants';
import AuthWrapper from '../../routes/authwrapper';
import { CampusRoutes, CandidateRoutes, CommonRoutes, CompanyRoutes, GuestRoutes } from '../../routes/routes';

class Index extends Component {

    state = {
        isLoggedIn: false,
        isRecruiter: false,
        isCampus: false
    }

    componentWillMount() {

        const user = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_profile'));
        if (user) {
            this.setState({
                isRecruiter: user.user_type === Recruiter_User_Type_ID,
                isCampus: user.user_type === Campus_User_Type_ID
            });
        }
        const authToken = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_token'));

        if (authToken) {
            this.setState({
                isLoggedIn: true
            });
        }

    }


    render() {
 
        return (
            <div>
                <Header props={this.props} />
                <section className='home-container mt-5'>

                    <Switch>
                        {/* guest user */}
                        {GuestRoutes.map((route, i) => {
                            return (
                                <Route
                                    key={i}
                                    path={route.path}
                                    exact={route.exact}
                                    component={route.component}
                                />
                            );
                        })}
                        {/* guest user */}


                        {/* logged in user */}
                        {
                            CompanyRoutes.map((route, i) => {
                                return (<AuthWrapper authed={this.state.isRecruiter} path={route.path} component={route.component} exact={route.exact} key={i} />);
                            })
                        }

                        {
                            CampusRoutes.map((route, i) => {
                                return (<AuthWrapper authed={this.state.isCampus} path={route.path} component={route.component} exact={route.exact} key={i} />);
                            })
                        }

                        {
                            CandidateRoutes.map((route, i) => {
                                return (<AuthWrapper authed={this.state.isLoggedIn} path={route.path} component={route.component} exact={route.exact} key={i} />);
                            })
                        }

                        {
                            CommonRoutes.map((route, i) => {
                                return (<AuthWrapper authed={this.state.isLoggedIn} path={route.path} component={route.component} exact={route.exact} key={i} />);
                            })
                        }
                        {/* logged in user */}



                    </Switch>
                </section>
            </div>
        );
    }

}


export default Index;