import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { getLoggedInUser } from '../../../classes/index';
import { getJobFormData } from '../../../store/actions/jobs';

import { validation } from '../../../classes/validation';
import { notification } from '../../../classes/messages';

import { connect } from 'react-redux';
import SideBar from '../../../components/hoc/SideBar';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';

import JobForm from './JobForm';

import { routeChanged, routePushed } from '../../../classes/browserHistory';
import { getQuiz } from '../../../store/actions/quiz';
import { getLetterIntent } from '../../../store/actions/letter';
import { createTemplate } from '../../../store/actions/template';

class AddTemplate extends Component {
	state = {
		job_type: '',
		job_title: '',
		designation: '',
		nature_of_employment: '',
		job_description: '',
		skill_set: '',
		qualification: '',
		ctc_from: '',
		ctc_to: '',
		min_work_exp: '',
		max_work_exp: '',
		job_location: '',
		job_function: '',
		number_of_vaccancy: '',
		user_id: null,
		preview: 0,
		errors: {},
		api_res: null,
		edit_id: 0,
		plans: [],
		quizs: [],
		template: [],
		company_id: null,
		letter_of_intent: [],
	};

	componentWillMount() {
		this.getUserId();
		this.setState({
			edit_id: this.props.match.params.id,
		});
	}

	/* get quiz */
	getQuizs = async () => {
		await this.props.getQuiz(this.state.company_id);
		console.log(this.props.quizdata);
		this.setState({ quizs: this.props.quizdata?.data });
	};
	/* get quiz */

	/* get letter */
	getLetterIntent = async () => {
		await this.props.getLetterIntent(this.state.user_id);
		console.log(this.props.letterintentdata.data);
		if (this.props.letterintentdata.status == 'success')
			this.setState({ letter_of_intent: this.props.letterintentdata?.data });
	};
	/* get letter */

	/* get user id */
	getUserId = async () => {
		const result = await getLoggedInUser();
		console.log(result);
		this.setState(
			{
				user_id: parseInt(result.id),
				company_id: parseInt(result.company_id),
			},
			() => {
				this.getQuizs();
				this.getLetterIntent();
			},
		);
	};
	/* get user id */

	/* handle validation */

	handleValidation = (obj) => {
		let error = this.state.errors;

		console.log(obj);

		let valiRes = validation(obj);

		console.log(valiRes);

		//email
		if (valiRes['error'] == 1) {
			error[obj.name] = valiRes['message'];

			this.setState({
				errors: error,
			});
		} else {
			error[obj.name] = '';

			this.setState({
				errors: error,
			});
		}
	};

	/* handle validation */

	// Handle fields change
	handleChange = async (e, valiType = '', valiMsg = '') => {
		if (e.target) {
			let ivalue = e.target.value;
			let iname = e.target.name;

			if (e.target.type == 'checkbox') {
				if (e.target.checked) {
					ivalue = 1;
				} else {
					ivalue = 0;
				}
			}

			if (valiType && valiMsg)
				this.handleValidation({
					name: iname,
					type: valiType,
					value: ivalue,
					message: valiMsg,
				});

			//this.setState({...this.state,[iname]: ivalue});

			this.setState({ [iname]: ivalue }, () => {
				console.log(this.state);

				console.log(this.state.errors);
			});
		}
	};
	/* handle change */

	/* handle Submit */
	handleSubmit = async (e) => {
		e.preventDefault();

		this.props.getJobFormData(this.state);

		let formValid = true;

		let notify = null;

		if (this.state.skill_set.length < 3) {
			formValid = false;
		}
		if (this.state.errors) {
			Object.keys(this.state.errors).map((k, v) => {
				console.log(k);
				if (this.state.errors[k] != '') {
					formValid = false;
				}
			});
		}

		if (formValid == true) {
			let formData = {
				//user_id: this.state.user_id,
				job_type: 1,
				job_title: this.state.job_title,
				designation: this.state.designation,
				nature_of_employment: this.state.nature_of_employment,
				job_description: this.state.job_description,
				skill_set: this.state.skill_set.toString(),
				qualification: this.state.qualification,
				ctc_from: this.state.ctc_from,
				ctc_to: this.state.ctc_to,
				min_work_exp: this.state.min_work_exp,
				max_work_exp: this.state.max_work_exp,
				job_location: this.state.job_location,
				job_function: this.state.job_function,
				number_of_vaccancy: this.state.number_of_vaccancy,
				company_id: this.state.company_id,
			};

			console.log(formData);

			await this.props.createTemplate(formData);

			let res = this.props.data;

			if (res) {
				if (res.status == 'success') {
					notify = notification({ message: res.message, type: 'success' });

					//routeChanged('/recruiter', this.props);

					routePushed('/successful', this.props, {
						message: 'Your Template Added Successfully.',
					});

					//routeChanged('/successful', this.props);
				} else {
					notify = notification({ message: JSON.stringify(res.message), type: 'error' });
				}
			}
		} else {
			if (this.state.skill_set.length < 3) {
				notify = notification({ message: 'Select atleast 3 skill set', type: 'error' });
			}
			else notify = notification({ message: 'Please fill the form correctly.', type: 'error' });
		}

		if (notify) notify();
	};
	/* handle Submit */

	render() {
		let errs =
			this.state.errors &&
			Object.keys(this.state.errors).map((k, v) => {
				return (
					this.state.errors[k].length >= 1 && (
						<li className='text-danger'>{this.state.errors[k]}</li>
					)
				);
			});

		return (
			<Section>
				<Main>
					<ul>{errs}</ul>

					{this.state.api_res && <p className='text-danger'>{this.state.api_res}</p>}
					{this.state.preview == 0 && (
						<JobForm
							handleChange={this.handleChange}
							handleSubmit={this.handleSubmit}
							errors={this.state.errors}
							formData={this.state}
						/>
					)}
				</Main>

				<SideBar>
					<ProfileName />
					<ActionButtons />
					<Company />
				</SideBar>
			</Section>
		);
	}
}

const mapStateToProps = (state) => {
	const { data, quizdata, letterintentdata, templatedata } = state.common;

	const { data: form_data } = state.jobreducer;
	return {
		data,
		form_data,
		quizdata,
		letterintentdata,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		createTemplate: (formData) => dispatch(createTemplate(formData)),
		getJobFormData: (formData) => dispatch(getJobFormData(formData)),
		getQuiz: (id) => dispatch(getQuiz(id)),
		getLetterIntent: (id) => dispatch(getLetterIntent(id)),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(AddTemplate);
