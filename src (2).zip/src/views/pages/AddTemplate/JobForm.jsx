import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import SkillsSelect from './SkillsSelect';

class JobForm extends Component {


    componentWillMount() {

        console.log('job form here');
        //console.log(formData)
        // this.props.fetchUser(this.props.params.id);
    }


    render() {

        const { handleChange, handleSubmit, errors, formData } = this.props;

        console.log('render here job form');

        return (
            <>
                <form method="POST" action="" onSubmit={(e) => handleSubmit(e)}>
                    <div className="bg-white">
                        <div>
                            <h4 className="text-dark">Add Template</h4>
                            <div className="border-gray-line mt-2 mb-2"></div>

                            {/* form starts here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">
                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job title
                                    </label>
                                </div>
                                <div className="col-md-12">
                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e, "letters_only", "Job Title Should be Letters Only")}
                                        name='job_title'
                                        defaultValue={formData.job_title}
                                        required
                                    />

                                    {errors['job_title'] != '' && <p className="text-danger">{errors['job_title']}</p>}
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">
                                <div className="col-md-7">
                                    <div className="row mt-2">
                                        <div className="col-md-12">
                                            <label className="text-dark">
                                                Designation
                                            </label>
                                        </div>
                                        <div className="col-md-12">
                                            <input
                                                type='text'
                                                className='form-control input-border mt-1'
                                                onKeyUp={(e) => handleChange(e, "letters_only", "Designation Should Letters Only")}
                                                name='designation'
                                                defaultValue={formData.designation}
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-5">
                                    <div className="row mt-2">
                                        <div className="col-md-12">

                                            <label className="text-dark">
                                                Nature of Employment
                                            </label>

                                            <select className="form-select form-select-md input-border mt-1" onChange={(e) => handleChange(e, "letters_only", "Nature of Employment Should Letters Only")} name="nature_of_employment" required>
                                                <option value="">
                                                    --Select Nature Employment--
                                                </option>
                                                <option value="full_time" selected={(formData.nature_of_employment == 'full_time') ? true : false}>
                                                    Full Time
                                                </option>
                                                <option value="part_time" selected={(formData.nature_of_employment == 'part_time') ? true : false}>
                                                    Part Time
                                                </option>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* fields ends here */}


                            {/* fields starts here*/}
                            <div className="row mt-2" >


                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Skill Set
                                    </label>
                                    <p className="f-0-8 text-gray">Select atleast 3 skill set which will be displayed in job and will help you target the candidates</p>
                                </div>
                                <div className="col-md-12">
                                    <SkillsSelect
                                        handleChange={handleChange}
                                    />
                                </div>


                            </div>
                            {/* fields ends here */}



                            {/* border */}
                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>
                            {/* border */}

                            {/* fields starts here*/}
                            <div className="row mt-2" >


                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Qualification
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e, "required", "Qualification is required")}
                                        name='qualification'
                                        defaultValue={formData.qualification}
                                        required
                                    />
                                </div>




                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">
                                <div className="col-md-6">

                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Annual CTC From (in lakhs/per annum)
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onKeyUp={(e) => handleChange(e, "required", "CTC From is required")}
                                            name='ctc_from'
                                            defaultValue={formData.ctc_from}
                                            required
                                        />
                                    </div>
                                </div>


                                <div className="col-md-6">
                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Annual CTC To (in lakhs/per annum)
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onKeyUp={(e) => handleChange(e, "required", "CTC to is required")}
                                            name='ctc_to'
                                            defaultValue={formData.ctc_to}
                                            required
                                        />

                                    </div>
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">
                                <div className="col-md-6">

                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Min Work Experience
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => handleChange(e, "required", "Min Work Experience Field is required")}
                                            name='min_work_exp'
                                            defaultValue={formData.min_work_exp}
                                            required
                                        />

                                        {errors['min_work_exp'] != '' && <p className="text-danger">{errors['min_work_exp']}</p>}
                                    </div>
                                </div>


                                <div className="col-md-6">
                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Max Work Experience
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => handleChange(e, "required", "Max Work Experience Field is required")}
                                            name='max_work_exp'
                                            defaultValue={formData.max_work_exp}
                                            required
                                        />

                                    </div>
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* dotted border */}

                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>

                            {/* dotted border */}

                            {/* fields starts here*/}
                            <div className="row mt-2">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job Location
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e, "required", "Job Location Field is required")}
                                        name='job_location'
                                        defaultValue={formData.job_location}
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job Function
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e, "required", "Job Function Field is required")}
                                        name='job_function'
                                        defaultValue={formData.job_function}
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Number of Vacancies
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='number'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e, "required", "Number of Vacany is required")}
                                        name='number_of_vaccancy'
                                        defaultValue={formData.number_of_vaccancy}
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* border */}
                            {/* <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div> */}
                            {/* border */}

                            {/* fields starts here*/}
                            {/* <div className="row mt-2">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Company Website
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onKeyUp={(e) => handleChange(e)}
                                        name='company_website'
                                        defaultValue={formData.company_website}
                                        required
                                    />
                                </div>

                            </div> */}
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            {/* <div className="row mt-2">
                                <div className="col-md-12">

                                    <select className="form-select form-select-md mb-3 input-border" onChange={(e) => handleChange(e, "numbers_only", "Letter of Intent Should be Number")} name="loi" required>
                                        <option value="" selected disabled>
                                            --Letter of Intent--
                                        </option>

                                        {formData.letter_of_intent.length > 0 && formData.letter_of_intent.map((p) => {
                                            return <option value={p.id} selected={(formData.loi == p.id) ? true : false}>
                                                {p.title}
                                            </option>
                                        })}

                                    </select>

                                </div>
                            </div> */}
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            {/* <div className="row mt-2">
                                <div className="col-md-12">

                                    <select className="form-select form-select-md mb-3 input-border" onChange={(e) => handleChange(e, "numbers_only", "Quiz Should be Numbers Only")} name="quiz_id" required>
                                        <option value="" selected disabled>
                                            --Add Quiz--
                                        </option>

                                        {formData.quizs && formData.quizs.map((p) => {
                                            return <option value={p.id} selected={(formData.quiz_id == p.id) ? true : false}>
                                                {p.title}
                                            </option>
                                        })}

                                    </select>

                                </div>
                            </div> */}
                            {/* fields ends here */}

                            {/* border */}
                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>
                            {/* border */}

                            {/* submit button */}
                            <div className="row">
                                <div className="col-md-6">
                                    <button type="submit" className="btn btn-primary ml-auto mr-auto d-block" >Add Template</button>
                                </div>
                            </div>

                        </div>
                        {/* submit button */}

                        {/* form ends here */}
                    </div>
                </form>
            </>
        );

    }

}

export default JobForm;