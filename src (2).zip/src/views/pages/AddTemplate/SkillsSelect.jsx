import React, { useState, useEffect } from 'react';
import { getSkills } from '../../../store/actions/skills';
import { useDispatch, useSelector } from 'react-redux';

const SkillsSelect = (props) => {
    const [search, setSearch] = useState('');
    const [filterItems, setFilterItems] = useState([]);
    const [items, setItems] = useState([]);

    const dispatch = useDispatch();

    const { skillsdata } = useSelector((state) => state.common);

    useEffect(() => {
        dispatch(getSkills());
    }, []);

    useEffect(() => {
        console.log(skillsdata?.data);
        if (skillsdata?.data) {

            let arr = Object.keys(skillsdata?.data).map((k) => {
                return skillsdata?.data[k];
            });

            console.log(arr, 'fsdfsd');
            if (arr.length > 0) {
                setItems(arr);
            }

        }
    }, [skillsdata]);


    const [selectedItems, setSelectedItems] = useState([]);

    const handleRemoveSelectedItem = (value) => {
        const filterItems = [...selectedItems].filter((e) => e !== value);
        setSelectedItems(filterItems);
        props.handleChange({ target: { name: 'skill_set', value: filterItems } });
    };

    const handleAddSelectedItem = (value) => {
        const filterItems = [...new Set([...selectedItems, value])];
        setSelectedItems(filterItems);
    };

    const setItemsHandleChange = (item, newItems) => {
        setSelectedItems([...selectedItems, item]);
        props.handleChange({ target: { name: 'skill_set', value: [...selectedItems, item] } });
    }

    React.useEffect(() => {
        console.log(items);
        const newArray = [...items].filter((item) => item.toLowerCase().includes(search.toLowerCase()));
        setFilterItems([...new Set(newArray)]);
        //props.handleChange({ target: { name: 'skill_set', value: newArray } });
    }, [search]);

    return (
        <div className='position-relative'>
            <div className='position-relative'>
                <input
                    placeholder='search'
                    className='form-control'
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                {search && (
                    <button
                        type='button'
                        class='btn-close translate-right-middle'
                        style={{ right: '10px' }}
                        onClick={() => setSearch('')}
                        aria-label='Close'
                    ></button>
                )}
            </div>
            <main className='w-35'>
                {search && filterItems.length >= 1
                    ? filterItems.map((item, i) => (
                        <div className='list-group '>
                            <li className='list-group-item list-group-item-action'>
                                <div class='form-check'>
                                    <input
                                        class='form-check-input'
                                        type='checkbox'
                                        checked={selectedItems.includes(item)}
                                        value={item}
                                        id={i}
                                        onChange={(e) => {
                                            e.target.checked
                                                ? setItemsHandleChange(item, selectedItems)
                                                : handleRemoveSelectedItem(e.target.value);
                                        }}
                                    />
                                    <label class='form-check-label h-100 w-100' for={i}>
                                        {item}
                                    </label>
                                </div>
                            </li>
                        </div>
                    ))
                    : search && (
                        <button
                            className='btn bg-secondary bg-opacity-10 mt-1 fs-13'
                            onClick={() => handleAddSelectedItem(search)}
                            type="button"
                        >
                            Create Skill
                        </button>

                    )}
            </main>
            <div className='mt-2'>
                {selectedItems.map((item) => {
                    return (
                        <span
                            class='badge border text-dark p-1 me-1 fs-13 rounded-pill'
                        >
                            {item} <i className="las la-times" onClick={() => handleRemoveSelectedItem(item)}></i>
                        </span>
                    );
                })}
            </div>
        </div >
    );
};

export default SkillsSelect;
