import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, isRecruiter } from '../../../classes';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { applyForJob } from '../../../store/actions/jobs';

import { connect } from 'react-redux';
import SideBar from '../../../components/hoc/SideBar';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';

import { notification } from '../../../classes/messages';
import { routePushed } from '../../../classes/browserHistory';
import ConfirmationModal from '../../../components/CadidateAppliedJobs/ConfirmationModal';

class QuizSection extends Component {

    state = {
        message: '',
        is_applied: 0,
        quiz_details: null,
        error_applied: false,
        error_msg: null,
        start_test: false,
        confirmationModalData: {
            title: 'Ready to Start the Quiz!',
            message: 'Once the Quiz starts you cannot go back or lese the progress will be lost want to start the quiz?',
            link: '',
            button: 'Start the Quiz'
        },
    }

    showStartTest = (linkdata) => {
        this.setState({
            start_test: true,
            confirmationModalData: { ...this.state.confirmationModalData, link: linkdata }
        });
    }
    hideStartTest = () => {
        this.setState({
            start_test: false,
        });
    }
    componentWillMount() {

        if (isRecruiter()) {
            routePushed('/', this.props);
        }

        let id = this.props.match.params?.job_id;
        this.apply(id);

    }

    apply = async (id) => {

        const result = await getLoggedInUser();

        if (result) {
            await this.props.applyForJob({ user_id: result.id, job_id: id });

            if (this.props.data?.status == 'success') {
                if (!this.props.data.data) {
                    this.setState({ is_applied: 1 });
                    this.setState({ message: this.props.data.message });
                } else {
                    let x;
                    Object.keys(this.props.data?.data).map((key) => {
                        x = {
                            ...x,
                            [key]: this.props.data?.data[key]
                        };
                    });

                    this.setState({ quiz_details: x }, () => {
                        localStorage.setItem('quiz_' + this.state.quiz_details?.quiz_id, JSON.stringify(this.state.quiz_details));

                        let job = {
                            job_title: this.props.match.params?.job_title,
                            company_name: this.props.match.params?.company_name,
                            logo: (this.props.match.params?.logo && this.props.match.params?.logo != 'undefined') ? atob(this.props.match.params?.logo) : ''
                        }

                        localStorage.setItem('quiz_job_' + this.state.quiz_details?.quiz_id, JSON.stringify(job));

                        localStorage.setItem(`currentTimerData` + this.state.quiz_details?.quiz_id, '');

                    });

                }
            } else {
                this.setState({
                    error_applied: true,
                    error_msg: this.props.data?.message
                })
                let notify = notification({ message: this.props.data?.message, type: 'error' });
                notify();
            }

        }

    }

    render() {

        return (
            <>
                <ConfirmationModal closeModal={() => this.hideStartTest()} status={this.state} mdata={this.state.confirmationModalData} />
                <div className="container">
                    <div className="row">

                        <div className="col-md-9 p-0">
                            <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                                <div className="col-md-12">

                                    {this.state.is_applied == 1 &&
                                        <>
                                            <div className="text-center">
                                                <img className="w-100" src="/assets/imgs/successfullly-applied.png" />

                                                <h4>{this.state.message ? this.state.message : 'You have Successfully Done.'}</h4>
                                                <NavLink to="/">Go to homepage</NavLink>
                                            </div>
                                        </>
                                    }

                                    {this.state.error_applied == true &&
                                        <>
                                            <h4>{this.state.error_msg}</h4>
                                            <NavLink to="/search">Search For New Job</NavLink>
                                        </>
                                    }

                                    {(this.state.is_applied == 0 && this.state.error_applied == false) &&
                                        <>
                                            {/* title starts here */}
                                            <div>
                                                <h4>Quiz Title</h4>
                                                <p>{this.state.quiz_details?.quiz_title}</p>
                                            </div>


                                            {/* title ends here */}

                                            {/* row starts here */}
                                            {/* <div className="row mt-5 mb-5"> */}
                                            <div className="row mt-5 mb-5">
                                                {this.state.quiz_details?.sections.map((val) => {
                                                    console.log(val)
                                                    return <>
                                                        <div className="col-md-3  mb-2">
                                                            <div className='border-blue p-1'>
                                                                <h5 class="text-primary">{val.section_name}</h5>
                                                                {/* <img src="/assets/imgs/clock.png" className="img-fluid ms-auto me-auto" /> */}
                                                                <p className="font-bold mt-1 mb-1">
                                                                    Total Questions : {val.total_questions}
                                                                </p>

                                                                <h5>{val.points} Points</h5>
                                                            </div>
                                                        </div></>;
                                                })}

                                            </div>
                                            {/* row ends here */}

                                            {/* row starts here */}
                                            <div className='row'>
                                                <div className='col-lg-9 col-12 mb-2'>
                                                    <header class="d-flex">
                                                        <div class="me-3">
                                                            {console.log("JJHJHHJNJK")}
                                                            {console.log(this.props.match.params?.logo && this.props.match.params?.logo != 'undefined')}
                                                            <img src={(this.props.match.params?.logo && this.props.match.params?.logo != 'undefined' ? atob(this.props.match.params?.logo) : `/assets/imgs/dummy-logo.png`)} class="img-fluid shadow br-5 h-60p" />
                                                        </div>
                                                        <div>
                                                            <h4 class="font-bold f-Poppins-Medium">{this.props.match.params?.job_title}</h4>
                                                            <p class="f-Poppins-Regular f-1-1">{this.props.match.params?.company_name}</p>
                                                        </div>
                                                        {console.log(this.props.match)}
                                                    </header>
                                                </div>
                                                <div className='col-lg-3 col-12'>
                                                    <div className="ms-auto mt-auto mb-auto float-end">
                                                        <a onClick={() => this.showStartTest(`/start-quiz/${this.props.match.params?.job_id}/${this.state.quiz_details?.quiz_id}`)} className='btn btn-primary btn-sm text-light px-4'>Start the Test</a>
                                                    </div>
                                                </div>
                                            </div>




                                            {/* row ends here */}

                                        </>

                                    }

                                </div>

                            </div>

                        </div>

                        {/* sidebar */}
                        <SideBar>
                            <ProfileName />
                            <ActionButtons />
                            <CandidateCards />
                            <Skills />
                            <FeaturedCompanies />
                            <Designations />
                            <Locations />
                            <Company />
                        </SideBar>
                        {/* sidebar */}

                    </div>
                </div>
            </>
        );
    }

}

const mapStateToProps = (state) => {
    const { data } = state.common
    return {
        data
    }
};

function mapDispatchToProps(dispatch) {
    return {
        applyForJob: (formData) => dispatch(applyForJob(formData)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(QuizSection);