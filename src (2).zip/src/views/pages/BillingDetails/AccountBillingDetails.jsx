import React, { useState, useEffect } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { saveBillingDetails } from '../../../store/actions/SaveBillingDetails';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { findAllInRenderedTree } from 'react-dom/test-utils';
import { getLoggedInUser } from '../../../classes';
import { Recruiter_User_Type_ID, Candidate_User_Type_ID } from '../../../config/constants';
import { getAuthToken } from '../../../classes/index';
import { END_POINT, GET_COUNTRY_CATEGORY, GET_STATE_CATEGORY, GET_CITY_CATEGORY, EDIT_BILLING_DETAILS } from "../../../routes/api_routes";
//import { useHistory } from "react-router-dom";
const AccountBillingDetails = ({ history, match }) => {

    const dispatch = useDispatch();
    let [user, setuser] = useState([]);
    const [country, setcountry] = useState({});
    const [states, setsatates] = useState({});
    const [city, setcity] = useState({});
    const [formData, setFormData] = useState({
        user_id: {
            value: '',
            required: true,
            error: '',
        },
        name: {
            value: '',
            required: true,
            error: '',
        },
        company_name: {
            value: '',
            required: true,
            error: '',
        },
        gst_number: {
            value: '',
            required: false,
            error: '',
        },
        phone_number: {
            value: '',
            required: true,
            error: '',
        },
        email: {
            value: '',
            required: true,
            error: '',
        },
        address_line1: {
            value: '',
            required: true,
            error: '',
        },
        address_line2: {
            value: '',
            required: true,
            error: '',
        },
        country: {
            value: '',
            required: true,
            error: '',
        },
        state: {
            value: '',
            required: true,
            error: '',
        },
        city: {
            value: '',
            required: true,
            error: '',
        },
        zip: {
            value: '',
            required: true,
            error: '',
        },
        additional_information: {
            value: '',
            required: true,
            error: '',
        },
    });
    const getedit_billing_details = async () => {
        let token = await getAuthToken();
        if (token) {
            const response = await fetch(END_POINT + EDIT_BILLING_DETAILS + "/" + match.params.id, {
                method: 'GET',
                headers: { 'Authorization': 'Bearer ' + token },
            });
            const json = await response.json();
            if (json.status == "success") {
                Object.entries(json.data).forEach((fields) => {
                    const key = fields[0];
                    const value = fields[1] == "null" ? '' : fields[1];
                    let data = { ...formData };
                    if (data[key] != undefined) {
                        data[key].value = value;
                        if (value !== '') {
                            data[key].error = '';
                        }
                        setFormData(data);
                    }
                });
            }
            getstate(json.data.country);
            getcity(json.data.state);
        }
    };
    const getcountry = async () => {
        try {
            let token = await getAuthToken();
            if (token) {
                const response = await fetch(END_POINT + GET_COUNTRY_CATEGORY, {
                    method: 'GET',
                    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
                });
                const json = await response.json();
                setcountry(json.data);
            }
        } catch (e) {
            console.log(e);
        }
    };
    const getstate = async (countryid) => {
        try {
            let token = await getAuthToken();
            if (token) {
                const response = await fetch(END_POINT + GET_STATE_CATEGORY + "/" + countryid, {
                    method: 'GET',
                    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
                });
                const statejson = await response.json();
                setsatates(statejson.data);
            }
        } catch (e) {
            console.log(e);
        }
    };
    const getcity = async (stateid) => {
        try {
            let token = await getAuthToken();
            if (token) {
                const response = await fetch(END_POINT + GET_CITY_CATEGORY + "/" + stateid, {
                    method: 'GET',
                    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
                });
                const cityjson = await response.json();
                setcity(cityjson.data);
            }
        } catch (e) {
            console.log(e);
        }
    };
    const onValueChange = async (e) => {
        if (e.target.name === "phone") {
            if (e.target.value.length > 10) {
                e.target.value = e.target.value.slice(0, 10)
            }
        }
        const key = e.target.id;
        const value = e.target.value;
        let data = { ...formData };
        data[key].value = value;
        if (value !== '') {
            data[key].error = '';
        }
        setFormData(data);
        if (e.target.name === "country") {
            getstate(e.target.value);
        }
        if (e.target.name === "state") {
            getcity(e.target.value);
        }
    };
    const onSubmitForm = async (e) => {
        e.preventDefault();
        Object.keys(formData).forEach((key) => {
            if (formData[key].value == '' && formData[key].required) {
                let data = { ...formData };
                data[key].error = `please provide ${key}`;
                setFormData(data);
            }
        });
        let data = {};
        Object.keys(formData).forEach((key) => {
            data[key] = formData[key].value;
        });
        let user = await getLoggedInUser();
        data['back'] = 'back';
        if (user) {
            if (Object.values(formData).some((e) => e.value)) {
                data['user_id'] = user.id;
                if (match.params.id != undefined) {
                    data['id'] = match.params.id;
                }
                dispatch(saveBillingDetails(data, history));
            }
        }

    };
    useEffect(async () => {
        const user = await getLoggedInUser();
        setuser(user);
        getcountry();
        if (match.params.id != undefined) {
            getedit_billing_details();
        }
    }, []);
    return (
        <Section>
            <Main>
                <section className='py-2'>
                    <div>
                        <form onSubmit={(e) => onSubmitForm(e)}>
                            <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Name
                                    </label>
                                    <input
                                        onChange={onValueChange}
                                        type='text'
                                        class='form-control'
                                        id='name'
                                        placeholder='John Doe'
                                        value={formData['name'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['name'].error}</small>
                                    </div>
                                </div>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Phone Number
                                    </label>
                                    <input
                                        type='number'
                                        name="phone"
                                        onChange={onValueChange}
                                        class='form-control'
                                        id='phone_number'
                                        placeholder='+91 1111 22 3333'
                                        value={formData['phone_number'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['phone_number'].error}</small>
                                    </div>
                                </div>


                            </div>
                            {user.user_type !== Candidate_User_Type_ID && (
                                <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                    <div class='col mb-md-0 mb-3'>
                                        <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                            Company Name
                                        </label>
                                        <input
                                            onChange={onValueChange}
                                            type='text'
                                            class='form-control'
                                            id='company_name'
                                            placeholder='Enter your Company Name here'
                                            value={formData['company_name'].value}
                                        />
                                        <div className='mt-1'>
                                            <small className='text-danger'>{formData['company_name'].error}</small>
                                        </div>
                                    </div>
                                    <div class='col mb-md-0 mb-3'>
                                        <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                            GTS Number(Optional)
                                        </label>
                                        <input
                                            onChange={onValueChange}
                                            type='text'
                                            class='form-control'
                                            id='gst_number'
                                            placeholder='Enter your GST Number here'
                                            value={formData['gst_number'].value}
                                        />
                                        <div className='mt-1'>
                                            <small className='text-danger'>{formData['gst_number'].error}</small>
                                        </div>
                                    </div>
                                </div>

                            )}
                            <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Email
                                    </label>
                                    <input
                                        onChange={onValueChange}
                                        type='email'
                                        class='form-control'
                                        id='email'
                                        placeholder='Johndoe@example.com'
                                        value={formData['email'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['email'].error}</small>
                                    </div>
                                </div>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Address line 1
                                    </label>
                                    <input
                                        onChange={onValueChange}
                                        type='text'
                                        class='form-control'
                                        id='address_line1'
                                        placeholder='Enter your address line 1 here'
                                        value={formData['address_line1'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['address_line1'].error}</small>
                                    </div>
                                </div>
                            </div>
                            <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Address line 2
                                    </label>
                                    <input
                                        onChange={onValueChange}
                                        type='text'
                                        class='form-control'
                                        id='address_line2'
                                        placeholder='Enter your address line 2 here'
                                        value={formData['address_line2'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['address_line2'].error}</small>
                                    </div>
                                </div>
                                <div class='col mb-md-0 mb-3'>
                                    <label htmlFor='' class='form-label fw-bold'>
                                        country
                                    </label>
                                    <select
                                        class='form-select'
                                        aria-label='Default select example'
                                        value={formData['country'].value}
                                        id='country'
                                        name='country'
                                        onChange={onValueChange}
                                    >
                                        <option>Select Your country</option>
                                        {
                                            country.length > 0 && country.map((count) => {
                                                return <option value={count.id}>{count.name}</option>
                                            })
                                        }


                                    </select>
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['country'].error}</small>
                                    </div>
                                </div>
                            </div>
                            <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                <div className='col mb-md-0 mb-3'>
                                    <label htmlFor='' class='form-label fw-bold'>
                                        State
                                    </label>
                                    <select
                                        class='form-select'
                                        aria-label='Default select example'
                                        id='state'
                                        value={formData['state'].value}
                                        onChange={onValueChange}
                                        name='state'
                                    >
                                        <option selected>Select Your State</option>
                                        {
                                            states.length > 0 && states.map((count) => {
                                                return <option value={count.id}>{count.name}</option>
                                            })
                                        }
                                    </select>
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['state'].error}</small>
                                    </div>
                                </div>
                                <div class='col mb-md-0 mb-3'>
                                    <label htmlFor='' class='form-label fw-bold'>
                                        Town / City
                                    </label>
                                    <select
                                        class='form-select w-100'
                                        aria-label='Default select example'
                                        value={formData['city'].value}
                                        id='city'
                                        onChange={onValueChange}
                                        name='city'
                                    >
                                        <option selected>Select Your City</option>
                                        {
                                            city.length > 0 && city.map((count) => {
                                                return <option value={count.id}>{count.name}</option>
                                            })
                                        }
                                    </select>
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['city'].error}</small>
                                    </div>
                                </div>
                            </div>
                            <div class='row row-cols-1 row-cols-md-2 mb-md-2'>
                                <div class='col mb-md-0 mb-3'>
                                    <label for='exampleFormControlInput1' class='form-label fw-bold'>
                                        Postcode / ZIP
                                    </label>
                                    <input
                                        onChange={onValueChange}
                                        type='text'
                                        class='form-control'
                                        id='zip'
                                        placeholder='Select Your Postcode / ZIP here'
                                        value={formData['zip'].value}
                                    />
                                    <div className='mt-1'>
                                        <small className='text-danger'>{formData['zip'].error}</small>
                                    </div>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label for='exampleFormControlTextarea1' class='form-label fw-bold'>
                                    Additional Information
                                </label>
                                <textarea
                                    class='form-control'
                                    id='additional_information'
                                    rows='3'
                                    value={formData['additional_information'].value}
                                    placeholder='Notes about the order'
                                    onChange={onValueChange}
                                ></textarea>
                                <div className='mt-1'>
                                    <small className='text-danger'>
                                        {formData['additional_information'].error}
                                    </small>
                                </div>
                            </div>
                            <div class='d-flex justify-content-end'>
                                <button type='submit' class='btn btn-primary'>
                                    Save Address
                                </button>
                            </div>
                        </form>
                    </div>
                </section>
            </Main >
            <SideBar>
                <ProfileName></ProfileName>
                <ActionButtons />
                <div className='my-2'>
                    <p className='fs-18'>Want to reach out more candidates?</p>
                    <Link to='#'>Click Here</Link>
                </div>
                <Company></Company>
            </SideBar>
        </Section >
    );
};

export default AccountBillingDetails;
