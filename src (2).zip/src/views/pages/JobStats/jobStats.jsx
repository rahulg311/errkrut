import React, { useEffect, useState } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink, Link } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import { useDispatch, useSelector } from "react-redux";
import { formatTitle, getLoggedInUser } from '../../../classes';
import { END_POINT } from '../../../routes/api_routes';
import { Chart } from "react-google-charts";
import { getAuthToken } from '../../../classes/index';
import { jobDetail } from '../../../store/actions/jobs';
import PostedOn from '../../../components/PostedOn';

const JobStats = () => {
	const dispatch = useDispatch();
	const { job_detail } = useSelector((state) => state.common);
	const [jobdetaildata, setJobDetailData] = useState();
	const [data, setData] = useState({});
	const [filter, setFilter] = useState();
	const [graphData, setgraphData] = useState({});
	const [jobTitle, setjobTitle] = useState();
	const [demoCountry, setdemoCountry] = useState();
	const [demoState, setdemoState] = useState();
	const [questions, setquestions] = useState();
	const [barchartData, setbarchartData] = useState({});
	const [avgMarksObtained, setavgMarksObtained] = useState('0');
	const [badgeEligibility, setbadgeEligibility] = useState('0');
	const [passedCandidate, setpassedCandidate] = useState('0');
	useEffect(() => {
		setJobDetailData(job_detail?.data[0])
	}, [job_detail])


	const LineChartOptions = {
		series: {
			0: { curveType: 'function', legend: { position: 'bottom' } },
			1: { curveType: 'function', legend: { position: 'bottom' } },
		},
		legend: { position: 'bottom', alignment: 'start' }
	}

	const barchartoptions = {
		legend: { position: 'none' }
	}

	React.useEffect(async () => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var formdata = new FormData();
		formdata.append('user_id', user.id);
		formdata.append('company_id', user.company_id);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'get_job_stats', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				setData(result.data);
				let graphData = [['x', 'Candidates Appiled', 'Quiz Taken']]
				for (let i = 0; i < result.data.candidates_applied.length; i++) {
					let quizTake;
					if (result.data.quiz_taken[i] == null || result.data.quiz_taken[i] == undefined) {
						quizTake = 0;
					} else {
						quizTake = result.data.quiz_taken[i].value;
					}
					let temp = [
						result.data.candidates_applied[i].month,
						result.data.candidates_applied[i].value,
						quizTake,
					]

					graphData.push(temp);

				}
				setgraphData(graphData);

				let jobTitle = result.data.job_titles.map((row, index) => {
					return (
						<option key={index} value={row.id}>{row.job_title}</option>
					)
				})
				setjobTitle(jobTitle);

				let demoCountry = result.data.demographic.map((row, index) => {
					return (
						<div className='col-12 mb-2'>
							<div className='cards bg-rejected br-5 ps-1 h-100 mr-2' onClick={() => getStateData(row.state)}>
								<p className='fs-17 font-bold float-start mt-3 mb-3 '>{row.country}</p>
								<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>{row.total_candidates}</p>
							</div>
						</div>
					)
				})
				setdemoCountry(demoCountry);
				if (result.data.demographic.length > 0) {
					let demoState = result.data.demographic[0].state.map(row => {
						return (
							<div className='col-12 pt-1 cards-shadow pb-1 mb-1'>

								<p className='float-start fs-15 fw-bold text-capitalize'>{row[Object.keys(row)[0]]} </p>
								<p className='float-end fw-bold fs-15'>{row[Object.keys(row)[1]]}</p>
							</div>
						)
					})
					setdemoState(demoState);
				}
				var questions = result.data.hardest_question.map((row, index) => {
					return (
						<div key={index} className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1 mr-2 mb-1'>
							<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
							<p class="fs-12 text-dark pb-1">{row.title}</p>
						</div>
					)
				})
				setquestions(questions);

				setavgMarksObtained(result.data.avg_marks_obtained);
				setbadgeEligibility(result.data.badge_eligibility)
				setpassedCandidate(result.data.passed_candidate.min + '/' + result.data.passed_candidate.min)

				let barchartData = [
					["Take", "Value"],
					["Multiple take", result.data.assessment.multiple_take],
					["Single take ", result.data.assessment.single_take],
				]
				setbarchartData(barchartData);
			})
			.catch((error) => console.log('error', error));
	}, [])

	function getStateData(states) {
		let demoState = states.map(row => {
			return (
				<div className='col-12 pt-1 cards-shadow pb-1 mb-1'>
					<p className='float-start fs-15 fw-bold text-capitalize	'>{row[Object.keys(row)[0]]}</p>
					<p className='float-end fw-bold fs-15'>{row[Object.keys(row)[1]]}</p>
				</div>
			)
		})
		setdemoState(demoState)
	}

	function getQuestion(e) {
		//console.log(e.target.value);
		if (e.target.value == 1) {
			var questions = data?.esiest_question.map((row, index) => {
				return (
					<div key={index} className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1 mr-2 mb-1'>
						<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
						<p class="fs-12 text-dark pb-1">{row.title}</p>
					</div>
				)
			})
			setquestions(questions);
		} else {
			var questions = data?.hardest_question.map((row, index) => {
				return (
					<div key={index} className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1 mr-2 mb-1'>
						<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
						<p class="fs-12 text-dark pb-1">{row.title}</p>
					</div>
				)
			})
			setquestions(questions);
		}
	}
	async function getJobDetail(e) {
		const user = await getLoggedInUser();
		if (e.target.value != '') {
			dispatch(jobDetail({ job_id: e.target.value, user_id: user?.id }));
		}
		else {
			setJobDetailData(null);
		}
	}
	async function getGraphData(e) {
		setgraphData('')
		setdemoCountry('')
		setdemoState('')
		setquestions('')
		setbarchartData('')
		setavgMarksObtained('0')
		setbadgeEligibility('0')
		setpassedCandidate('0')

		setFilter(e.target.value);
		let token = await getAuthToken();
		let user1 = await getLoggedInUser();
		var formdata = new FormData();
		formdata.append('user_id', user1.id);
		formdata.append('company_id', user1.company_id);
		formdata.append('filter', e.target.value);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'get_job_stats', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				setData(result.data);
				console.log(result)
				let graphData = [['x', 'Candidates Appiled', 'Quiz Taken']]
				for (let i = 0; i < result.data.candidates_applied.length; i++) {
					let quizTake;
					if (result.data.quiz_taken[i] == null || result.data.quiz_taken[i] == undefined) {
						quizTake = 0;
					} else {
						quizTake = result.data.quiz_taken[i].value;
					}
					let temp = [
						result.data.candidates_applied[i].month,
						result.data.candidates_applied[i].value,
						quizTake
					]
					graphData.push(temp);

				}
				setgraphData(graphData);


				let jobTitle = result.data.job_titles.map((row, index) => {
					return (
						<option key={index} value={row.id}>{row.job_title}</option>
					)
				})
				setjobTitle(jobTitle);

				let demoCountry = result.data.demographic.map((row, index) => {
					return (
						<div className='col-12 mb-2'>
							<div className='cards bg-rejected br-5 ps-1 h-100 mr-2' onClick={() => getStateData(row.state)}>
								<p className='fs-17 font-bold float-start mt-3 mb-3 '>{row.country}</p>
								<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>{row.total_candidates}</p>
							</div>
						</div>
					)
				})
				setdemoCountry(demoCountry);

				if (result.data.demographic.length > 0) {
					let demoState = result.data.demographic[0].state.map(row => {
						return (
							<div className='col-12 pt-1 cards-shadow pb-1 mb-1'>

								<p className='float-start fs-15 fw-bold text-capitalize'>{row[Object.keys(row)[0]]} </p>
								<p className='float-end fw-bold fs-15'>{row[Object.keys(row)[1]]}</p>
							</div>
						)
					})
					setdemoState(demoState);
				}

				var questions = result.data.hardest_question.map((row, index) => {
					return (
						<div key={index} className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1 mr-2 mb-1'>
							<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
							<p class="fs-12 text-dark pb-1">{row.title}</p>
						</div>
					)
				})
				setquestions(questions);

				setavgMarksObtained(result.data.avg_marks_obtained);
				setbadgeEligibility(result.data.badge_eligibility)
				setpassedCandidate(result.data.passed_candidate.min + '/' + result.data.passed_candidate.min)

				let barchartData = [
					["Take", "Value"],
					["Multiple take", result.data.assessment.multiple_take],
					["Single take ", result.data.assessment.single_take],
				]
				setbarchartData(barchartData);

			})
			.catch((error) => console.log('error', error));

	}
	async function download_stats_handler() {
		let token = await getAuthToken();

		var requestOptions = {
			method: 'POST',
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}

		};

		fetch(END_POINT + 'exportJobStats?filter=' + filter, requestOptions)
			.then((response) => response.json())
			.then((result) => {

				if (result.status == "success") {
					const link = document.createElement('a');
					link.download = "";
					let str = result.excel_url.replace(/[\\]/g, '');
					link.href = str;
					document.body.appendChild(link);
					link.click();
					document.body.removeChild(link);
				}
			})
			.catch((error) => console.log('error', error));

	}

	return (
		<div className="container">
			<div className="row">
				<div className="col-md-9 p-0">
					<div className="p-1  ">
						<div className=" ">
							{/* submit button */}
							{/* start Edit hr profile  */}
							<div className=" row bg-white mt-2   ">
								<div className='container'>
									<div className='bg-white pt-4 pb-4 px-2 rounded-4'>
										<div className='row'>
											<div className='col-md-12'>
												<div className='d-flex justify-content-between w-100'>
													<select class="form-select w-50  text-primary" aria-label="Default select example"
														onChange={e => { getGraphData(e); getJobDetail(e); }}
													>
														<option className='text-primary' selected value="">All Job</option>
														{jobTitle}
													</select>
													<p className='float-right mt-auto mb-auto'>
														<button type="button" class="btn btn-primary f-r-12 ps-5 pe-5" onClick={download_stats_handler}>Download Stats</button>
													</p>
												</div>
											</div>
										</div>
										<div className='row mt-4 '>
											<div className='col-md-8  '>
												<div className='row'>
													<div className='col-md-9 cards-shadow br-5 mb-2'>
														<div className='row mt-1 '>
															<div className='col-md-5  '>
																<h6 className='font-bold float-left p-1'>Job Stats</h6>
															</div>
														</div>
														<div className='row'>
															<div className='col-md-12'>
																{graphData.length > 1 ? <Chart
																	width={'100%'}
																	height={'150px'}
																	chartType="LineChart"
																	loader={<div>Loading Chart</div>}
																	data={graphData}
																	options={LineChartOptions}
																	rootProps={{ 'data-testid': '2' }}
																/> : "No records found!"}
															</div>
														</div>
													</div>
													<div className='col-md-3 '>
														<div className='row'>
															<div className='col-12'>
																<div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
																	<p className='fs-28 position-abs t-2 l-2 m-0 font-bold  '>{data?.job_saved == null ? '0' : data?.job_saved}</p>
																	<p className='fs-14 position-abs b-2 pe-1 text-end m-0 mt-3  font-bold pb-1 '><span className='ms-4 '> Job </span><br /> <span className='float-end'>Saved</span> </p>
																</div>
															</div>
														</div>
														<div className='row mt-2'>
															<div className='col-12'>
																<div className='cards bg-greenesh-blue br-5 text-white ps-1  h-100 mr-2'>
																	<p className='fs-28 position-abs t-2 l-2 m-0 font-bold'>{data?.total_likes == null ? '0' : data?.total_likes}</p>
																	<p className='fs-14 position-abs b-2 pe-1 text-end m-0 mt-3  font-bold pb-1 '><span className='ms-4 '> Total</span><br /> <span className='float-end'>Likes</span> </p>
																</div>
															</div>
														</div>
													</div>
												</div>

												<div className='row mt-2 br-5 cards-shadow me-1 mb-2'>
													<div className='col-md-12'>
														<h5 className='mt-3 m-2 fw-bold'>Demographics</h5>
														<div className='row pb-4 '>
															<div className='col-md-5'>
																<div className='row '>
																	{demoCountry}
																	{(data.demographic && data.demographic.length < 1) && <p>No record found!</p>}

																</div>
															</div>
															<div className='col-md-7 '>
																<div className='row p-1'>
																	{demoState}
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div className='col-md-4'>
												<div className='row cards-shadow br-5'>
													<div className='col-12'>
														<p className='fw-bold fs-18 p-1 '> Assessment</p>
													</div>
													<div className='col-12'>
														{barchartData.length > 0 && <Chart
															chartType="PieChart"
															data={barchartData}
															options={barchartoptions}
															width={"100%"}
															height={"200px"}
														/>}
													</div>
													<div className='col-12 d-flex'>
														<button type="button" class="btn btn-danger  ms-2"></button>
														<p className='fs-12 ms-1'>Completed in a single take</p>

													</div>
													<div className='col-12 mt-1 d-flex'>
														<button type="button" class="btn btn-primary  ms-2"></button>
														<p className='fs-12 ms-1'>Completed in a multiple takes</p>

													</div>

													{/*<div className='col-12 d-flex justify-content-center'>
														<div class="ui-widgets">
															<div class="ui-values">80%</div>
														</div>
													</div>

													*/
													}

													<div className='border-dashed1 mt-3 mb-2'></div>


													<div className='row mb-3'>
														<div className='col-4 m-0 p-0'>
															<h5 className='fw-bold mt-1 ps-1 fs-20'>Top 5</h5>

														</div>
														<div className='col-8 m-0 p-0'>
															<select class="form-select fw-bold" aria-label="Default select example"
																onChange={getQuestion}>

																<option className='fw-bold' value="0" selected>Hardest Questions</option>
																<option value="1">Easiest Questions</option>
															</select>

														</div>
													</div>

													<div className='row pb-2 '>
														{questions}
													</div>

												</div>
											</div>
										</div>

										<div className='row mt-2 pb-4 '>
											<div className='col-12 '>
												<div className='row'>
													<div className='col-12 col-md-4 mb-1'>
														<div class="cards  bg-blue br-5 text-white p-1 h-100 mr-2">
															<p class="fs-18 font-bold">{avgMarksObtained}</p>
															<p class="fs-15  text-end m-0">Avg Marks  <br /><span class="ms-3">Obtained</span></p>
														</div>
													</div>
													<div className='ol-12 col-md-4 mb-1'>
														<div class="cards  bg-dark-pink br-5 text-white p-1 h-100 mr-2">
															<p class="fs-18 font-bold">{passedCandidate}</p>
															<p class="fs-15 text-end m-0 ">Passed  <br /><span class="ms-3">Candidates</span></p>
														</div>
													</div>
													<div className='col-12 col-md-4 mb-1'>
														<div class="cards  bg-greenesh-blue br-5 text-white p-1 h-100 mr-2">
															<p class="fs-18 font-bold">{badgeEligibility}</p>
															<p class="fs-15 text-end m-0">Candidate with <br /><span class="ms-3">Badge Eliglbilty</span></p>
														</div>
													</div>
												</div>

											</div>
										</div>
										{
											jobdetaildata != null && <div className='row'>
												<div className="col-md-9 p-0 ">

													<div className=" bg-white br-5 ">
														<div className="br-5 shadow">
															<div className="container pt-2 pb-2">

																<div className="row mb-2">
																	<div className="col-md-11 col-10">
																		<header className='d-flex '>
																			<div className='me-3'>

																				<img
																					src={(jobdetaildata?.company_logo) ? JSON.parse(jobdetaildata?.company_logo) : `/assets/imgs/dummy-logo.png`}
																					className='img-fluid shadow br-5 h-60p'
																				/>
																			</div>
																			<div>
																				<h4 className='font-bold f-Poppins-Medium'>{jobdetaildata?.job_title}</h4>
																				<p className="f-Poppins-Regular f-1-1">{jobdetaildata?.company_name}</p>
																			</div>
																		</header>
																	</div>

																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
																		<p className=""><span className="text-primary f-Poppins-Medium   f-1 me-2">Experience</span><span className=" f-Poppins-Light font-bold f-r-11 ">{jobdetaildata?.min_work_exp} - {jobdetaildata?.max_work_exp} Yrs.</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-map-marker   text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium f-1 me-2">Locations</span><span className="f-Poppins-Light font-bold f-r-11 ">{jobdetaildata?.city}</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-rupee-sign  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Salary</span><span className="f-Poppins-Light font-bold f-r-11 ">
																			{jobdetaildata?.ctc_from} - {jobdetaildata?.ctc_to} L.P.A
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-user-minus  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Vacancy</span><span className="f-Poppins-Light font-bold f-r-11 ">
																			{jobdetaildata?.number_of_vaccancy}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-user-edit  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light font-bold f-r-11 text-break">
																			{jobdetaildata?.skill_set}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-user-graduate  text-sky-blue f-1-4  pe-1' />
																		<p><span className="text-primary f-Poppins-Medium  f-1 me-2">Designation</span><span className="f-Poppins-Light font-bold f-r-11 ">
																			{jobdetaildata?.designation}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-tasks  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Job Function</span><span className="f-Poppins-Light font-bold f-r-11 ">
																			{jobdetaildata?.job_function}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-graduation-cap  text-sky-blue f-1-4  pe-1' />
																		<p className="    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Qualification</span><span className="f-Poppins-Light font-bold f-r-11 ">
																			{jobdetaildata?.qualification}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-clock  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Nature of Employment</span><span className="f-Poppins-Light font-bold f-r-11 text-uppercase">
																			{formatTitle(jobdetaildata?.nature_of_employment)}
																		</span> </p>
																	</div>
																</div>
																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-clock  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Job Type</span><span className="f-Poppins-Light font-bold f-r-11">
																			{formatTitle(jobdetaildata?.job_type)}
																		</span> </p>
																	</div>
																</div>

																<div className="row mb-1">
																	<div className="col-12 d-flex">
																		<i class='las la-clipboard-list  text-sky-blue f-1-4  pe-1' />
																		<p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Description</span></p>
																	</div>

																	<div className='col-12'>
																		<div>
																			<p className='mb-1 mt-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Title
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.title}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium f-1 me-2">
																					Purpose
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.purpose}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Industry
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.industry}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Job Responsibilites
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.job_responsibilities}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Preferred Skills
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.preffered_skills}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Desired Qualification
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.desired_qualification}
																				</span>
																			</p>

																			<p className='mb-1 f-0-9'>
																				<span className="text-primary f-Poppins-Medium  f-1 me-2">
																					Job Summary
																				</span>
																				<span className="f-Poppins-Light">
																					{jobdetaildata?.summary}
																				</span>
																			</p>
																		</div>
																	</div>
																</div>

																{jobdetaildata?.hr_details != undefined && <div class="row mb-1">
																	<div class="col-12 d-flex">
																		<i class="las la-clipboard-list  text-sky-blue f-1-4  pe-1"></i>
																		<p class="">
																			<span class="text-primary f-Poppins-Medium  f-1 me-2">HR Details</span>
																			<span class="f-Poppins-Light font-bold f-r-11 ">{JSON.parse(jobdetaildata?.hr_details).hr_name} ({JSON.parse(jobdetaildata?.hr_details).hr_designation})</span>
																		</p>
																	</div>
																</div>}


																{jobdetaildata?.show_website_link ? <div class="row mb-1">
																	<div class="col-12 d-flex">
																		<i class="las la-globe text-sky-blue f-1-4 pe-1"></i>
																		<p class="">
																			<span class="text-primary f-Poppins-Medium  f-1 me-2">Website Link</span>
																			<span class="f-Poppins-Light font-bold f-r-11"><a href={jobdetaildata?.website_link} target="_blank">{jobdetaildata?.website_link}</a></span>
																		</p>
																	</div>
																</div> : ""}



																<div className="row">
																	<div className="col-md-12 p-0">
																		<div className="bg-whitept-3 pb-3 px-3 br-5">
																			<div className="row">
																				<div className="col-md-12 mt-1">
																					{jobdetaildata?.skill_set?.split(',').map((value) => {
																						return <span class="badge badge-default cursor me-1 f-Poppins-Medium"><a href={`/search/${value}`}> {value} </a></span>
																					})}
																				</div>
																			</div>
																		</div>
																	</div>
																</div>


																<div className="row ">
																	<div className="col-md-4">
																		<section className='d-flex justify-content-between mt-1'>
																			<div className='d-flex align-items-center mb-md-0'>
																				<div className='d-flex align-items-center'>
																					<img src='/assets/imgs/fire.png' />
																				</div>
																				<small className='ps-2 f-1'><PostedOn date={jobdetaildata?.created_at} /></small>
																			</div>
																		</section>
																	</div>
																	<div className='col-md-8'>
																		<div className='ms-auto float-end '>
																			<Link
																				className='btn btn-sm ps-4 pe-4 me-2 btn-border'
																				to={`/edit-job/${jobdetaildata?.job_id}`}
																			>
																				Edit
																			</Link>

																		</div>

																	</div>
																</div>

															</div>


														</div>
													</div>

												</div>
											</div>
										}

									</div>
								</div>
							</div>
						</div>
						{/* submit button */}
						{/* form ends here */}
					</div>
				</div>
				{/* sidebar */}
				<div className="col-md-3">
					<ProfileName />
					<ActionButtons />
					<Company />
				</div>
				{/* sidebar */}
			</div>
		</div>
	);

}
export default JobStats;