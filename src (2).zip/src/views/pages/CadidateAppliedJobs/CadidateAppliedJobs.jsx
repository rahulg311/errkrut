import React, { useEffect, useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import { getLoggedInUser } from '../../../classes/index';
import { END_POINT } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import JobCard from "../../../components/CadidateAppliedJobs/JobCard"

const CadidateAppliedJobs = ({ history }) => {
	
	return (
		<Section>
			<Main>
				<header className='border-bottom border-primary py-2 border-2'>
					<div className='d-flex justify-content-between align-items-center'>
						<h4>Total Cadidates </h4>
						<div className='d-flex align-items-center'>
							<select class='form-select form-select-sm' aria-label='Default select example'>
								<option selected>All Jobs</option>
								<option value='1'>One</option>
								<option value='2'>Two</option>
								<option value='3'>Three</option>
							</select>
							<select class='form-select form-select-sm ms-2' aria-label='Default select example'>
								<option selected>All</option>
								<option value='1'>One</option>
								<option value='2'>Two</option>
								<option value='3'>Three</option>
							</select>
						</div>
					</div>
				</header>
                <main>
                    <JobCard/>
                    <JobCard/>
                    <JobCard/>
                    <JobCard/>
                </main>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default CadidateAppliedJobs;