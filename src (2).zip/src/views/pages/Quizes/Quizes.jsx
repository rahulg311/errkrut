import React, { Component } from 'react';
import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
class Quizes extends Component {
render() {
return (
<div className='main-container position-relative'>
   <Header />
   <div className='content-wrapper'>
      <div className="container">
         <div className='row mt-4 '>
            {/* Content */}
            <div className='col-md-9'>
               <div className="container bg-white mb-2">
                  <div className="row mt-2">
                     <div className="col-md-12 col-12 mt-2 ms-1">
                        <h4 className="f-Poppins-Medium  text-dark">Quizes</h4>
                     </div>
                    
                  </div>
                                       {/* border */}
                                       <div className="border-gray-line  mt-2 mb-1"></div>
                     {/* border */}
                     <div className="row ms-1 ">
                         <div className="col-md-8 ">
                         <label className=" text-primary mt-2">
                           Address line 1
                           </label>
                           <select   className="form-select form-select-sm mt-2 mb-2 h-40px " aria-label=".form-select-sm example">
                                <option  selected >Select Quiz Category</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                        <option value="3">Three</option>
                                   </select>

                           
                         </div>
                     </div>
                     <div className="row  mt-2 ms-1">
                         <div className="col-md-7 col-10">
                             <h6>Dynamic Quiz</h6>
                             <p className="mt-1 f-Poppins-Regular f-0-9 ">Lorem ipsum sitamet, consectetuer adipiscing elit, seddiam</p>
                         </div>
                         <div className="col-md-2 col-2 ">
                         <div class="form-check form-switch">
                           <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                            
                        </div>
                         </div>
                     </div>
                     <div className="row ms-1 ">
                         <div className="col-md-8 ">
                         <label className=" text-primary mt-2">
                         Question Tags
                           </label>
                           <select   className="form-select form-select-sm mt-2 mb-2 h-40px " aria-label=".form-select-sm example">
                                <option  selected >Select Quiz Category</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                        <option value="3">Three</option>
                                   </select>

                           
                         </div>
                         <div className="mt-1 mb-1  ">
                                 <span class="badge badge-default cursor me-1">Communication Skills</span> <span class="badge badge-default cursor me-1">Decision Making Capability</span> <span class="badge badge-default cursor me-1">Leadership Skills</span>
                                
                              </div>
                     </div>
                     <div className="row mt-1 ms-1">
                         <div className="col-md-4 col-12 ">
                         <label className=" text-primary mt-2 f-0-8">
                         Question type
                           </label>
                           <select   className="form-select form-select-sm mt-2 mb-2 h-40px thin " aria-label=".form-select-sm example">
                                <option  selected >Select Question type</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                        <option value="3">Three</option>
                                   </select>

                         </div>
                         <div className="col-md-4 col-12 mt-2  ">
                         <label className="f-0-8">
                         Number of Questions
                           </label>
                           <input
                              type='text'
                              className='form-control  mt-2 thin h-40px'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter Quiz Duration"
                              />
                         </div>
                     </div>
                       {/* border */}
                  <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-4 mb-4"></div>
                  {/* border */}
                  <div className="row ">
                      <div className="col-md-12 col-12 bg-blue   ms-2 pt-2 pb-2 br-5">
                          <table className="w-100">
                              <thead>
                                  <tr>
                                      <td className="w-30">
                                     <p className="text-white f-Poppins-Medium   "> Title</p>
                                  
                                      </td>
                                      <td className="w-30">
                                      <p className="text-white f-Poppins-Medium "> Title</p>
                                      </td>
                                      <td className="w-30">
                                      <p className="text-white f-Poppins-Medium "> Title</p>
                                      </td>
                                      <td className="w-30">
                                      <p className="text-white f-Poppins-Medium "> Title</p>
                                      </td>
                                      <td>
                                      <p className="text-white f-Poppins-Medium "> Title</p>
                                      </td>
                                      <td>
                                      <p className="text-white f-Poppins-Medium "> </p>
                                      </td>
                                  </tr>
                              </thead>
                          </table>
                      </div>
                  </div>

                  <div className="row">
                      <div className="col-md-12 col-12 table-responsive-sm  mt-1 ms-2 pt-2 pb-2 br-5">
                          <table className="w-100">
                              <thead>
                                  <tr>
                                      <td className="w-30">
                            
                                     <p className="text-black f-Poppins-Medium f-0-9  "> Question title 1</p>
                                  
                                      </td>
                                      <td className="w-30">
                             
                                      <p className="text-black f-Poppins-Medium f-0-9 ">Question title 1</p>
                                      </td>
                                      <td className="w-30">
                              
                                      <p className="text-black f-Poppins-Medium  f-0-9">Creative hinking Communication Skills</p>
                                      </td>
                                      <td className="w-30">
                                      <p className="text-black f-Poppins-Medium f-0-9"> MCQ</p>
                                      </td>
                                      <td  className="w-30">
                                  
                                      <p className="text-black f-Poppins-Medium f-0-9 "> 12/10/2021</p>
                                      </td>
                                      <td>
                                  <button className="pt-1 pb-1 ps-2 pe-2 text-dark border-blue1 f-0-9"> Select</button>
                                      </td>
                                  </tr>
                              </thead>
                          </table>
                      </div>
                      



                   
                  
                  </div>
                     {/* submit button */}
                     <div className="row mt-2 mb-2">
                     <div className="col-md-10  col-6">
                        <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2  ms-2">Previous</button>
                     </div>
                     <div className="col-md-2 col-6 ">
                        <button href="" className="btn btn-primary mr-auto d-block mt-2 ">Add Quiz</button>
                     </div>
                  </div>
               
               {/* submit button */}
                  
















              </div>
            </div>
            {/* Content */}
            {/* Sidebar */}
            <div className='col-md-3 pt-2 pb-2 '>
               {/* Profile Name */}
               <ProfileName />
               {/* Profile Name */}
               {/* AddButtons */}
               <ActionButtons />
               {/* AddButtons */}
               <div className='row'>
                  <div className='col-md-12 p-0 '>
                     <h6>
                        <p class='font-bold m-0'>Want to reach out to more Candidates?</p>
                        <a href=''>
                        <span class='font-bold mr-2'>Click here</span>
                        </a>
                     </h6>
                  </div>
               </div>
               {/* Contact */}
               <Company></Company>
               {/* Contact */}
            </div>
            {/* Sidebar */}
         </div>
      </div>
   </div>
</div>
);
}
}
export default Quizes;