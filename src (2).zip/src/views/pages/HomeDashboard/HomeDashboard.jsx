import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';

class HomeDashboard extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-1  ">
            <div className=" ">
               
              
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className=" row bg-white mt-2   ">
                   <div className='container'>
                   <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
							<h4 className='font-bold float-left'>Dashboard</h4>
							<p className='float-right mt-auto mb-auto'>
								<a href='/search'>See All</a>
							</p>
						</div>
					</div>
					
				</div>
                <div className='row mt-4 '>
                    <div className='col-md-6 cards-shadow'>
                   
                        <div className='row mt-3 mb-3'>
					<div className='col-md-5 mt-1'>
					
							<h6 className='font-bold float-left'>Job Start</h6>
					

						
					
				</div>
                <div className='col-md-7'> 							<select class="form-select" aria-label="Default select example">
  <option selected>All Job</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select></div>

                        </div>
                        <div className='row'>
                            <div className='col-md-12'>
                                
                            </div>
                        </div>

                    </div>
                    <div className='col-md-6'>
                    <div className='row '>
                 <div className='col-md-4 mb-2  '>
					<div className='cards  bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '><span className='ms-4 '> Total</span>  Quize</p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-greenesh-blue br-5 text-white ps-1 h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>12</p>
						<p className='fs-14 position-abs b-2 r-2 text-right m-0 float-end mt-3 font-bold  pb-1  '><span className='float-end me-1'>Total</span> <br /> <span className='ms-2 me-1'> Questions</span> </p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-dark-pink br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>10</p> 
						<p className='fs-14 position-abs b-2 r-2  me-1 text-right m-0 float-end mt-8 font-bold  pb-1 '><span className=''> Badges</span> </p>
					</div>
				</div>
                 </div>
                 <div className='row p-1  gap-0 '>
                 <div className='col-md-6  shadow  '>
                       <div className='pt-1 p-1   '>
                       <h6>12/20</h6>
                         <progress className='mt-1 ' id="file" value="32" max="100"> 32% </progress>
                         <div className='row'>
                             <div className='col-md-12'>
                                 <p className='float-start fs-10'>Want to post more jobs?</p>
                                 <a href="#" className='float-start fs-10 float-end'> click here</a>
                                 <h6 className='float-end f-0-8 mt-1 mb-1'>Job Posted</h6>
                       </div>
                             </div>
                             {/* <div className='row mt-1 mb-1'>
                                 <div className='col-md-12'>
                                 <h6 className='float-end f-0-8'>Job Posted</h6>
                                 </div>
                             </div> */}
                           
                         </div>
                     </div>
                     <div className='col-md-6    '>
                       <div className='pt-1 p-1   shadow'>
                       <h6>12/20</h6>
                         <progress className='mt-1 ' id="file" value="32" max="100"> 32% </progress>
                         <div className='row'>
                             <div className='col-md-12'>
                                 <p className='float-start fs-10'>Want to post more jobs?</p>
                                 <a href="#" className='float-start fs-10 float-end'> click here</a>
                                 <h6 className='float-end f-0-8 mt-1 mb-1'>Job Posted</h6>
                       </div>
                             </div>
                             {/* <div className='row mt-1 mb-1'>
                                 <div className='col-md-12'>
                                 <h6 className='float-end f-0-8'>Job Posted</h6>
                                 </div>
                             </div> */}
                           
                         </div>
                     </div>
                 </div>

                    </div>
                </div>
			</div>
                
                 </div>
               </div>
               <div className='row bg-white mt-2'>
               <div className='col-md-12'>
									<TopCompaniesCard></TopCompaniesCard>
										</div>
               </div>

               <div className='row bg-white mt-2'>
               <div className='col-md-10 col-12   '>
									<h4 className='float-start p-2 pt-5 pb-5 '>Search for Candidates</h4>
									
								</div>
								<div className='col-md-2 col-12'>
								<button type="button" class="btn btn-primary  w-100   mb-4 mt-4 ">Start Now</button>
									
								</div>
               </div>
               <div className='row bg-white mt-2 pt-3 '>
               <div className='container ms-4'>
							<div className='row'>
								<div className='col-md-12 '>
									{/* Tabs */}
									<ul class='nav  '>
										<li class='nav-item'>
											<NavLink className={`nav-link fs-20 px-0 me-5`} to='/recruiter' exact>
												Jobs
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/quiz'
												exact
											>
												Quiz
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/questions'
												exact
											>
												Questions
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5`}
												to='/recruiter/testimonials'
												exact
											>
												Testimonials
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5 `}
												to='/recruiter/offer-letters'
												exact
											>
												Offer Letters
											</NavLink>
										</li>
										<li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5 `}
												to='/recruiter/members'
												exact
											>
											Letter Of Intent
											</NavLink>
										</li>
									</ul>
								</div>

							</div>
                            
						</div>
                                         
               </div>
               <div className='border-bottom-blue'></div>

             
                      
                    
                                <div className=' row pb-5 bg-white  '>
                                <div className="  ">
									<div className="container cards-shadow mt-2 ">
										<div className="row p-2">
											<div className="col-md-11 col-10">
												<header className='d-flex '>
													<div className='me-3 mt-2'>
														<img
															src='/assets/imgs/dummy-logo.png'
															className='img-fluid box-shadow br-5 h-60p'
														/>
													</div>
													<div>
														<h4 className='font-bold mb-1 mt-2 f-Poppins-Medium'>UI/UX Designer</h4>
														<p className="f-Poppins-Regular f-1-1">Company Name
														</p>
													</div>
												</header>
											</div>
											<div className="col-md-1 col-2">
                                            <i class="fas fa-trash-alt text-danger h3"></i>										</div>
										</div>
										
										
										<div className="row w-80 w-100-xs mt-1 ">
											<div className="col-md-4 col-12 d-flex">
												<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   f-1 me-2">Experience</span><span className=" f-Poppins-Light font-bold f-0-8   ">0-5 Year</span> </p>
											</div>
											<div className="col-md-4  col-12 d-flex">
												<i class='las la-map-marker   text-sky-blue f-1-4 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   f-1 me-2">Locations</span><span className="f-Poppins-Light font-bold ">Bengalurur</span> </p>
											</div>
											<div className="col-md-4   col-12 d-flex">
												<i class='las la-rupee-sign  text-sky-blue f-1-4 1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Salary</span><span className="f-Poppins-Light font-bold ">Not Disclosed</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light font-bold ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-3 col-12 d-flex ">
												<i class='las la-user-check  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Vacancy</span><span className="f-Poppins-Light font-bold ">8</span> </p>
											</div>
											<div className="col-md-4 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Candidates Applied</span><span className="f-Poppins-Light font-bold ">8</span> </p>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 p-0">
												<div className="bg-whitept-3 pb-3 px-3 br-5">
													<div className="row">
														<div className="col-md-12 mt-1">
															<span class="badge badge-default cursor me-1 f-Poppins-Medium">UI</span>
															<span class="badge badge-default cursor me-1 f-Poppins-Medium">UX</span>
															<span class="badge badge-default cursor me-1 ms-2 f-Poppins-Medium">User Flow</span>
															<span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Design</span>
															<span class="badge badge-default cursor me-1   f-Poppins-Medium">User Interface Design</span>
															<span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Product Design</span>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div className="row ">
											<div className="col-md-8">
												<section className='d-flex justify-content-between mt-1'>
													<div className='d-flex align-items-center mb-md-0'>
														<div className='d-flex align-items-center'>
															<img src='/assets/imgs/fire.png' />
														</div>
														<small className='ps-2 f-1'> Posted 3 days ago</small>
													</div>
												</section>
											</div>
											<div className="col-md-4  col-12 ">
                                            <button type="button" class="btn btn-outline-primary me-1  mb-2 float-start  ps-5 pe-5 ">Edit</button>
                                            <button type="button" class="btn btn-primary me-1  mb-2 float-end   ps-5 pe-5  ">Promote</button>
												
											</div>
										</div>
										
										
									</div>
								</div>
				
							
                              
                                </div>
            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default HomeDashboard;