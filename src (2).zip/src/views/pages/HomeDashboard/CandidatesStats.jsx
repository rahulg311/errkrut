import React, { Component } from 'react';
import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { getProfileCards } from '../../../store/actions/profile';
import { getLoggedInUser } from '../../../classes';
import { connect } from 'react-redux';
import Assessment from './../Assessment/Assessment';
import Designations from './../../../components/Sidebars/Candidate/Designations';
import OfferLetters from './../../../components/Recruiter/OfferLetters';
import CareerProfile from './../PersonalDetails/CareerProfile';

class CandidatesStats extends Component {


   render() {
      return (
         <div className='main-container position-relative  '>
            <Header />
            <div className='content-wrapper'>
               <div className="container">
                  <div className='row'>

                     {/* Content */}
                     <div className='col-md-9'>
                     <div className="container p-4  bg-white ">
                           <div className="row  ">
                              <div className="col-md-12 col-12">
                                 <h4 className="f-Poppins-Medium text-primary">Candidates Stats</h4>
                              </div>
                              </div>
                              <div className='border-blue1 mt-2 mb-2'></div>

                         <div className='row'>
                            <div className='col-3'>
                               <div className='container'>
                                  <div className='row'>
                                     <div className='col-12'>

                                     <div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>24</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end   font-bold pb-1 '><span className='ms-4 '>   Assessment </span><br /> <span className='float-end'>Token</span> </p>
					</div>

                                     </div>
                                  </div>
                                  <div className='row mt-3'>
                                     <div className='col-12'>

                                     <div className='cards   bg-greenesh-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end   font-bold pb-1 '><span className='ms-4 '> Total Badges </span><br /> <span className='float-end'>Recieved</span> </p>
					</div>

                                     </div>
                                  </div>
                                  <div className='row mt-3'>
                                     <div className='col-12'>

                                     <div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>12</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '> <span className='float-end mt-4'>Offer Latter</span> </p>
					</div>

                                     </div>
                                  </div>
                               </div>
                            </div>
                            <div className='col-9 shadow'>

                                  <div className='row mt-3 ' >

                                     <div className="col-md-12 col-12">
                                 <p className="f-Poppins-Medium fs-18 fw-bold">Companies Applied :28</p>


                                  </div>
                               </div>
                               <div className='row mt-2 ' >

                                     <div className="col-md-12 col-12 ">

                                        <table class="table m-0 p-0	">
                                           <thead class="shadow-none bg-primary text-white">
                                              <tr><th className='fs-12' scope="col">Company Name</th>
                                              <th className='fs-12' scope="col">Job Designations</th>
                                              <th className='fs-12' scope="col">Job Status</th>
                                              <th  className='fs-12' scope="col">Assessment Token</th>
                                              <th  className='fs-12' scope="col">OfferLetters</th>

                                              </tr>
                                              </thead><tbody></tbody>
                                              </table>


                                  </div>
                                  <div className="col-md-12 col-12 ">

                                        <table class="table m-0 p-0 mt-1	">
                                           <thead class="shadow-none bg-light-blue ">
                                              <tr><td className='fs-12' scope="col">Company Name</td>
                                              <td className='fs-12' scope="col">UI/UX Designer</td>
                                              <td className='fs-12' scope="col">Final Round</td>
                                              <td  className='fs-12' scope="col">yes</td>
                                              <td  className='fs-12' scope="col">yes</td>

                                              </tr>
                                              </thead><tbody></tbody>
                                              </table>


                                  </div>

                                  <div className="col-md-12 col-12 ">

                                     <table class="table m-0 p-0 mt-1	">
                                        <thead class="shadow-none bg-light-blue ">
                                           <tr><td className='fs-12' scope="col">Company Name</td>
                                           <td className='fs-12' scope="col">UI/UX Designer</td>
                                           <td className='fs-12' scope="col">Final Round</td>
                                           <td  className='fs-12' scope="col">yes</td>
                                           <td  className='fs-12' scope="col">yes</td>

                                           </tr>
                                           </thead><tbody></tbody>
                                           </table>


                               </div>
                               <div className="col-md-12 col-12 ">

                                     <table class="table m-0 p-0 mt-1	">
                                        <thead class="shadow-none bg-light-blue ">
                                           <tr><td className='fs-12' scope="col">Company Name</td>
                                           <td className='fs-12' scope="col">UI/UX Designer</td>
                                           <td className='fs-12' scope="col">Final Round</td>
                                           <td  className='fs-12' scope="col">yes</td>
                                           <td  className='fs-12' scope="col">yes</td>

                                           </tr>
                                           </thead><tbody></tbody>
                                           </table>


                               </div>
                               <div className="col-md-12 col-12 ">

                                     <table class="table m-0 p-0 mt-1	">
                                        <thead class="shadow-none bg-light-blue ">
                                           <tr><td className='fs-12' scope="col">Company Name</td>
                                           <td className='fs-12' scope="col">UI/UX Designer</td>
                                           <td className='fs-12' scope="col">Final Round</td>
                                           <td  className='fs-12' scope="col">yes</td>
                                           <td  className='fs-12' scope="col">yes</td>

                                           </tr>
                                           </thead><tbody></tbody>
                                           </table>


                               </div>
                               <div className="col-md-12 col-12 ">

                                     <table class="table m-0 p-0 mt-1	">
                                        <thead class="shadow-none bg-light-blue ">
                                           <tr><td className='fs-12' scope="col">Company Name</td>
                                           <td className='fs-12' scope="col">UI/UX Designer</td>
                                           <td className='fs-12' scope="col">Final Round</td>
                                           <td  className='fs-12' scope="col">yes</td>
                                           <td  className='fs-12' scope="col">yes</td>

                                           </tr>
                                           </thead><tbody></tbody>
                                           </table>


                               </div>
                               </div>
                            </div>
                         </div>

                        </div>
                        <div className="container p-4 mt-2 bg-white ">
                           <div className="row ">
                              <div className="col-md-12 col-12">
                                 <h6 className="f-Poppins-Medium">Personal Details</h6>
                              </div>

                           </div>
                           <header className='d-flex'>
                              <div className='me-3 mt-2'>
                                 <img
                                    src='/assets/imgs/dummy-logo.png'
                                    className='img-fluid box-shadow br-5 h-60p'
                                 />
                              </div>
                              <div>
                                 <h5 className='font-bold mb-1 mt-2 f-Poppins-Medium'>Sam Doe</h5>
                                 <p className='fs-14'>UI Designer</p>
                              </div>
                           </header>
                           <div className="row">
                              <div className="col-md-8">
                                 <div className="row  mt-2">
                                    <div className="col-md-6">
                                       <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                                          <p className=" f-Poppins-Regular mt-2  position-abs t-2 l-2 m-0 h-20px "><span className="float-start">Experience</span>  <span className="float-end"> 3 years</span></p>
                                       </div>
                                    </div>
                                    <div className="col-md-6">
                                       <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                                          <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular "><span className="f-1-1 m-0  p-0"> Email</span> </p>
                                          <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular "> <span className="">akestech@gmail.com </span></p>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row mb-2 mt-2">
                                    <div className="col-md-6 ">
                                       <div className="cards position-relative mt-2 bg-blue br-5 text-white p-2 mr-2 h-70">
                                          <p className=" position-abs t-2 l-2 m-0 mt-2   f-Poppins-Regular "> <span className="float-start">Salary </span> <span className="float-end" > 6 lpa</span></p>
                                       </div>
                                    </div>
                                    <div className="col-md-6">
                                       <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 mr-2 h-70 ps-2">
                                          <p className=" position-abs t-2 l-2 m-0    h-20px f-Poppins-Regular "><span className="f-1-1 m-0  p-0"> Phone No</span> </p>
                                          <p className=" position-abs t-2 l-2 mt-1  h-20px f-Poppins-Regular "> <span className="">+9196000000035</span></p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative  bg-dark-pink
                           br-5 text-white p-2 h-172  mr-2">
                                    <p className="position-abs t-2 l-2 m-0  f-Poppins-Regular ">Address</p>
                                    <p className="f-Poppins-Regular "> Lorem ipsum dolor sitamet, consectetue radipisc ingelit,seddiamn onummynibheu ismodti ncidu ntut</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        {/* <div className="container mt-4   bg-white">
                           <div className="row ">
                              <div className="col-md-12  mt-2 p-0  ">
                                 <h4>
                                    <span className="font-bold mr-2  ms-2 f-Poppins-Medium float-start">Profile Strength(Average)</span> <span className="font-bold text-blue  float-end">60%</span>
                                 </h4>
                              </div>
                              <div className="row mt-1">
                                 <div className="col-md-12">
                                    <div class="progress mt-1">
                                       <div class="progress-bar bg-info bg-primary" style={{ width: "60%" }}>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div className="row mt-4  ">
                              <div className="col-md-12 ">
                                 <h6>Complete Your Profile</h6>
                              </div>
                           </div>
                           <div className="row mt-4  pb-2">
                              <div className="col-md-3 mt-1 mb-1">
                                 <div className="cards position-relative  bg-blue br-5 text-white p-2 mr-2 h-90">
                                    <h6 className=" f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2">Upload Portfolio  </h6>
                                 </div>
                              </div>
                              <div className="col-md-3 mt-1 mb-1">
                                 <div className="cards position-relative bg-greenesh-blue  br-5 text-white p-2 mr-2 h-90">
                                    <h6 className=" f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2">Update Skill </h6>
                                 </div>
                              </div>
                              <div className="col-md-3 mt-1 mb-1 ">
                                 <div className="cards position-relative    bg-dark-pink br-5 text-white p-2 mr-2 h-90">
                                    <h6 className=" f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2">Add Education </h6>
                                 </div>
                              </div>
                              <div className="col-md-3 mt-1 mb-1">
                                 <div className="cards position-relative  bg-blue br-5 text-white p-2 mr-2 h-90">
                                    <h6 className=" f-Poppins-Regular  position-abs t-2 l-2 m-0 h-25vh text-center p-2">Add Employment  </h6>
                                 </div>
                              </div>
                           </div>
                        </div> */}
                        <div className="container mt-2 bg-white pb-4">
                           <div className="row mt-2 ">
                              <div className="col-md-12 col-12 ">
                                 <h5 className="f-Poppins-Medium mt-2 ms-2">Summary</h5>
                              </div>

                           </div>
                           <div className="row">
                              <div className="col-md-12">
                                 <p className="fs-14 f-Poppins-thin mt-2">A paragraph is a series of related sentences developing a central idea, called the topic. Try to think about paragraphs in terms of thematic unity: a paragraph is a sentence or a group of sentences that supports one central, unified idea. Paragraphs add one idea at a time to your broader argument.</p>
                              </div>
                           </div>
                           <div className="row">
                              <div className="col-md-12">
                                 <div className="row mt-2 mb-2 ">
                                    <div className="col-md-12">
                                       <h5 className="f-Poppins-Medium">Key Skill</h5>
                                    </div>
                                 </div>
                                 <div className="row">
                                    <div className="col-md-12 ">
                                       <div className="mt-1 mb-1 ">
                                          <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">User Interface Design</span> <span class="badge badge-default cursor me-1">UI/UX Product design</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row">
                                    <div className="col-md-12 ">
                                       <div className="mt-1 mb-1 ">
                                          <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge t cursor me-1 bg-primary">Add more +</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row mt-2 mb-2 ">
                                    <div className="col-md-12">
                                       <h5 className="f-Poppins-Medium">Software Skill</h5>
                                    </div>
                                 </div>
                                 <div className="row">
                                    <div className="col-md-12 ">
                                       <div className="mt-1 mb-1 ">
                                          <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">User Interface Design</span> <span class="badge badge-default cursor me-1">UI/UX Product design</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row">
                                    <div className="col-md-12 ">
                                       <div className="mt-1 mb-1 ">
                                          <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                          <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge t cursor me-1 bg-primary">Add more +</span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                         <div className="container mt-2 bg-white  pb-4 ">
                         <div className="row  mb-2  ">
                              <div className="col-md-12">
                                 <h5 className="f-Poppins-Medium mt-2 ">Career Profile</h5>
                              </div>
                           </div>
                           <div className='row mt-4'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate CV</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>rahulCV.pdf</h6>
</div>
                           </div>
                           <div className='row mt-2'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate Portfolio</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>rahulPortfolio.pdf</h6>
</div>
                           </div>
                           <div className='row mt-2'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate Publication</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>rahulPortfolio.doc</h6>
</div>
                           </div>
                           <div className='row mt-2'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate Presentations</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>rahulPortfolio.pptx</h6>
</div>
                           </div>
                           <div className='row mt-2'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate Certifications</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>rahulPortfolio.pdf</h6>
</div>
                           </div>
                           <div className='row mt-2'>
                              <div className='col-md-4 col-6'>
                                <h6 className='fw-bold '>Candidate Link Profile</h6>
                              </div>
                              <div className='col-md-8 col-6'>
                              <h6 className='text-primary'>linkdin/rahul</h6>
</div>
                           </div>
                           </div>
                        {/* <div className="container mt-2 bg-white  pb-4 ">
                           <div className="row mt-2 ">
                              <div className="col-md-11 col-10">
                                 <h4 className="f-Poppins-Medium mt-2 ms-2">Summary</h4>
                              </div>
                              <div className="col-md-1 col-2" >
                                 <h3><i class="las la-edit text-blue  mt-2"></i></h3>
                              </div>
                           </div>
                           <div className="row">
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative bg-blue
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">CV</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">sam doe CV.pdf</p>
                                       <button class="btn btn-light text-primary " type="button">Update CV</button>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative  bg-purple
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">Portfolio</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">sam do Portfolio.pdf</p>
                                       <button class="btn btn-light text-primary " type="button">Update  Portfolio</button>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative  bg-blue
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">Publications</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">sam doe1.doc</p>
                                       <button class="btn btn-light text-primary  " type="button">Update Publications</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div className="row">
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative bg-purple
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">Presentations</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">sam doe present.pptx</p>
                                       <button class="btn btn-light text-primary " type="button">Update Presentations</button>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative  bg-blue
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">Certificates</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">sam doe Certificate3.pdf</p>
                                       <button class="btn btn-light text-primary " type="button">Update Certificates</button>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4 mt-4">
                                 <div className="cards position-relative  bg-purple
                        br-5 text-white p-2 h-172  mr-2">
                                    <h4 className="position-abs t-2 l-2 m-0 ms-2 p-2f-Poppins-Regular ">Linked Profiles</h4>
                                    <div class="d-grid gap-2">
                                       <p className="mt-5 ms-2 ">linkedin/samdoe</p>
                                       <button class="btn btn-light text-primary  " type="button">Update Publications</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div> */}
                        <div className="container mt-2 bg-white pb-4 ">
                           <div className="row  mb-2  ">
                              <div className="col-md-12">
                                 <h5 className="f-Poppins-Medium mt-2 ms-2">Employment</h5>
                              </div>
                           </div>
                           <div className="container  ">
                              <div className="row  w-xs-100 shadow mt-4 ">
                                 <div className="col-md-12 col-12  mt-2 mb-2">
                                    <header className='d-flex'>
                                       <div className='me-3'>
                                          <img
                                             src='/assets/imgs/dummy-logo.png'
                                             className='img-fluid box-shadow br-5 h-60p'
                                          />
                                       </div>
                                       <div>
                                          <h5 className='font-bold '>Designation</h5>
                                          <p className='fs-12'>Company Name</p>
                                          <p className='fs-12'>June 2017 to June 2019</p>
                                       </div>
                                    </header>
                                 </div>

                              </div>
                              <div className="row  w-xs-100 shadow mt-4 ">
                              <div className="col-md-12 col-12  mt-2 mb-2">
                                    <header className='d-flex'>
                                       <div className='me-3'>
                                          <img
                                             src='/assets/imgs/dummy-logo.png'
                                             className='img-fluid box-shadow br-5 h-60p'
                                          />
                                       </div>
                                       <div>
                                          <h5 className='font-bold '>Designation</h5>
                                          <p className='fs-12'>Company Name</p>
                                          <p className='fs-12'>June 2017 to June 2019</p>
                                       </div>
                                    </header>
                                 </div>
                              </div>
                           </div>

                        </div>
                        <div className="container mt-2 bg-white pb-2 ">
                           <div className="row  mb-2  ">
                              <div className="col-md-12">
                                 <h5 className="f-Poppins-Medium mt-2 ms-2">Education</h5>
                              </div>
                           </div>
                           <div className="container  ">
                              <div className="row  w-xs-100 shadow mt-4 ">
                                 <div className="col-md-12 col-12  mt-2 mb-2">
                                 <header className='d-flex'>
                                       <div className='me-3'>
                                          <img
                                             src='/assets/imgs/dummy-logo.png'
                                             className='img-fluid box-shadow br-5 h-60p'
                                          />
                                       </div>
                                       <div>
                                          <h5 className='font-bold '>Designation</h5>
                                          <p className='fs-12'>Company Name</p>
                                          <p className='fs-12'>June 2017 to June 2019</p>
                                       </div>
                                    </header>
                                 </div>

                              </div>
                           </div>

                        </div>
                        <div className="container mt-2 bg-white pb-4 ">
                           <div className="row mt-2 ">
                              <div className="col-md-12 col-12">
                                 <h5 className="f-Poppins-Medium mt-2 ms-2">Language</h5>
                              </div>

                           </div>
                           <div className="row w-80 w-xs-100">
                              <div className="col-md-3">
                                 <div className="cards position-relative   bg-blue br-5 text-white h-90px mt-2 ">
                                    <p className="f-Poppins-Regular  text-center pt-1 ps-2  f-0-9">English</p>
                                    <h1 className="d-flex justify-content-center align-items-center mt-3">a</h1>
                                    <p className="f-Poppins-Light pb-1  mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="cards position-relative   bg-greenesh-blue  br-5 text-white h-90px mt-2 ">
                                    <p className="f-Poppins-Regular  pt-1 ps-2  f-0-9 text-center">
                                       Hindi
                                    </p>
                                    <h1 className="text-center mt-3">अ</h1>
                                    <p className="f-Poppins-Light pb-1   mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="cards position-relative  bg-dark-pink br-5 text-white h-90px mt-2 ">
                                    <p className="f-Poppins-Regular  pt-1 ps-2 text-center  f-0-9">Tamil</p>
                                    <h1 className="text-center mt-3">க</h1>
                                    <p className="f-Poppins-Light pb-1   mt-3 f-0-9 text-center ">Read, Write, Speak</p>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="cards position-relative   bg-blue br-5 text-white h-90px mt-2 ">
                                    <p className="f-Poppins-Regular  pt-1 ps-2  f-0-9 text-center">Kannada</p>
                                    <h1 className="text-center mt-3">ಅ</h1>
                                    <p className="f-Poppins-Light pb-1   mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     {/* Content */}

                     {/* Sidebar */}
                     <div className="col-md-3">
                        <ProfileName />
                        <ActionButtons />
                        <Company />
                     </div>
                     {/* Sidebar */}
                  </div>
               </div>
            </div>
         </div>
      );
   }
}



export default CandidatesStats;
