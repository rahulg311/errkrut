import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';

class UiHome extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-1  ">
            <div className=" ">
               
              
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className=" row bg-white mt-2   ">
                   <div className='container'>
                   <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
                  						<select class="form-select w-35 text-primary" aria-label="Default select example">
                                              
  <option className='text-primary' selected>All Job</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>
							<p className='float-right mt-auto mb-auto'>
							<button type="button" class="btn btn-primary ps-5 pe-5">Download Stats</button>
							</p>
						</div>
					</div>
					
				</div>



                <div className='row mt-4 '>
                     <div className='col-md-8  '>
                         <div className='row'>
                             <div className='col-md-9 cards-shadow'>
                             <div className='row mt-3 mb-3 '>
					<div className='col-md-5 mt-1'>
					
							<h6 className='font-bold float-left'>Job Start</h6>
					

						
					
				</div>
            

                        </div>
                        <div className='row'>
                            <div className='col-md-12'>
                                
                            </div>
                        </div>
                                 
                             </div>
                             <div className='col-md-3 '>
                                 <div className='row'>
                                     <div className='col-12'>
                                     <div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '><span className='ms-4 '> Job </span><br /> <span className='float-end'>Saved</span> </p>
					</div>
                                     </div>
                                 </div>
                                 <div className='row mt-2'>
                                     <div className='col-12'>
                                     <div className='cards   bg-greenesh-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '><span className='ms-4 '> Total</span><br /> <span className='float-end'>Likes</span> </p>
					</div>
                                     </div>
                                 </div>
                        
                    
                    
                             </div>
                         </div>





                         <div className='row mt-2  cards-shadow me-1'>
                             <div className='col-md-12'>
                                 <h5 className='mt-3 m-2 fw-bold'>Demographics</h5>





                                 <div className='row pb-4 '>
                                     <div className='col-md-4'>
										 <div className='row '>
											 <div className='col-12'>
											 <div className='cards  bg-blue br-5 text-white ps-1  h-100 mr-2 '>
						<p className='fs-15 font-bold float-start mt-3 mb-3 '>India</p>
						<p className='fs-15 font-bold float-end  mt-3 mb-3 me-1'>68</p>
					
					</div>
											 </div>


											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Australia</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>54</p>
					
					</div>
											 </div>
											 
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>America</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
											 </div>
											 
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Brazil</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
					
											 </div>
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Canada</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
					
											 </div>
										 </div>
									 </div>
                                     <div className='col-md-8'>
										 <div className='row  me-1'>
											 <div className='col-12 pt-1 cards-shadow pb-1'>
												 <p className='float-start fs-15 fw-bold'>Karnataka</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Delhi</p>
												 <p className='float-end fw-bold fs-15'>42</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Chandigarh</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Noida</p>
												 <p className='float-end fw-bold fs-15'>12</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Lucknow</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Uttrakhand</p>
												 <p className='float-end fw-bold fs-15'>642</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Karnataka</p>
												 <p className='float-end fw-bold fs-15'>92</p>
											 </div>
										 </div>
									 </div>
                                 </div>
                             </div>
                         </div>
                     </div>



                     <div className='col-md-4'>
						 <div className='row cards-shadow'>
							 <div className='col-12'>
								 <p className='fw-bold fs-18 p-1 '> Assessment</p>
							 </div>

							 <div className='col-12 d-flex justify-content-center'>
							 <div class="ui-widgets">
            <div class="ui-values">80%</div>
           
        </div>
							 </div>

							 <div className='col-12  mt-2 d-flex'>
							 <button type="button" class="btn btn-danger  ms-2"></button>
							 <p className='fs-12 ms-1'>Completed in a single take</p>

							 </div>
							 <div className='col-12 mt-1 d-flex'>
							 <button type="button" class="btn btn-primary  ms-2"></button>
							 <p className='fs-12 ms-1'>Completed in a 	multiple takes</p>

							 </div>

							 <div className='border-dashed1 mt-3 mb-2'></div>


							 <div className='row mb-3'>
								 <div className='col-4 m-0 p-0'>
									 <h5 className='fw-bold mt-1 ps-1 fs-20'>Top 5</h5>
									 
								 </div>
								 <div className='col-8 m-0 p-0'>
								 <select class="form-select fw-bold  " aria-label="Default select example">
                                              
											  <option className='fw-bold ' selected>Hardest Questions</option>
											  <option value="1">One</option>
											  <option value="2">Two</option>
											  <option value="3">Three</option>
											</select>
															
								 </div>
							 </div>


							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-15 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							
								
								
							
						 </div>
                         
                     </div>
                 </div>













                <div className='row mt-2 pb-4 '>
                    <div className='col-12 '>
						<div className='row'>
							<div className='col-4'>
							<div class="cards  bg-blue br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Avg Marks  <br/><span class="ms-3">Obtained</span></p></div>
							</div>
							<div className='col-4'>
							<div class="cards  bg-dark-pink br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Passed  <br/><span class="ms-3">Candidates</span></p></div>
							</div>
							<div className='col-4'>
							<div class="cards  bg-greenesh-blue br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Candidate  <br/><span class="ms-3">Eliglbilty</span></p></div>
							</div>
						</div>
                   
                    

                    </div>





























</div>
</div>
</div>

</div>
<div class="row mt-3 bg-white p-2">
	<div class="col-md-12">
		<div class="d-flex justify-content-between w-100">
			<p className='fw-bold fs-22'>View Candidates</p>
			<p class="float-right mt-auto mb-auto">
					<button type="button" class="btn btn-primary ps-5 pe-5">View</button></p></div>
					
					
					
					
					
					
					
					</div>
					
					
					
					
					
					
					
					
					
					
					</div>



					
					<div className=" row shadow bg-white mt-3">
						<div className='col-12'>
									<div className="container ">
										<div className="row p-2">
											<div className="col-md-11 col-10">
												<header className='d-flex '>
													<div className='me-3 mt-2'>
														<img
															src='/assets/imgs/dummy-logo.png'
															className='img-fluid box-shadow br-5 h-60p'
														/>
													</div>
													<div>
														<h4 className='font-bold mb-1 mt-2 f-Poppins-Medium'>UI/UX Designer</h4>
														<p className="f-Poppins-Regular f-1-1">Company Name
														</p>
													</div>
												</header>
											</div>
											<div className="col-md-1 col-2">
											<i class="far fa-edit h4 text-primary"></i>
											</div>
										</div>
				
										<div className="row">
											<div className="col-md-12 col-12 d-flex mt-2">
											<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   f-1 me-2">Candidate Applied</span><span className=" f-Poppins-Light  f-0-8   ">42</span> </p>
											
											</div>
										</div>
										<div className="row w-80 w-100-xs mt-1 ">
											<div className="col-md-4 col-12 d-flex">
												<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   f-1 me-2">Experience</span><span className=" f-Poppins-Light  f-0-8   ">0-5 Year</span> </p>
											</div>
											<div className="col-md-4  col-12 d-flex">
												<i class='las la-map-marker   text-sky-blue f-1-4 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   f-1 me-2">Locations</span><span className="f-Poppins-Light  ">Bengalurur</span> </p>
											</div>
											<div className="col-md-4   col-12 d-flex">
												<i class='las la-rupee-sign  text-sky-blue f-1-4 1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Salary</span><span className="f-Poppins-Light  ">Not Disclosed</span> </p>
											</div>
										</div>
										
										<div className="row mt-1">
											<div className="col-md-3 col-12 d-flex ">
												<i class='las la-user-check  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Vacancy</span><span className="f-Poppins-Light  ">8</span> </p>
											</div>
											<div className="col-md-4 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light  ">8</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light  ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2"> Key Skill </span><span className="f-Poppins-Light  ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2"> Technical Skill </span><span className="f-Poppins-Light  ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-3 col-3 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Job Description</span></p>
											</div>
											<div className="col-md-9 col-9 d-flex m-0 p-0 ">
												
												<p className=" f-0-8    "><span className="f-Poppins-Light  ">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi quae distinctio nihil at! Provident atque pariatur, harum aperiam beatae asperiores et alias, quisquam culpa officiis quas eum tempore corrupti animi.</span> </p>
											</div>
										</div>
										<div className="row mt-2">
											<div className="col-md-12 p-0">
												<div className="bg-whitept-3 pb-3 px-3 br-5">
													<div className="row">
														<div className="col-md-12 mt-1">
															<span class="badge badge-default cursor me-1 f-Poppins-Medium">UI</span>
															<span class="badge badge-default cursor me-1 f-Poppins-Medium">UX</span>
															<span class="badge badge-default cursor me-1 ms-2 f-Poppins-Medium">User Flow</span>
															<span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Design</span>
															<span class="badge badge-default cursor me-1   f-Poppins-Medium">User Interface Design</span>
															<span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Product Design</span>
														</div>
													</div>
												</div>
											</div>
										</div>
										
									</div>
								</div>
								
								
								
								
								
								
								
								
								</div>



<div className='row shadow bg-white mt-3 '>
	<div className='col-12'>

<div className='row p-2'>
<div class="col-md-12">
		<div class="d-flex justify-content-between w-100">
			<p className='fw-bold fs-22 text-primary'>Quize</p>
			<p class="float-right mt-auto mb-auto">
			<i class="far fa-edit  h4 text-primary"></i> </p></div>
					
					
					
					
					
					
					
					</div>

</div>
<div className='border-blue1'></div>
<div className='container'>
<div className='row mt-2'>
	<div className='col-12'>
		<h4>Quizes</h4>
	</div>
	<div className='col-12 mt-2'>
		<h6 >Quize Instruction</h6>
		<p className='mt-2'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur dolorem magni consequuntur, ipsam itaque voluptates quo amet corporis architecto quis iure, odit similique deleniti nobis tempore repellendus atque quibusdam aut.Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur dolorem magni consequuntur, ipsam itaque voluptates quo amet corporis architecto quis iure, odit similique deleniti nobis tempore repellendus atque quibusdam aut.</p>
	</div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Quize Duration</h6></div>
		<div className='col-6'><h6>45:00 min</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Quize Evalutaion</h6></div>
		<div className='col-6'><h6>Automatic</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
	<div className='col-12 mt-2'>
		<h6 >Success Message</h6>
		<p className='mt-2'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur dolorem magni consequuntur, ipsam itaque voluptates quo amet corporis architecto quis iure, odit similique deleniti nobis tempore repellendus atque quibusdam aut.Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur dolorem magni consequuntur, ipsam itaque voluptates quo amet corporis architecto quis iure, odit similique deleniti nobis tempore repellendus atque quibusdam aut.</p>
	</div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Passing Marks</h6></div>
		<div className='col-6'><h6>20</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Correct</h6></div>
		<div className='col-6'><h6>20</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>incorrect Marks</h6></div>
		<div className='col-6'><h6>20</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Retake Quiz</h6></div>
		<div className='col-6'><h6>4</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Show Result</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Check Answer Hint</h6></div>
		<div className='col-6'><h6> yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Partial Marking</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Partial Marking</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Randomize Question</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Randomize Question between Section</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Randomize Section Question</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	
	<div className='row mt-2'>
		<div className='col-6'> <h6>RandomizE Options</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-6'> <h6>Negative Maeking</h6></div>
		<div className='col-6'><h6>yes</h6></div>
	</div>
	<div className=' mt-1  new2'></div>
	<div className='row mt-2'>
		<div className='col-12'> <h6>Quiz Sections</h6></div>
		
	</div>
	<div className='row    gap-2 mt-3 mb-7'>
		<div className='col-3 border-blue rounded-4'>
			<h5 className='text-primary mt-1'>Section 1</h5>
			
		<p className='mt-1'>Analytical Reasoning <br /> Total Question :15</p>


		<h5 className='mt-3'>15 Points</h5>

		<button type="button" class="btn btn-primary w-100 mb-1 mt-2">View Question</button> 

			 </div>
			 <div className='col-3 border-blue rounded-4'>
			<h5 className='text-primary mt-1'>Section 1</h5>
			
		<p className='mt-1'>Analytical Reasoning <br /> Total Question :15</p>


		<h5 className='mt-3'>15 Points</h5>

		<button type="button" class="btn btn-primary w-100 mb-1 mt-2">View Question</button> 
			 </div>
	</div>
	
	</div>
</div>

</div></div>

            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default UiHome;