import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Summary from './../../../components/CompanyProfile/Summary';


class TotalCandidates1 extends Component {
	// Handle fields change
	handleChange = (e) => {
	}
	render() {
		return (
			<div className="container bg-white">
				<div className="row">
					<div className="col-md-9 p-0">
						<div className="">
							<div className="container">
								<div className="row mt-3 mb-4">
									<div className="col-md-6  col-12 mt-1 ">
										<h3 className="text-primary  mb-2 f-Poppins-Medium ms-4 ">Total Candidates</h3>
									</div>
									<div className="col-md-6 p-0 m-0 mt-1 ">
										<select class="p-1 text-primary ms-1 fs-12 " aria-label="Default select example">
											<option selected>UI/UX Designer</option>
											<option value="1">One</option>
											<option value="2">Two</option>
											<option value="3">Three</option>
										</select>
										<select class="p-1 text-primary ms-1 fs-12  " aria-label="Default select example">
											<option selected>ALL</option>
											<option value="1">Call For Interview</option>
											<option value="2">Letter of Intent sent</option>
											<option value="3">Offer Letter Sent</option>
											<option value="1">Rejected By Me</option>
											<option value="2">Rejected By Candidates </option>
											<option value="3">Saves Candidates</option>
										</select>

										<button type="button" class="btn btn-primary fs-12 ps-4 pe-4 pt-1 pb-1 ms-1  ">Fliter</button>
									</div>
									<div className="border-blue1  "></div>
								</div>

								<div className=" shadow ">
									<div className="container ">
										<div className="row p-2">
											<div className="col-md-8 col-10 p-0d-flexd-flexd-flexd-flexd-flex">
												<header className='d-flex '>
													<div className='me-3 mt-2'>
														<img
															src='/assets/imgs/dummy-logo.png'
															className='img-fluid box-shadow br-5 h-60p'
														/>
													</div>
													<div>
														<h5 className='font-bold mb-1 mt-2 f-Poppins-Medium'>Sam Doe</h5>
														<p className="f-Poppins-Regular f-1">Current Designation
														</p>
													</div>
												</header>
											</div>
											<div className="col-md-4 col-2 mt-2 d-flex">
											<p className='text-primary fw-bold pe-1 '>Status : Applied for Interview</p>
												<div class="form-check ">
												
													<input class="form-check-input p-1" type="checkbox" value="" id="flexCheckDefault" />
												</div>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 col-12">
												<h6 className="text-primary">Applied For : UI/UX Designer
												</h6>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 col-12 d-flex mt-2">
												<p className="text-primary pe-1 f-Poppins-Regular">Portfolio
												</p><p className="text-primary f-Poppins-Regular">SamDoe.pdf
												</p>
											</div>
										</div>
										<div className="row  w-100-xs mt-1 ">
											<div className="col-md-3 col-12 d-flex">
												<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   fs-15 me-2">Experience</span><span className=" f-Poppins-Light  f-0-8   ">0-5 Year</span> </p>
											</div>
											<div className="col-md-3  col-12 d-flex">
												<i class='las la-map-marker   text-sky-blue f-1-4 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2">Locations</span><span className="f-Poppins-Light  ">Bengalurur</span> </p>
											</div>
											<div className="col-md-4   col-12 d-flex">
												<i class='las la-rupee-sign  text-sky-blue f-1-4 1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2"> Current Salary</span><span className="f-Poppins-Light  ">Not Disclosed</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2">Skill Set</span><span className="f-Poppins-Light  ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className='col-1'>
												<p className='text-primary'>Summary</p>
											</div>
											<div className='col-11 '>
												<p className='ps-2 fs-12'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Temporibus laudantium dicta cum aut adipisci alias, doloribus, facere cupiditate dolores animi est, praesentium quia at quidem! Labore, voluptates minus. Consequatur, illo!</p>
											</div>
										</div>
						
										<div className="border mt-2 mb-4"></div>
										<div className="row mb-4 pb-3">
											<div className="col-md-8 col-12 d-flex mb-2 ">
											<i class="fas fa-trash-alt h4 text-danger"></i>
											<i class="fas fa-sync-alt ps-4 h4 text-primary"></i>
											<i class="far fa-bookmark ps-4 h4"></i>
											</div>
											<div className="col-md-4 m-0 p-0 col-12 ">
												<button type="button" class="btn btn-outline-primary me-1  float-start">Save Profile</button>
												<button type="button" class="btn btn-primary float-end">Call For interview </button>
											</div>
										</div>
									</div>
								</div>
								<div className=" shadow mt-3 ">
									<div className="container ">
										<div className="row p-2">
											<div className="col-md-8 col-10 p-0d-flexd-flexd-flexd-flexd-flex">
												<header className='d-flex '>
													<div className='me-3 mt-2'>
														<img
															src='/assets/imgs/dummy-logo.png'
															className='img-fluid box-shadow br-5 h-60p'
														/>
													</div>
													<div>
														<h5 className='font-bold mb-1 mt-2 f-Poppins-Medium'>Sam Doe</h5>
														<p className="f-Poppins-Regular f-1">Current Designation
														</p>
													</div>
												</header>
											</div>
											<div className="col-md-4 col-2 mt-2 d-flex">
											<p className='text-primary fw-bold pe-1 '>Status : Applied for Interview</p>
												<div class="form-check ">
												
													<input class="form-check-input p-1" type="checkbox" value="" id="flexCheckDefault" />
												</div>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 col-12">
												<h6 className="text-primary">Applied For : UI/UX Designer
												</h6>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 col-12 d-flex mt-2">
												<p className="text-primary pe-1 f-Poppins-Regular">Portfolio
												</p><p className="text-primary f-Poppins-Regular">SamDoe.pdf
												</p>
											</div>
										</div>
										<div className="row  w-100-xs mt-1 ">
											<div className="col-md-3 col-12 d-flex">
												<i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium   fs-15 me-2">Experience</span><span className=" f-Poppins-Light  f-0-8   ">0-5 Year</span> </p>
											</div>
											<div className="col-md-3  col-12 d-flex">
												<i class='las la-map-marker   text-sky-blue f-1-4 ' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2">Locations</span><span className="f-Poppins-Light  ">Bengalurur</span> </p>
											</div>
											<div className="col-md-4   col-12 d-flex">
												<i class='las la-rupee-sign  text-sky-blue f-1-4 1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2"> Current Salary</span><span className="f-Poppins-Light  ">Not Disclosed</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className="col-md-12 col-12 d-flex ">
												<i class='las la-briefcase  text-sky-blue f-1-4  pe-1' />
												<p className=" f-0-8    "><span className="text-primary f-Poppins-Medium  fs-15 me-2">Skill Set</span><span className="f-Poppins-Light  ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
											</div>
										</div>
										<div className="row mt-1">
											<div className='col-1'>
												<p className='text-primary'>Summary</p>
											</div>
											<div className='col-11 '>
												<p className='ps-2 fs-12'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Temporibus laudantium dicta cum aut adipisci alias, doloribus, facere cupiditate dolores animi est, praesentium quia at quidem! Labore, voluptates minus. Consequatur, illo!</p>
											</div>
										</div>
						
										<div className="border mt-2 mb-4"></div>
										<div className="row mb-4 pb-3">
											<div className="col-md-8 col-12 d-flex mb-2 ">
											<i class="fas fa-trash-alt h4 text-danger"></i>
											<i class="fas fa-sync-alt ps-4 h4 text-primary"></i>
											<i class="far fa-bookmark ps-4 h4"></i>
											</div>
											<div className="col-md-4 m-0 p-0 col-12 ">
												<button type="button" class="btn btn-outline-primary me-1  float-start">Save Profile</button>
												<button type="button" class="btn btn-primary float-end">Call For interview </button>
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* submit button */}
							{/* form ends here */}
						</div>
					</div>
					{/* sidebar */}
					<div className="col-md-3">
						<ProfileName />
						<ActionButtons />
						<Company />
					</div>
					{/* sidebar */}
				</div>
			</div>
		);
	}
}
export default TotalCandidates1;