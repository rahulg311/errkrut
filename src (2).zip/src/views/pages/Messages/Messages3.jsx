import React, { Component } from 'react';

import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';

import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
class Messages3 extends Component {
render() {
return (
<div className="container">
<div className="row">
   <div className="col-md-9 p-0 m-0">
      <div className="">
         <div className="">
            <div className='row bg-white  mb-5'>
               <div className='col-md-12'>
                  <div className=''>
                     <div className='row mt-2 mb-2'>
                        <div className='col-md-12 col-12'>
                           <h4 className='text-primary float-start mt-1 ms-1 p-0'>Meassage</h4>
                           <button type="button" class="btn btn-primary ps-1  float-end f-1">New Messages</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div className='row mt-2   '>
            <div className='col-md-4 bg-white mb-4 '>
                  <div className=' row'>
                     <div className='col-md-12 pt-2 '>
                        <h5 className='text-primary float-start '>Inbox</h5>
                        <i class="las la-ellipsis-v text-primary float-end h4"></i>
                     </div>
                  </div>
                  <div className='border-blue1 mt-2 '></div>
                  <div className="scrollbar w-100 force-overflow  bg-white" >
    
                  <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-primary rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium text-white'>Company 1</p>
                              <p className=" fs-12  text-white ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4 text-white fs-12  '>just Now</p>
                     </div>
                  </div>
                  <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div> <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div> <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div> <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div> <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div> 
                 
                   <div className="row ms-1px me-1px mt-2  mb-2 pb-2 bg-light-blue  rounded-3">
                     <div className="col-md-9 col-9 p-0 m-0">
                        <header className='d-flex '>
                           <div className=' ms-1 me-1 mt-2'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow  h-40px'
                                 />
                           </div>
                           <div>
                              <p className='font-bold fs-14  mt-2 f-Poppins-Medium '>Company 1</p>
                              <p className=" fs-12   ">Campus Placement
                              </p>
                           </div>
                        </header>
                     </div>
                     <div className="col-md-3 col-3 p-0 m-0">
                        <p className=' pt-4  fs-12  '>just Now</p>
                     </div>
                  </div>
                  
                  
  
       
      </div>
    
                  
                  <div ></div>
               </div>
               
               <div className='col-md-8   col-12  d-full'>
				   <div className='row'>
					   <div className='col-md-12 col-12'>
                  <div className='container   col-12'>
                     <div className='row   '>
                        <div className='col-md-12  blue-box-shadow  bg-white p-1 '>
                           <div class="search-box d-flex ">
                              <button class="search-button border-none bg-transparent ">
                              {/* <i class="fas fa-search bg-white pe-2"></i> */}
                              <i class="fas fa-search border-none "></i>
                              </button>
							  <input type="text" class="form-control border-none w-90 border-0 ps-2 search-input"  placeholder="Search mail" aria-label="Username" aria-describedby="basic-addon1"/>
                              {/* <input type="text" className='w-90 border-0 ps-2 search-input ' placeholder="Search mail"/> */}
                           </div>
                        </div>
						</div>
                        <div className='row bg-white mt-2'>
                           <div className='col-md-12'>
                              <div className="row pb-1">
                                 <div className="col-md-12 col-12">
                                    <header className='d-flex '>
                                       <div className='me-3 mt-2'>
                                          <img
                                             src='/assets/imgs/dummy-logo.png'
                                             className='img-fluid box-shadow br-5 h-60p'
                                             />
                                       </div>
                                       <div>
                                          <h6 className='font-bold mb-1px mt-2 f-Poppins-Medium'>Sam Deo</h6>
                                          <p className="f-Poppins-Regular f-0-8  f-Poppins-Regular">Tuesday |23-12-2021|1422</p>
                                          <p className="f-Poppins-Regular f-0-8  f-Poppins-Regular">To:Company 1</p>
                                       </div>
                                    </header>
                                 </div>
                              </div>
                              <div className='row '>
                                 <div className='col-md-12'>
                                    <h6 className='mt-  f-Poppins-Light m-2'>Subject:  Campus invite</h6>
                                    <p className=' f-Poppins-Regular m-2'>
                                        Hello, <br  />
                                        Online Grammar and Writing Checker To Help You Deliver Impeccable, Mistake-free Writing. Grammarly Has a Tool For Just About Every Kind Of Writing You Do. Try It Out For Yourself!
                                         <br />
                                        
                                        </p>
                                        <p className='mt-4 f-Poppins-Regular  m-2'>Student CVs:20 <br />
                                        Recruit Co Ordinator :Deo Johnson </p>
                                    <p className='mt-4 f-Poppins-Regular  m-2'>Regards, <br />
                                       Bill joe
                                    </p>
                                 </div>
                              </div>
                              <div className='border-blue1 mt-2 mb-2'></div>
                              <div className='row'>
                                 <div className='col-md-6'></div>
                                 <div className='col-md-6 d-flex gap-4 mb-4' >
                                    <button type="button" class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium ">Reply</button>
                                    <button type="button" class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium">Forward</button>
                                 </div>
                              </div>
                           </div>
                       
                        <div className=''>
                           <div className='row'>
                              <div className='col-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                  <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 
                                 </div>
                                 <div className='row mt-3'>
                              <div className='col-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                  <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 
                                 </div>
                                 <div className='row mt-3'>
                              <div className='col-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                  <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 
                                 </div>
                                 <div className='row mt-3'>
                              <div className='col-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                  <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div>  
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 <div className='col-2 ms-2'>
                                 <a className='bg-light-blue p-1 rounded-3' href="">Student.pdf</a>
                           
                                 </div> 
                                 
                                 </div>
                            </div>
                            </div>
                    
                     {/* <div className="row pb-1 bg-white mt-3">
                        <div className="col-md-12 col-12">
                           <header className='d-flex '>
                              <div className='me-3 mt-2'>
                                 <img
                                    src='/assets/imgs/dummy-logo.png'
                                    className='img-fluid box-shadow br-5 h-60p'
                                    />
                              </div>
                              <div>
                                 <h6 className='font-bold mb-1px mt-2 f-Poppins-Medium'>Rahul gupta</h6>
                                 <p className=" f-Poppins-Regular f-0-8">Tuesday |23-12-2021|1422</p>
                                 <p className="f-Poppins-Regular f-0-8">To:Rahul gupta</p>
                              </div>
                           </header>
                           <h6 className='mt-4 mb-3 ms-2 f-Poppins-Light'>Subject:Campus invite</h6>
                        </div>
                     </div> */}
                  </div></div>
				   </div>
				  
               </div>
            </div>
            {/* 
            <div className="col-md-7  col-12">
               <h3 className="text-primary mt-3 mb-2 f-Poppins-Medium ms-4 ">Total Candidates</h3>
            </div>
            */}
           
            </div>
         </div>
         {/* submit button */}
         {/* form ends here */}
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default Messages3;