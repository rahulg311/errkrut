import React from "react";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import ListModal from "../../../components/Messages/ListModal";
import { useHistory, useLocation } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";
import { SEND_MESSAGE, END_POINT, GetProfile } from "../../../routes/api_routes";
import { notification } from '../../../classes/messages';
import usePost from "../../../hooks/usePost";
import { getLoggedInUser } from "../../../classes";
import { getAuthToken } from '../../../classes/index';
const SendMsgToRecruiter = ({ match }) => {
  console.log(match.params);
  const [companyList, setCompanyList] = useState([]);
  const location = useLocation();
  const [coordinatorListModal, setCoordinatorListModal] = useState(false);
  const [studentListModal, setStudentListModal] = useState(false);
  const sendMessageAPI = usePost();
  const [messagePayload, setMessagePayload] = useState({
    subject: "Job Application",
    message: ``,
    attachment: null,
    students: [],
    coordinator: [],
  });
  const history = useHistory();

  const closeCoordinatorModal = () => setCoordinatorListModal(false);
  const closeStudentListModal = () => setStudentListModal(false);

  useEffect(async () => {
    if (
      location.state?.companyData &&
      Object.keys(location.state.companyData)
    ) {
      setCompanyList(location.state.companyData);
    }
    // try {
    //   let token = await getAuthToken();
    //   if (token) {
    //     const response = await fetch(END_POINT + GetProfile + `/${match.params.id}`, {
    //       method: 'GET',
    //       headers: {
    //         'Accept': 'application/json',
    //         'Authorization': 'Bearer ' + token,
    //         'Content-Type': 'application/json'
    //       }
    //     });
    //     const json = await response.json();
    //     console.log(json);
    //   }
    // } catch (e) {
    //   console.log(e);
    // }
  }, [location]);

  useEffect(() => {
    if (sendMessageAPI.response && sendMessageAPI.response.status == 'success') {
      history.push("/search");
      const notify = notification({ message: sendMessageAPI.response.message, type: 'success' });
      notify();
    }
  }, [sendMessageAPI?.response])

  const handleForm = (e) => {
    if (e.target) {
      let ivalue = e.target.value;
      let iname = e.target.name;
      let ftype = e.target.type;

      if (ftype == "file") {
        if (e.target.files.length > 0) {
          ivalue = e.target.files[0];
        }
      }
      setMessagePayload({
        ...messagePayload,
        [iname]: ivalue,
      });
    }
  };

  const handleSendMessage = async () => {
    const user = await getLoggedInUser();
    let formData = new FormData();
    formData.append("subject", messagePayload.subject);
    formData.append("message", messagePayload.message);
    formData.append("attachment", messagePayload.attachment);
    formData.append("sender_id", user.id);
    formData.append(
      "receiver_id", "[" + match.params.id + "]"
    );
    let token = await getAuthToken();
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json", 'Authorization': 'Bearer ' + token },
    };
    sendMessageAPI.doPost(`${SEND_MESSAGE}`, formData, requestOptions);
  };

  const handleModalSubmit = (type, data) => {
    switch (type) {
      case "coordinator":
        setMessagePayload({
          ...messagePayload,
          coordinator: data,
        });
        break;
      case "students":
        setMessagePayload({
          ...messagePayload,
          students: data,
        });
        break;
      default:
        break;
    }
  };

  const calculateMoreString = (arr) => {
    let str = "";
    if (arr.length <= 2) {
      return arr.join(", ");
    }
    for (let i = 0; i <= 1; i++) {
      str = str + arr[i] + ", ";
    }
    str = str + `+ ${arr.length - 2} More`;
    return str;
  };

  return (
    <>
      <ListModal
        closeModal={closeCoordinatorModal}
        is_modal={coordinatorListModal}
        title="Select Coordinator"
        type="coordinator"
        handleSubmit={handleModalSubmit}
      />
      <ListModal
        closeModal={closeStudentListModal}
        is_modal={studentListModal}
        title="Select Students"
        type="students"
        handleSubmit={handleModalSubmit}
      />

      <div className="container">
        <div className="row">
          <div className="col-md-9 p-0 m-0">
            <div className="">
              <div className="">

                <div className="row mt-2   ">
                  <div className="col-md-4 bg-white mb-4 ">
                    <div className=" row">
                      <div className="col-md-12 pt-2 ">
                        <h5 className="text-primary float-start ">Messages</h5>
                        <i class="las la-ellipsis-v text-primary float-end h4"></i>
                      </div>
                    </div>
                    <div className="border-blue1 mt-2 "></div>
                    <div className="scrollbar w-100 force-overflow  bg-white"></div>
                  </div>

                  <div className="col-md-8   col-12  d-full">
                    <div className="row">
                      <div className="col-md-12 col-12">
                        <div className="container   col-12">
                          <div className="row   ">
                            <div className="col-md-12  blue-box-shadow  bg-white p-1 ">
                              <div class="search-box d-flex ">
                                <button class="search-button border-none bg-transparent ">
                                  {/* <i class="fas fa-search bg-white pe-2"></i> */}
                                  <i class="fas fa-search border-none "></i>
                                </button>
                                <input
                                  type="text"
                                  class="form-control border-none w-90 border-0 ps-2 search-input"
                                  placeholder="Search mail"
                                  aria-label="Username"
                                  aria-describedby="basic-addon1"
                                />
                                {/* <input type="text" className='w-90 border-0 ps-2 search-input ' placeholder="Search mail"/> */}
                              </div>
                            </div>
                          </div>

                          <div className="row bg-white mt-2">
                            <div className="container">
                              <div className="row">
                                <div className="col-md-12">
                                  <div class="form-group m-1 ">
                                    <div class="input-group">
                                      <div class="input-group-addon me-2 mt-1 fs-5">
                                        To:
                                      </div>
                                      <input
                                        className="form-control border-none"
                                        id="text"
                                        name="company_emails"
                                        type="text"
                                        // disabled
                                        value={match.params.cname}
                                      />
                                    </div>
                                  </div>
                                  <div className="border-blue1  "></div>
                                </div>

                                <div className="col-md-12">
                                  <div class="form-group m-1 ">
                                    <h6 className="mt-4 mb-3  f-Poppins-Light">
                                      Subject : <input
                                        className="form-control border-none mt-1"
                                        id="text"
                                        name="subject"
                                        type="text"
                                        onChange={handleForm}
                                        value={messagePayload.subject}
                                      />
                                    </h6>
                                  </div>
                                  <div className="border-blue1 "></div>
                                </div>
                              </div>

                              <div className="row ">
                                <div className="col-md-12">
                                  <textarea onChange={handleForm} rows={10} className="form-control border-none" name="message" placeholder="Mention why you want to apply for this job.">
                                    {messagePayload.message}
                                  </textarea>
                                </div>
                                <div className="col-md-12">
                                  <div className="border-blue1 "></div>
                                  <div class="form-group m-1 ">
                                    <div class="input-group">
                                      <div class="input-group-addon me-2 mt-1 fs-15 ">
                                        Upload CV :
                                      </div>
                                      <input
                                        type="file"
                                        class="form-control  input_file"
                                        id="inputGroupFile02"
                                        name="attachment"
                                        hidden
                                        onChange={handleForm}
                                        accept="application/pdf,application/vnd.ms-excel"
                                      />
                                      <label
                                        class="mt-1 fs-14 text-blue"
                                        for="inputGroupFile02"
                                      >
                                        {messagePayload.attachment
                                          ? messagePayload.attachment.name
                                          : "Upload File"}
                                      </label>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="border-blue1 mt-2 mb-2"></div>
                              <div className="row">
                                <div className="col-md-12  gap-4 mb-4">
                                  <button
                                    type="button"
                                    class="btn btn-primary ps-5 pe-5 f-Poppins-Medium float-end me-4"
                                    onClick={handleSendMessage}
                                  >
                                    Send
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* sidebar */}
          <div className="col-md-3">
            <ProfileName />
            <ActionButtons />
            <Company />
          </div>
          {/* sidebar */}
        </div>
      </div>
    </>
  );
};
export default SendMsgToRecruiter;
