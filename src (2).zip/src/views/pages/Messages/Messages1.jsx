import React, { Component } from "react";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ReplyMessages from "../../../components/Messages/ReplyMessages";
import moment from "moment";
import { getAuthToken, getLoggedInUser } from "../../../classes/index";
import { notification } from "../../../classes/messages";
import {
  END_POINT,
  SEND_MESSAGE,
  GET_CHAT_USERS,
  GET_ALL_MESSAGES,
} from "../../../routes/api_routes";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";

class Messages1 extends Component {
  state = {
    showReplyMessage: false,
    message_body: "",
    attachmentFiles: null,
    message_title: "",
    chat_users: [],
    selected_chat: null,
    firstMessage: null,
    chatMessages: null,
  };

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.getAllCompaniesList();
  }

  async getAllCompaniesList() {
    const user = await getLoggedInUser();
    const token = await getAuthToken();

    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
      },
    };
    fetch(END_POINT + GET_CHAT_USERS + `/${user.id}`, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        console.log(data.data)
        if (data.status == "success") {
          if (data && data.data && data.data.length > 0) {
            this.setState(
              { chat_users: data.data, selected_chat: data.data[0] },
              () => {
                this.getAllMessages(user.id, this.state.selected_chat.user_id);
              }
            );
          }
        } else {
          let notify = notification({ message: data.message, type: "error" });
          notify();
        }
      })
      .catch((error) => console.log("error", error));
  }

  async getAllMessages(sender_id, receiver_id) {
    const token = await getAuthToken();
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
      },
    };
    
    fetch(
      END_POINT +
        GET_ALL_MESSAGES +
        `?data={"sender_id":${sender_id},"receiver_id":${receiver_id}}`,
      requestOptions
    )
      .then((response) => response.json())
      .then((data) => {
        if (data.status == "success") {
          console.log(data.data)
          var msgs = [...data.data].reverse();
          const [firstMessage, ...restMessages] = msgs;
          this.setState({
            chatMessages: restMessages,
            firstMessage,
            message_title: this.state.selected_chat.subject,
          });
        } else {
          let notify = notification({ message: data.message, type: "error" });
          notify();
        }
      })
      .catch((error) => console.log("error", error));
  }

  /* handle change */
  handleChange = async (e) => {
    if (e.target) {
      let ivalue = e.target.value;
      let iname = e.target.name;

      this.setState({ [iname]: ivalue });
    }
  };
  /* handle change */

  /* Add Attachment */
  addAttachment = async (e) => {
    this.setState({ attachmentFiles: e.target.files[0] });
    console.log(e.target.files[0]);
  };
  /* Add Attachment */

  /* Send Message */
  sendMessage = async (e) => {
    e.preventDefault();
    const token = await getAuthToken();
    const user = await getLoggedInUser();
    
    var formData = new FormData();
    

    formData.append("sender_id", user.id);
    formData.append(
      "receiver_id", "[" + this.state.selected_chat.user_id + "]" 
      );
      formData.append("subject", this.state.message_title);
      formData.append("message", this.state.message_body);
      formData.append("attachment", this.state.attachmentFiles);


      var requestOptions = {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ' + token
        }
      };

    fetch(END_POINT + SEND_MESSAGE, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.status == "success") {
          let notify = notification({
            message: "Message Send Successfully",
            type: "success",
          });
          this.setState({ attachmentFiles: null });
          notify();
          this.setState({ showReplyMessage: false }, () => {
            this.getAllMessages(user.id, this.state.selected_chat.user_id);
          });
        } else {
          let notify = notification({ message: data.message, type: "error" });
          notify();
        }
      })
      .catch((error) => console.log("error", error));
  };
  /* Send Message */

  async handleChatClick(selected_chat) {
    const user = await getLoggedInUser();
    this.setState({ selected_chat, attachmentFiles: null }, () => {
      this.getAllMessages(user.id, this.state.selected_chat.user_id);
    });
  }

  showChatCard = (chatData) => {
    console.log(chatData)
    const selected = this.state.selected_chat.user_id === chatData.user_id;
    return (
      <div
        onClick={this.handleChatClick.bind(this, chatData)}
        className={`row ms-1px me-1px mt-2  mb-2 pb-2 ${
          selected ? "bg-primary" : "bg-light-blue"
        } rounded-3 cursor-pointer`}
      >
        <div className="col-md-9 col-9 p-0 m-0">
          <header className="d-flex ">
            <div className=" ms-1 me-1 mt-2">
              <img
                src="/assets/imgs/dummy-logo.png"
                className="img-fluid box-shadow  h-40px"
              />
            </div>
            <div>
              <p
                className={`font-bold fs-14  mt-2 f-Poppins-Medium ${
                  selected ? "text-white" : ""
                }`}
              >
                {chatData.company_name}
              </p>
              <p className={`fs-12 ${selected ? "text-white" : ""}`}>
                {chatData.subject}
              </p>
            </div>
          </header>
        </div>
        <div className="col-md-3 col-3 p-0 m-0">
          <p className={`pt-4 ${selected ? "text-white" : ""} fs-12`}>
            {chatData?.created_at &&
              moment(chatData?.created_at).format("DD/MM/YYYY h:mm a")}
          </p>
        </div>
      </div>
    );
  };

  messageCard = (messageData) => {
    return (
      <>
        <div className="row pb-1 bg-white mt-3">
          <div className="col-md-12 col-12">
            <header className="d-flex ">
              <div className="me-3 mt-2">
                <img
                  src={
                    messageData?.logo
                      ? `${messageData?.logo}`
                      : "/assets/imgs/dummy-logo.png"
                  }
                  className="img-fluid box-shadow br-5 h-60p"
                />
              </div>
              <div>
                <h6 className="font-bold mb-1px mt-2 f-Poppins-Medium">
                  {messageData?.receiver_name}
                </h6>
                <p className=" f-Poppins-Regular f-0-8">
                  {messageData?.created_at &&
                    moment(messageData.created_at).format("DD/MM/YYYY h:mm a")}
                </p>
                {/* <p className="f-Poppins-Regular f-0-8">To:Rahul gupta</p> */}
              </div>
            </header>
            <div className="row ">
              <div className="col-md-12">
                <p className="mt-3 mb-3 fw-bold f-Poppins-Light">
                  Subject: {messageData?.subject}
                </p>
                <p className=" f-Poppins-Regular">{messageData?.message}</p>
                {messageData?.attachment && (
                  <div
                    className="mt-4 mb-3"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <a
                      className="bg-light-blue p-1 rounded-3"
                      download="attachment"
                      href={`${messageData?.attachment}`}
                    >
                      Download Attachment
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };

  showMessage = (messageData) => {
    return (
      <>
        <div className="row bg-white mt-2">
          <div className="col-md-12">
            {this.messageCard(messageData)}
            <div className="border-blue1 mt-2 mb-2"></div>
            <div className="row">
              <div className="col-md-6"></div>
              <div className="col-md-6 d-flex gap-4 mb-4">
                {this.state.showReplyMessage === false ? (
                  <button
                    type="button"
                    class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium "
                    onClick={() =>
                      this.setState({
                        showReplyMessage: true,
                      })
                    }
                  >
                    Reply
                  </button>
                ) : (
                  <button
                    type="button"
                    class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium "
                    onClick={() =>
                      this.setState({
                        showReplyMessage: false,
                      })
                    }
                  >
                    Cancel
                  </button>
                )}
                <button
                  type="button"
                  class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium"
                >
                  Forward
                </button>
              </div>
            </div>
          </div>
        </div>

        {this.state.showReplyMessage == true && (
          <ReplyMessages
            handleChange={this.handleChange}
            addAttachment={this.addAttachment}
            sendMessage={this.sendMessage}
            attachedFile={this.state.attachmentFiles}
          />
        )}
      </>
    );
  };

  showChatMessages = (chatMessages) => {
    return (
      <>
        {chatMessages &&
          chatMessages.length > 0 &&
          chatMessages.map((messageData) => this.messageCard(messageData))}
      </>
    );
  };

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-9 p-0 m-0">
            <div className="">
              <div className="">
                {/* <div className="row bg-white  mb-5">
                  <div className="col-md-12">
                    <div className="">
                      <div className="row ">
                        <div className="col-md-12 col-12 pt-2 pb-2">
                          <h4 className="text-primary float-start fs-20  ms-1 p-0">
                            Meassage
                          </h4>
                          <button
                            type="button"
                            class="btn btn-primary ps-1  float-end  "
                          >
                            New Messages
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> */}
                <div className="row mt-2">
                  <div className="col-md-4 bg-white mb-4">
                    <div className=" row">
                      <div className="col-md-12 pt-2 ">
                        <h5 className="text-primary float-start ">Messages</h5>
                        <i class="las la-ellipsis-v text-primary float-end h4"></i>
                      </div>
                    </div>
                    <div className="border-blue1 mt-2 "></div>
                    <div className="scrollbar w-100 force-overflow  bg-white">
                      {this.state.chat_users.length > 0 ? (
                        this.state.chat_users.map((chatData) => {
                          return this.showChatCard(chatData);
                        })
                      ) : (
                        <div className="f-poppins mt-4 mb-4">No messages</div>
                      )}
                    </div>
                  </div>

                  <div className="col-md-8   col-12  d-full">
                    <div className="row">
                      <div className="col-md-12 col-12">
                        <div className="container   col-12">
                          <div className="row   ">
                            <div className="col-md-12  blue-box-shadow  bg-white p-1 ">
                              <div class="search-box d-flex ">
                                <button class="search-button border-none bg-transparent ">
                                  {/* <i class="fas fa-search bg-white pe-2"></i> */}
                                  <i class="fas fa-search border-none "></i>
                                </button>
                                <input
                                  type="text"
                                  class="form-control border-none w-90 border-0 ps-2 search-input"
                                  placeholder="Search mail"
                                  aria-label="Username"
                                  aria-describedby="basic-addon1"
                                />
                                {/* <input type="text" className='w-90 border-0 ps-2 search-input ' placeholder="Search mail"/> */}
                              </div>
                            </div>
                          </div>
                          {/* reply message here */}
                          {this.state.firstMessage &&
                            this.showMessage(this.state.firstMessage)}

                          {this.showChatMessages(this.state.chatMessages)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/*
            <div className="col-md-7  col-12">
               <h3 className="text-primary mt-3 mb-2 f-Poppins-Medium ms-4 ">Total Candidates</h3>
            </div>
            */}
              </div>
            </div>
            {/* submit button */}
            {/* form ends here */}
          </div>
          {/* sidebar */}
          <div className="col-md-3">
            <ProfileName />
            <ActionButtons />
            <Company />
          </div>
          {/* sidebar */}
        </div>
      </div>
    );
  }
}
export default Messages1;