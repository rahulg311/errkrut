import React from "react";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import ListModal from "../../../components/Messages/ListModal";
import { useHistory, useLocation } from "react-router";
import { useState } from "react";
import { useEffect } from "react";
import { SEND_MESSAGE } from "../../../routes/api_routes";
import usePost from "../../../hooks/usePost";
import { getLoggedInUser, getAuthToken, isCampus } from "../../../classes";

const CompanyMessage = () => {
  const [companyList, setCompanyList] = useState([]);
  const location = useLocation();
  
  const sendMessageAPI = usePost();
  const [messagePayload, setMessagePayload] = useState({
    subject: "Company Invite",
    message: `Hello,
    Online Grammar and Writing Checker To Help You Deliver Impeccable, Mistake-free Writing. Grammarly Has a Tool For Just About Every Kind Of Writing You Do. Try It Out For Yourself!
    
    Student CVs:20
    Recruit Co Ordinator :Deo Johnson
    
    Regards,
    Bill joe`,
    attachment: null,
    students: [],
    coordinator: [],
  });
  const history = useHistory();

  useEffect(() => {
    if (
      location.state?.companyData &&
      Object.keys(location.state.companyData)
    ) {
      setCompanyList(location.state.companyData);
    }
  }, [location]);

  useEffect(() => {
    if(sendMessageAPI.response && sendMessageAPI.response.status == 'success') {
       console.log("aaya")
       history.push("/company-messages");
    }
  },[sendMessageAPI?.response])

  const handleForm = (e) => {
    if (e.target) {
      let ivalue = e.target.value;
      let iname = e.target.name;
      let ftype = e.target.type;

      if (ftype == "file") {
        if (e.target.files.length > 0) {
          ivalue = e.target.files[0];
        }
      }
      setMessagePayload({
        ...messagePayload,
        [iname]: ivalue,
      });
    }
  };

  const handleSendMessage = async () => {
    const user = await getLoggedInUser();
    let formData = new FormData();
    let token = await getAuthToken();

    console.log(user)

    formData.append("subject", messagePayload.subject);
    formData.append("message", messagePayload.message);
    formData.append("attachment", messagePayload.attachment);
    
    formData.append("sender_id", user.id);
    formData.append(
      "receiver_id",
      JSON.stringify(companyList.map((data) => data.id))
    );

    const requestOptions = {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
      },
    };

    sendMessageAPI.doPost(`${SEND_MESSAGE}`, formData, requestOptions);
  };

  const calculateMoreString = (arr) => {
    let str = "";
    if (arr.length <= 2) {
      return arr.join(", ");
    }
    for (let i = 0; i <= 1; i++) {
      str = str + arr[i] + ", ";
    }
    str = str + `+ ${arr.length - 2} More`;
    return str;
  };

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-9 p-0 m-0">
            <div className="">
              <div className="">
                {/* <div className="row bg-white  mb-5">
                  <div className="col-md-12">
                    <div className="">
                      <div className="row mt-2 mb-2">
                        <div className="col-md-12 col-12">
                          <h4 className="text-primary float-start mt-1 ms-1 p-0">
                            Meassage
                          </h4>
                          <button
                            type="button"
                            class="btn btn-primary ps-1  float-end f-1"
                          >
                            New Messages
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> */}
                <div className="row mt-2   ">
                  <div className="col-md-4 bg-white mb-4 ">
                    <div className=" row">
                      <div className="col-md-12 pt-2 ">
                        <h5 className="text-primary float-start ">Messages</h5>
                        <i class="las la-ellipsis-v text-primary float-end h4"></i>
                      </div>
                    </div>
                    <div className="border-blue1 mt-2 "></div>
                    <div className="scrollbar w-100 force-overflow  bg-white"></div>
                  </div>

                  <div className="col-md-8   col-12  d-full">
                    <div className="row">
                      <div className="col-md-12 col-12">
                        <div className="container   col-12">
                          <div className="row   ">
                            <div className="col-md-12  blue-box-shadow  bg-white p-1 ">
                              <div class="search-box d-flex ">
                                <button class="search-button border-none bg-transparent ">
                                  {/* <i class="fas fa-search bg-white pe-2"></i> */}
                                  <i class="fas fa-search border-none "></i>
                                </button>
                                <input
                                  type="text"
                                  class="form-control border-none w-90 border-0 ps-2 search-input"
                                  placeholder="Search mail"
                                  aria-label="Username"
                                  aria-describedby="basic-addon1"
                                />
                                {/* <input type="text" className='w-90 border-0 ps-2 search-input ' placeholder="Search mail"/> */}
                              </div>
                            </div>
                          </div>

                          <div className="row bg-white mt-2">
                            <div className="container">
                              <div className="row">
                                <div className="col-md-12">
                                  <div class="form-group m-1 ">
                                    <div class="input-group">
                                      <div class="input-group-addon me-2 mt-1 fs-5">
                                        To:
                                      </div>
                                      <input
                                        className="form-control border-none"
                                        id="text"
                                        name="company_emails"
                                        type="text"
                                        // disabled
                                        value={
                                          (companyList &&
                                          companyList.length > 0) ?
                                          companyList
                                            .map(
                                              (company) => company.campus_name
                                            )
                                            .join(", ")
                                            : ''
                                        }
                                      />
                                    </div>
                                  </div>
                                  <div className="border-blue1  "></div>
                                </div>
                                {/*<div className="col-md-12">
                                  <div class="form-group m-1 ">
                                    <div class="input-group">
                                      <div class="input-group-addon me-2 mt-1 fs-5">
                                        Cc:
                                      </div>
                                      <input
                                        className="form-control border-none"
                                        id="text"
                                        name="cc_email"
                                        type="text"
                                        disabled
                                        value=""
                                      />
                                    </div>
                                  </div>
                                  <div className="border-blue1 "></div>
                                </div>*/}
                                <div className="col-md-12">
                                  <div class="form-group m-1 ">
                                    <h6 className="mt-4 mb-3  f-Poppins-Light">
                                      Subject : Company invite
                                    </h6>
                                  </div>
                                  <div className="border-blue1 "></div>
                                </div>
                              </div>

                              <div className="row ">
                                <div className="col-md-12">
                                  <p className=" f-Poppins-Regular m-2">
                                    Hello, <br />
                                    Online Grammar and Writing Checker To Help
                                    You Deliver Impeccable, Mistake-free
                                    Writing. Grammarly Has a Tool For Just About
                                    Every Kind Of Writing You Do. Try It Out For
                                    Yourself!
                                    <br />
                                  </p>
                                  <p className="mt-4 f-Poppins-Regular  m-2">
                                    Recruit Co Ordinator :Deo Johnson{" "}
                                  </p>
                                  <p className="mt-4 f-Poppins-Regular  m-2">
                                    Regards, <br />
                                    Bill joe
                                  </p>
                                </div>

                                <div className="col-md-12">
                                 <div className="border-blue1 mt-2 mb-2"></div>
                                  <div class="form-group m-1 ">
                                    <div class="input-group">
                                      <div class="input-group-addon me-2 mt-1 fs-15 ">
                                        Attach File :
                                      </div>
                                      <input
                                        type="file"
                                        class="form-control  input_file"
                                        id="inputGroupFile02"
                                        name="attachment"
                                        hidden
                                        onChange={handleForm}
                                        accept="application/pdf,application/vnd.ms-excel"
                                      />
                                      <label
                                        class="mt-1 fs-14 text-blue"
                                        for="inputGroupFile02"
                                      >
                                        {messagePayload.attachment
                                          ? messagePayload.attachment.name
                                          : "Upload File"}
                                      </label>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="border-blue1 mt-2 mb-2"></div>
                              <div className="row">
                                <div className="col-md-12  gap-4 mb-4">
                                  <button
                                    type="button"
                                    class="btn btn-primary ps-5 pe-5 f-Poppins-Medium float-end me-4"
                                    onClick={handleSendMessage}
                                  >
                                    Send
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* sidebar */}
          <div className="col-md-3">
            <ProfileName />
            <ActionButtons />
            <Company />
          </div>
          {/* sidebar */}
        </div>
      </div>
    </>
  );
};
export default CompanyMessage;
