import React, { Component } from 'react';
import { getPlansAction } from '../../../store/actions/Plans';
import IntroSideBar from '../../../components/SelectPlan/introSide';
import PlanCard from '../../../components/SelectPlan/PlanCard';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes';
import { Campus_User_Type_ID } from '../../../config/constants';

class SelectPlan extends Component {
	state = { plans: [], plan_id: null, user: [], cplan: true };
	constructor(props) {
		super(props);
	}
	render() {
		return (
			<div className='container pe-lg-7 px-lg-0 px-md-8 px-sm-5 px-3 mt-35px'>
				<div className='row'>
					{/* <div className='col-lg-4'>
						<div className>
							<IntroSideBar></IntroSideBar>
						</div>
					</div> */}
					<div className='col-lg-12'>
						<header className='d-flex justify-content-between mb-4'>
							<h4 className=' f-r-17'>Please Select Your Plan</h4>
							{/* {this.state.plan_id != null && */}
							{(this.state.plan_id != null && this.state.cplan) &&
								<Link className='h4 f-r-12' to={`/expand-campus-plan/${this.state?.plan_id}/${btoa(1)}`} >
									Expand Pack
								</Link>
							}
							{/* } */}
						</header>
						<div className='row pb-5'>
							{this.state.plans.length > 0 &&
								this.state.plans.map((plan, i) => {
									const cardName =
										plan.name === 'Amateur'
											? 'amateur-plan-card'
											: plan.name == 'Pro'
												? 'pro-plan-card'
												: 'enterprise-plan-card';
									if (plan.name === 'Amateur' && this.state.plan_id != null && this.state.plan_id == plan.id && this.state.cplan) {
										this.setState({
											cplan: false,
										});
									}
									return <PlanCard key={i} cardName={cardName} plan={plan} />;
								})}
						</div>
					</div>
				</div>
			</div>
		);
	}
	async componentDidMount() {
		await this.props.getplans();
		this.props?.data?.data && this.setState({ plans: this.props?.data?.data });
		const user = await getLoggedInUser();
		console.log('USER LIST');
		console.log(user);
		if (user) {
			this.state.user = user;
			if (user.user_type !== Campus_User_Type_ID) {
				this.props.history.push('/');
			}
			this.setState({
				plan_id: 9
			})
		}

	}
}
const mapStateToProps = (state) => {
	const { data } = state.common;
	return { data };
};
const mapDispatchToProps = (dispatch) => {
	return { getplans: () => dispatch(getPlansAction()) };
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectPlan);
