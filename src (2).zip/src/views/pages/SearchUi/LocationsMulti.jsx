import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getLocations } from '../../../store/actions/locations';

const LocationsMulti = (props) => {
    const [search, setSearch] = useState('');
    const [filterItems, setFilterItems] = useState([]);
    const [items, setItems] = useState([]);

    const dispatch = useDispatch();

    const { location_res } = useSelector((state) => state.common);

    useEffect(() => {
        dispatch(getLocations());
    }, []);

    useEffect(() => {
        console.log(location_res)
        if (location_res?.data) {
            let locations = Object.keys(location_res?.data).map((v) => {
                return location_res?.data[v];
            });
            setItems(locations);
        }

    }, [location_res]);

    const [selectedItems, setSelectedItems] = useState([]);

    const handleRemoveSelectedItem = (value) => {
        const filterItems = [...selectedItems].filter((e) => e !== value);
        setSelectedItems(filterItems);
    };

    const setItemsHandleChange = (item) => {
        setSelectedItems([...selectedItems, item]);
    }

    useEffect(() => {
        if (selectedItems)
            props.handleChange({ target: { name: 'location', value: selectedItems } });
    }, [selectedItems]);


    React.useEffect(() => {
        console.log(items);
        const newArray = [...items].filter((item) => item.toLowerCase().includes(search.toLowerCase()));
        setFilterItems([...new Set(newArray)]);
    }, [search]);

    return (
        <div className='position-relative'>
            <div className='position-relative'>
                <input
                    placeholder='Locations'
                    className='form-control form-control-sm text-blue placeholder-blue'
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                {search && (
                    <button
                        type='button'
                        class='btn-close translate-right-middle btn-xs'
                        style={{ right: '10px' }}
                        onClick={() => setSearch('')}
                        aria-label='Close'
                    ></button>
                )}
            </div>
            <main className='w-100'>
                {search && filterItems.length >= 1
                    ? filterItems.map((item, i) => (
                        <div className='list-group position-absolute w-100'>
                            <li className='list-group-item list-group-item-action w-100 pt-0 pb-0'>
                                <div class='form-check'>
                                    <input
                                        class='form-check-input'
                                        type='checkbox'
                                        checked={selectedItems.includes(item)}
                                        value={item}
                                        id={i}
                                        onChange={(e) => {
                                            e.target.checked
                                                ? setItemsHandleChange(item)
                                                : handleRemoveSelectedItem(e.target.value);
                                        }}
                                    />
                                    <label class='form-check-label h-100 w-100 f-0-8' for={i}>
                                        {item}
                                    </label>
                                </div>
                            </li>
                        </div>
                    ))
                    : search && (
                        /* <button
                            className='btn bg-secondary bg-opacity-10 mt-1 fs-13'
                            onClick={() => handleAddSelectedItem(search)}
                        >
                            create a new tag
                        </button> */
                        <p>
                            No Locations Found
                        </p>
                    )}
            </main>
        </div >
    );
};

export default LocationsMulti;
