import React, { Component } from 'react';
import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
class StartQuize2 extends Component {
render() {
return (
<div className='main-container position-relative  '>
   <Header />
   <div className='content-wrapper  '>
      <div className="container  shadow p-4 ">
         <div className='row mt-4  mb-2 '>
            {/* Content */}
            <div className='col-md-9 '>
               <div className="container p-4  bg-white  ">

                   {/* testimonials */}
                   <div class="scrollmenu">
                   <a className="f-Poppins-Medium f-1-1  ms-2 me-2 " href=""> Jobs</a>
                   <a className="f-Poppins-Medium f-1-1  ms-2   me-2" href=""> Quiz</a>
                   <a className="f-Poppins-Medium f-1-1  ms-2  me-2 " href=""> Questions</a>
                   <a className="f-Poppins-Medium f-1-1  ms-5  me-2 " href=""> Testimonials</a>
                   <a className="f-Poppins-Medium f-1-1  ms-5  me-2" href=""> Offer Letter</a>
  
</div>

                <div className="border-gray-line "></div>
                  <div className="container shadow p-4 mt-4" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-2">
                     <div className="col-md-11 col-10  mt-1 mb-2">
                        <header className='d-flex'>
                           <div className='me-3'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow br-5 h-60p'
                                 />
                           </div>
                           <div>
                              <h5 className='font-bold f-Poppins-Medium'>SamDoe</h5>
                              <p className="mt-1 f-Poppins-Medium">Company Name</p>
                            
                           </div>
                        </header>
                     </div>
                     <div className="col-md-1 col-2 mt-2" >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-4" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-2">
                     <div className="col-md-11 col-10  mt-1 mb-2">
                        <header className='d-flex'>
                           <div className='me-3'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow br-5 h-60p'
                                 />
                           </div>
                           <div>
                              <h5 className='font-bold f-Poppins-Medium'>SamDoe</h5>
                              <p className="mt-1 f-Poppins-Medium">Company Name</p>
                            
                           </div>
                        </header>
                     </div>
                     <div className="col-md-1 col-2 mt-2" >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-4" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-2">
                     <div className="col-md-11 col-10  mt-1 mb-2">
                        <header className='d-flex'>
                           <div className='me-3'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow br-5 h-60p'
                                 />
                           </div>
                           <div>
                              <h5 className='font-bold f-Poppins-Medium'>SamDoe</h5>
                              <p className="mt-1 f-Poppins-Medium">Company Name</p>
                            
                           </div>
                        </header>
                     </div>
                     <div className="col-md-1 col-2 mt-2" >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-4" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-2">
                     <div className="col-md-11 col-10  mt-1 mb-2">
                        <header className='d-flex'>
                           <div className='me-3'>
                              <img
                                 src='/assets/imgs/dummy-logo.png'
                                 className='img-fluid box-shadow br-5 h-60p'
                                 />
                           </div>
                           <div>
                              <h5 className='font-bold f-Poppins-Medium'>SamDoe</h5>
                              <p className="mt-1 f-Poppins-Medium">Company Name</p>
                            
                           </div>
                        </header>
                     </div>
                     <div className="col-md-1 col-2 mt-2" >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>

                  {/* offer letar*/}

                  <div class="scrollmenu">
                   <a className="f-Poppins-Medium f-1-1  ms-2 me-2 " href=""> Jobs</a>
                   <a className="f-Poppins-Medium f-1-1  ms-2   me-2" href=""> Quiz</a>
                   <a className="f-Poppins-Medium f-1-1  ms-2  me-2 " href=""> Questions</a>
                   <a className="f-Poppins-Medium f-1-1  ms-5  me-2 " href=""> Testimonials</a>
                   <a className="f-Poppins-Medium f-1-1  ms-5  me-2" href=""> Offer Letter</a>
  
</div>

                <div className="border-gray-line "></div>
                  <div className="container shadow p-4 mt-2" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-1">
                     <div className="col-md-11 col-10  mt-1 mb-1">
                    <h5 className="f-Poppins-Medium"> Job Offer Title</h5>
                     </div>
                     <div className="col-md-1 col-2 " >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                          <p class=" float-start ">25/11/2021</p>
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-2" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-1">
                     <div className="col-md-11 col-10  mt-1 mb-1">
                    <h5 className="f-Poppins-Medium"> Job Offer Title</h5>
                     </div>
                     <div className="col-md-1 col-2 " >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                          <p class=" float-start ">25/11/2021</p>
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-2" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-1">
                     <div className="col-md-11 col-10  mt-1 mb-1">
                    <h5 className="f-Poppins-Medium"> Job Offer Title</h5>
                     </div>
                     <div className="col-md-1 col-2 " >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                          <p class=" float-start ">25/11/2021</p>
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                  <div className="container shadow p-4 mt-2" >
                      <div className="row">
                          <div className="col-md-12">
                          <div className="row   mt-1  mb-1">
                     <div className="col-md-11 col-10  mt-1 mb-1">
                    <h5 className="f-Poppins-Medium"> Job Offer Title</h5>
                     </div>
                     <div className="col-md-1 col-2 " >
                        <h1><i class="lar la-trash-alt text-danger"></i></h1>
                     </div>
                  </div>                     </div>
                       <p className="f-Poppins-Regular">Lorem ipsum do lorsit et,con sectetue radipisci ngelit,seddiam nonummyn ibheuism dtinci duntut lao reetd olorem agnaali quamer atvolut pat.Utwis ienimad minimv eniam,q uisnostr udexercit ationullamc orpersus cipitl obortisnisl utaliquip exeaco mmodocon equat.Dui sautemvele miriuredo lorinhendr erit nvulput tevelit essem oles tie</p>
                      
                      <div className="mt-2 mb-1 ">
                          <p class=" float-start ">25/11/2021</p>
                  <button type="button" class="btn btn-primary float-end ps-5 pe-5">Edit</button>
                  </div>
                  </div>
                  </div>
                 

             


               </div>
             









             



            
            </div>
            {/* Content */}
            {/* Sidebar */}
            <div className='col-md-3 pt-2 pb-2 '>
               <div className="container ">
                  {/* Profile Name */}
                  <ProfileName />
                  {/* Profile Name */}
                  {/* AddButtons */}
                  <ActionButtons />
                  {/* AddButtons */}
                  <div className='row'>
                     <div className='col-md-12 p-0'>
                        <h6>
                           <p class='font-bold m-0'>Want to reach out to more Candidates?</p>
                           <a href=''>
                           <span class='font-bold mr-2'>Click here</span>
                           </a>
                        </h6>
                     </div>
                  </div>
                  {/* Contact */}
                  <Company></Company>
                  {/* Contact */}
               </div>
               {/* Sidebar */}
            </div>
         </div>
      </div>
   </div>
</div>
);
}
}
export default StartQuize2;