import React, { useState } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { Link, NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import { getLoggedInUser, getAuthToken } from '../../../classes';
import { notification } from '../../../classes/messages';
import { END_POINT, DELETE_BILLING } from '../../../routes/api_routes';

const CandidateAccount = () => {
    const [data, setData] = useState({});
    const [addresses, setAddresses] = useState();

    const deleteaddress = async (id) => {
        let user = await getLoggedInUser();
        let token = await getAuthToken();
        var formdata = new FormData();
        formdata.append('user_id', user.id);
        formdata.append('id', id);
        const response = await fetch(END_POINT + DELETE_BILLING, {
            method: 'POST',
            body: formdata,
            headers: { 'Authorization': 'Bearer ' + token },
        });
        const json = await response.json();
        if (json?.status == 'success') {
            let notify = notification({ type: 'success', message: "Address Deleted Successfully" });
            notify();
            getaddress();
        }
    }
    const getaddress = async (id) => {
        const user = await getLoggedInUser();
        var requestOptions = {
            method: 'GET',
            //body: formdata,
            redirect: 'follow',
        };
        fetch(END_POINT + 'get_account/' + user.id, requestOptions)
            .then((response) => response.json())
            .then((result) => {
                console.log(result);
                setData(result.data);
                let addresses = result.data.billing_address.map((row, index) => {
                    return (
                        <div className='col-5 border-blue1 rounded-4'>
                            <div className='row'>
                                <div className='d-flex mb-2 justify-content-between align-items-center'>
                                    <h5 className='d-flex justify-content-between'>Address {index + 1}</h5>
                                    <div>
                                        <Link to={'/account-billing/' + row.id} className={`btn btn-sm text-dark`}>
                                            <i class='far float-end la-edit h6 text-primary'></i>
                                        </Link>
                                        <button className='btn  btn-sm' onClick={() => { deleteaddress(row.id) }}>
                                            <i class='far float-end la-trash h6 text-danger' ></i>
                                        </button>
                                    </div>


                                </div>
                                <div className='col-12 mt-3'>
                                    <p><span className='fw-bold fs-'>Candidate Name :</span> <span>{row.name}</span></p>
                                </div>
                            </div>
                            <div className='row mt-2 mb-4 '>
                                <div className='col-3 m-0 p-0 ps-2'>
                                    <p className='fw-bold'>  Address :</p>
                                </div>
                                <div className='col-9 '>
                                    <p>{row.address_line1 + ' ' + row.address_line2}</p>
                                    <p>{row.state + ', ' + row.country + '-' + row.zip}</p>
                                </div>
                            </div>
                        </div>
                    )
                })

                setAddresses(addresses);
            })
            .catch((error) => console.log('error', error));
    }
    React.useEffect(async () => {
        getaddress();
    }, [])

    return (
        <div className="container">
            <div className="row">
                <div className="col-md-9 p-0">
                    <div className="p-1  ">
                        <div className=" ">

                            {/* submit button */}
                            {/* start Edit hr profile  */}
                            <div className=" row  mt-2   ">
                                <div className='container'>
                                    <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
                                        <div className='container'>
                                            <div className='row'>
                                                <div className='col-md-12'>
                                                    <p className='fw-bold fs-22 float-start'>Current Plan: {data.current_plan?.name}</p>
                                                    <button type="button" class="btn btn-primary ps-5 float-end pe-5 rounded-0"><NavLink to="/plans"><span className='text-white'>Upgrade Plan</span></NavLink></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                                        <div className='container'>
                                            <div className='row'>
                                                <div className='col-md-12'>
                                                    <p className='fw-bold fs-22 float-start'>Invoice Details</p>
                                                </div>
                                                <div className='container'>
                                                    <div className='row mt-3 bg-light-blue pt-3 pb-3 '>
                                                        <div className='col-md-12 d-flex justify-content-between'>
                                                            <p className='fw-bold fs-20'>Plan: {data.current_plan?.name}</p>
                                                            <p>{data.current_plan?.created_at.split('T')[0]}</p>
                                                            <button type="button" class="btn btn-primary rounded-0 ">Download Invoice</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                                        <div className='container'>
                                            <div className='row'>
                                                <div className='col-md-12'>
                                                    <p className='fw-bold fs-22 float-start'>Billing Details</p>
                                                </div>
                                                <div className='comntainer'>
                                                    <div className='row gap-2 mt-2'>
                                                        {addresses}
                                                    </div>
                                                </div>
                                                <div className='new2 mt-3 mb-3'></div>
                                                <div className='row'>
                                                    <div className='col-12'>
                                                        <div className='col-12'>
                                                            <Link to={'/account-billing'} >
                                                                <p className='fw-bold fs-20 text-primary'>Add New Address +</p>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* sidebar */}
                <div className="col-md-3">
                    <ProfileName />
                    <ActionButtons />
                    <Company />
                </div>
                {/* sidebar */}
            </div>
        </div>
    );

}
export default CandidateAccount;