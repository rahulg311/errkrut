import React, { Component } from 'react';
import { getLoggedInUser, getAuthToken, getValueFromArr } from '../../../classes';
import { END_POINT, GET_ASSESSMENT_DETAILS } from '../../../routes/api_routes';
import { NavLink } from 'react-router-dom';
import { notification } from '../../../classes/messages';
import ConfirmationModal from '../../../components/CadidateAppliedJobs/ConfirmationModal';
import Parser from 'react-html-parser'

class AssessmentRound extends Component {
    state = {
        url: this.props.match.params.id,
        assessdata: null,
        secSection: false,
        start_test: false,
        confirmationModalData: {
            title: 'Ready to Start the Quiz!',
            message: 'Once the Quiz starts you cannot go back or lese the progress will be lost want to start the quiz?',
            link: '',
            button: 'Start Assessment'
        },
    };

    showStartTest = (linkdata) => {
        this.setState({
            start_test: true,
            confirmationModalData: { ...this.state.confirmationModalData, link: linkdata }
        });
    }
    hideStartTest = () => {
        this.setState({
            start_test: false,
        });
    }
    getAssessmentData = async () => {
        let token = await getAuthToken();
        let response = await fetch(END_POINT + GET_ASSESSMENT_DETAILS + '/' + this.state.url, {
            headers: { 'Authorization': 'Bearer ' + token },
        })
        const json = await response.json();
        if (json.status == 'success') {
            localStorage.setItem('quiz_' + json.data.quiz_id, JSON.stringify(json.data));
            this.setState({
                assessdata: json.data
            });

            let job = {
                job_title: this.state.assessdata?.quiz_title,
                company_name: this.state.assessdata?.company_name,
                user_id: this.state.assessdata?.user_id,
                logo: (this.state.assessdata?.company_logo) ? getValueFromArr(this.state.assessdata?.company_logo, 0) : `/assets/imgs/dummy-logo.png`
            }
            localStorage.setItem('quiz_job_' + json.data.quiz_id, JSON.stringify(job));
        }
        else {
            let notify = notification({ type: 'error', message: json.message });
            notify();
            this.props.history.push('/');
        }
    }
    componentWillMount = async () => {
        this.getAssessmentData();
    }

    render() {

        return (
            <>
                <ConfirmationModal closeModal={() => this.hideStartTest()} status={this.state} mdata={this.state.confirmationModalData} />
                <div className="container">
                    <div className="row">
                        <div className="col-md-9 p-0">
                            <div className='bg-white text-center ps-4 pt-2'>
                                <img src={(this.state.assessdata?.company_logo) ? getValueFromArr(this.state.assessdata?.company_logo, 0) : `/assets/imgs/dummy-logo.png`} class="img-fluid shadow br-5 h-60p" />
                            </div>
                            {
                                (!this.state.secSection &&
                                    <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                                        <div className="col-md-12">
                                            <>
                                                {/* title starts here */}
                                                <div>
                                                    <h4>Assessment Round</h4>
                                                    <p>Complete the test to advance the next round</p>
                                                </div>

                                                <div className="mt-3 mb-3">
                                                    <h6 className="text-primary">Assessment Title</h6>
                                                    <p>{this.state.assessdata?.quiz_title}</p>
                                                </div>

                                                <div>
                                                    <h6 className="text-primary">Assessment Instructions</h6>
                                                    <p>{Parser(this.state.assessdata?.quiz_instructions)}</p>
                                                </div>
                                                {/* title ends here */}

                                                {/* row starts here */}
                                                {/* <div className="row mt-5 mb-5"> */}
                                                <div className="row mt-5 mb-5">
                                                    <div className="col-md-3 text-center">
                                                        <img src="/assets/imgs/clock.png" className="img-fluid ms-auto me-auto" />
                                                        <p className="font-bold mt-1 mb-1">
                                                            {this.state.assessdata?.quiz_duration} Min
                                                        </p>
                                                    </div>
                                                    <div className="col-md-3 text-center">
                                                        <img src="/assets/imgs/section.png" className="img-fluid ms-auto me-auto" />
                                                        <p className="font-bold mt-1 mb-1">
                                                            {this.state.assessdata?.total_section} Sections
                                                        </p>
                                                    </div>
                                                    <div className="col-md-3 text-center">
                                                        <img src="/assets/imgs/question.png" className="img-fluid ms-auto me-auto" />
                                                        <p className="font-bold mt-1 mb-1">
                                                            {this.state.assessdata?.total_question} Questions
                                                        </p>
                                                    </div>
                                                    {this.state.assessdata?.total_points != null &&
                                                        <div className="col-md-3 text-center">
                                                            <img src="/assets/imgs/points.png" className="img-fluid ms-auto me-auto" />
                                                            <p className="font-bold mt-1 mb-1">
                                                                {this.state.assessdata?.total_points} Points
                                                            </p>
                                                        </div>
                                                    }
                                                </div>
                                                {/* row ends here */}

                                                {/* row starts here */}
                                                <header class="d-flex">
                                                    <div class="me-3">
                                                        <img src={(this.state.assessdata?.company_logo) ? getValueFromArr(this.state.assessdata?.company_logo, 0) : `/assets/imgs/dummy-logo.png`} class="img-fluid shadow br-5 h-60p" />
                                                    </div>
                                                    <div>
                                                        <h4 class="font-bold f-Poppins-Medium">{this.state.assessdata?.quiz_title}</h4>
                                                        <p class="f-Poppins-Regular f-1-1">{this.state.assessdata?.company_name}</p>
                                                    </div>


                                                    <div className="ms-auto mt-auto mb-auto">
                                                        {/* <a onClick={() => this.showStartTest(`/start-quiz/${this.state.assessdata?.id}/${this.state.assessdata?.quiz_id}`)} className='btn btn-primary btn-sm text-light px-4'>Start the Test</a> */}
                                                        {/* <NavLink class="btn btn-primary btn-sm text-light px-4" to={`/start-quiz/${this.state.assessdata?.id}/${this.state.assessdata?.quiz_id}`}>Continue to Quiz</NavLink> */}
                                                        <button onClick={() => this.setState({ secSection: true })} class="btn btn-primary btn-sm text-light px-4" >Continue</button>
                                                    </div>

                                                </header>
                                                {/* row ends here */}

                                            </>

                                        </div>

                                    </div>
                                )
                            }

                            {
                                (this.state.secSection &&
                                    <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                                        <div className="col-md-12">

                                            <>
                                                {/* title starts here */}
                                                <div>
                                                    <h4>Assessment Title</h4>
                                                    <p>{this.state.assessdata?.quiz_title}</p>
                                                </div>


                                                {/* title ends here */}

                                                {/* row starts here */}
                                                {/* <div className="row mt-5 mb-5"> */}
                                                <div className="row mt-5 mb-5">
                                                    {this.state.assessdata?.all_sections.map((val) => {
                                                        return <>
                                                            <div className="col-md-3 ">
                                                                <div className='border-blue p-1'>
                                                                    <h5 class="text-primary">{val.section_name}</h5>
                                                                    <p className="font-bold mt-1 mb-1">
                                                                        Total Questions : {val.total_questions}
                                                                    </p>
                                                                    <h5>{val.points} Points</h5>
                                                                </div>
                                                            </div></>;
                                                    })}

                                                </div>
                                                {/* row ends here */}

                                                {/* row starts here */}
                                                <header class="d-flex">
                                                    <div class="me-3">
                                                        <img src={(this.state.assessdata?.company_logo) ? getValueFromArr(this.state.assessdata?.company_logo, 0) : `/assets/imgs/dummy-logo.png`} class="img-fluid shadow br-5 h-60p" />
                                                    </div>
                                                    <div>
                                                        <h4 class="font-bold f-Poppins-Medium">{this.state.assessdata?.quiz_title}</h4>
                                                        <p class="f-Poppins-Regular f-1-1">{this.state.assessdata?.company_name}</p>
                                                    </div>

                                                    <div className="ms-auto mt-auto mb-auto">
                                                        <button onClick={() => this.setState({ secSection: false })} class="btn btn-primary btn-sm text-light px-4" >Previous</button> &nbsp;
                                                        <a onClick={() => this.showStartTest(`/start-assessment/${this.state.assessdata?.quiz_id}/${this.state.assessdata?.user_id}`)} className='btn btn-primary btn-sm text-light px-4'>Start the Quiz</a>
                                                    </div>

                                                </header>
                                                {/* row ends here */}

                                            </>


                                        </div>

                                    </div>
                                )
                            }
                            <div className='bg-white text-center'>Powered by Erekrut</div>
                        </div>
                    </div>
                </div>
            </>
        );
    }

}

export default AssessmentRound;