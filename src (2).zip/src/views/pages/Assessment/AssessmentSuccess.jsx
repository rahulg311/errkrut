import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import Company from '../../../components/Contact/Company';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { connect } from 'react-redux';
import SideBar from '../../../components/hoc/SideBar';
import { routePushed } from '../../../classes/browserHistory';

class AssessmentSuccess extends Component {

    componentWillMount() {

        console.log(this.props.quiz_result);

    }
    /* render */
    render() {
        let tper = 0;
        return (

            <div className="container">
                <div className="row">

                    <div className="col-md-9 p-0">

                        <div className="col-md-12">

                            <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                                {/* header starts here */}

                                <header className='d-flex '>
                                    <div className='me-3'>
                                        <img
                                            src={(this.props.quiz_result?.logo ? this.props.quiz_result?.logo : `/assets/imgs/dummy-logo.png`)}
                                            className='img-fluid shadow br-5 h-60p'
                                        />
                                    </div>
                                    <div className="mt-auto mb-auto">
                                        <h4 className='font-bold f-Poppins-Medium'>{this.props.quiz_result?.job_title}</h4>
                                        <p className="f-Poppins-Regular f-1-1">{this.props.quiz_result?.company_name}</p>
                                    </div>

                                    <div className="ms-auto mt-auto mb-auto">
                                        <h5 className='font-bold f-Poppins-Medium'>Assessment Completed In</h5>
                                        <h5 className='font-bold f-Poppins-Medium text-primary'>{this.props.quiz_result?.result.attempt_time} Min</h5>
                                    </div>
                                </header>

                                {/* header ends here */}

                                {/* row */}
                                {this.props.quiz_result?.result?.result?.map((val, i) => {
                                    tper = tper + val.percent;
                                })}
                                <div className="text-center">
                                    {tper <= 60 &&
                                        <img src={`assets/imgs/successfully-50.png`} className="img-fluid ms-auto me-auto d-block mb-2" />
                                    }

                                    {tper > 60 &&
                                        <img src={`assets/imgs/successfully-100.png`} className="img-fluid ms-auto me-auto d-block mb-2" />
                                    }

                                    <h3 className='font-bold f-Poppins-Medium text-primary'>
                                        {tper && Math.floor((tper / this.props.quiz_result?.result?.result.length) * 100) / 100}%
                                    </h3>
                                    <p>Your Result</p>
                                </div>
                                {/* row */}

                                {/* dotted border */}

                                <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>

                                {/* dotted border */}

                                {(this.props?.quiz_result && this.props.quiz_result?.result?.result?.length > 0) &&
                                    this.props.quiz_result?.result.result.map((value) => {
                                        return <div className='d-flex '>
                                            <div className="mt-auto mb-auto">
                                                <h5 className='font-bold f-Poppins-Medium'>{value.section_name}</h5>
                                            </div>

                                            <div className="ms-auto mt-auto mb-auto">
                                                <h5 className='font-bold f-Poppins-Medium'>{value?.percent && Math.floor((value.percent) * 100) / 100}%</h5>
                                            </div>
                                        </div>;
                                    })
                                }



                                <div className='d-flex mt-3 mb-3'>

                                    {this.props.quiz_result?.result.quiz_retake == true &&
                                        <div className="mt-auto mb-auto">
                                            {
                                                localStorage.removeItem(`currentTimerData${this.props.quiz_result?.quiz_id}`)
                                            }
                                            <NavLink className="btn btn-outline-primary ml-auto mr-auto  mt-2  ps-2 pe-2 float-start" to={`/start-assessment/${this.props.quiz_result?.quiz_id}/${this.props.quiz_result?.user_id}`}>Retake Test</NavLink>
                                        </div>
                                    }

                                    <div className="ms-auto mt-auto mb-auto">
                                        <button className="btn btn-primary ml-auto mr-auto mt-2  ps-4 pe-4 float-end" onClick={(e) => {
                                            routePushed('/successful', this.props, { message: 'Thank you for applying for this position', subtitle: 'We will get back to you as soon as possible', image: '/assets/imgs/successfullly-applied.png' })
                                        }}>Finish</button>
                                    </div>
                                </div>


                            </div>

                        </div>


                    </div>



                </div>
            </div>

        );
    }

}


const mapStateToProps = (state) => {
    const { quiz_result } = state.common
    return {
        quiz_result
    }
};

function mapDispatchToProps(dispatch) {
    return {

    };
}


export default connect(mapStateToProps, mapDispatchToProps)(AssessmentSuccess);