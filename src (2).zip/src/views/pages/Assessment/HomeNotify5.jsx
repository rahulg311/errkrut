import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';

class HomeNotify5 extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-1  ">
            <div className=" ">
               
              
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className=" row bg-white mt-2   ">
                   <div className='container'>
                   <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
                  						<select class="form-select w-35 text-primary" aria-label="Default select example">
                                              
  <option className='text-primary' selected>All Job</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>
							<p className='float-right mt-auto mb-auto'>
							<button type="button" class="btn btn-primary ps-5 pe-5">Download Stats</button>
							</p>
						</div>
					</div>
					
				</div>



                <div className='row mt-4 '>
                     <div className='col-md-8  '>
                         <div className='row'>
                             <div className='col-md-9 cards-shadow'>
                             <div className='row mt-3 mb-3 '>
					<div className='col-md-5 mt-1'>
					
							<h6 className='font-bold float-left'>Job Start</h6>
					

						
					
				</div>
            

                        </div>
                        <div className='row'>
                            <div className='col-md-12'>
                                
                            </div>
                        </div>
                                 
                             </div>
                             <div className='col-md-3 '>
                                 <div className='row'>
                                     <div className='col-12'>
                                     <div className='cards   bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '><span className='ms-4 '> Job </span><br /> <span className='float-end'>Saved</span> </p>
					</div>
                                     </div>
                                 </div>
                                 <div className='row mt-2'>
                                     <div className='col-12'>
                                     <div className='cards   bg-greenesh-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>8</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-5  font-bold pb-1 '><span className='ms-4 '> Total</span><br /> <span className='float-end'>Likes</span> </p>
					</div>
                                     </div>
                                 </div>
                        
                    
                    
                             </div>
                         </div>





                         <div className='row mt-2  cards-shadow me-1'>
                             <div className='col-md-12'>
                                 <h5 className='mt-3 m-2 fw-bold'>Demographics</h5>





                                 <div className='row pb-4 '>
                                     <div className='col-md-4'>
										 <div className='row '>
											 <div className='col-12'>
											 <div className='cards  bg-blue br-5 text-white ps-1  h-100 mr-2 '>
						<p className='fs-15 font-bold float-start mt-3 mb-3 '>India</p>
						<p className='fs-15 font-bold float-end  mt-3 mb-3 me-1'>68</p>
					
					</div>
											 </div>


											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Australia</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>54</p>
					
					</div>
											 </div>
											 
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>America</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
											 </div>
											 
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Brazil</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
					
											 </div>
											 <div className='col-12 mt-2'>
											 <div className='cards  bg-rejected br-5  ps-1  h-100 mr-2 '>
						<p className='fs-17 font-bold float-start mt-3 mb-3 '>Canada</p>
						<p className='fs-17 font-bold float-end  mt-3 mb-3 me-1'>43</p>
					
					</div>
					
											 </div>
										 </div>
									 </div>
                                     <div className='col-md-8'>
										 <div className='row  me-1'>
											 <div className='col-12 pt-1 cards-shadow pb-1'>
												 <p className='float-start fs-15 fw-bold'>Karnataka</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Delhi</p>
												 <p className='float-end fw-bold fs-15'>42</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Chandigarh</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Noida</p>
												 <p className='float-end fw-bold fs-15'>12</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Lucknow</p>
												 <p className='float-end fw-bold fs-15'>142</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Uttrakhand</p>
												 <p className='float-end fw-bold fs-15'>642</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-15 fw-bold'>Karnataka</p>
												 <p className='float-end fw-bold fs-15'>92</p>
											 </div>
										 </div>
									 </div>
                                 </div>
                             </div>
                         </div>
                     </div>



                     <div className='col-md-4'>
						 <div className='row cards-shadow'>
							 <div className='col-12'>
								 <p className='fw-bold fs-18 p-1 '> Assessment</p>
							 </div>

							 <div className='col-12 d-flex justify-content-center'>
							 <div class="ui-widgets">
            <div class="ui-values">80%</div>
           
        </div>
							 </div>

							 <div className='col-12  mt-2 d-flex'>
							 <button type="button" class="btn btn-danger  ms-2"></button>
							 <p className='fs-12 ms-1'>Completed in a single take</p>

							 </div>
							 <div className='col-12 mt-1 d-flex'>
							 <button type="button" class="btn btn-primary  ms-2"></button>
							 <p className='fs-12 ms-1'>Completed in a 	multiple takes</p>

							 </div>

							 <div className='border-dashed1 mt-3 mb-2'></div>


							 <div className='row mb-3'>
								 <div className='col-4 m-0 p-0'>
									 <h5 className='fw-bold mt-1 ps-1 fs-20'>Top 5</h5>
									 
								 </div>
								 <div className='col-8 m-0 p-0'>
								 <select class="form-select fw-bold  " aria-label="Default select example">
                                              
											  <option className='fw-bold ' selected>Hardest Questions</option>
											  <option value="1">One</option>
											  <option value="2">Two</option>
											  <option value="3">Three</option>
											</select>
															
								 </div>
							 </div>


							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-17 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							 <div className='row pb-2 '>
								 <div className='col-12 ms-1 cards bg-rejected text-dark br-5 text-white ps-1  h-100 mr-2 '>
								<h6 class="fs-15 font-bold  mb-1 mt-1 text-dark ">Question Title</h6>
								<p class="fs-12 text-dark pb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
								</div>
								
								
							 </div>
							
								
								
							
						 </div>
                         
                     </div>
                 </div>













                <div className='row mt-2 pb-4 '>
                    <div className='col-12 '>
						<div className='row'>
							<div className='col-4'>
							<div class="cards  bg-blue br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Avg Marks  <br/><span class="ms-3">Obtained</span></p></div>
							</div>
							<div className='col-4'>
							<div class="cards  bg-dark-pink br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Passed  <br/><span class="ms-3">Candidates</span></p></div>
							</div>
							<div className='col-4'>
							<div class="cards  bg-greenesh-blue br-5 text-white p-1 h-100 mr-2"><p class="fs-18 float-start font-bold">130</p><p class="fs-15  float-end m-0 mt-5 ">Candidate  <br/><span class="ms-3">Eliglbilty</span></p></div>
							</div>
						</div>
                   
                    

                    </div>





























</div></div></div></div>
            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default HomeNotify5;