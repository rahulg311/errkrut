import React, { Component } from 'react';
import { getLoggedInUser, ObjectLength } from '../../../classes';

import { connect } from 'react-redux';
import SideBar from '../../../components/hoc/SideBar';
import QuizStatus from '../../../components/Sidebars/Candidate/QuizStatus';

import { notification } from '../../../classes/messages';
import { assessmentAttemptQuiz, dispatchQuizResult, assessmentFinalSubmit, assessmentSelectAnswer, assessmentStartQuiz, assessmentGetQuizStatus, assessmentSkipQuizQuestions } from '../../../store/actions/quiz';
import Countdown from 'react-countdown';
import { routeChanged, routePushed } from '../../../classes/browserHistory';
import { QUIZ_RESULT } from '../../../config/constants';
import ConfirmationModal from '../../../components/CadidateAppliedJobs/ConfirmationModal';

class StartAssessment extends Component {

    state = {
        section_details: null,
        quiz_details: null,
        job_details: null,
        current_section: 0,
        timerCount: 20,
        page_num: 0,
        offset: 0,
        limit: 0,
        per_page: 0,
        user_id: null,
        quiz_result_id: null,
        quiz_sec_res_id: null,
        currentDate: Date.now(),
        selected_answers: null,
        is_final_submit: 0,
        quiz_status_data: null,
        timersubmit: false,
        start_test: false,
        confirmationModalData: {
            title: 'You Seemed to miss out Some Questions, Are you sure you want to finish the quiz?',
            message: '',
            link: '',
            button: 'Finish Assessment',

        }
    }

    // Quiz Confirmation
    showStartTest = (linkdata) => {
        this.setState({
            start_test: true,
            confirmationModalData: { ...this.state.confirmationModalData, link: linkdata }
        });
    }
    hideStartTest = () => {
        this.setState({
            start_test: false,
        });
    }

    // End Quiz Confirmation

    componentDidMount() {
        window.scrollTo(0, 0);
        this.initializeQuiz();
        if (!localStorage.getItem(`currentTimerData${this.props.match.params?.quiz_id}`)) {
            localStorage.setItem(`currentTimerData${this.props.match.params?.quiz_id}`, this.state.currentDate);
        } else {
            this.setState({
                currentDate: parseInt(localStorage.getItem(`currentTimerData${this.props.match.params?.quiz_id}`))
            });
        }
    }

    fetchQuizStatus = async () => {
        await this.props.assessmentGetQuizStatus(this.state.quiz_result_id);
        if (this.props.quiz_status_data?.status == "success") {
            this.setState({ quiz_status_data: this.props.quiz_status_data.data });
        }
    }

    initializeQuiz = async () => {

        let notify;
        if (this.props.match.params?.user_id != null) {

            let j = { user_id: this.props.match.params?.user_id, quiz_id: this.props.match.params?.quiz_id };

            await this.props.assessmentAttemptQuiz(j);
            if (this.props.attempt_quiz_res?.status == 'success') {

                /* if questions null */
                if (this.props.attempt_quiz_res?.data.length == 0) {
                    notify = notification({ message: 'Can not start quiz', type: 'error' });
                    this.props.history.goBack()
                }
                /* if questions null */

                let x;
                Object.keys(this.props.attempt_quiz_res?.data).map((key) => {
                    x = {
                        ...x,
                        [key]: this.props.attempt_quiz_res?.data[key]
                    };
                });


                let quiz_details = JSON.parse(localStorage.getItem('quiz_' + this.props.match.params?.quiz_id));
                let job_details = JSON.parse(localStorage.getItem('quiz_job_' + this.props.match.params?.quiz_id));
                await this.props.assessmentStartQuiz(j);
                this.setState({
                    section_details: x,
                    quiz_details: quiz_details,
                    job_details: job_details,
                    user_id: this.props.match.params?.user_id,
                    quiz_result_id: this.props.start_quiz_res?.data?.quiz_result_id,
                    quiz_sec_res_id: this.props.start_quiz_res?.data?.quiz_sec_res_id
                }, () => {
                    this.nextQuestion();
                    this.fetchQuizStatus();
                });

            } else {
                notify = notification({ message: JSON.stringify(this.props.attempt_quiz_res?.message), type: 'error' });
            }

        }

        if (notify)
            notify();

    }


    /* next question */
    nextQuestion() {
        this.skipQUestions(this.state.limit, this.state.offset, this.state.current_section, parseInt(this.state.page_num));
        let currentQuestionCount = this.state.section_details[this.state.current_section]?.questions.length;
        let page_num = parseInt(this.state.page_num) + parseInt(1);

        console.log(this.state.limit, "prev limit");
        console.log(this.state.offset, "prev offset");
        console.log(this.state.current_section, "prev section");

        if (this.state.limit < currentQuestionCount) {

            this.setState({
                limit: page_num * parseInt(this.state.quiz_details?.per_page_questions),
                offset: (page_num * parseInt(this.state.quiz_details?.per_page_questions)) - parseInt(this.state.quiz_details?.per_page_questions),
                page_num: page_num
            }, () => {
                console.log(this.state.limit)
                console.log(this.state.offset)
                console.log(currentQuestionCount);
                this.isFinalSubmit();
            });

        } else {

            let page_num = 1;

            this.setState({
                current_section: this.state.current_section + 1,
                page_num: page_num,
                offset: (page_num * parseInt(this.state.quiz_details?.per_page_questions)) - parseInt(this.state.quiz_details?.per_page_questions),
                limit: page_num * parseInt(this.state.quiz_details?.per_page_questions),
            }, () => {
                this.isFinalSubmit();
            });

        }

        console.log(this.state.selected_answers)

    }

    handleNext = () => {
        this.skipQUestions();
        this.nextQuestion()
    }

    isFinalSubmit() {
        let section_count = ObjectLength(this.state.section_details) - 1;
        let currentQuestionCount = this.state.section_details[this.state.current_section].questions.length;
        console.log(currentQuestionCount);
        console.log(this.state.limit);
        console.log(this.state.offset);
        if (section_count == this.state.current_section) {
            if (this.state.limit >= currentQuestionCount)
                this.setState({
                    is_final_submit: 1
                });
        }
    }


    /* previous question */
    prevQuestion() {

        let page_num = parseInt(this.state.page_num) - parseInt(1);

        let currentQuestionCount = this.state.section_details[this.state.current_section].questions.length;

        if (this.state.offset > 0) {

            this.setState({
                limit: page_num * parseInt(this.state.quiz_details?.per_page_questions),
                offset: (page_num * parseInt(this.state.quiz_details?.per_page_questions)) - parseInt(this.state.quiz_details?.per_page_questions),
                page_num: page_num
            });

        } else {

            let newSection = this.state.current_section - 1;

            let page_num = Math.ceil(parseInt(this.state.section_details[newSection].questions.length) / parseInt(this.state.quiz_details?.per_page_questions));

            this.setState({
                current_section: newSection,
                page_num: page_num,
                offset: (page_num * parseInt(this.state.quiz_details?.per_page_questions)) - parseInt(this.state.quiz_details?.per_page_questions),
                limit: page_num * parseInt(this.state.quiz_details?.per_page_questions),
            });

        }

        console.log(this.state.selected_answers);

        this.setState({
            is_final_submit: 0
        });

    }

    updateSelectedAnswer = async (obj) => {
        await this.props.assessmentSelectAnswer(obj);
        if (this.props.select_answer_res?.status == 'success') {
            this.fetchQuizStatus();
        } else {
            let notify = notification({ message: JSON.stringify(this.props.select_answer_res?.message), type: 'error' });
            notify();
        }
    }

    /* set answer */
    setAnswer = async (obj) => {
        obj['user_id'] = this.state.user_id;
        obj['quiz_result_id'] = this.state.quiz_result_id;
        // obj['quiz_sec_res_id'] = this.state.quiz_sec_res_id;

        this.setState({
            selected_answers: {
                ...this.state.selected_answers,
                [obj.section_id + "_" + obj.question_id]: obj.answer_id
            }
        }, () => {
            this.updateSelectedAnswer(obj);
        })

    }

    /* skip questions */
    skipQUestions = async (limit, offset, current_section, page_num) => {
        if (page_num > 0) {
            const question_ids = [];
            let section_id;

            if (this.state.section_details && Object.keys(this.state.section_details).length > 0) {
                Object.keys(this.state.section_details).map((sectionKey) => {
                    if (sectionKey == current_section) {
                        this.state.section_details[sectionKey].questions.map((question, i) => {
                            if (i >= offset && i < limit) {
                                section_id = question.section_id;
                                const selected_answers = this.state.selected_answers || {};
                                if (selected_answers && !Object.keys(selected_answers).includes(String(question.section_id + "_" + question.question_id))) {
                                    question_ids.push(question.question_id);
                                }
                            }
                        })
                    }
                });
            }

            if (question_ids.length > 0) {
                const formData = new FormData();
                formData.append('quiz_result_id', this.state.quiz_result_id);
                formData.append('user_id', this.props.match.params?.user_id);
                formData.append('section_id', section_id);
                formData.append('question_id', JSON.stringify(question_ids));

                await this.props.assessmentSkipQuizQuestions(formData);

                if (this.props.skip_questions_data?.status == 'success') {
                    this.fetchQuizStatus();
                } else {
                    let notify = notification({ message: JSON.stringify(this.props.skip_questions_data?.message), type: 'error' });
                    notify();
                }
            }
        }
    }

    /* final submit */

    finalSubmit = async () => {

        let qsub = true;
        let data = {
            quiz_result_id: this.state.quiz_result_id,
            user_id: this.state.user_id,
            quiz_id: this.props.match.params?.quiz_id,
        }
        await this.props.assessmentFinalSubmit(data);

        {
            Object.values(this.state.quiz_status_data)?.map((key, value) => (
                Object.values(key).map((v) => {
                    if (v.status == 3) {
                        qsub = false;
                    }
                })
            ))
        }
        if (qsub || this.state.timersubmit) {
            if (this.props.final_submit_res?.status == 'success') {
                this.props.dispatchQuizResult({ type: QUIZ_RESULT, data: { result: this.props.final_submit_res.data, quiz_id: this.props.match.params?.quiz_id, job_title: this.state.job_details?.job_title, company_name: this.state.job_details?.company_name, logo: this.state.job_details?.logo, user_id: this.state.user_id } });
                routePushed('/assessment-success', this.props);

            } else {
                let notify = notification({ message: JSON.stringify(this.props.select_answer_res?.message), type: 'error' });
                notify();
            }
        }
        else {
            this.showStartTest('');
        }



    }
    skipQuiz = () => {
        this.setState({
            timersubmit: true,
        });
    }

    /* render */
    render() {



        const renderer = ({ hours, minutes, seconds, completed }) => {
            if (completed && !this.state.timersubmit) {
                // Render a completed state
                localStorage.setItem(`currentTimerData${this.props.match.params?.quiz_id}`, null);
                this.setState({
                    timersubmit: true,
                });
                this.finalSubmit();
                return 'Quiz Completed';
            } else {
                // Render a countdown
                return <span>{minutes}:{seconds}</span>;
            }
        };

        return (
            <>
                <ConfirmationModal closeModal={() => this.hideStartTest()} status={this.state} mdata={this.state.confirmationModalData} subFunction={() => this.finalSubmit()} skipQuiz={() => this.skipQuiz()} />
                <div className="container">
                    <div className="row">

                        <div className="col-md-9 p-0">

                            <div className="col-md-12">

                                {/* timer */}
                                <div className="ms-auto bg-white br-5">
                                    <h4 className="text-primary text-center pt-2">
                                        {
                                            this.state.quiz_details?.quiz_duration &&
                                            <Countdown date={this.state.currentDate + (parseInt(this.state.quiz_details?.quiz_duration) * parseInt(60)) * parseInt(1000)} renderer={renderer} />
                                        }
                                    </h4>
                                </div>
                                {/* timer */}

                                {this.state.section_details &&
                                    Object.keys(this.state.section_details).map((sectionKey) => {

                                        if (sectionKey == this.state.current_section)

                                            return <>

                                                {/* header */}
                                                <div className="container p-4 bg-white br-5">
                                                    <div className="d-flex mt-2 mb-2">
                                                        <div>
                                                            <h4 className="f-Poppins-Medium f-xs-4">
                                                                {this.state.section_details[sectionKey].section_title}
                                                            </h4>
                                                        </div>
                                                    </div>
                                                    <header className='d-flex'>
                                                        <div className='me-3'>
                                                            <img
                                                                src={(this.state.job_details?.logo) ? this.state.job_details?.logo : `/assets/imgs/dummy-logo.png`}
                                                                className='img-fluid shadow br-5 h-60p'
                                                            />
                                                        </div>
                                                        <div className="mt-auto mb-auto">
                                                            <h5 class="font-bold f-Poppins-Medium">
                                                                {this.state.job_details?.job_title}
                                                            </h5>
                                                            <p class="f-Poppins-Regular f-1-1">
                                                                {this.state.job_details?.company_name}
                                                            </p>
                                                        </div>
                                                    </header>
                                                </div>
                                                {/* header */}

                                                {/* questions */}
                                                <div className="container p-4 mt-4 bg-white br-5">

                                                    {this.state.section_details[sectionKey].questions?.length > 0 &&

                                                        this.state.section_details[sectionKey].questions.map((question, i) => {

                                                            if (i >= this.state.offset && i < this.state.limit)
                                                                return <>

                                                                    <h5 className="d-flex">
                                                                        <span className="font-bold f-xs-5 f-Poppins-Medium">
                                                                            {i + 1}. {question.title.replace(/(<([^>]+)>)/ig, '')}
                                                                        </span>
                                                                        {/* <span className="font-bold text-dark f-xs-5 ms-auto">1/15</span> */}
                                                                    </h5>

                                                                    <p className="f-1 f-Poppins-Medium mt-2 f-xs-5">
                                                                        {question?.explanation.replace(/(<([^>]+)>)/ig, '')}
                                                                    </p>

                                                                    <ul className="mt-2 list-unstyled">
                                                                        {question?.options && Object.keys(question?.options).map((k) => {
                                                                            return (
                                                                                <>
                                                                                    <li className="pb-1">

                                                                                        <label>
                                                                                            <div className="d-flex cursor">
                                                                                                <div class="form-check">
                                                                                                    <input onChange={() => this.setAnswer({ answer_id: k, question_id: question.question_id, section_id: question.section_id, status: 1 })} class="form-check-input p-1 cursor" type="radio" id="flexCheckDefault" name={`question_option_${question.question_id}`} checked={(this.state.selected_answers != null && this.state.selected_answers[question.section_id + "_" + question.question_id] == k) ? true : false} />
                                                                                                </div>
                                                                                                <span className="mt-auto mb-auto">{question?.options[k]}</span>
                                                                                            </div>
                                                                                        </label>

                                                                                    </li>
                                                                                </>);
                                                                        })}
                                                                    </ul>
                                                                    <hr />

                                                                </>

                                                        })

                                                    }

                                                </div>
                                                {/* questions */}

                                                {/* footer */}
                                                <div className="container mt-4 bg-white br-5">
                                                    <div className="row  mb-2">
                                                        <div className="col-md-12 mb-2 col-12">
                                                            {(this.state.offset > 0 || this.state.current_section != 0) &&
                                                                <button className="btn btn-outline-primary ml-auto mr-auto  mt-2  ps-2 pe-2 float-start" onClick={() => this.prevQuestion()}>Previous</button>
                                                            }

                                                            {this.state.is_final_submit == 1 && <button className="btn btn-primary ml-auto mr-auto mt-2  ps-4 pe-4 float-end" onClick={() => this.finalSubmit()}>Submit</button>}

                                                            {this.state.is_final_submit == 0 &&
                                                                <button className="btn btn-primary ml-auto mr-auto mt-2  ps-4 pe-4 float-end" onClick={() => this.handleNext()}>Next</button>}
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* footer */}

                                            </>

                                    })
                                }

                            </div>


                        </div>

                        {/* sidebar */}
                        <SideBar>
                            <QuizStatus quiz_status_data={this.state.quiz_status_data} cdata={this.state.job_details} finishExam={() => this.finalSubmit()} />
                        </SideBar>
                        {/* sidebar */}

                    </div>
                </div>
            </>
        );
    }

}

const mapStateToProps = (state) => {
    const { attempt_quiz_res, start_quiz_res, select_answer_res, final_submit_res, quizstatusdata, skip_questions_data } = state.common
    return {
        attempt_quiz_res,
        start_quiz_res,
        select_answer_res,
        final_submit_res,
        quiz_status_data: quizstatusdata,
        skip_questions_data,
    }
};

function mapDispatchToProps(dispatch) {
    return {
        assessmentAttemptQuiz: (formData) => dispatch(assessmentAttemptQuiz(formData)),
        assessmentStartQuiz: (formData) => dispatch(assessmentStartQuiz(formData)),
        assessmentSelectAnswer: (formData) => dispatch(assessmentSelectAnswer(formData)),
        assessmentFinalSubmit: (formData) => dispatch(assessmentFinalSubmit(formData)),
        dispatchQuizResult: (data) => dispatch(dispatchQuizResult(data)),
        assessmentGetQuizStatus: (id) => dispatch(assessmentGetQuizStatus(id)),
        assessmentSkipQuizQuestions: (formData) => dispatch(assessmentSkipQuizQuestions(formData)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(StartAssessment);