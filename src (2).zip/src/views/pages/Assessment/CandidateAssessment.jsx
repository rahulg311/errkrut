import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { getLoggedInUser } from '../../../classes';
import {END_POINT, GET_USER_ASSESSMENT} from "../../../routes/api_routes";
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import Designations from './../../../components/Sidebars/Candidate/Designations';
import { notification } from "../../../classes/messages";
class CandidateAssessment extends Component {
   state = {
      assessmentList: "",
   }
   componentDidMount(){
      this.getUser()
   }
   getUser = async (e) => {
      let userDetails = await getLoggedInUser();
      const requestOptions = {
         method: "GET",
         headers: { "Content-Type": "application/json" },
       };

      fetch(END_POINT + GET_USER_ASSESSMENT + `/${userDetails.id}`, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        if (data.status == "success") {
          console.log(data)
          let assessmentList = data.data.map(row => {
            return(
               <div className='col-md-12 bg-light-blue br-5 mb-2'>
                  <div className="row py-1 align-items-center">
                     <div className='col-md-4 d-flex align-items-center'>
                        <div class="me-3 d-flex">
                           <span class="bg-dark-pink px-20px  py-1px rounded me-3px text-light f-2 shadow">
                              <a class="text-light" href="/job/152/youtube-tutor">S</a>
                           </span>
                        </div>
                        <div>
                           <div className="f-Poppins-Regular f-0-8  f-Poppins-Regular">{row.company_name}</div>
                           <div className="f-Poppins-Regular f-0-8  f-Poppins-Regular">{row.status}</div>
                        </div>
                     </div>
                     <div className='col-md-2 f-Poppins-Regular f-0-8  f-Poppins-Regular"'>{row.created_at}</div>
                     <div className='col-md-6 d-flex justify-content-between align-items-center'>
                        <div className="f-Poppins-Regular f-0-8  f-Poppins-Regular">
                        {row.assessment_name}
                        </div>
                        <div>
                           <button type="button" class="btn btn-primary ps-5 pe-5 f-0-8 rounded-0">Start Assessment</button>
                        </div>
                     </div>
                     
                  </div>
               </div>
            )
          });

          this.setState({assessmentList: assessmentList})
          
        } else {
          let notify = notification({ message: data.message, type: "error" });
          notify();
        }
      })
      .catch((error) => console.log("error", error));
   }
// Handle fields change
handleChange = (e) => {
}

render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-1  ">
            <div className=" ">
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className=" row  mt-2   ">
                  <div className='container'>
                     <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
                        <div className='container'>
                           <div className='row'>
                              <div className='col-md-7'>
                                 <p className='fw-bold fs-22 float-start'>Assessment</p>
                              </div>
                              <div className='col-md-5'>
                                 <form>
                                    <div className='row'>
                                       <div className='col-md-7 '>
                                          <select class="form-select w-100 text-primary" aria-label="Default select example">
                                             <option className='text-primary' selected>All</option>
                                             <option value="1">Not Taken</option>
                                             <option value="2">Retake</option>
                                             <option value="3">Saved</option>
                                             <option value="4">Pass</option>
                                             <option value="5">Fail</option>
                                          </select>
                                       </div>
                                       <div className='col-md-5'>
                                          <button type="button" class="btn btn-primary ps-5 pe-5 rounded-0">Filter</button>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                           <div className='border-blue1 mt-2 mb-2'></div>
                           <div className='row'>
                              {this.state.assessmentList}
                           </div>

                        </div>
                     </div>
                     
                     
                  </div>
               </div>
            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default CandidateAssessment;