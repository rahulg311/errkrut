import React, { Component, useEffect, useState } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import Designations from './../../../components/Sidebars/Candidate/Designations';
import useFetch from "../../../hooks/useFetch";
import { END_POINT, GET_ASSESSMENT_RESULT, GET_ASSESSMENT } from "../../../routes/api_routes";
import { getLoggedInUser, getAuthToken } from "../../../classes";
import { notification } from '../../../classes/messages';
const Assessment = () => {

   const [filters, setfilters] = useState({});
   const [allChecked, setAllChecked] = useState(false);
   const [isChecked, setIsChecked] = useState([]);
   const AssessmentListResult = useFetch();
   const handlefilter = e => {
      setfilters({
         ...filters,
         [e.target.name]: e.target.value
      });

   };
   const getfilterdata = async () => {
      let assess = filters.assess == undefined ? "" : filters.assess;
      let status = filters.status == undefined ? "" : filters.status;
      let filter = {
         assessment_name: assess,
         status: status,
      }
      const user = await getLoggedInUser();
      if (assess == '' && status == '') {
         getAssessmentList();
      }
      else {
         AssessmentList.doFetch(END_POINT + `${GET_ASSESSMENT_RESULT}/${user.company_id}?filter=` + JSON.stringify(filter));
      }
   };
   const handleAllCheck = e => {
      if (!allChecked) {
         setIsChecked(AssessmentList?.data?.data?.map((c) => c.id));
         setAllChecked(true);
      }
      else {
         setIsChecked([]);
         setAllChecked(false);
      }
   };

   const handleSingleCheck = e => {
      if (isChecked.includes(parseInt(e.target.value))) {
         var myIndex = isChecked.indexOf(parseInt(e.target.value));
         if (myIndex !== -1) {
            isChecked.splice(myIndex, 1);
            setIsChecked([...isChecked]);
         }
      }
      else {
         setIsChecked([...isChecked, parseInt(e.target.value)]);
      }
   };
   const allAssessmentList = useFetch();
   const getAllAssessmentList = async () => {
      const user = await getLoggedInUser();
      await allAssessmentList.doFetch(END_POINT + `${GET_ASSESSMENT}/${user.company_id}`);
   };
   const AssessmentList = useFetch();
   const getAssessmentList = async () => {
      const user = await getLoggedInUser();
      AssessmentList.doFetch(END_POINT + `${GET_ASSESSMENT_RESULT}/${user.company_id}`);
   };

   const downloadResult = async () => {
      const user = await getLoggedInUser();
      let token = await getAuthToken();
      let assess = filters.assess == undefined ? "" : filters.assess;
      let status = filters.status == undefined ? "" : filters.status;
      let filter = {
         assessment_name: assess,
         status: status,
      }
      var requestOptions = {
         method: 'GET',
         redirect: 'follow',
         headers: { 'Authorization': 'Bearer ' + token },
      };
      let notify = null;

      if (assess == '' && status == '' && isChecked.length <= 0) {
         getAssessmentList();
         notify = notification({ message: 'Select any One Assessment to Download.', type: 'error' });
         notify();
      }
      else {
         fetch(END_POINT + `download_assessment_result/${user.company_id}?filter=` + JSON.stringify(filter) + "&ids=" + JSON.stringify(isChecked.join().split(',')), requestOptions).then(response => response.json()).then((data) => {
            if (data.status == "success") {
               const link = document.createElement('a');
               link.download = "";
               let str = data.excel_url.replace(/[\\]/g, '');
               link.href = str;
               document.body.appendChild(link);
               link.click();
               document.body.removeChild(link);
            }
            else {
               notify = notification({ message: data.message, type: 'error' });
               notify();
            }
         });
      }
   }

   useEffect(() => {
      getAssessmentList();
      getAllAssessmentList();
   }, []);
   return (
      <div className="container">
         <div className="row">
            <div className="col-md-9 p-0">
               <div className="p-1  ">
                  <div className=" ">
                     {/* submit button */}
                     {/* start Edit hr profile  */}
                     <div className=" row  mt-2   ">
                        <div className='container'>
                           <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                              <div className='containe'>
                                 <div className="row  mb-2">
                                    <div className="col-md-5 mt-2  col-12 mb-1">
                                       <h3 className="text-primary f-Poppins-Medium ms-4 ">View Assessment Result</h3>
                                    </div>
                                    <div className="col-md-7 text-end">
                                       <select class="p-1 text-primary ms-1 fs-12  " name="assess" onChange={handlefilter} selected={filters.experience} aria-label="Default select example">
                                          <option selected value="">ALL Assessment</option>
                                          {
                                             allAssessmentList?.data?.data.map((ass, id) => {
                                                return (
                                                   <option>
                                                      {ass.title}
                                                   </option>
                                                );
                                             })
                                          }
                                       </select>
                                       <select class="p-1 text-primary ms-1 fs-12 " name="status" onChange={handlefilter} selected={filters.status} aria-label="Default select example">
                                          <option selected value="">Status</option>
                                          <option value="pass">Pass</option>
                                          <option value="fail">Fail</option>
                                       </select>
                                       <button type="button" onClick={getfilterdata} class="btn fs-12 btn-primary ps-4 pe-4 pt-1 pb-1 ms-1 m-2 rounded-0 ">Filter</button>
                                    </div>
                                 </div>
                                 <div className="border-blue1  mb-2  "></div>
                                 <div className='row'>
                                    <div className='col-12'>
                                       <button type="button" class="btn btn-outline-secondary float-start" onClick={downloadResult}>Download Data</button>
                                       <a className='float-end cursor' onClick={handleAllCheck}> Select All</a>
                                    </div>
                                 </div>
                                 <div className=''>
                                    {AssessmentList?.data?.data.map((e) => {
                                       return <section class=" card shadow border-0 rounded-4 py-3 px-4 overflow-hidden mt-3">
                                          <header class="d-flex"
                                          >
                                             <div class="me-3 d-flex">
                                                <span class="bg-dark-pink px-20px  py-1px rounded me-3px text-light f-2 shadow">
                                                   <a class="text-light text-uppercase">{e.name.substring(0, 1)}</a>
                                                </span>
                                             </div>
                                             <div class="mt-auto mb-auto">
                                                <h6 class="font-bold">{e.name}</h6>
                                                <p>Designations</p>
                                             </div>
                                             <div class="ms-auto ">
                                                <div class="form-check ">
                                                   <input class="form-check-input float-end fs-20" type="checkbox" checked={isChecked.includes(parseInt(e?.id))} name={e?.name} value={e?.id} onChange={handleSingleCheck} id="flexCheckDefault" />
                                                </div>
                                                <h5 className='mt-2 '>Score : {e.result}</h5>
                                             </div>
                                          </header>
                                          <div className='new2 mt-3 mb-2 '></div>
                                          <div className='row '>
                                             <div className='col-12'>
                                                <p className='float-start text-primary fw-bold'>{e.assessment_name}</p>
                                                <p className='float-end text-success fw-bold'>Status : {e.status}</p>
                                             </div>
                                             <div className='col-12 mt-2'>
                                                <p className='float-start '>Section 1</p>
                                                <p className='float-end '>80%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 2</p>
                                                <p className='float-end '>60%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 3</p>
                                                <p className='float-end '>40%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                          </div>
                                       </section>;
                                    })}


                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/* submit button */}
                  {/* form ends here */}
               </div>
            </div>
            {/* sidebar */}
            <div className="col-md-3">
               <ProfileName />
               <ActionButtons />
               <Company />
            </div>
            {/* sidebar */}
         </div>
      </div>
   );
}
export default Assessment;