import React, { Component, useEffect, useState } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Quizes from '../Quizes/Quizes';
import PlanCard from '../../../components/SelectPlan/PlanCard';
import { getLoggedInUser, isRecruiter } from '../../../classes/index';
import useFetch from "../../../hooks/useFetch";
import { END_POINT, GET_CANDIDATES, GETALLJOBS } from "../../../routes/api_routes";
import { getAuthToken } from '../../../classes/index';
import { notification } from "../../../classes/messages";



const SendAnnouncement = () => {
	const [title, setTitle] = useState();
	const [jobs, setJobs] = useState();
	const [candidate, setCandidates] = useState();
	const [message, setMessage] = useState();

	const CandidateList = useFetch();
	const JobList = useFetch();

	const getCandidateList = async () => {
		let token = await getAuthToken();
		CandidateList.doFetch(END_POINT + `${GET_CANDIDATES}`, {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		});
		//console.log(CandidateList);
	};
	const getJobsList = async () => {
		const result = await getLoggedInUser();
		let token = await getAuthToken();
		JobList.doFetch(END_POINT + `${GETALLJOBS}/${result.company_id}`, {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		});
		//console.log(JobList);
	};
	useEffect(async () => {
		getCandidateList();
		getJobsList();
	}, []);

	const onSubmitData = async () => {
		let token = await getAuthToken();
		const result = await getLoggedInUser();
		console.log(title)
		console.log(candidate)
		console.log(jobs)
		
		if(title == undefined || candidate == undefined || jobs == undefined || message == undefined){
			
			let notify = notification({ message: "Enter the subject, Job, Candidates and Message", type: 'error' });
			notify();
		}else{
			const formdata = new FormData();
			formdata.append('subject', title);
			formdata.append('candidate_id', candidate);
			formdata.append('job_id', jobs);
			formdata.append('company_id', result.company_id);
			formdata.append('message', message);
			
			var requestOptions = {
				method: 'POST',
				body: formdata,
				redirect: 'follow',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token
				}
			};
			fetch(END_POINT + 'add_announcement', requestOptions)
				.then((response) => response.json())
				.then((data) => {
					console.log(data);
					let notify = notification({ message: data.message, type: 'success' });
					notify();
				})
				.catch((error) => { 
					let notify = notification({ message: error.message, type: 'error' });
					notify();
				});
		}
	}
	return (
		<div className="container mb-2">
			<div className="row">
				<div class="col-lg-9">
					<div class="container bg-white rounded-4 pt-3 pb-7 mb-2">
						<ul></ul>
						<form method="post">
							<div class="bg-white">
								<div>
									<div className='row'>
										<div className='col-md-12'>
											<h4 className='text-primary'>Add Anouncement</h4>
										</div>
									</div>
									<div class="border-bottom-blue mb-2 mt-2"></div>


									<div className='w-80  w-100-xs'>



										<div class="row mt-1 ">
											<div class="col-md-12"><label class="text-primary">Subject</label></div>
											<div class="col-md-12"><input type="text" class="border-color-blue form-control input-border fs-12 " name="title" required="" value={title} onChange={event => setTitle(event.target.value)} placeholder='Enter your Full Name' /></div>
										</div>
										<div class="row mt-1 ">

											<div class="col-md-5">
												<div class="row mt-1">
													<div class="col-md-12">
														<label class="text-primary">Select Job</label>
														<select class="form-select border-color-blue form-select-md input-border fs-12" name="evaluation" onChange={event => setJobs(event.target.value)} required="" placeholder='All Job'>
															<option value="0">Select Job</option>
															{
																JobList?.data?.data?.map((jobs) => {
																	return <><option value={jobs?.id}>{jobs?.job_title}</option></>;
																})
															}
														</select>
													</div>
												</div>
											</div>
											<div class="col-md-7">
												<div class="row mt-1">
													<div class="col-md-12"> <label class="text-primary">Candidates</label>
														<select class="form-select border-color-blue form-select-md input-border fs-12" name="evaluation" required="" onChange={event => setCandidates(event.target.value)} placeholder='All Candidates'>
															<option value="all">All Candidates</option>
															<option value="saved">Saved Candidates</option>
															<option value="applied">Applied Candidates</option>
															<option value="rejected">Rejected Candidates</option>
															{
																CandidateList?.data?.map((candidate) => {
																	return <><option value={candidate?.id}>{candidate?.name}</option></>;
																})
															}
														</select>
													</div>

												</div>
											</div>
										</div>
										<div class="row mt-1 ">
											<div class="col-md-12">
												<div class="row mt-1">
													<div class="col-md-12"><div class="mb-3">
														<label for="exampleFormControlTextarea1" class="form-label">Message</label>
														<textarea class="form-control" id="exampleFormControlTextarea1" rows="5" onChange={event => setMessage(event.target.value)}></textarea>
													</div></div>

												</div>
											</div>
										</div>

										<div class="row mt-1 ">
											<div class="col-md-12">
												<div class="col-md-12 mt-3">
													<button type="button" onClick={() => {
														onSubmitData();
													}} class="btn btn-primary float-end d-block  ps-5 pe-5">Send</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				{/* sidebar */}
				<div className="col-md-3">
					<ProfileName />
					<ActionButtons />
					<Company />
				</div>
				{/* sidebar */}
			</div >
		</div >
	);
}

export default SendAnnouncement;