import React, { useState, useEffect } from 'react';

import Header from '../../../components/common/Header';
import RecruiterHomeCard from '../../../components/Cards/RecruiterHomeCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Jobs from '../../../components/Recruiter/Jobs';
import Quiz from '../../../components/Recruiter/Quiz';
import Questions from '../../../components/Recruiter/Questions';
import Testimonial from '../../../components/Recruiter/Testimonial';
import OfferLetters from '../../../components/Recruiter/OfferLetters';
import Members from '../../../components/Recruiter/Members';
import { Route, useHistory } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import LetterOfIntent from '../../../components/Recruiter/LetterOfIntent';
import usePost from "../../../hooks/usePost";
import useFetch from "../../../hooks/useFetch";
import UserList from "../../../components/Recruiter/UserList";
import { getLoggedInUser, getAuthToken } from "../../../classes";
import { notification } from '../../../classes/messages';
import ImportUserModal from "../../../components/Recruiter/ImportUserModal";
import AddAssessmentModal from "../../../components/Recruiter/AddAssessmentModal";
import AddExcelModal from '../CandidateList/ExcelModal';
import TopCampusesCard from '../../../components/Cards/TopCampusesCard';
import { Link } from 'react-router-dom';
import {
	END_POINT,
	USER_IMPORT,
	STUDENT_LISTING,
	USER_DELETE,
	RESEND_INVITATION,
	COMPANY_LISTING,
} from "../../../routes/api_routes";

const RecruiterHome = ({ match }) => {
	const history = useHistory();
	const [importModal, setImportModal] = useState(false);
	const closeImportModal = () => setImportModal(false);
	const showImportModal = () => setImportModal(true);

	const [AssessmentModal, setAssessmentModal] = useState(false);
	const showAssessmentModal = () => setAssessmentModal(true);
	const closeAssessmentModal = () => setAssessmentModal(false);
	const [ExcelModal, setExcelModal] = useState(false);
	const showExcelModal = () => setExcelModal(true);
	const closeExcelModal = () => setExcelModal(false);
	const { response, isLoading, error, doPost } = usePost();

	const studentCvListAPI = useFetch();
	const studentDeleteAPI = usePost();
	const resendInvitationAPI = usePost();
	const companiesListAPI = useFetch();

	const [allChecked, setAllChecked] = useState(false);
	const [isChecked, setIsChecked] = useState([]);

	const handleAllCheck = e => {
		if (!allChecked) {
			setIsChecked(studentCvListAPI?.data?.data.map((user) => user.id));
			setAllChecked(true);
		}
		else {
			setIsChecked([]);
			setAllChecked(false);
		}
	};

	const handleSingleCheck = e => {
		if (isChecked.includes(parseInt(e.target.value))) {
			var myIndex = isChecked.indexOf(parseInt(e.target.value));
			if (myIndex !== -1) {
				isChecked.splice(myIndex, 1);
				setIsChecked([...isChecked]);
			}
		}
		else {
			setIsChecked([...isChecked, parseInt(e.target.value)]);
		}
	};
	const handleSingleAssessment = (id) => {
		setIsChecked([...isChecked, parseInt(id)]);
		setAssessmentModal(true);
	};

	const handleStudentRowAPI = async (type, studentProfile) => {

		const user = await getLoggedInUser();
		const formData = new FormData();
		formData.append("campus_id", user.id);
		formData.append("id", studentProfile.id);
		const requestOptions = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
		};
		if (type === "delete_user") {
			studentDeleteAPI.doPost(`${USER_DELETE}`, formData, requestOptions);
		} else if (type == "resend_invitation") {
			resendInvitationAPI.doPost(
				`${RESEND_INVITATION}`,
				formData,
				requestOptions
			);
		} else {
			console.log("view profile");
		}
	};
	const handleImportSubmit = async (file) => {
		const user = await getLoggedInUser();
		const formData = new FormData();
		formData.append("campus_id", user.id);
		formData.append("file", file);
		let token = await getAuthToken();
		const requestOptions = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			headers: { 'Authorization': 'Bearer ' + token }

		};

		doPost(`${USER_IMPORT}`, formData, requestOptions).then((result) => {
			let notify = "";
			if (result.status == "success") {
				notify = notification({
					type: 'success',
					message: result.message,
				});
			}
			else {
				notify = notification({
					type: 'error',
					message: 'Something went wrong',
				});
			}
			notify();
			window.location.reload(false);
		});

		closeImportModal();
	};
	const getUserList = async () => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};
		studentCvListAPI.doFetch(END_POINT + `${STUDENT_LISTING}/${user.id}`, requestOptions);
	};
	useEffect(() => {
		getUserList();
	}, [response, studentDeleteAPI.response, resendInvitationAPI.response,]);
	return (
		<>
			<ImportUserModal
				is_modal={importModal}
				closeModal={closeImportModal}
				handleSubmit={handleImportSubmit}
			/>
			<AddAssessmentModal
				is_modal={AssessmentModal}
				closeModal={closeAssessmentModal}
				isChecked={isChecked}
				alluserlist={studentCvListAPI?.data?.data}
			/>
			<AddExcelModal
				is_modal={ExcelModal}
				closeModal={closeExcelModal}
				alluserlist={isChecked}
			/>

			<div className='main-container position-relative'>
				<div className='container'>
					<div className='row '>
						<div className='col-lg-9'>
							<RecruiterHomeCard> </RecruiterHomeCard>
							<div className='mt-5'>
								<TopCampusesCard></TopCampusesCard>
							</div>
							<div className='mt-5'>
								<div className='bg-white pt-4 pb-4 px-4 rounded-4'>
									<div className='row'>
										<div className='col-md-12'>
											<div className='d-flex justify-content-between w-100 row'>
												<h3 className='text-primary font-bold float-left custom-heading f-r-14  col-7 col-md-9'>Search for Candidates</h3>
												<Link
													className='btn btn-primary btn-sm ps-3 pe-3 col-5 col-md-3 f-r-14'
													to={`/candidateSearch`}
												>
													Start Now
												</Link>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className='bg-white mt-2 rounded-5  pb-2  ps-4 pe-4'>


								<div className='containe bg-white mt-5 rounded-5 pt-3 pb-4  '>

									{/* <div className="d-flex bg-white justify-content-between align-items-center p-4 mt-5 mb-3 rounded-4">
								<h1 className="custom-heading">Send Campus Invitation</h1>
								<NavLink
								to="/send-campus-invite"
								className="btn btn-primary btn-sm ps-4 pe-4 font-bold"
								>
								Start Now
								</NavLink>
							</div> */}

									<div className='row'>
										<div className="col-md-12 mt-1 ">
											<h3 className="text-primary  mb-2 f-Poppins-Medium f-r-18  "> Candidates Upload</h3>
										</div>
										<div className="border-blue1  "></div>
										<div className='col-md-12 '>
											<div className="bg-white  rounded-4 ">

												<div className=" mt-3 rounded-4">
													<div className='row'>
														<div className='col-lg-3 col-12 mb-1'> 		<button
															onClick={showAssessmentModal}
															className="btn btn-primary fs-12  ps-4 pe-4  w-100  poppins-bold"
														>
															Send Assessment
														</button></div>
														<div className='col-lg-3 col-12 mb-1'>
															<button
																onClick={showExcelModal}
																className="btn btn-primary   fs-12 ps-4 pe-4 w-100  poppins-bold"
															>Download Profiles In Excel
															</button>
														</div>
														<div className='col-lg-3 col-12 mb-1'>
															<button
																onClick={showImportModal}
																className="btn btn-primary  fs-12 ps-4 pe-4  w-100  poppins-bold"
															>
																Import Users
															</button>

														</div>
														<div className='col-lg-3 col-12 mb-1'>
															<a href='/view-assessment-result'>
																<button
																	className="btn btn-primary fs-12 btn-sm ps-4 pe-4 font-bold poppins-bold"
																>
																	View Assessment Result
																</button></a>
														</div>
													</div>

												</div>

												<div className="">
													<UserList
														data={studentCvListAPI?.data?.data}
														loading={studentCvListAPI.loading}
														handleStudentRowAPI={handleStudentRowAPI}
														handleSingleCheck={handleSingleCheck}
														handleAllCheck={handleAllCheck}
														handleSingleAssessment={handleSingleAssessment}
														isChecked={isChecked}
													/>
												</div>
											</div>
										</div>
									</div>
								</div>



							</div>
							<div className='bg-white mt-2 rounded-5 pt-3 pb-4 p-2  '>
								<div className='row'>
									<div className='col-md-12  '>
										{/* Tabs */}
										<ul class='nav border-bottom py-1'>
											<li class='nav-item p-0'>
												<NavLink className={`nav-link p-0 fs-20 f-r-14 px-0 me-5 m-e`} to='/recruiter' exact>
													Jobs
												</NavLink>
											</li>
											<li class='nav-item p-0'>
												<NavLink
													activeClassName='text-primary'
													className={`nav-link fs-20 p-0 px-0 f-r-14 me-5 m-e`}
													to='/recruiter/quiz'
													exact
												>
													Quiz
												</NavLink>
											</li>
											<li class='nav-item'>
												<NavLink
													activeClassName='text-primary'
													className={`nav-link fs-20 p-0 px-0 f-r-14 me-5 m-e`}
													to='/recruiter/questions'
													exact
												>
													Questions
												</NavLink>
											</li>
											{/* <li class='nav-item'>
											<NavLink
												activeClassName='text-primary'
												className={`nav-link fs-20 px-0 me-5 m-e`}
												to='/recruiter/testimonials'
												exact
											>
												Testimonials
											</NavLink>
										</li> */}
											<li class='nav-item'>
												<NavLink
													activeClassName='text-primary'
													className={`nav-link fs-20 p-0 px-0 f-r-14 me-5 m-e`}
													to='/recruiter/loi'
													exact
												>
													Letter of Intent
												</NavLink>
											</li>
											<li class='nav-item'>
												<NavLink
													activeClassName='text-primary'
													className={`nav-link fs-20 p-0 f-r-14 px-0 me-5 m-e `}
													to='/recruiter/offer-letters'
													exact
												>
													Offer Letters
												</NavLink>
											</li>
											<li class='nav-item'>
												<NavLink
													activeClassName='text-primary'
													className={`nav-link fs-20 p-0 f-r-14 px-0 me-5 m-e `}
													to='/recruiter/members'
													exact
												>
													Members
												</NavLink>
											</li>
										</ul>
									</div>

									<Route exact path='/recruiter' component={Jobs} />
									<Route path='/recruiter/quiz' component={Quiz} />
									<Route path='/recruiter/questions' component={Questions} />
									<Route path='/recruiter/loi' component={LetterOfIntent} />
									{/* <Route path='/recruiter/testimonials' component={Testimonial} /> */}
									<Route path='/recruiter/members' component={Members} />
									<Route path='/recruiter/offer-letters' component={OfferLetters} />
								</div>
							</div>


							{/* Sidebar */}
						</div>
						<div className='col-lg-3 pt-2 pb-2'>
							<ProfileName />
							<ActionButtons />
							<Company></Company>
						</div>
					</div>
				</div>
			</div>
		</>

	);
};

export default RecruiterHome;
