import React, { useEffect, useState } from "react";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import Loading from "../../../components/common/Loading";
import useFetch from "../../../hooks/useFetch";
import { END_POINT, GET_COMPANY_LISTING, GetTopCampuses } from "../../../routes/api_routes";
import { useHistory } from "react-router";
import { notification } from "../../../classes/messages";
import {
  getCompSubCategory,
  getCompanyCategory,
} from "../../../store/actions/signup";
import { connect } from "react-redux";
import { getAuthToken } from "../../../classes";


const SendCompanyInvite = ({
  comp_category_res,
  getCompanyCategory,
  comp_sub_category_res,
  getCompSubCategory,
}) => {
  const companiesListAPI = useFetch();
  const [selectAllCheck, setSelectAllCheck] = useState(false);
  const [selectedCheckboxList, setSelectedCheckboxList] = useState([]);
  const [companyFilters, setCompanyFilters] = useState({
    name: "",
    location: "",
  });
  const history = useHistory();

  const handleCompanyFilters = (e) => {
    e.preventDefault();
    const ivalue = e.target.value;
    const iname = e.target.name;
    setCompanyFilters({ ...companyFilters, [iname]: ivalue });
  };

  /*const fetchCompSubCategory = (event) => {
    if (event) {
      getCompSubCategory(event.target.value);
    }
  };*/

  async function getCampusListing(filter = {}) {
    let route = `${GetTopCampuses}`;
    if (Object.keys(filter).length) {
      let filterRoute = Object.keys(filter).reduce(
        (accumulator, currentVal) => {
          return (accumulator =
            accumulator + `"${currentVal}":"${filter[currentVal]}", `);
        },
        "?filter={"
      );
      console.log(filterRoute)
      let token = await getAuthToken();

      route = route + filterRoute.substring(0, filterRoute.length - 2) + "}";
      companiesListAPI.doFetch(END_POINT + route);
    }else{
      companiesListAPI.doFetch(END_POINT + route );
    }
  }

  useEffect(() => {
    if (
      companiesListAPI &&
      companiesListAPI.data &&
      companiesListAPI.data.data
    ) {
      
      const checkboxData = companiesListAPI.data.data.map((item) => {
        return {
          id: item.id,
          selected: false,
        };
      });
      setSelectedCheckboxList(checkboxData);
    }
  }, [companiesListAPI?.data]);

  const handleSingleCheckbox = (id) => {
    const checkboxData = selectedCheckboxList.map((checkbox) => {
      if (checkbox.id == id) {
        return {
          ...checkbox,
          selected: !checkbox.selected,
        };
      }
      return checkbox;
    });
    setSelectedCheckboxList(checkboxData);
  };

  const handleSelectAll = (checkValue) => {
    setSelectAllCheck(checkValue);
    if (checkValue) {
      setSelectedCheckboxList((values) =>
        values.map((checkbox) => ({ ...checkbox, selected: true }))
      );
      return;
    }
    setSelectedCheckboxList((values) =>
      values.map((checkbox) => ({ ...checkbox, selected: false }))
    );
  };

  const handleInvite =()=> {
    if(selectedCheckboxList && selectedCheckboxList.some((checkbox) => checkbox.selected == true )) {
      const filteredIds = selectedCheckboxList.filter((checkbox) => checkbox.selected ).map(filterdData => filterdData.id);
      const companyData = companiesListAPI.data.data.filter((data) => filteredIds.includes(data.id));

      history.push({
        pathname: "/send-company-message",
        state: {companyData}
      });
    } else {
      let notify = notification({ message: 'Select company name to send invite', type: 'error' });
			notify();
    }
  }

  const handleSingleInvite = (id) => {
    console.log("in")
    const companyData = companiesListAPI.data.data.filter((data) => data.id == id);
    history.push({
      pathname: "/send-company-message",
      state: {companyData}
    });
  }

  useEffect(() => {
    getCompanyCategory();
    getCampusListing();
  }, []);

  const InvitationList = ({ data, loading }) => {
    console.log(data)
    return (
      <div className="col-md-12 mt-3">
        <div>
          <header className="row bg-primary text-white p-2 rounded-top shadow">
            <div className=" col-1 d-flex justify-content-between align-item-center">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  checked={selectAllCheck}
                  value={selectAllCheck}
                  onChange={() => handleSelectAll(!selectAllCheck)}
                />
              </div>
            </div>
            <div className=" col-4 d-flex justify-content-between align-item-center">
              <span className="f-r-12  d-flex">Campus Name    <i className="fas fa-sort mt-4px ms-2"></i></span>
           
            </div>

            <div className=" col-4 d-flex justify-content-between align-item-center">
              <span className="f-r-12 d-flex"> Location  <i className="fas fa-sort mt-4px ms-2"></i></span>
             
            </div>

            <div className="col-3 d-flex justify-content-between align-item-center"></div>
          </header>
          <main>
            {loading ? (
              <Loading className="my-3" />
            ) : data && data.length ? (
              <>
                {data.map((profile, idx) => {
                  const even = idx % 2 == 0;
                  return (
                    <div
                      key={idx}
                      className={`row align-items-center p-2 ${
                        even ? "bg-light-blue" : "bg-table-striped"
                      }`}
                    >
                      <div className=" col-1 p-0 d-flex justify-content-between align-item-center">
                        <div class="form-check">
                          <input
                            class="form-check-input f-r-12 p-0 mt-1"
                            type="checkbox"
                            checked={
                              selectedCheckboxList &&
                              selectedCheckboxList.length > 0 &&
                              selectedCheckboxList.filter(
                                (checkbox) => checkbox.id === profile.id
                              )[0]?.selected
                            }
                            value={
                              selectedCheckboxList &&
                              selectedCheckboxList.length > 0 &&
                              selectedCheckboxList.filter(
                                (checkbox) => checkbox.id === profile.id
                              )[0]?.id
                            }
                            id={profile?.id}
                            onChange={(e) => {
                              handleSingleCheckbox(e.target.value);
                            }}
                          />
                        </div>
                      </div>
                      <div className="col-4 p-0">
                        <small className="f-r-12">{profile?.campus_name}</small>
                      </div>

                      <div className="col-4 p-0">
                        <small className="f-r-12">{profile?.city +', '+ profile?.state}</small>
                      </div>

                      <div className="col-3  d-flex justify-content-end">
                        <button
                         onClick={() => handleSingleInvite(profile.id)}
                          className="btn f-r-12 btn-primary btn-sm ps-2 pe-2 font-bold poppins-bold"
                        >
                          Send Invite
                        </button>
                      </div>
                    </div>
                  );
                })}
              </>
            ) : (
              <div className="row justify-content-center align-items-center p-4 bg-light-blue">
                <div className="text-center font-bold text-sky-blue">
                  No Campus Found
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    );
  };

  return (
    <div className="main-container position-relative">
      <div className="container">
        <div className="row gx-5">
          <div className="col-lg-9">
            <div className="bg-white mt-5 rounded-5 pt-5 pb-4  ps-4 pe-4">
              <div className="border-bottom-blue pb-3 w-100 border-bottom-bold">
                <div className="d-flex justify-content-between">
                  <h3 className="text-blue font-bold ">Campus List</h3>
                  <button
                    onClick={() => getCampusListing(companyFilters)}
                    className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                  >
                    Filter
                  </button>
                </div>
                <div className="pt-2 ">
                  <div className="row mr-2">
                    {/*<div class="row mb-2">
                      <div class="col-md-12">
                        <label className="f-1">Campus Category</label>
                      </div>
                      <div class="col-md-12">
                        <select
                          className="form-control"
                          name="category"
                          onChange={(e) => {
                            handleCompanyFilters(e);
                            fetchCompSubCategory(e);
                          }}
                          value={companyFilters.category}
                        >
                          <option value="" selected disabled>
                            --Company Category--
                          </option>
                          {comp_category_res?.data &&
                            comp_category_res?.data.map((opt) => {
                              return (
                                <option value={opt.id} key={opt.id}>
                                  {opt.title}
                                </option>
                              );
                            })}
                        </select>
                      </div>
                    </div>

                    <div class="row mb-2 ml-1">
                      <div class="col-md-12">
                        <label className="f-1">Campus Sub Category</label>
                      </div>
                      <div class="col-md-12">
                        <select
                          className="form-control"
                          name="sub_category"
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters.sub_category}
                        >
                          <option value="" selected disabled>
                            --Company subCategory--
                          </option>
                          {comp_sub_category_res?.data &&
                            comp_sub_category_res?.data.map((opt) => {
                              return (
                                <option value={opt.id} key={opt.id}>
                                  {opt.title}
                                </option>
                              );
                            })}
                        </select>
                      </div>
                    </div>*/}
                    <div className="col-md-4 mb-2"></div>
                    <div className="col-md-4 mb-2">
                      <div className="col-md-12">
                        <label>Campus Name</label>
                      </div>
                      <div className="col-md-12">
                        <input
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters?.name}
                          type="text"
                          className="form-control"
                          name="name"
                        />
                      </div>
                    </div>
                    <div className="col-md-4 mb-2">
                      <div className="col-md-12">
                        <label>Location</label>
                      </div>
                      <div className="col-md-12">
                        <input
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters?.location}
                          type="text"
                          className="form-control"
                          name="location"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between align-items-end mt-5">
                <div className="text-blue font-bold">Select All</div>
                <button
                  onClick={handleInvite}
                  className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                >
                  Send Invite
                </button>
              </div>
              <InvitationList
                data={companiesListAPI?.data?.data}
                loading={companiesListAPI?.loading}
              />
            </div>
          </div>
          <div className="col-lg-3 pt-2 pb-2">
            <ProfileName />
            <ActionButtons />
            <Company></Company>
          </div>
        </div>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => {
  const { comp_category_res, comp_sub_category_res } = state.common;
  return {
    comp_category_res,
    comp_sub_category_res,
  };
};

function mapDispatchToProps(dispatch) {
  return {
    getCompanyCategory: () => dispatch(getCompanyCategory()),
    getCompSubCategory: (id) => dispatch(getCompSubCategory(id)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SendCompanyInvite);
