import React, { useEffect, useState } from 'react';
import IntroSideBar from '../../../components/SelectPlan/introSide';
import { Link, NavLink } from 'react-router-dom';
import FeatureCard from '../../../components/ExpendPlan/FeatureCard';
import { END_POINT, Get_feature } from '../../../routes/api_routes';
import { useSelector } from 'react-redux';
import { notification } from '../../../classes/messages';
import { getLoggedInUser } from '../../../classes';
import { Recruiter_User_Type_ID, Candidate_User_Type_ID, Campus_User_Type_ID } from '../../../config/constants';
import { getCurrPlanFeatures } from '../../../store/actions/Plans';
import { getAuthToken } from '../../../classes';

const ExpendPlan = ({ match, history }) => {
	const [features, setFeatures] = useState([]);
	const [totalPrice, setTotalPrice] = useState(0);
	const [previousprice, setpreviousprice] = useState(0);
	const [previousIndex, setpreviousIndex] = useState(0);
	const [ISUpgrade, setISUpgrade] = useState(false);
	const [CurrPlanFeatures, setCurrPlanFeatures] = useState([]);
	const { SelectedFeature } = useSelector((state) => state.common);
	let [plan, setPlan] = useState({});
	let [user, setuser] = useState([]);

	useEffect(async () => {
		const localPlan = JSON.parse(localStorage.getItem('PLAN'));
		setPlan(localPlan);
		let user = await getLoggedInUser();

		setuser(user);

		if (match.params?.current) {
			setISUpgrade(true);

			const data = {
				'plan_id': match.params?.id,
				'user_id': user.id
			}
			let curr = await getCurrPlanFeatures(data);

			if (curr.status == 'success') {
				setCurrPlanFeatures(JSON.parse(curr?.data));
			}
			else {
				const notify = notification({ message: curr.message, type: 'error' });
				notify();
				history.push('/campus-plans');
			}
		}
		let token = await getAuthToken();
		const response = await fetch(END_POINT + `${Get_feature}/${match.params.id}`, {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		setFeatures(json.data);
	}, []);

	useEffect(() => {
		let newFeature = features.map((feature) => {
			if (feature.feature_id == SelectedFeature.feature_id) {
				return {
					...feature,
					selectedPriceIndex: SelectedFeature.selectedPriceIndex,
				};
			} else {
				let index = feature.selectedPriceIndex == undefined ? 0 : feature.selectedPriceIndex;
				return {
					...feature,
					selectedPriceIndex: index,
				};
			}
		});
		setFeatures(newFeature);
	}, [SelectedFeature]);

	useEffect(() => {

		if (previousprice == 0 && CurrPlanFeatures.length != 0) {
			let totalPrice =
				features.length >= 1 &&
				features.reduce((acc, current) => {
					let curfeatureindex = CurrPlanFeatures.findIndex((cur) => {
						return cur.feature_id == current.feature_id;
					});
					let curfeaturepriceindex = current.pricing.findIndex((cur) => {
						return cur.price == CurrPlanFeatures[curfeatureindex].ammount;
					});
					current.selectedPriceIndex = curfeaturepriceindex;

					let index = current.selectedPriceIndex == undefined ? 0 : current.selectedPriceIndex;
					if (current.pricing[index].price !== 'free') {
						return acc + Number(current.pricing[curfeaturepriceindex].price);
					}
					return acc;
				}, 0);

			setTotalPrice(totalPrice);
			setpreviousprice(totalPrice);
		}
		else {

			let totalPriceinit = 0;
			let totalPrice =
				features.length >= 1 &&
				features.reduce((acc, current) => {


					if (current.selectedPriceIndex == undefined) {
						let value = parseInt(current.current);
						const sortedPricing = current.pricing.length >= 1 && current.pricing.sort((a, b) => a.max_range - b.max_range);
						if (sortedPricing.length > 0) {
							sortedPricing.find((price, i) => {
								if (value == parseInt(price.max_range)) {
									current.selectedPriceIndex = i;
									return acc + Number(current.pricing[i].price);
								}
							});
						}
						return acc;
					}
					else {
						let index = current.selectedPriceIndex == undefined ? 0 : current.selectedPriceIndex;
						if (current.pricing[index].price !== 'free') {
							return acc + Number(current.pricing[index].price);
						}
						return acc;
					}
				}, 0);

			setTotalPrice(totalPrice);

		}



	}, [features]);

	const onCheckout = async () => {
		const user = await getLoggedInUser();
		const featuresToSend = features.map((feature) => {
			const index = !feature.hasOwnProperty('selectedPriceIndex')
				? 0
				: feature.selectedPriceIndex;
			return {
				feature_id: feature.feature_id,
				feature_title: feature.feature_name,
				quantity: feature.pricing[index].max_range,
				ammount: feature.pricing[index].price,
			};
		});

		const formdata = new FormData();
		formdata.append('user_id', user.id);
		if (ISUpgrade) {
			formdata.append('plan_id', match.params?.id);
			formdata.append('expand', 1);
		}
		else
			formdata.append('plan_id', plan.id);
		formdata.append('amount', (ISUpgrade ? totalPrice - previousprice : totalPrice));
		formdata.append('payment_status', '1');
		formdata.append('json_data', JSON.stringify(featuresToSend));
		let token = await getAuthToken();

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'select_plan', requestOptions)
			.then((response) => response.json())
			.then((data) => {
				if (data.status == 'success') {

					localStorage.setItem('plan_temp_id', data.data.temp_id);
					localStorage.setItem('selected_plan_id', data.data?.id);
					const notify = notification({ message: data.message, type: 'success' });
					notify();
					localStorage.setItem('PLAN_TOTAL_PRICE', (ISUpgrade ? totalPrice - previousprice : totalPrice));
					/* save address */
					localStorage.setItem('BILLING-ADRESS', JSON.stringify(data.data?.billing_address));

					if (user.user_type == Recruiter_User_Type_ID) {
						history.push('/checkout');
					}
					else if (user.user_type == Candidate_User_Type_ID) {
						history.push('/candidatecheckout');
					}
					else if (user.user_type == Campus_User_Type_ID) {
						history.push('/campus-checkout');
					}
					/* save address */


				} else {
					data.message.forEach((e) => {
						const notify = notification({ message: e, type: 'error' });
						notify();
					});
				}
			})
			.catch((error) => { });
	};

	return (


		<div className='pe-lg-7 px-lg-0 px-md-8 px-sm-5 px-3 mt-26px'>

			<div className='row'>
				{/* <div className='col-lg-4'>
					<div className>
						<IntroSideBar></IntroSideBar>
					</div>
				</div> */}
				<div className='col-lg-12 my-lg-0 my-4 ps-lg-5 pb-6'>
					<div className='bg-light-blue vh- bg-no-repeat bg-40-size'>
						<header className='d-flex justify-content-between mb-4'>

							<h4>Select the items you want to expand</h4>
							<NavLink to={user.user_type !== Candidate_User_Type_ID ? '/plans' : '/candidate-plans'} class='h5'>

								Select Plan
							</NavLink>
						</header>
						<div className='row'>
							<div className='row'>
								{features &&
									features.map((feature, i) => {
										return (
											<FeatureCard index={i} featuresArray={features} feature={feature} currentPlanFeature={CurrPlanFeatures[i]} ISUpgrade={ISUpgrade} />
										);
									})}
							</div>
						</div>
						<footer className='d-flex justify-content-between align-items-center mt-3'>
							<h4 className='text-primary fw-bold d-flex'>
								Total Amount: <h6 className='ms-1'>₹</h6>
								{/* {totalPrice}-{previousprice}- */}
								{(ISUpgrade ? totalPrice - previousprice : totalPrice)}
							</h4>
							<button
								className='btn btn-primary'
								onClick={() => {
									onCheckout();
								}}
							>
								Proceed To Checkout
							</button>
						</footer>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ExpendPlan;