import React, { Component } from 'react';
import { reSetLoggedInUser } from '../../../classes';

import Header from '../../../components/common/Header';



import Company from '../../../components/Contact/Company';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';
import SideBar from '../../../components/hoc/SideBar';

import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';

class Thanku extends Component {

    componentDidMount() {

        let plan = JSON.parse(localStorage.getItem('PLAN'));

        if (plan) {
            reSetLoggedInUser({ plan_id: plan.id });
            localStorage.setItem('selected_plan_id', null);
            localStorage.setItem('PLAN_TOTAL_PRICE', null);
            localStorage.setItem('SELECTED-BILLING-ADDRESS', null);
            localStorage.setItem('PLAN', null);
            localStorage.setItem('BILLING-ADRESS', null);
        }

    }

    render() {

        return (


            <>
                <Section>
                    <Main>
                        {/* Content */}
                        <div className="col-md-9 p-0">
                            <div className="row">
                                <div className="col-md-12">
                                    <img className="img-fluid me-auto ms-auto d-block" src="/assets/imgs/thanku.PNG" alt="THANKU" />
                                </div>
                            </div>

                        </div>
                        {/* Content */}
                    </Main>

                    {/* Sidebar */}

                    <SideBar>
                        <ProfileName />
                        <ActionButtons />
                        <Company />
                    </SideBar>

                    {/* Sidebar */}

                </Section>
            </>

        );
    }

}

export default Thanku;