import React, { useEffect, useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import { getLoggedInUser, isJson, getAuthToken, isCampus } from '../../../classes/index';
import { CREATE_ACCESS_LEVEL, END_POINT, GET_ACCESS_LEVEL, UPDATE_ACCESS_LEVEL } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import Loading from '../../../components/common/Loading';
import useFetch from '../../../hooks/useFetch';

const AddAccessLevel = ({ history }) => {

	const { data, loading, error, doFetch } = useFetch();

	const [level_name, setLevelName] = useState('');
	const [json, setAccessJson] = useState({});
	const [user, setUser] = useState(null);
	const [postloading, setPostLoading] = useState(false);
	const [edit_id, setEditId] = useState(null);

	useEffect(async () => {
		const result = await getLoggedInUser();
		setUser(result);
		if(result?.company_id) {
			getAccessLevels(`company_id=${result.company_id}`);
		} else {
			getAccessLevels(`campus_id=${result.id}`)
		}
	}, []);

	const getAccessLevels = (param) => {
		doFetch(END_POINT + GET_ACCESS_LEVEL + '?' + param);
	}

	const setAccessLevel = async (e) => {
		if (e.target.checked == true) {
			json[e.target.name] = true;
		} else {
			json[e.target.name] = false;
		}
		setAccessJson(json);
	}

	const editAccessLevel = async (obj) => {

		setEditId(obj.id);
		setLevelName(obj.name);
		if (obj.json) {
			setAccessJson(JSON.parse(obj.json));
		}

	}



	const handleOnSave = async (e) => {
		e.preventDefault();
		let API_URI;
		if (edit_id != null) {
			API_URI = UPDATE_ACCESS_LEVEL
		} else {
			API_URI = CREATE_ACCESS_LEVEL;
		}
		setPostLoading(true);
		const formdata = new FormData();
		let token = await getAuthToken();

		if (user) {

			formdata.append('level_name', level_name);
			formdata.append('json', JSON.stringify(json));
			if(isCampus()) {
				formdata.append('campus_id', user.id);
			}else {
				formdata.append('user_id', user.id);
				formdata.append('company_id', user.company_id);
			}
			if (edit_id != null) {
				formdata.append('access_level_id', edit_id);
			}
			let token = await getAuthToken();
			const requestOptions = {
				method: 'POST',
				body: formdata,
				redirect: 'follow',
				headers: {
					'Authorization': 'Bearer ' + token
				}
			};

			if (API_URI) {
				fetch(END_POINT + API_URI, requestOptions)
					.then((response) => response.json())
					.then((data) => {
						if (data.status == 'success') {
							let notify = notification({ message: data.message, type: 'success' });
							notify();
							setEditId(null);
							setLevelName('');
							setAccessJson({});
							if(user?.company_id)
							getAccessLevels(`company_id=${user.company_id}`)
							else
							getAccessLevels(`campus_id=${user.id}`)
							//history.push('/recruiter');
						} else {
							if (isJson(data.message)) {
								data.message.forEach((element) => {
									let notify = notification({ message: element, type: 'error' });
									notify();

								});
							} else {
								let notify = notification({ message: data.message, type: 'error' });
								notify();
							}
						}


						setPostLoading(false);
					})
					.catch((error) => console.log('error', error));
			}

		}
	};

	return (
		<Section>
			<Main>
			<div className=''>
			<header className='border-bottom border-primary py-2 border-2'>
					<h4>Add Access Level </h4>
				</header>
				<main className='mt-4'>

					<form onSubmit={(e) => handleOnSave(e)}>
						<div className="w-80  w-100-xs ">
							<div class='mb-3'>
								<label for='exampleFormControlInput1' class='form-label'>
									Name
								</label>
								<input
									type='text'
									class='form-control'
									id='exampleFormControlInput1'
									value={level_name}
									name="level_name"
									onChange={(e) => setLevelName(e.target.value)}
									required={true}
								/>
							</div>


							{/* permissions */}

							<div class='mb-3 d-flex'>

								<label for='exampleFormControlInput1' class='form-label'>
									<p className="font-bold">Add Quiz</p>
									<p>Lorem ipsum ipsum</p>
								</label>

								<div class="form-check form-switch ms-auto">
									<input class="form-check-input ms-0" checked={json?.add_quiz} type="checkbox" id="flexSwitchCheckChecked" name="add_quiz" onChange={(e) => setAccessLevel(e)} />
								</div>
							</div>

							{/* permissions */}

							{/* permissions */}

							<div class='mb-3 d-flex'>
								<label for='exampleFormControlInput1' class='form-label'>
									<p className="font-bold">Add Job</p>
									<p>Lorem ipsum ipsum</p>
								</label>

								<div class="form-check form-switch ms-auto">
									<input class="form-check-input ms-0" checked={json?.add_job} type="checkbox" id="flexSwitchCheckChecked" name="add_job" onChange={(e) => setAccessLevel(e)} />
								</div>
							</div>

							{/* permissions */}
							<div className="d-flex">
								<button
									type='submit'
									className='btn btn-primary btn-sm px-5 ms-auto'
									disabled={postloading}
								>
									{postloading ? <Loading /> : 'Save'}
								</button>
							</div>
						</div>

						<div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-3 mb-3 f-0-9"></div>

						{/* access level lists */}
						<h4 className="text-primary">Edit Access Level</h4>

						{loading == true && <Loading />}

						{console.log(data)}

						{data != null && data?.data?.map((access) => {

							return <div className="w-80 mt-2">
								<div class='mb-3 d-flex'>

									<p className="font-bold">{access.name}</p>

									<button
										type='button'
										className='btn btn-outline-primary btn-sm px-5 ms-auto float-end'
										onClick={(e) => { editAccessLevel(access) }}
									>
										Edit
									</button>
								</div>
							</div>

						})}

						{/* access level lists */}

					</form>
				</main>
			</div>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default AddAccessLevel;
