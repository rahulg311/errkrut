import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';

import { connect } from 'react-redux';
import JobsList from '../../../components/Cards/JobsList';
import { getSkills } from '../../../store/actions/skills';
import LocationsMulti from '../SearchUi/LocationsMulti';
import Loading from '../../../components/common/Loading';
import { SEARCH_DATA } from '../../../config/constants';
import { searchDetail, searchUpdate } from '../../../store/actions/search';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import { getLoggedInUser } from '../../../classes';

class Search extends Component {

	state = {
		jobs: [],
		filters: {
			title: null,
			company: null,
			skill: null,
			designation: null,
			location: null,
			order_by_date: null,
			filter_date: null,
			title: null,
			page_num: 0,
			limit_page: 200,
			experience: null,
			text: this.props.match.params?.term,
			company_id: null
		},
		skills: null,
		loader: false
	}

	componentWillMount = async () => {
		this.getSkills();
		this.getJobs(this.state.filters);
		let user = await getLoggedInUser();
		this.setState({
			filters: {
				...this.state.filters,
				company_id: user?.company_id
			}
		});
	}

	componentDidUpdate() {
		if (this.props.search_data) {
			this.props.searchUpdate('');
			this.getJobs({ text: this.props.search_data, company_id: this.state.filters?.company_id });
		}
	}

	handleChange = (e) => {
		this.setState({
			text: this.props.match.params?.term,
			filters: {
				...this.state.filters,
				[e.target.name]: e.target.value
			}
		});
	}

	filterJobs = () => {
		this.getJobs(this.state.filters);
	}

	getJobs = async (obj) => {

		this.setState({
			loader: true
		});

		await this.props.searchDetail(obj);

		if (this.props.search_res != '') {
			this.setState({
				loader: false,
				jobs: this.props.search_res?.data
			});
		}

	}


	getSkills = async () => {

		await this.props.getSkills('filter');

		if (this.props.skills_filter?.status == 'success') {
			this.setState({
				skills: this.props.skills_filter.data
			});
		}

	}


	render() {

		return (
			<div>
				<Section>
					<Main>

						{/* filters */}
						<div className='d-flex mt-3 mb-4 align-items-center'>
							<div className=''>
								{/*<h5 className="text-blue">{this.props.match.params?.term}</h5>*/}
							</div>
						</div>
						{/* align-items-start d-flex flex-wrap ms-auto */}
						<div className=' row p-2 mb-3'>
							<div className='col-lg-2 me-1 col-12  p-0'>

							</div>
							<div className='col-lg-2 me-1 col-5 mb-1  p-0'>
								{/* experience */}
								<select
									class='form-select  form-select-sm text-primary f-0-8'
									aria-label='Default select example'
									onChange={this.handleChange}
									name="experience"
								>
									<option selected value="" >Any Experience</option>
									<option value='1-3'>1-3 Years</option>
									<option value='4-6'>4-6 Years</option>
									<option value='7-10'>7-10 Years</option>
									<option value='11-15'>11-15 Years</option>
									<option value='15-'>15+ Years</option>
								</select>
								{/* experience */}
							</div>
							<div className='col-lg-2 me-1 col-5 mb-1  p-0'>
								{/* locations */}
								<LocationsMulti
									handleChange={this.handleChange}
								/>
								{/* locations */}
							</div>
							<div className='col-lg-2 me-1 col-5 mb-1 p-0'>
								{/* skills */}
								{console.log(this.state.skills)}
								<select
									class='form-select   form-select-sm text-primary f-0-8'
									aria-label='Default select example'
									onChange={this.handleChange}
									name="skill"
								>
									<option value="">Skills</option>
									{this.state.skills && Object.keys(this.state.skills).map((k) => {
										return <option value={this.state.skills[k]}>{this.state.skills[k]}</option>
									})
									}
								</select>
								{/* skills */}
							</div>
							<div className='col-lg-2 me-1 col-5 mb-1'>
								{/* job types */}
								<select
									class='form-select  form-select-sm text-primary f-0-8'
									aria-label='Default select example'
									onChange={this.handleChange}
									name="order_by_date"
								>
									<option value="featured">Featured</option>
									<option value="desc">Latest</option>
									<option value="asc">Older</option>
								</select>
								{/* job types */}
							</div>
							<div className='col-lg-1  col-1  p-0'>

								<button type='button' class='btn btn-primary btn-sm' onClick={(e) => this.filterJobs()}>
									<i class="las la-filter f-1"></i>
								</button>
							</div>

						</div>

						{/* filters */}

						{/* jobs list */}
						{this.state.loader &&
							<div className='mt-2'>
								<Loading />
							</div>
						}

						{(this.state.jobs?.length > 0) ?
							<JobsList title='' jobs={this.state.jobs} />
							:
							<h5 className="text-blue text-center">No Jobs Found. Please try with different search.</h5>
						}

						{/* jobs list */}

					</Main>
					<SideBar>
						<ProfileName />
						<ActionButtons />
						<CandidateCards />
						<Skills />
						<FeaturedCompanies />
						<Designations />
						<Locations />
						<Company />
					</SideBar>
				</Section>
			</div>
		);
	}
}


const mapStateToProps = (state) => {

	const { data, location_res, skills_filter, search_data, search_res } = state.common;

	return {
		data,
		location_res,
		skills_filter,
		search_data,
		search_res
	}
};

function mapDispatchToProps(dispatch) {
	return {
		searchDetail: (formData) => dispatch(searchDetail(formData)),
		getSkills: (type) => dispatch(getSkills(type)),
		searchUpdate: (data) => dispatch(searchUpdate(data)),
	};
}


export default connect(mapStateToProps, mapDispatchToProps)(Search);