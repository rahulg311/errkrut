import React, { useEffect, useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes/index';
import { END_POINT } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/common/Loading';

const AddOfferLetter = ({ match }) => {
	const {
		data,
		loading: getDataLoading,
		error,
	} = useFetch(`https://beta.api.erekrut.in/api/edit_offer_letter/${match.params.id}`);
	const [title, setTitle] = useState('');
	const [content, setContent] = useState('');
	const [isCheck, setIsCheck] = useState('');
	const [loading, setLoading] = useState(false);

	const handleOnSave = async () => {
		setLoading(true);
		const result = await getLoggedInUser();
		const formdata = new FormData();
		formdata.append('id', match.params.id);
		formdata.append('user_id', result.id);
		formdata.append('title', title);
		formdata.append('content', content);
		formdata.append('radio_check', isCheck);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
		};

		fetch(END_POINT + 'update_offer_letter', requestOptions)
			.then((response) => response.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({
						message: 'Offer Letter Updated Successfully',
						type: 'success',
					});
					notify();
					setLoading(false);
				} else {
					data.message.forEach((element) => {
						let notify = notification({ message: element, type: 'error' });
						notify();
						setLoading(false);
					});
				}
			})
			.catch((error) => console.log('error', error));
	};

	useEffect(() => {
		if (data?.data) {
			const result = data?.data;
			setTitle(result.job_offer_title);
			setContent(result.job_offer_content);
			setIsCheck(result.enable_print_and_pdf);
		}
	}, [data]);

	return (
		<div className='container mt-4 '>
			<section className='row'>
				<section className='col-md-8 bg-white px-5 py-4 rounded-3'>
					<header className='border-bottom border-primary py-2 border-2'>
						<h4>Edit Offer Letter</h4>
					</header>
					{getDataLoading ? (
						<Loading />
					) : (
						<main className='mt-4'>
							<div class='mb-3'>
								<label for='exampleFormControlInput1' class='form-label'>
									Job Offer Title
								</label>
								<input
									type='email'
									class='form-control'
									id='exampleFormControlInput1'
									value={title}
									onChange={(e) => setTitle(e.target.value)}
								/>
							</div>
							<div class='mb-3'>
								<label for='exampleFormControlTextarea1' class='form-label'>
									Offer Letter Content
								</label>
								<textarea
									class='form-control'
									id='exampleFormControlTextarea1'
									rows='3'
									value={content}
									onChange={(e) => setContent(e.target.value)}
								></textarea>
							</div>
							<div class='mb-3'>
								<div className='d-flex justify-content-between'>
									<label class='form-check-label' for='flexSwitchCheckChecked'>
										Enable Print & Pdf
									</label>
									<div class='form-check form-switch'>
										<input
											class='form-check-input'
											type='checkbox'
											role='switch'
											id='flexSwitchCheckChecked'
											value={isCheck}
											checked={isCheck}
											onChange={(e) => setIsCheck(e.target.checked)}
										/>
									</div>
								</div>
								<small className='mt-1'>
									Display Print and download option on the top right corner of the certificate
								</small>
							</div>
							<div className='text-end mt-5'>
								<button
									className='btn bg-primary text-white px-5'
									disabled={loading}
									onClick={() => handleOnSave()}
								>
									{loading ? (
										<div className='spinner-border spinner-border-sm' role='status'></div>
									) : (
										'Save'
									)}
								</button>
							</div>
						</main>
					)}
				</section>
				<section className='col-md-4 mt-md-0 mt-5'>
					<section className='px-5'>
						<ProfileName></ProfileName>
						<div className='d-flex align-items-center flex-wrap mt-3'>
							<Option title='Add job' styleClasses='bg-primary text-light me-2 mb-2' />
							<Option title='Add Quiz' styleClasses='bg-danger text-light me-2 mb-2' />
							<Option title='Add question' styleClasses='bg-warning me-2 mb-2' />
							<Option title='Create Offer Letter' styleClasses='bg-primary text-light mb-2' />
						</div>

						<div className='my-2'>
							<p className='fs-18'>Want to reach out more candidates?</p>
							<Link to='#'>Click Here</Link>
						</div>
						<Company></Company>
					</section>
				</section>
			</section>
		</div>
	);
};

export default AddOfferLetter;
