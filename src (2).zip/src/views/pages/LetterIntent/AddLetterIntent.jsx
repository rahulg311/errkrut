import React, { useEffect, useState } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link } from 'react-router-dom';
import { getLoggedInUser, MimeIcon, getAuthToken } from '../../../classes/index';
import { CREATE_LOI, EDIT_LOI, END_POINT, UPDATE_LOI } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';

const AddLetterIntent = ({ history, match }) => {
	const [title, setTitle] = useState('');
	const [content, setContent] = useState('');
	const [intentFiles, setFiles] = useState('');
	const [loading, setLoading] = useState(false);
	const [fileName, setFileName] = useState('');
	const [editId, setEditId] = useState(null);
	const [editFile, setEditFile] = useState(null);

	useEffect(() => {
		getLoi(match.params?.id);
	}, []);

	const getLoi = async (id) => {
		if (id) {
			let token = await getAuthToken();

			const requestOptions = {
				method: 'GET',
				redirect: 'follow',
				headers: {
					'Authorization': 'Bearer ' + token
				}
			};

			fetch(END_POINT + EDIT_LOI + '/' + id, requestOptions)
				.then((response) => response.json())
				.then((res) => {
					if (res?.status == 'success') {
						setLoading(false);
						setEditId(res?.data?.id);
						setTitle(res?.data?.title);
						setContent(res?.data?.content);
						setEditFile(res?.data?.file);
					} else {
						res?.message.forEach((element) => {
							let notify = notification({ message: element, type: 'error' });
							notify();
							setLoading(false);
						});
					}
				})
				.catch((error) => console.log('error', error));
		}
	}

	const handleOnSave = async () => {
		setLoading(true);
		const result = await getLoggedInUser();
		let token = await getAuthToken();
		const formdata = new FormData();

		formdata.append('user_id', result.id);
		formdata.append('company_id', result.company_id);
		formdata.append('title', title);
		formdata.append('content', content);
		formdata.append('file', intentFiles);

		const requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		};

		let uri = null;
		if (editId) {
			uri = UPDATE_LOI;
			formdata.append('id', editId);
		} else {
			uri = CREATE_LOI;
		}

		fetch(END_POINT + uri, requestOptions)
			.then((response) => response.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({ message: data.message, type: 'success' });
					notify();
					setLoading(false);
					history.push('/recruiter/loi');
				} else {
					data.message.forEach((element) => {
						let notify = notification({ message: element, type: 'error' });
						notify();
						setLoading(false);
					});
				}
			})
			.catch((error) => console.log('error', error));
	};

	return (
		<Section>

			<Main>
				<section className='col-md-12 bg-white px-2 py-2 rounded-3'>
					<header className='border-bottom border-primary py-2 border-2'>
						{editId && <h4>Edit Letter of Intent</h4>}
						{editId == null && <h4>Add Letter of Intent</h4>}
					</header>
					<main className='mt-4'>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Title
							</label>
							<input
								type='text'
								class='form-control'
								onChange={(e) => setTitle(e.target.value)}
								defaultValue={title}
							/>
						</div>
						<div class='mb-3'>
							<label for='exampleFormControlTextarea1' class='form-label'>
								Content
							</label>
							<textarea
								class='form-control'
								rows='3'
								onChange={(e) => setContent(e.target.value)}
							>{content}</textarea>
						</div>
						<div class='mb-3'>
							<div className='d-flex justify-content-between'>

								<label className="btn btn-primary btn-sm" for={`intentfile`} type="button">
									<span className="vertical-middle">Select File</span>
									<i class="las la-file-export f-1-1 vertical-middle"></i>
								</label>

								<input type="file" style={{ display: "none" }} id={`intentfile`} multiple onChange={(e) => {
									setFiles(e.target.files[0]);
									setFileName(e.target.files[0]?.name);
								}} />

								{fileName && <p> {fileName} </p>}

								{editFile && <a className='f-1' href={editFile} target={`_blank`}>{MimeIcon(editFile)} View</a>}
							</div>

						</div>
						<div className='text-end mt-5'>
							<button
								className='btn bg-primary text-white px-5'
								disabled={loading}
								onClick={() => handleOnSave()}
							>
								{loading ? (
									<div className='spinner-border spinner-border-sm' role='status'></div>
								) : (
									'Save'
								)}
							</button>
						</div>
					</main>
				</section>
			</Main>

			<SideBar>
				<ProfileName />
				<ActionButtons />
				<Company />
			</SideBar>

		</Section>
	);
};

export default AddLetterIntent;
