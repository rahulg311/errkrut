import React, { Component, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { errorPrettifyObjArr, getLoggedInUser } from '../../../classes';
import { getCities } from '../../../store/actions/jobs';
import JDForm from './JDForm';
import SkillsSelect from './SkillsSelect';
import { END_POINT, GET_CITIES } from "../../../routes/api_routes";
import Select from 'react-select';


let ci = [{ data: ['Mirpet', 'Mirganj', 'Chirmiri', 'Miramar',] }]
let node;
let dcity = [];
class JobForm extends Component {

    state = {
        flag: 0,
        cities: [{}],
        ncity: [],
        selectedcity: [],
    };
    setJDForm = (value) => {
        if (this.props.is_jd_form == false)
            this.props.handleChange({ target: { name: 'job_description', value: '' } })
        this.props.setDescForm();
    }

    async componentWillMount() {
        const user = await getLoggedInUser();
        if(user.recruitment_agency == "yes"){
            this.setState({recruitment_agency : true});
        }else{
            this.setState({recruitment_agency : false});
        }
    }

    changecity = async (cities) => {
        let selectedcity = [];
        let selectedcityname = [];
        cities.map((city) => {
            selectedcity.push(city.value);
            selectedcityname.push(city.label);
        });
        this.setState({ selectedcity: cities });
        this.props.handleChange({ target: { name: 'jobCityLoc', value: selectedcityname.join() } })
    }
    getCities = async (e) => {
        
        const formData = new FormData();
        formData.append("country_id", e.target.value);
        const requestOptions = {
            body: formData,
            method: "POST",
        };
        fetch(END_POINT + `${GET_CITIES}`, requestOptions)
            .then((response) => response.json())
            .then((data) => {
                if (data.status === 'success') {
                    let citylist = [];
                    data?.data.map((p) => {
                        citylist.push({ "value": p.name, "label": p.name })
                    })
                    this.setState({ ncity: citylist });
                    this.setState({
                        cities: data?.data,
                    });
                }
            })
            .catch((error) => { });
    }


    render() {

        const { handleChange, step1Submit, errors, formData, selectTemplate, jobTypeDetails, getJobDescriptions, subCategory, stateDetails, cityDetails, jobcityDetails, addLogo, getProbableCandidate } = this.props;
        //console.log(formData)
        dcity = [];
        formData?.jobCityLoc?.split(',').map((citydata) => {
            dcity.push({ "value": citydata, "label": citydata })
        });
        if (this.state.flag == 0 && dcity.length != 0) { this.setState({ flag: 1, selectedcity: dcity }) }

        return (
            <>

                <form method="POST" action="" onSubmit={(e) => step1Submit(e)}>
                    <div className="bg-white br-5">
                        <div>

                            <h4 className="text-blue">{(formData.edit_id) ? `Edit Job` : `Add Job`}</h4>
                            <div className="border-gray-line mt-2 mb-2"></div>

                            {/* form starts here */}

                            <div>Probable Candidate: {formData.probableCandidatesVal?.total}</div>

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs  ">
                                <div className="col-md-12">

                                    <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "Job Type is Required"); jobTypeDetails(e); }} name="feature_id" required>
                                        <option value="" selected disabled>
                                            --Select Job Type--
                                        </option>

                                        {formData.job_types && formData.job_types.map((p) => {
                                            return <option datatype={p.feature_detail_id} value={p.feature_id} selected={(formData.feature_id == p.feature_id) ? true : false}>
                                                {p.name}
                                            </option>
                                        })}

                                    </select>

                                </div>
                            </div>
                            {/* fields ends here */}


                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs  ">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Use Template
                                    </label>

                                    {(formData.job_type_details?.detailed_job_description == "Template Based") && <div className="ms-auto d-table mt-auto mb-auto float-end">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="use_template" onChange={(e) => handleChange(e)} />
                                        </div>
                                    </div>}
                                </div>


                                <div className="col-md-12">

                                    <select disabled={!formData.use_template} className="form-select form-select-md mb-3 input-border" onChange={(e) => selectTemplate(e, "", "")} name="job_template">

                                        <option value="" selected disabled>
                                            --Select Template--
                                        </option>

                                        {formData.template?.length > 0 && formData.template.map((p) => {
                                            return <option value={p.id} selected={(formData.job_template == p.id) ? true : false}>
                                                {p.job_title} ({p.designation})
                                            </option>
                                        })}
                                    </select>
                                </div>

                                { (formData.job_type_details?.detailed_job_description != "Template Based") && <div className='f-r-14 p-0 ps-1'>want to unlock this feature? <span className='text-blue f-r-14'><NavLink to="/plans">Upgrade Plan</NavLink></span></div> }
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs  ">
                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job title
                                    </label>
                                </div>
                                <div className="col-md-12">
                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onChange={(e) => handleChange(e, "required", "Job Title Should be Letters Only")}
                                        name='job_title'
                                        defaultValue={formData.job_title}
                                        required
                                    />

                                    {errors['job_title'] != '' && <p className="text-danger">{errors['job_title']}</p>}
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs  ">

                                <div className="col-md-6">
                                    <div className="row mt-2">
                                        <div className="col-md-12">

                                            <label className="text-dark">
                                                Job Type
                                            </label>

                                            <select className="form-select form-select-md input-border mt-1" onChange={(e) => handleChange(e, "letters_only", "Job Type Should Letters Only")} name="job_type" required>
                                                <option value="">
                                                    --Select Job Type--
                                                </option>
                                                <option value="work_from_home" selected={(formData.job_type == 'work_from_home') ? true : false}>
                                                    Work From Home
                                                </option>
                                                <option value="hybrid" selected={(formData.job_type == 'hybrid') ? true : false}>
                                                    Hybrid
                                                </option>
                                                <option value="work_from_office" selected={(formData.job_type == 'work_from_office') ? true : false}>
                                                    Work From Office
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="row mt-2">
                                        <div className="col-md-12">

                                            <label className="text-dark">
                                                Employment Type
                                            </label>

                                            <select className="form-select form-select-md input-border mt-1" onChange={(e) => handleChange(e, "letters_only", "Nature of Employment Should Letters Only")} name="nature_of_employment" required>
                                                <option value="">
                                                    --Select Employment Type--
                                                </option>
                                                <option value="full_time" selected={(formData.nature_of_employment == 'full_time') ? true : false}>
                                                    Full Time
                                                </option>
                                                <option value="part_time" selected={(formData.nature_of_employment == 'part_time') ? true : false}>
                                                    Part Time
                                                </option>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-12">
                                    <div className="row mt-2">
                                        <div className="col-md-12">
                                            <label className="text-dark">
                                                Designation
                                            </label>
                                        </div>
                                        <div className="col-md-12">
                                            <input
                                                type='text'
                                                className='form-control input-border mt-1'
                                                onChange={(e) => handleChange(e, "letters_only", "Designation Should Letters Only")}
                                                name='designation'
                                                defaultValue={formData.designation}
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>


                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs ">
                                <div className="col-md-7">
                                    <div className="row mt-2">
                                        <div className="col-md-12">
                                            <label className="text-dark">
                                                Job Posting Date
                                            </label>
                                        </div>
                                        <div className="col-md-12">

                                            <input
                                                type='date'
                                                className='form-control input-border'
                                                onChange={(e) => handleChange(e, "required", "Job Posting Date is required")}
                                                name='job_posting_date'
                                                defaultValue={(formData.job_posting_date) ? new Date(formData.job_posting_date).toISOString().slice(0, 10) : ''}
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                                {/* <div className="col-md-5">
                                    <div className="row mt-2">
                                        <div className="col-md-12">

                                            <label className="text-dark">
                                                Job Expiry Date
                                            </label>

                                            <input
                                                type='date'
                                                className='form-control input-border'
                                                onChange={(e) => handleChange(e, "required", "Job Expiry Date is required")}
                                                name='job_expiry_date'
                                                defaultValue={(formData.job_expiry_date) ? new Date(formData.job_expiry_date).toISOString().slice(0, 10) : ''}
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>*/
                                }
                            </div>
                            {/* fields ends here */}

                            {/* job description */}

                            <div className="row mt-2 w-80 w-100-xs" >
                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job Description
                                    </label>


                                </div>
                                <div className="col-md-12">
                                    <select className="form-control" name="job_description" onChange={(e) => { handleChange(e); getJobDescriptions() }}>
                                        <option value="">--Select Job Description--</option>

                                        {formData.job_descriptions_options?.length > 0 && formData.job_descriptions_options.map((opt) => {
                                            return <option value={opt.id} selected={(formData.description_id == opt.id) ? true : false}>{opt.title}</option>;
                                        })}

                                    </select>

                                    <p onClick={(e) => this.setJDForm()} className="text-primary cursor">Add new job description</p>
                                </div>




                            </div>
                            {this.props.is_jd_form == true &&
                                <JDForm
                                    handleChange={handleChange}
                                    formData={formData}
                                />
                            }


                            {/* job description */}

                            {/* border */}
                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>
                            {/* border */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs" >


                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Skill Set
                                    </label>
                                    <p className="f-0-8 text-gray">Select atleast 3 skill set which will be displayed in job and will help you target the candidates</p>
                                </div>
                                <div className="col-md-12">
                                    <SkillsSelect
                                        handleChange={handleChange}
                                        getProbableCandidate={getProbableCandidate}
                                        getSkillSet={this.props.formData.skill_set}
                                        is_edit={this.props.formData.edit_id}
                                    />

                                </div>
                            </div>
                            {/* fields ends here */}



                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs" >


                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Qualification
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='text'
                                        className='form-control input-border'
                                        onChange={(e) => handleChange(e, "required", "Qualification is required")}
                                        name='qualification'
                                        defaultValue={formData.qualification}
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6">

                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Annual CTC From (in lakhs/per annum)
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, "numbers_only", "CTC From is required"); }}
                                            name='ctc_from'
                                            defaultValue={formData.ctc_from}
                                            min="0"
                                            required
                                        />
                                    </div>
                                </div>


                                <div className="col-md-6">
                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Annual CTC To (in lakhs/per annum)
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, "required", "CTC to is required"); }}
                                            name='ctc_to'
                                            defaultValue={formData.ctc_to}
                                            min="0"
                                            required
                                        />

                                    </div>
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6">

                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Min Work Experience
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, "required", "Min Work Experience Field is required"); }}
                                            name='min_work_exp'
                                            defaultValue={formData.min_work_exp}
                                            min="0"
                                            required
                                        />

                                        {errors['min_work_exp'] != '' && <p className="text-danger">{errors['min_work_exp']}</p>}
                                    </div>
                                </div>


                                <div className="col-md-6">
                                    <div className="col-md-12">
                                        <label className="text-dark">
                                            Max Work Experience
                                        </label>
                                    </div>
                                    <div className="col-md-12">

                                        <input
                                            type='number'
                                            className='form-control input-border'
                                            onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, "required", "Max Work Experience Field is required"); }}
                                            name='max_work_exp'
                                            defaultValue={formData.max_work_exp}
                                            min="0"
                                            required
                                        />

                                    </div>
                                </div>
                            </div>
                            {/* fields ends here */}

                            {/* dotted border */}

                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>

                            {/* dotted border */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job Location
                                    </label>
                                </div>


                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Country
                                    </label>

                                    <select className="form-select form-select-md mb-3 input-border"
                                        onChange={(e) => { handleChange(e, "requied", "Country is Required"); jobcityDetails(e); this.getCities(e); }} name="jobCountryLoc[]"
                                        onBlur={(e) => getProbableCandidate(e)}
                                        required>
                                        <option value="" selected disabled>
                                            --Select Country--
                                        </option>
                                        {

                                            formData.countryopt && formData.countryopt.map((p) => {
                                                
                                                if (this.state.ncity.length <= 0 && formData.jobCountryLoc == p.name && this.state.flag == 1) {
                                                    this.getCities({ target: { name: 'country', value: p.id } });
                                                    this.setState({ flag: 2 });
                                                };
                                                return <option datatype={p.name} value={p.id} selected={(formData.jobCountryLoc == p.name) ? true : false}>
                                                    {p.name}
                                                </option>
                                            })}

                                    </select>

                                    {/*<input
                                        type='text'
                                        className='form-control input-border'
                                        onChange={(e) => handleChange(e, "required", "Job Location Field is required")}
                                        name='job_location'
                                        defaultValue={formData.job_location}
                                        required
                                    />*/}
                                </div>
                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Select Cities
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <Select
                                        options={this.state.ncity}
                                        valueType={"string"}
                                        isMulti={true}
                                        value={this.state.selectedcity}
                                        placeholder="Select the Cities"
                                        onChange={(e) => this.changecity(e)}
                                        getOptionLabel={x => x.label}
                                        getOptionValue={x => x.value}
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Job Function
                                    </label>
                                </div>
                                <div className="col-md-12">
                                    <textarea className='form-control input-border'
                                        onChange={(e) => handleChange(e, "required", "Job Function Field is required")}
                                        name='job_function' defaultValue={formData.job_function} required></textarea>
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* fields starts here*/}
                            <div className="row mt-2 w-80 w-100-xs">

                                <div className="col-md-12">
                                    <label className="text-dark">
                                        Number of Vacancies
                                    </label>
                                </div>
                                <div className="col-md-12">

                                    <input
                                        type='number'
                                        className='form-control input-border'
                                        onChange={(e) => { e.target.value = (e.target.value < 0) ? 0 : e.target.value; handleChange(e, "required", "Number of Vacany is required"); }}
                                        name='number_of_vaccancy'
                                        defaultValue={formData.number_of_vaccancy}
                                        min="0"
                                        required
                                    />
                                </div>

                            </div>
                            {/* fields ends here */}

                            {/* border */}
                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>
                            {/* border */}

                            {/* fields starts here */}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6 col-9">
                                    <label className="text-dark f-1">Show HR Details</label>
                                </div>
                                <div className="col-md-6 col-2">
                                    <div className="ms-auto d-table mt-auto mb-auto">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="show_hr_details" onChange={(e) => handleChange(e)} checked={(formData.show_hr_details == 1) ? true : false} />
                                        </div>
                                    </div>
                                </div>
                                {formData.show_hr_details == 1 &&
                                    <div className='mt-2'>
                                        <p>These details will be visible to candidates</p>
                                        <div className="col-md-12">
                                            <label className="text-dark">
                                                Name
                                            </label>
                                        </div>
                                        <div className="col-md-12">

                                            <input
                                                type='text'
                                                className='form-control input-border'
                                                onChange={(e) => handleChange(e, "required", "Name is required")}
                                                name='hrName'
                                                defaultValue={formData.hrName}
                                                required
                                            />
                                        </div>
                                        <div className="col-md-12 mt-2">
                                            <label className="text-dark">
                                                Designation
                                            </label>
                                        </div>
                                        <div className="col-md-12">

                                            <input
                                                type='text'
                                                className='form-control input-border'
                                                onChange={(e) => handleChange(e, "required", "Designation is required")}
                                                name='hrDesignation'
                                                defaultValue={formData.hrDesignation}
                                                required
                                            />
                                        </div>

                                    </div>
                                }
                            </div>
                            {/* fields ends here */}

                            {/* fields starts here */}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6 col-9">
                                    <label className="text-dark f-1">Show Company Logo</label>
                                </div>
                                <div className="col-md-6 col-2">
                                    <div className="ms-auto d-table mt-auto mb-auto">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="show_company_logo" onChange={(e) => handleChange(e)} checked={(formData.show_company_logo == 1) ? true : false} disabled={(formData.job_type_details?.company_logo != "Yes") ? true : false} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {(formData.job_type_details?.company_logo != "Yes") ? <p>Want to unlock this feature? <NavLink to="/plans">Upgrade Plan</NavLink></p> : ''}
                            {/* fields ends here */}


                            {/* fields starts here */}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6 col-9">
                                    <label className="text-dark f-1">Show Company Banner</label>
                                </div>
                                <div className="col-md-6 col-2">
                                    <div className="ms-auto d-table mt-auto mb-auto">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="show_company_banner" onChange={(e) => handleChange(e)} checked={(formData.show_company_banner == 1) ? true : false} disabled={(formData.job_type_details?.company_banner != "Yes") ? true : false} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {(formData.job_type_details?.company_banner != "Yes") ? <p>Want to unlock this feature? <NavLink to="/plans">Upgrade Plan</NavLink></p> : ''}
                            {/* fields ends here */}

                            {/* fields starts here */}
                            <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6 col-9">
                                    <label className="text-dark f-1">Show Company Website Link</label>
                                </div>
                                <div className="col-md-6 col-2">
                                    <div className="ms-auto d-table mt-auto mb-auto">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="show_company_website_link" onChange={(e) => handleChange(e)} checked={(formData.show_company_website_link == 1) ? true : false} disabled={(formData.job_type_details?.website_link != "Yes") ? true : false} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {(formData.job_type_details?.website_link != "Yes") ? <p>Want to unlock this feature? <NavLink to="/plans">Upgrade Plan</NavLink></p> : ''}
                            {/* fields ends here */}

                            {this.state.recruitment_agency && <div className="row mt-2 w-80 w-100-xs">
                                <div className="col-md-6 col-9">
                                    <label className="text-dark f-1">Add Company Details (for hiring agencies)</label>
                                </div>
                                <div className="col-md-6 col-2">
                                    <div className="ms-auto d-table mt-auto mb-auto">
                                        <div class="form-check form-switch ms-auto">
                                            <input class="form-check-input ms-0" type="checkbox" id="flexSwitchCheckChecked" name="show_hiring_agencies" onChange={(e) => handleChange(e)} checked={(formData.show_hiring_agencies == 1) ? true : false} />
                                        </div>
                                    </div>
                                </div>
                                {formData.show_hiring_agencies == 1 &&
                                    <div className='mt-2'>
                                        <p>These details will be visible to candidates</p>
                                        <div className="row">
                                            <div className="col-md-9">
                                                <label className="text-dark">
                                                    Upload Company Logo
                                                </label>
                                            </div>
                                            <div className="col-md-3">
                                                <label className="float-end" for={`compLogo`} type="button">
                                                    <span className="text-primary cursor vertical-middle">Uploads</span>
                                                    <i class="las la-file-export f-1-1 text-primary cursor vertical-middle"></i>
                                                </label>

                                                <input type="file" style={{ display: "none" }} id={`compLogo`}
                                                    onChange={(e) => addLogo(e)} required
                                                />
                                                <div className='text-end'>{formData.logo?.name}</div>

                                            </div>
                                            <div className="col-md-12">
                                                <label className="text-dark">
                                                    Company Name
                                                </label>
                                                <input
                                                    type='text'
                                                    className='form-control input-border mb-3'
                                                    onChange={(e) => handleChange(e, "required", "Company Name is required")}
                                                    name='compName'
                                                    defaultValue={formData.compName}
                                                    required
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Company Category
                                                </label>

                                                <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "Company Category is Required"); subCategory(e); }} name="compCategory" required>
                                                    <option value="" selected disabled>
                                                        --Select Company Category--
                                                    </option>
                                                    {formData.companyCategoriesopt && formData.companyCategoriesopt.map((p) => {
                                                        return <option value={p.id} selected={(formData.id == p.id) ? true : false}>
                                                            {p.title}
                                                        </option>
                                                    })}


                                                </select>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Company Subcategory
                                                </label>

                                                <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "Company subcategory is Required"); }} name="compSubcategory" required>
                                                    <option value="" selected disabled>
                                                        --Select Company Subcategory--
                                                    </option>
                                                    {formData.companySubCategoriesopt && formData.companySubCategoriesopt.map((p) => {
                                                        return <option value={p.id} selected={(formData.id == p.id) ? true : false}>
                                                            {p.title}
                                                        </option>
                                                    })}

                                                </select>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Email
                                                </label>
                                                <input
                                                    type='email'
                                                    className='form-control input-border mb-3'
                                                    onChange={(e) => handleChange(e, "required", "Email is required")}
                                                    name='compEmail'
                                                    defaultValue={formData.compEmail}
                                                    required
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Phone No
                                                </label>
                                                <input
                                                    type='number'
                                                    className='form-control input-border mb-3'
                                                    onChange={(e) => handleChange(e, "required", "phone is required")}
                                                    name='compPhone'
                                                    defaultValue={formData.compPhone}
                                                    required
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Website
                                                </label>
                                                <input
                                                    type='text'
                                                    className='form-control input-border mb-3'
                                                    onChange={(e) => handleChange(e, "required", "Website is required")}
                                                    name='compWebsite'
                                                    defaultValue={formData.compWebsite}
                                                    required
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    Country
                                                </label>

                                                <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "Country is Required"); stateDetails(e); }} name="compCountry" required>
                                                    <option value="" selected disabled>
                                                        --Select Country--
                                                    </option>
                                                    {formData.countryopt && formData.countryopt.map((p) => {
                                                        return <option value={p.id} selected={(formData.id == p.id) ? true : false}>
                                                            {p.name}
                                                        </option>
                                                    })}


                                                </select>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    State
                                                </label>

                                                <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "State is Required"); cityDetails(e); }} name="compState" required>
                                                    <option value="" selected disabled>
                                                        --Select State--
                                                    </option>
                                                    {formData.stateopt && formData.stateopt.map((p) => {
                                                        return <option value={p.id} selected={(formData.id == p.id) ? true : false}>
                                                            {p.name}
                                                        </option>
                                                    })}

                                                </select>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="text-dark">
                                                    City
                                                </label>

                                                <select className="form-select form-select-md mb-3 input-border" onChange={(e) => { handleChange(e, "requied", "City is Required"); }} name="compCity" required>
                                                    <option value="" selected disabled>
                                                        --Select City--
                                                    </option>
                                                    {formData.cityopt && formData.cityopt.map((p) => {
                                                        return <option value={p.id} selected={(formData.id == p.id) ? true : false}>
                                                            {p.name}
                                                        </option>
                                                    })}

                                                </select>
                                            </div>

                                        </div>

                                    </div>
                                }
                            </div>}


                            {/* border */}
                            <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>
                            {/* border */}

                            {/* submit button */}
                            <div className="row">
                                <div className="col-md-6">

                                    <button type="submit" className="btn btn-primary ml-auto mr-auto d-block" >{(formData.edit_id) ? `Edit Job` : `Add Job`}</button>
                                </div>
                            </div>

                        </div>
                        {/* submit button */}

                        {/* form ends here */}
                    </div>
                </form>
            </>
        );

    }

}

export default JobForm;