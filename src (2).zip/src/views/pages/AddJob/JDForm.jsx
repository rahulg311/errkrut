
import React, { Component } from 'react';
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { EditorState, convertToRaw, convertFromRaw, ContentState, convertFromHTML } from 'draft-js';
import draftToHtml from 'draftjs-to-html';

class JDForm extends Component {
    state = {
		instructionState: EditorState.createEmpty(),
	}
    onInstructionChange = (neweditorState) => {
		this.setState({ instructionState: neweditorState });
		let htmlmsg = draftToHtml(convertToRaw(neweditorState.getCurrentContent()));
		this.props.handleChange({ target: { name: 'job_responsibilities', value: htmlmsg } }, 'required', 'job_responsibilities is required')
	};
    componentWillMount(){
        if (this.props.formData.job_responsibilities != null) {
			let n = EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(this.props.formData.job_responsibilities)));
			this.setState({ instructionState: n });
		}
    }

    render() {

        const { handleChange, formData } = this.props;

        return (
            <>

                <div className="row mt-2 w-80" >

                    <div className="col-md-12">
                        <label className="text-dark">
                            JD Title
                        </label>
                    </div>
                    <div className="col-md-12">

                        <input
                            type='text'
                            className='form-control input-border'
                            onChange={(e) => handleChange(e, "required", "Title is required")}
                            name='jd_title'
                            defaultValue={formData.jd_title}
                            required
                        />
                    </div>

                </div>

                <div className="row mt-2 w-80" >

                    <div className="col-md-7">

                        {/* prupose */}
                        <div className="col-md-12">
                            <label className="text-dark">
                                Purpose
                            </label>
                        </div>
                        <div className="col-md-12">

                            <input
                                type='text'
                                className='form-control input-border'
                                onChange={(e) => handleChange(e, "required", "Purpose is required")}
                                name='purpose'
                                defaultValue={formData.purpose}
                                required
                            />
                        </div>
                        {/* prupose */}
                    </div>

                    <div className="col-md-5">

                        <div className="col-md-12">
                            <label className="text-dark">
                                Industry
                            </label>
                        </div>
                        <div className="col-md-12">

                            <input
                                type='text'
                                className='form-control input-border'
                                onChange={(e) => handleChange(e, "required", "Industry is required")}
                                name='industry'
                                defaultValue={formData.industry}
                                required
                            />
                        </div>

                    </div>

                </div>

                {/* Job Summary */}
                <div className="row mt-2 w-80" >

                    <div className="col-md-12">
                        <label className="text-dark">
                            Job Summary
                        </label>
                    </div>
                    <div className="col-md-12">
                        <textarea
                            className='form-control input-border'
                            onChange={(e) => handleChange(e, "", "")}
                            name='summary'
                            defaultValue={formData.summary}
                            required
                        ></textarea>
                    </div>

                </div>
                {/* Job Summary */}

                {/* preferred skills */}
                <div className="row mt-2 w-80" >

                    <div className="col-md-12">
                        <label className="text-dark">
                            Preferred Skills
                        </label>
                    </div>
                    <div className="col-md-12">
                        <textarea className='form-control input-border'
                            onChange={(e) => handleChange(e, "required", "Preffered Skills is required")}
                            name='preffered_skills' required>{formData.preffered_skills}</textarea>
                    </div>

                </div>
                {/* preferred skills */}


                {/* Desired Qualifications */}
                <div className="row mt-2 w-80" >

                    <div className="col-md-12">
                        <label className="text-dark">
                            Desired Qualification
                        </label>
                    </div>
                    <div className="col-md-12">

                        <input
                            type='text'
                            className='form-control input-border'
                            onChange={(e) => handleChange(e, "", "")}
                            name='desired_qualification'
                            defaultValue={formData.desired_qualification}
                            required
                        />
                    </div>

                </div>
                {/* Desired Qualification */}

                {/* job responsibilites */}
                <div className="row mt-2 w-80" >

                    <div className="col-md-12">
                        <label className="text-dark">
                            JD Responsibilities
                        </label>
                    </div>

                    <div className='col-md-12'>
                        <Editor
                            editorState={this.state.instructionState} defaultEditorState={this.state.instructionState} wrapperClassName="demo-wrapper" editorClassName="editer-content"
                            onEditorStateChange={this.onInstructionChange}
                        />
                    </div>

                    {/*<div className="col-md-12">
                        <textarea required className='form-control input-border'
                            onChange={(e) => handleChange(e, "required", "Job Responsibilities is required")}
                            name='job_responsibilities'>{formData.job_responsibilities}</textarea>
                    </div>*/}

                </div>
                {/* job responsibilties */}

            </>
        )
    }

}

export default JDForm;