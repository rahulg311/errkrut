
import React, { Component } from 'react';
import { getMembers } from '../../../store/actions/members';

import { connect } from 'react-redux';
import { getLoggedInUser, getObjFromArrBykey } from '../../../classes';
import { getLetterIntent, getOfferLetters } from '../../../store/actions/letter';
import { NavLink } from 'react-router-dom';
import { getQuiz } from '../../../store/actions/quiz';

class InterviewRounds extends Component {

    state = {
        user_id: null,
        company_id: null,
        round_type_options: null,
        questionnaires: [],
        que_edu_qualification: '',
        que_skill_set: '',
        que_salary: '',
        badgesNo: []
    }

    componentDidMount = async () => {
        let user = await getLoggedInUser();
        if (user) {
            this.setState({
                user_id: user.id,
                company_id: user.company_id
            });
            await this.props.getMembers(user.id);
        }
        console.log("in")
        this.setState({badgesNo: this.props.badges});
        this.setState({questionnaires: this.props.questionnaire});

    }

    /* Add bagde */
    addBadge = () => {
        
        let badgeNo = {
            'quiz_id' : '',
            'points' : '',
            'badge_name' : ''
        }
        let temp = this.props.badges;
        temp.push(badgeNo)

        this.setState({
            badgesNo: temp
        })
        this.props.updatedBadge(temp);
    }

    addQuestionnaire = () => {
        let temp = this.props.questionnaire;
        temp.push("");
        this.setState({questionnaires: temp});
        this.props.updatequestionnaire(temp);
    }

    handleQuestionnaireDelete = (e, id) => {
        let temp = this.props.questionnaire;
        temp.splice(id, 1);
        this.setState({
            questionnaires: temp
        })
        this.props.updatequestionnaire(temp);
        document.getElementById('queform').reset();
        e.preventDefault();
    }

    handleBadgeDelete = (e, id) => {
        let temp = this.props.badges;
        temp.splice(id, 1);
        this.setState({
            badgesNo: temp
        })
        this.props.updatedBadge(temp);
        document.getElementById('badgeform').reset();
        e.preventDefault();
    }

    setRoundOption = async (rtype) => {

        if (rtype == 'interview')
            await this.props.getQuiz(this.state.company_id, 2);

        this.setState({ quizs: this.props.quizdata?.data });

        if (this.props.quizdata?.status == 'success') {

            let r = <div className='col-md-12 mb-2'>
                <label class="form-label">Select Quiz</label>

                <select class="form-select" name="quizz_id" required defaultValue={((this.props.edit_round_index != null) ? this.props.rounds[this.props.edit_round_index]?.quizz_id : '')}>

                    <option selected value="">--Select Quiz--</option>
                    {this.props.quizdata != null && this.props.quizdata?.data?.map((quiz) => {

                        return <option value={quiz.id} selected={((this.props.edit_round_index != null) ? (this.props.rounds[this.props.edit_round_index].quizz_id == quiz.id) ? true : false : false)}>{quiz.title}</option>;

                    })}

                </select>

                <p>Want to add more quiz? <NavLink to="/add-quiz" target="_blank">Add Quiz</NavLink></p>
            </div>;

            this.setState({
                round_type_options: r
            })
        }

        //loi
        if (rtype == 'offer_letter') {
            this.setState({
                round_type_options: null
            })
        }
        if (rtype == 'letter_of_intent') {

            await this.props.getLetterIntent(this.state.user_id);

            if (this.props.letterintentdata?.status == 'success') {

                let r = <div className='col-md-12 mb-2'>
                    <label class="form-label">Select Letter of Intent</label>

                    <select class="form-select" name="loi_id" required defaultValue={((this.props.edit_round_index != null) ? this.props.rounds[this.props.edit_round_index]?.loi_id : '')}>

                        <option selected value="">--Select Letter of Intent--</option>
                        {this.props.letterintentdata != null && this.props.letterintentdata?.data?.map((letter) => {

                            return <option value={letter.id} selected={((this.props.edit_round_index != null) ? (this.props.rounds[this.props.edit_round_index].loi_id == letter.id) ? true : false : false)}>{letter.title}</option>;

                        })}

                    </select>

                    {(this.props.letterintentdata == null || this.props.letterintentdata?.data?.length == 0) && <NavLink to="/letter-intent" target="_blank">Add Letter of Intent</NavLink>}
                </div>;

                this.setState({
                    round_type_options: r
                })
            }

        }

        if (rtype == 'offer_letter') {

            await this.props.getOfferLetters(this.state.user_id);

            if (this.props.get_offer_letters_res?.status == 'success') {

                let r = <div className='col-md-12 mb-2'>
                    <label class="form-label">Select Offer Letter</label>

                    <select class="form-select" name="offer_letter_id" required defaultValue={((this.props.edit_round_index != null) ? this.props.rounds[this.props.edit_round_index]?.offer_letter_id : '')}>

                        <option selected value="">--Select Offer Letter--</option>
                        {this.props.get_offer_letters_res != null && this.props.get_offer_letters_res?.data?.map((letter) => {

                            return <option value={letter.id} selected={((this.props.edit_round_index != null) ? (this.props.rounds[this.props.edit_round_index].offer_letter_id == letter.id) ? true : false : false)}>{letter.job_offer_title}</option>;

                        })}

                    </select>

                    {(this.props.get_offer_letters_res == null || this.props.get_offer_letters_res?.data?.length == 0) && <NavLink to="/add-offer-letter" target="_blank">Add Offer Letter</NavLink>}
                </div>;

                this.setState({
                    round_type_options: r
                })
            }

        }

        if (rtype == 'quizz') {

            await this.props.getQuiz(this.state.company_id, 1);

            this.setState({ quizs: this.props.quizdata?.data });

            if (this.props.quizdata?.status == 'success') {

                let r = <div className='col-md-12 mb-2'>
                    <label class="form-label">Select Quiz</label>

                    <select class="form-select" name="quizz_id" required defaultValue={((this.props.edit_round_index != null) ? this.props.rounds[this.props.edit_round_index]?.quizz_id : '')}>

                        <option selected value="">--Select Quiz--</option>
                        {this.props.quizdata != null && this.props.quizdata?.data?.map((quiz) => {

                            return <option value={quiz.id} selected={((this.props.edit_round_index != null) ? (this.props.rounds[this.props.edit_round_index].quizz_id == quiz.id) ? true : false : false)}>{quiz.title}</option>;

                        })}

                    </select>

                    <p>Want to add more quiz? <NavLink to="/add-quiz" target="_blank">Add Quiz</NavLink></p>
                </div>;

                this.setState({
                    round_type_options: r
                })
            }

        }
    }
    getQuestionniare = (e) => {
        this.setState({
            [e.target.name]: e.target.value,
        })

    }

    resetForm = (e) => {
        Object.keys(e.target).map((index, ele) => {
            if (e.target[index].name)
                e.target[index].value = '';
        });
        this.setState({
            round_type_options: null
        });
    }

    render() {

        const { addRound, show_add_round_form, questions, setQuestion, setStep, createRound, rounds, editRound, edit_round_index, deleteRound, badgesChangeHandler, questionnaireChangeHandler} = this.props;

        return (
            <>

                {/* Rounds */}
                {show_add_round_form == false &&
                    <div className="container bg-white mb-2">
                        <div className="row mt-2">
                            <div className="col-md-12 col-12 mt-2 ms-1">
                                <h4 className="f-Poppins-Medium  text-primary">Rounds of Interview</h4>
                            </div>
                        </div>
                        {/* border */}
                        <div className="border-blue1  mt-2 mb-1"></div>
                        {/* border */}
                        <div className='container mb-5'>
                            <div className='row'>
                                {rounds.length > 0 &&
                                    <h4 className='mt-2 mb-1 p-0'>{rounds.length} Rounds</h4>
                                }
                                <div className='col-md-12'>
                                    <div className='row mb-5 gap-1'>

                                        {rounds.length > 0 && rounds.map((r, index) => {
                                            return <div className='col-md-3 mt-2 border-blue rounded'>


                                                <div className="d-flex align-items-start flex-column min-height-230">
                                                    <div class="dropdown float-end">
                                                        <button class="btn btn-secondary  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <a class="dropdown-item" href="#" onClick={(e) => { editRound(index); this.setRoundOption(r.round_type) }}>Edit</a>
                                                            <a class="dropdown-item" href="#" onClick={(e) => { deleteRound(index); this.resetForm(e); }}>Delete</a>
                                                        </div>
                                                    </div>

                                                    <h5 className='p-1 pt-2 text-primary fw-bolder'>
                                                        {r.round_name}
                                                    </h5>
                                                    <h6 className='p-1 pt-0 text-primary fw-bolder'>
                                                        <p className="text-black">Round Type</p>
                                                        <p className="text-capitalize">{r.round_type?.replace(/_/g, " ")}</p>
                                                    </h6>

                                                    <h6 className='p-1 pt-0 text-primary fw-bolder'>
                                                        <p className="text-black">Owner</p>
                                                        <p className="text-capitalize">{getObjFromArrBykey(this.props.get_all_members_res?.data, { key: 'id', value: r.round_owner_id })?.name}</p>
                                                    </h6>
                                                </div>
                                            </div>
                                        })}

                                        <div className='col-md-3 mt-2 border-blue rounded d-flex justify-content-center align-items-center cursor min-height-230' onClick={(e) => { addRound(e) }}>
                                            <div className=''>
                                                <h5 className='text-primary'>Add Round +</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Add questionnaire starts*/}
                                <div className='col-md-12'>
                                    <h4 className="f-Poppins-Medium">Who can apply for the job (Not Mandatory)</h4>
                                </div>
                                <div className="border-blue1  mt-2 mb-1"></div>
                                <form id="queform">

                                    {this.state.questionnaires.map((r, index) => {
                                        return <div className="row mb-1">
                                                <div className="col-md-10">
                                                    <input
                                                        type='text'
                                                        className='form-control input-border'
                                                        name='questionnaires'
                                                        placeholder='Questionnaires'
                                                        defaultValue={r}
                                                        onChange={(e) => questionnaireChangeHandler(e, index)} 
                                                        required />
                                                </div>
                                                
                                                <div className="col-md-2">
                                                    <button
                                                        className='btn btn-sm text-danger p-0 ms-2  '
                                                        onClick={(e) => this.handleQuestionnaireDelete(e, index)}
                                                    >
                                                        <i class='fas fa-trash f-r-8 '></i>
                                                    </button>
                                                </div>

                                            </div>
                                    }) 
                                    
                                    }
                                </form>
                                <div className="col-md-12">
                                    <button class="btn btn-outline-primary shadow" type="button" onClick={this.addQuestionnaire} >Add Questionnaire +</button>
                                </div>
                                
                                
                                
                                {/* Add questionnaire end*/}
                                {/* Add Badges starts*/}
                                <div className='col-md-12 mt-3'>
                                    <h4 className="f-Poppins-Medium">Add job Badges (Not Mandatory)</h4>
                                </div>
                                <div className="border-blue1  mt-2 mb-1"></div>
                                <div className="col-md-12">
                                    {this.state.badgesNo.length > 0 && 
                                        <div className="row mb-1">
                                            <div className="col-md-3"><b>Select Quiz</b></div>
                                            <div className="col-md-3"><b>Points</b></div>
                                            <div className="col-md-3"><b>Badge Name</b></div>
                                        </div>
                                    }
                                    <form id="badgeform">
                                        {this.state.badgesNo.map((r, index) => {
                                            return <div className="row mb-1">
                                                
                                                <div className="col-md-3">
                                                    <select className="form-select form-select-md input-border" onChange={(e) => badgesChangeHandler(e, index, 'quiz_id')} required>
                                                        <option value="">
                                                            --Select Quiz--
                                                        </option>
                                                        <option value="0">All Quizzes</option>
                                                        {rounds.filter(r => r.round_type == "quizz" ).map(el => {
                                                        return (
                                                            <option value={el.quizz_id} selected={r.quiz_id == el.quizz_id ? true : false}>{el.round_name}</option>
                                                        ) 
                                                        })}
                                                    </select>
                                                </div>
                                                <div className="col-md-3">
                                                    <input
                                                        type='number'
                                                        className='form-control input-border'
                                                        name='points'
                                                        placeholder='Points'
                                                        defaultValue={r.points}
                                                        onChange={(e) => badgesChangeHandler(e, index, 'points')} 
                                                        required />
                                                </div>
                                                <div className="col-md-3">
                                                    <input
                                                        type='text'
                                                        className='form-control input-border'
                                                        name='badge_name'
                                                        placeholder='Badge Name'
                                                        defaultValue={r.badge_name}
                                                        onChange={(e) => badgesChangeHandler(e, index, 'badge_name')} 
                                                        required />
                                                </div>
                                                <div className="col-md-3">
                                                    <button
                                                        className='btn btn-sm text-danger p-0 ms-2  '
                                                        onClick={(e) => {this.handleBadgeDelete(e, index);}}
                                                    >
                                                        <i class='fas fa-trash f-r-8 '></i>
                                                    </button>
                                                </div>
                                            </div>
                                        })}
                                    </form>
                                    <button class="btn btn-outline-primary shadow" type="button" onClick={this.addBadge} >Add Badge +</button>
                                
                                </div>

                                {/* Add Badges end*/}
                                <div className='d-flex mt-3 pb-2 pe-0 ps-0'>

                                    <button class="btn btn-outline-primary shadow" type="button" onClick={(e) => { setStep(1) }}>Previous</button>

                                    <button class="btn btn-primary shadow ms-auto" type="button" onClick={(e) => { setStep(3) }} >Preview & Post Job</button>

                                </div>
                            </div>

                        </div>
                        {/* submit button */}
                    </div>
                }
                {/* Rounds */}


                {/* Add Round */}
                {show_add_round_form == true &&
                    <div className="container bg-white mb-2">
                        <div className="row   mt-2">
                            <div className="col-md-12 col-12 mt-2 ms-1">
                                <h4 className="f-Poppins-Medium  text-primary"> Add Round</h4>
                            </div>
                        </div>
                        {/* border */}
                        <div className="border-blue1  mt-2 mb-1"></div>
                        {/* border */}
                        <div className='w-75 w-100-xs'>
                            <form onSubmit={(e) => { createRound(e); this.resetForm(e) }} id="add-round-form">
                                <div className='row  mt-4'>
                                    <div className='col-md-8'>
                                        <div class="mb-3">
                                            <label class="form-label">Round Name</label>
                                            <input type="text" name="round_name" class="form-control" placeholder='Enter Your Round Name here' required defaultValue={((edit_round_index != null) ? rounds[edit_round_index]?.round_name : '')} />
                                        </div>
                                    </div>
                                    <div className='col-md-4 mb-2'>
                                        <label class="form-label">Round Type</label>
                                        <select class="form-select" name="round_type" required defaultValue={((edit_round_index != null) ? rounds[edit_round_index]?.round_type : '')} onChange={(e) => { this.setRoundOption(e.target.value) }}>
                                            <option selected value="">--Select Round Type--</option>
                                            <option value="quizz">Quiz</option>
                                            <option value="interview">Interview</option>
                                            <option value="offer_letter">Letter of Intent / Offer Letter</option>
                                        </select>
                                    </div>
                                </div>
                                <div className='col-md-12 mb-2'>
                                    <label class="form-label">Round Owner</label>
                                    <select class="form-select" name="round_owner_id" required defaultValue={((edit_round_index != null) ? rounds[edit_round_index]?.round_owner_id : '')}>
                                        <option selected value="">--Select Round Owner--</option>
                                        {console.log(this.props.get_all_members_res)}
                                        {this.props.get_all_members_res != null && this.props.get_all_members_res?.data?.map((member) => {

                                            return <option value={member.id}>{member.name}</option>;

                                        })}

                                    </select>

                                    {(this.props.get_all_members_res == null || this.props.get_all_members_res?.data?.length == 0) && <NavLink to="/add-member" target="_blank">Add Member</NavLink>}
                                </div>

                                {this.state.round_type_options}

                                <div className='d-flex mt-2 pb-2 pe-0 ps-0'>

                                    <button class="btn btn-outline-primary shadow" type="button" onClick={(e) => { addRound(e) }}>Back</button>

                                    <button class="btn btn-primary shadow ms-auto" type="submit">Save Interview Round</button>

                                </div>
                            </form>
                        </div>
                        {/* submit button */}
                    </div>
                }
                {/* Add Round */}

            </>
        )
    }

}

const mapStateToProps = (state) => {
    const { get_all_members_res, letterintentdata, quizdata, get_offer_letters_res } = state.common;
    return {
        get_all_members_res,
        letterintentdata,
        quizdata,
        get_offer_letters_res
    }
};

function mapDispatchToProps(dispatch) {
    return {
        getMembers: (id) => dispatch(getMembers(id)),
        getLetterIntent: (id) => dispatch(getLetterIntent(id)),
        getQuiz: (id, type) => dispatch(getQuiz(id, type)),
        getOfferLetters: (id) => dispatch(getOfferLetters(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(InterviewRounds);