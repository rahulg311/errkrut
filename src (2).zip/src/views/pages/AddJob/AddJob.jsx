import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { createErrors, errorPrettify, errorPrettifyObjArr, formatTitle, getLoggedInUser, isLoggedIn } from '../../../classes/index';
import { createJob, editJob, getJobDescriptions, jobTypeDetails, jobTypes, updateJob, getCompanyCategories, getCompanySubcategories, getCountry, getState, getCity, getCities, get_probable_candidate } from '../../../store/actions/jobs';

import { validation } from '../../../classes/validation';
import { notification } from '../../../classes/messages';

import { connect } from "react-redux";
import JobPreview from '../JobPreview/JobPreview';
import JobForm from './JobForm';

import { routeChanged, routePushed } from '../../../classes/browserHistory';
import { getSingleTemplate, getTemplate } from '../../../store/actions/template';
import InterviewRounds from './InterviewRounds';
import SideBar from '../../../components/hoc/SideBar';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';

class AddJob extends Component {

    state = {
        user_id: '',
        company_id: '',
        feature_id: '',
        job_title: '',
        designation: '',
        nature_of_employment: '',
        job_type: '',
        job_description: '',
        skill_set: '',
        qualification: '',
        ctc_from: '',
        ctc_to: '',
        min_work_exp: '',
        max_work_exp: '',
        job_location: '',
        job_function: '',
        number_of_vaccancy: '',

        show_round: 0,
        errors: {},
        api_res: null,
        edit_id: 0,
        plans: [],
        template: [],

        show_hr_details: 0,
        show_hiring_agencies: 0,

        company_details: 0,
        job_posting_date: null,
        job_expiry_date: null,
        edit_id: null,
        job_types: [],
        job_type_details: null,
        plan_id: null,
        job_descriptions_options: [],
        companyCategoriesopt: [],
        companySubCategoriesopt: [],
        countryopt: [],
        stateopt: [],
        cityopt: [],
        citiesopt: [],
        jd_title: null,
        purpose: null,
        industry: null,
        job_responsibilities: null,
        preffered_skills: null,
        desired_qualification: null,
        summary: null,
        rounds: [],
        show_add_round_form: false,
        edit_round_index: null,
        step: 1,
        show_company_website_link: null,
        show_company_banner: null,
        show_company_logo: null,
        is_jd_form: false,

        ques: [],
        questionnaire: [],

        hrName: null,
        hrDesignation: null,
        compName: null,
        compCategory: null,
        compSubcategory: null,
        compEmail: null,
        compPhone: null,
        compWebsite: null,
        compCountry: null,
        compState: null,
        compCity: null,
        logo: null,
        probableCandidatesVal: '',
        jobCountryLoc: '',
        jobCityLoc: '',
        badges: []
    }


    componentWillMount() {
        this.getUserId();
        this.getJobDescriptions();

        if (this.props.match.params?.id) {
            this.setState({
                edit_id: this.props.match.params.id
            }, () => {
                this.editJobData();

            });
        }

    }


    setDescForm = () => {
        this.setState({ is_jd_form: !this.state.is_jd_form });
    }

    /* add round */
    addRound = (e) => {
        this.setState({
            show_add_round_form: !this.state.show_add_round_form
        });
    }
    /* add round */

    setQuestion = (e) => {
        this.setState({
            ques: {
                ...this.state.ques,
                [e.target.name]: e.target.value
            }
        });
    }

    /* create round */
    createRound = (e) => {
        e.preventDefault();
        let round = {};
        Object.keys(e.target).map((index, ele) => {
            if (e.target[index].name)
                round[e.target[index].name] = e.target[index].value;
        });

        if (this.state.edit_round_index != null) {

            let roundss = [...this.state.rounds];

            roundss[this.state.edit_round_index] = round;

            this.setState({
                rounds: roundss,
                edit_round_index: null,
                show_add_round_form: false
            });

        } else {
            this.setState(prevState => ({
                rounds: [...prevState.rounds, ...[round]],
                show_add_round_form: false
            }), () => {
                console.log(this.state.rounds);
            });
        }


    }
    /* create round */

    /* edit round */
    editRound = (index) => {
        this.setState({
            show_add_round_form: true,
            edit_round_index: index
        })

    }
    /* edit round */

    deleteRound = (index) => {
        let deleteRound = this.state.rounds;
        deleteRound.splice(index, 1);
        this.setState({ rounds: deleteRound });
        //this.addRound(index)
    }


    /*edit job*/
    editJobD = async () => {
        let formData = {
            user_id: this.state.user_id,
            company_id: this.state.company_id,
            feature_id: this.state.feature_id,
            job_title: this.state.job_title,
            designation: this.state.designation,
            nature_of_employment: this.state.nature_of_employment,
            job_type: this.state.job_type,
            job_description: this.state.job_description,
            job_posting_date: this.state.job_posting_date,
            skill_set: this.state.skill_set.toString(),
            qualification: this.state.qualification,
            ctc_from: this.state.ctc_from,
            ctc_to: this.state.ctc_to,
            min_work_exp: this.state.min_work_exp,
            max_work_exp: this.state.max_work_exp,
            job_id: this.state.edit_id,
            job_country: this.state.jobCountryLoc,
            job_city: this.state.jobCityLoc,

            job_function: this.state.job_function,
            number_of_vaccancy: this.state.number_of_vaccancy,
            show_company_logo: this.state.show_company_logo,
            show_company_banner: this.state.show_company_banner,
            show_company_website_link: this.state.show_company_website_link,
            hiring_agencies: this.state.show_hiring_agencies,
        };


        let res;
        await this.props.updateJob(JSON.stringify(formData));
        res = this.props.update_job_data;
        let notify = null;
        if (res) {
            if (res.status == 'success') {
                notify = notification({ message: res.message, type: 'success' });
                routePushed('/successful', this.props, { message: 'Your Job Added Successfully.' });
            } else {
                notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            }
        }

        if (notify)
            notify();
    }

    /* edit job data */
    editJobData = async () => {
        const result = await getLoggedInUser();

        let fm = new FormData();
        fm.append('job_id', this.state.edit_id);
        fm.append('company_id', result.company_id);

        await this.props.editJob(fm);

        let data = this.props.edit_job_data;

        if (data?.status == 'success') {
            Object.keys(data.data.job_details).map((key) => {
                if (key == 'description_id') {
                    this.setState({
                        'job_description': data.data.job_details[key],
                    });
                }
                if (key == 'publish_start') {
                    this.setState({
                        'job_posting_date': data.data.job_details[key],
                    });
                }
                if (key == 'country') {
                    this.setState({
                        'jobCountryLoc': data.data.job_details[key],
                    });
                }
                if (key == 'city') {
                    this.setState({
                        'jobCityLoc': data.data.job_details[key],
                    });
                }
                this.setState({
                    [key]: data.data.job_details[key]
                });
            });
            this.setState({
                'rounds': data.data.round_details
            });
        }
        else {
            let notify = null;
            notify = notification({ message: data?.message, type: data?.status });
            notify();
            this.props.history.push('/recruiter');
        }
        /* edit job */
    }
    /* edit job data */

    /* get job tyipes */
    getJobTypes = async () => {
        let fm = new FormData();
        fm.append('plan_id', (this.state?.plan_id) ? this.state?.plan_id : '');
        fm.append('user_id', (this.state?.user_id) ? this.state?.user_id : '');
        fm.append('company_id', (this.state?.company_id) ? this.state?.company_id : '');

        await this.props.jobTypes(fm);
        this.setState({ job_types: this.props.job_type_res?.data });
    }
    /* get job tyipes */

    /* get company category */

    getCompanyCategoriesop = async () => {
        await this.props.getCompanyCategories();
        this.setState({ companyCategoriesopt: this.props.comp_category_res?.data });
    }

    /* get company category */
    /* get company category */
    getCompanySubCategoriesop = async (id) => {
        await this.props.getCompanySubcategories(id);
        //console.log(this.props.comp_sub_category_res?.data);
        this.setState({ companySubCategoriesopt: this.props.comp_sub_category_res?.data });
    }
    /* get company category */

    /* get country list */
    getCountryOp = async () => {
        await this.props.getCountry();
        this.setState({ countryopt: this.props.country_res?.data });
    }

    getStateOp = async (id) => {
        await this.props.getState(id);
        this.setState({ stateopt: this.props.state_res?.data });
    }

    getCityOp = async (id) => {
        await this.props.getCity(id);
        this.setState({ cityopt: this.props.city_res?.data });
    }
    getCitiesOp = async (id) => {
        await this.props.getCities(id);
        this.setState({ citiesopt: this.props.citiesdata?.data });
    }


    /* get country list */

    /* job types details */
    jobTypeDetails = async (e) => {

        console.log(e);
        let id;
        Object.keys(e.target)?.map((i) => {

            if (e.target[i].value != '' && e.target[i].selected == true) {
                id = e.target[i].getAttribute("datatype");
            }
        });
        if (id) {
            await this.props.jobTypeDetails(id);
            this.setState({ job_type_details: this.props.job_type_details_res?.data });
        }


    }
    /* job types details */

    /* get template */
    getTemplate = async () => {
        await this.props.getTemplate(this.state.company_id);

        this.setState({ template: this.props.templatedata?.data });
    }
    /* get template */

    /* get user id */
    getUserId = async () => {
        const result = await getLoggedInUser();

        this.setState({
            user_id: parseInt(result.id),
            company_id: parseInt(result.company_id),
            plan_id: parseInt(result.plan_id)
        }, () => {
            this.getJobTypes();
            this.getTemplate();
            this.getCompanyCategoriesop();
            this.getCountryOp();
        });
    }
    /* get user id */

    /* handle validation */

    handleValidation = (obj) => {

        let error = this.state.errors;

        let valiRes = validation(obj);

        //email
        if (valiRes['error'] == 1) {

            error[obj.name] = valiRes['message'];

            this.setState({
                errors: error
            });

        } else {
            error[obj.name] = '';

            this.setState({
                errors: error
            });
        }

    }

    /* handle validation */

    /* select template */
    selectTemplate = async (e) => {
        if (e.target.value) {
            await this.props.getSingleTemplate(e.target.value);
            let tdata = this.props.single_template_data;
            if (tdata?.status == 'success') {
                Object.keys(tdata.data).map((k) => {
                    if (k === "skill_set") {
                        this.setState({ [k]: tdata.data[k].split(",") });
                    }
                    else {
                        this.setState({ [k]: tdata.data[k] });
                    }

                });
            }
        }

    }
    /* select template */

    subCategory = async (e) => {

        this.getCompanySubCategoriesop(e.target.value);
    }

    stateDetails = async (e) => {

        this.getStateOp(e.target.value);
    }

    cityDetails = async (e) => {

        this.getCityOp(e.target.value);
    }

    jobcityDetails = async (e) => {

        //country by city
        this.getCitiesOp(e.target.value);
    }


    addLogo = async (e) => {
        this.setState({ logo: e.target.files[0] });
        //console.log(e.target.files[0])
    }

    getProbableCandidate = async (e) => {
        if (e.target.name == 'jobCountryLoc') {
            let index = e.nativeEvent.target.selectedIndex;
            let text = e.nativeEvent.target[index].text;

            await this.props.get_probable_candidate(text);
            this.setState({ 'jobCountryLoc': e.target.value });
            this.setState({ probableCandidatesVal: this.props.probable_candidates_res?.data });

        } else if (e.target.name == 'jobCityLoc') {
            let index = e.nativeEvent.target.selectedIndex;
            let text = e.nativeEvent.target[index].text;

            await this.props.get_probable_candidate(text);
            this.setState({ 'jobCityLoc': e.target.value });
            this.setState({ probableCandidatesVal: this.props.probable_candidates_res?.data });

        } else {
            let str = this.state.skill_set.toString();
            await this.props.get_probable_candidate(str);
            this.setState({ probableCandidatesVal: this.props.probable_candidates_res?.data });
        }

        //console.log('PC'+ this.props.probable_candidates_res?.data)
        //this.setState({ probableCandidates: this.props.probable_candidates_res?.data });
    }
    // Handle fields change
    handleChange = async (e, valiType = '', valiMsg = '') => {

        if (e.target.name == 'jobCityLoc[]') {
            this.setState({
                citiesopt: Array.from(e.target.selectedOptions, (item) => item.value)
            });
        }
        if (e.target) {
            let ivalue = e.target.value;
            let iname = e.target.name;
            if (iname == 'jobCountryLoc[]') {
                iname = 'jobCountryLoc';
                ivalue = e.target[e.target.selectedIndex].getAttribute('datatype');
            }
            if (e.target.type == 'checkbox') {
                if (e.target.checked) {
                    ivalue = 1;
                } else {
                    ivalue = 0;
                }
            }
            if (valiType && valiMsg)
                this.handleValidation({ name: iname, type: valiType, value: ivalue, message: valiMsg });

            //this.setState({...this.state,[iname]: ivalue});
            this.setState({ [iname]: ivalue }, () => {
            });

        }
    }
    /* handle change */

    /* Badge change handler */
    badgesChangeHandler = (e, id, t) => {

        let tempBadge = this.state.badges;

        tempBadge[id][t] = e.target.value;

        this.setState({ badges: tempBadge });
        console.log(this.state.badges)
    }
    updatedBadge = (t) => {
        this.setState({ badges: t });
        console.log(t)
    }

    updatequestionnaire = (t) => {
        this.setState({ questionnaire: t });
        console.log(t)
    }
    questionnaireChangeHandler = (e, id) => {
        let tempQue = this.state.questionnaire;
        tempQue[id] = e.target.value;

        this.setState({ questionnaire: tempQue })
    }


    setStep = (step) => {
        this.setState({
            step: step
        })
    }

    step1Submit = (e) => {
        e.preventDefault();
        if (this.state.step == 1) {

            let formValid = true;

            let notify = null;
            if ((this.state.job_description == '' || this.state.job_description == null) && (this.state.jd_title == '' || this.state.jd_title == null)) {
                formValid = false;
                notify = notification({ message: 'Job Description field is required', type: 'error' });
                notify();
            }
            else if (
                ((this.state.jd_title == '' || this.state.jd_title == null) ||
                    (this.state.purpose == '' || this.state.purpose == null) ||
                    (this.state.industry == '' || this.state.industry == null) ||
                    (this.state.job_responsibilities == '' || this.state.job_responsibilities == null) ||
                    (this.state.preffered_skills == '' || this.state.preffered_skills == null) ||
                    (this.state.desired_qualification == '' || this.state.desired_qualification == null) ||
                    (this.state.summary == '' || this.state.summary == null)) && (this.state.job_description == '' || this.state.job_description == null)) {
                formValid = false;
                notify = notification({ message: 'Job Description field is required', type: 'error' });
                notify();
            } else if (this.state.skill_set == '' || this.state.skill_set == null) {
                formValid = false;
                notify = notification({ message: 'Skill Set field is required', type: 'error' });
                notify();
            }
            else if (this.state.skill_set.length < 3) {
                formValid = false;
                notify = notification({ message: 'Select atleast 3 skill set', type: 'error' });
                notify();
            }
            else if (this.state.errors) {

                Object.keys(this.state.errors).map((k, v) => {

                    if (this.state.errors[k] != "") {
                        formValid = false;
                        notify = notification({ message: 'Please fill all required fields correctly.', type: 'error' });
                        notify();
                    }
                })

            } else {
                formValid = true;
            }
            if (this.state.edit_id != '' && this.state.edit_id != null) {
                this.editJobD();
            }
            else {
                if (formValid == true) {
                    this.setState({
                        step: 2
                    })
                }
            }


        }
    }


    /* job descriptions */

    getJobDescriptions = async () => {
        let id = 0;
        await this.props.getJobDescriptions(id);

        if (this.props.job_desc_res?.data && this.props.job_desc_res?.status == 'success') {
            this.setState({
                job_descriptions_options: this.props.job_desc_res?.data
            });
        }

    }

    /* job descriptions */


    /* handle Submit */
    handleSubmit = async (e) => {

        let notify = null;
        let formData = {
            user_id: this.state.user_id,
            company_id: this.state.company_id,
            feature_id: this.state.feature_id,
            job_title: this.state.job_title,
            designation: this.state.designation,
            nature_of_employment: this.state.nature_of_employment,
            job_type: this.state.job_type,
            job_description: this.state.job_description,
            skill_set: this.state.skill_set.toString(),
            qualification: this.state.qualification,
            ctc_from: this.state.ctc_from,
            ctc_to: this.state.ctc_to,
            min_work_exp: this.state.min_work_exp,
            max_work_exp: this.state.max_work_exp,

            job_id: this.state.edit_id,
            job_function: this.state.job_function,
            number_of_vaccancy: this.state.number_of_vaccancy,

            company_details: this.state.company_details,
            job_posting_date: this.state.job_posting_date,
            job_expiry_date: this.state.job_expiry_date,
            jd_title: this.state.jd_title,
            purpose: this.state.purpose,
            industry: this.state.industry,
            job_responsibilities: this.state.job_responsibilities,
            preffered_skills: this.state.preffered_skills,
            desired_qualification: this.state.desired_qualification,
            summary: this.state.summary,
            rounds: JSON.stringify(this.state.rounds),
            show_company_website_link: this.state.show_company_website_link,
            show_company_banner: this.state.show_company_banner,
            show_company_logo: this.state.show_company_logo,
            plan_id: this.state.plan_id,

            hiring_agencies: this.state.show_hiring_agencies,

            job_country: this.state.jobCountryLoc,
            job_city: this.state.jobCityLoc,
            show_hr_details: this.state.show_hr_details,

            que_edu_qualification: this.state.que_edu_qualification,
            que_skill_set: this.state.que_skill_set,
            que_salary: this.state.que_salary,
            questionnaire: this.state.questionnaire,
            badges: JSON.stringify(this.state.badges),

            hr_name: this.state.hrName,
            hr_designation: this.state.hrDesignation,
            company_name: this.state.compName,
            category: this.state.compCategory,
            sub_category: this.state.compSubcategory,
            email: this.state.compEmail,
            phone: this.state.compPhone,
            website: this.state.compWebsite,
            country: this.state.compCountry,
            state: this.state.compState,
            city: this.state.compCity,
            logo: this.state.logo,
            job_location: this.state.country,
        };
        let res;
        if (this.state.edit_id) {
            await this.props.updateJob(JSON.stringify(formData));
            res = this.props.edit_job_data;
        } else {
            await this.props.createJob(formData);
            res = this.props.data;
        }

        if (res) {

            if (res.status == 'success') {
                notify = notification({ message: res.message, type: 'success' });

                routePushed('/successful', this.props, { message: 'Your Job Added Successfully.' });

                //routeChanged('/successful', this.props);

            } else {
                notify = notification({ message: JSON.stringify(res.message), type: 'error' });
            }
        }

        if (notify)
            notify();

    }
    /* handle Submit */

    render() {

        let errs = this.state.errors && Object.keys(this.state.errors).map((k, v) => { return this.state.errors[k].length >= 1 && <li className="text-danger">{this.state.errors[k]}</li> }
        )

        return (
            <Section>
                <Main>

                    {errs &&
                        <ul>
                            {errs}
                        </ul>
                    }

                    {(this.state.api_res) && <p className="text-danger">{this.state.api_res}</p>}

                    {/* Job Form */}
                    {(this.state.step == 1) &&
                        <JobForm
                            handleChange={this.handleChange}
                            getProbableCandidate={this.getProbableCandidate}
                            addLogo={this.addLogo}
                            errors={this.state.errors}
                            formData={this.state}
                            selectTemplate={this.selectTemplate}
                            jobTypeDetails={this.jobTypeDetails}
                            getJobDescriptions={this.getJobDescriptions}
                            setJDForm={this.setJDForm}
                            step1Submit={this.step1Submit}
                            is_jd_form={this.state.is_jd_form}
                            setDescForm={this.setDescForm}
                            subCategory={this.subCategory}
                            stateDetails={this.stateDetails}
                            cityDetails={this.cityDetails}
                            jobcityDetails={this.jobcityDetails}
                        />
                    }
                    {/* Job Form */}

                    {this.state.step == 2 &&
                        <InterviewRounds
                            rounds={this.state.rounds}
                            addRound={this.addRound}
                            setQuestion={this.setQuestion}
                            questions={this.state.ques}
                            show_add_round_form={this.state.show_add_round_form}
                            setStep={this.setStep}
                            createRound={this.createRound}
                            editRound={this.editRound}
                            deleteRound={this.deleteRound}
                            edit_round_index={this.state.edit_round_index}
                            badgesChangeHandler={this.badgesChangeHandler}
                            updatedBadge={this.updatedBadge}
                            badges={this.state.badges}
                            updatequestionnaire={this.updatequestionnaire}
                            questionnaire={this.state.questionnaire}
                            questionnaireChangeHandler={this.questionnaireChangeHandler}
                        />
                    }

                    {/* Preview Job */}
                    {this.state.step == 3 &&

                        <JobPreview
                            formData={this.state}
                            handleSubmit={this.handleSubmit}
                            setStep={this.setStep}
                        />

                    }
                    {/* Preview Job */}

                </Main>


                <SideBar>
                    <ProfileName />
                    <ActionButtons />
                    <Company />
                </SideBar>

            </Section>

        );

    }

}

const mapStateToProps = (state) => {
    const { data, templatedata, single_template_data, edit_job_data, update_job_data, job_type_res, job_type_details_res, job_desc_res, comp_category_res, comp_sub_category_res, country_res, state_res, city_res, citiesdata, probable_candidates_res } = state.common;
    return {
        data,
        templatedata,
        single_template_data,
        edit_job_data,
        update_job_data,
        job_type_res,
        job_type_details_res,
        job_desc_res,
        comp_category_res,
        comp_sub_category_res,
        country_res,
        state_res,
        city_res,
        citiesdata,
        probable_candidates_res,
    }
};

function mapDispatchToProps(dispatch) {
    return {
        createJob: (formData) => dispatch(createJob(formData)),
        jobTypes: (obj) => dispatch(jobTypes(obj)),
        getTemplate: (id) => dispatch(getTemplate(id)),
        getSingleTemplate: (id) => dispatch(getSingleTemplate(id)),
        editJob: (formData) => dispatch(editJob(formData)),
        updateJob: (formData) => dispatch(updateJob(formData)),
        jobTypeDetails: (id) => dispatch(jobTypeDetails(id)),
        getJobDescriptions: (id) => dispatch(getJobDescriptions(id)),
        getCompanyCategories: () => dispatch(getCompanyCategories()),
        getCompanySubcategories: (id) => dispatch(getCompanySubcategories(id)),
        getCountry: () => dispatch(getCountry()),
        getState: (id) => dispatch(getState(id)),
        getCity: (id) => dispatch(getCity(id)),
        get_probable_candidate: (str) => dispatch(get_probable_candidate(str)),
        getCities: (id) => dispatch(getCities(id)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AddJob);