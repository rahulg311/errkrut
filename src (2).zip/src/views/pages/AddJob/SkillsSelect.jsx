import React, { useState, useEffect } from 'react';
import { getSkills } from '../../../store/actions/skills';
import { useDispatch, useSelector } from 'react-redux';
import { SELECTED_SKILLS_DATA } from '../../../config/constants';

const SkillsSelect = (props) => {
    const [search, setSearch] = useState('');
    const [filterItems, setFilterItems] = useState([]);
    const [items, setItems] = useState([]);

    const dispatch = useDispatch();

    const { skillsdata, selectedSKills } = useSelector((state) => state.common);

    useEffect(() => {
        dispatch(getSkills());
        if (selectedSKills.length >= 1) {
            //setSelectedItems(selectedSKills);
        }
    }, []);

    useEffect(() => {
        if (skillsdata?.data) {
            let skills = Object.keys(skillsdata?.data).map((key) => {
                return skillsdata.data[key];
            });
            setItems(skills);
        }
    }, [skillsdata]);


    useEffect(() => {
        let skill = [];
        let skill_set = [];
        if (!Array.isArray(props.getSkillSet)) {
            skill_set = [props.getSkillSet];
        } else {
            skill_set = props.getSkillSet;
        }
        if (props.getSkillSet != '') {
            setSelectedItems(skill_set);
        }
    }, [props.getSkillSet]);

    const [selectedItems, setSelectedItems] = useState([]);

    const handleRemoveSelectedItem = (value) => {
        const filterItems = [...selectedItems].filter((e) => e !== value);
        setSelectedItems(filterItems);
        props.handleChange({ target: { name: 'skill_set', value: filterItems } });
    };

    useEffect(() => {
        //dispatch({ type: SELECTED_SKILLS_DATA, data: selectedItems })
    }, [selectedItems]);

    const handleAddSelectedItem = (value) => {
        const filterItems = [...new Set([...selectedItems, value])];
        setSelectedItems(filterItems);
        props.handleChange({ target: { name: 'skill_set', value: filterItems } });
    };

    const setItemsHandleChange = (item, newItems) => {
        setSelectedItems([...selectedItems, item])
        props.handleChange({ target: { name: 'skill_set', value: [...selectedItems, item] } });
    }


    React.useEffect(() => {
        const newArray = [...items].filter((item) => item.toLowerCase().includes(search.toLowerCase()));
        setFilterItems([...new Set(newArray)]);
    }, [search]);

    return (
        <div className='position-relative'>
            <div className='position-relative'>
                <input
                    placeholder='search'
                    className='form-control'
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                {search && (
                    <button
                        type='button'
                        class='btn-close translate-right-middle'
                        style={{ right: '10px' }}
                        onClick={() => setSearch('')}
                        aria-label='Close'
                    ></button>
                )}
            </div>
            <main className='w-35'>
                {search && filterItems.length >= 1
                    ? filterItems.map((item, i) => (
                        <div className='list-group '>
                            <li className='list-group-item list-group-item-action'>
                                <div class='form-check'>
                                    <input
                                        class='form-check-input'
                                        type='checkbox'
                                        checked={selectedItems.includes(item)}
                                        value={item}
                                        id={i}
                                        onChange={(e) => {
                                            e.target.checked
                                                ? setItemsHandleChange(item, selectedItems)
                                                : handleRemoveSelectedItem(e.target.value);
                                        }}
                                        onBlur={(e) => props.getProbableCandidate(e)}
                                    />
                                    <label class='form-check-label h-100 w-100' for={i}>
                                        {item}
                                    </label>
                                </div>
                            </li>
                        </div>
                    ))
                    : search && (
                        <button
                            className='btn bg-secondary bg-opacity-10 mt-1 fs-13'
                            onClick={() => handleAddSelectedItem(search)}
                            type="button"
                        >
                            Create Skill
                        </button>
                    )}
            </main>
            <div className='mt-2'>
                {selectedItems.map((item) => {
                    return (
                        <span
                            class='badge border text-dark p-1 me-1 fs-13 rounded-pill mb-1'
                        >
                            {item} <i className="las la-times cursor" onClick={() => handleRemoveSelectedItem(item)}></i>
                        </span>
                    );
                })}
            </div>
        </div >
    );
};

export default SkillsSelect;
