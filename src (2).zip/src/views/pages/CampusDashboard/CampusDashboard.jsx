import React, { Component } from 'react';
import CompaniesCard from '../../../components/Cards/CompaniesCard';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import TopJobsCard from '../../../components/Cards/TopJobsCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Search from '../../../components/Search';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import JobsList from '../../../components/Cards/JobsList';

import { getJobs } from '../../../store/actions/jobs';
import { connect } from "react-redux";
import { isLoggedIn, isRecruiter } from '../../../classes';
import SideBar from '../../../components/hoc/SideBar';
import Loading from '../../../components/common/Loading';
import { Link } from 'react-router-dom';
import { createLetter } from '../../../store/actions/letter';


class CampusDashboard extends Component {

	

	render() {
		return (
			<div className='container'>
				<div className='row gx-5 gy-5 '>
					<section className='col-lg-9'>
						<div>
						<div className='row gx-4  mb-2 rounded-4'>
					<div className='col-lg-12 mt-2 mb-2 '>
						<div className='container  rounded-4'>
						<div className=" row bg-white mt-2   ">
                   <div className='container'>
                   <div className='bg-white pt-4 pb-4 px-2 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
							<h4 className='font-bold float-left'>Dashboard</h4>
							<p className='float-right mt-auto mb-auto'>
								<a href='/search'>See All</a>
							</p>
						</div>
					</div>
					
				</div>
                <div className='row mt-4 '>
                    <div className='col-md-6 cards-shadow'>
                   
                        <div className='row mt-3 mb-1'>
					<div className='col-md-5 mt-1'>
					
							<h6 className='font-bold float-left'>Campus List</h6>
					

						
					
				</div>
                <div className='col-md-7'> 							<select class="form-select fs-12" aria-label="Default select example">
  <option selected>All Invited Companies</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select></div>

                        </div>
                       
							<div className='row'>
                            <div className='col-md-12 ms-1'>
							
										 <div className='row  me-1'>
											 <div className='col-12 pt-1 cards-shadow bg-blue rounded-3  pb-1'>
												 <p className='float-start fs-10 fw-bold text-white'>Campus 1</p>
												 <p className='float-end fw-bold fs-10 text-white'>10</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-10 fw-bold'>Campus 2</p>
												 <p className='float-end fw-bold fs-10'>42</p>
											 </div>
											 <div className='col-12 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-10 fw-bold'>Campus 3</p>
												 <p className='float-end fw-bold fs-10'>4</p>
											 </div>
											 <div className='col-12 b-2 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-10 fw-bold'>Campus 4</p>
												 <p className='float-end fw-bold fs-10'>12</p>
											 </div><div className='col-12 mb-1 pt-1 cards-shadow pb-1 mt-1'>
												 <p className='float-start fs-10 fw-bold'>Campus 5</p>
												 <p className='float-end fw-bold fs-10'>4</p>
											 </div>
											
											
										 </div>
									 
                                
                            </div>
                        </div>

                    </div>
                    <div className='col-md-6'>
                    <div className='row '>
                 <div className='col-md-4 mb-2  '>
					<div className='cards  bg-blue br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>70</p>
						<p className='fs-14 position-abs b-2 pe-1 text-right m-0 float-end mt-4  font-bold pb-1 '><span className='float-end '> Total</span> <br />  <span>Students CV</span></p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-greenesh-blue br-5 text-white ps-1 h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>12</p>
						<p className='fs-14 position-abs b-2 r-2 text-right m-0 float-end mt-4 font-bold  pb-1  '><span className='float-end me-1'>Companies</span> <br /> <span className='ms-2 me-1 float-end'> Invited</span> </p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-dark-pink br-5 text-white ps-1  h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>10</p> 
						<p className='fs-14 position-abs b-2 r-2  me-1 text-right m-0 float-end mt-4 font-bold  pb-1 '><span className='float-end'> Recruitment</span> <br /> <span className=' float-end'> Members</span> </p>
					</div>
				</div>
                 </div>
                 <div className='row '>
                 <div className='col-md-6    '>
                       <div className='pt-1 p-1   shadow'>
                       <h6>12/20</h6>
                         <progress className='mt-1 ' id="file" value="32" max="100"> 32% </progress>
                         <div className='row'>
                             <div className='col-md-12'>
                                 <p className='float-start fs-10'>Want to post more jobs?</p>
                                 <a href="#" className='float-start fs-10 float-end'> click here</a>
                                 <h6 className='float-end f-0-8 mt-1 mb-1'>Company Invited Sent</h6>
                       </div>
                             </div>
                             {/* <div className='row mt-1 mb-1'>
                                 <div className='col-md-12'>
                                 <h6 className='float-end f-0-8'>Job Posted</h6>
                                 </div>
                             </div> */}
                           
                         </div>
                     </div>
                     <div className='col-md-6    '>
                       <div className='pt-1 p-1   shadow'>
                       <h6>12/20</h6>
                         <progress className='mt-1 ' id="file" value="32" max="100"> 32% </progress>
                         <div className='row'>
                             <div className='col-md-12'>
                                 <p className='float-start fs-10'>Want to post more jobs?</p>
                                 <a href="#" className='float-start fs-10 float-end'> click here</a>
                                 <h6 className='float-end f-0-8 mt-1 mb-1'> Sent</h6>
                       </div>
                             </div>
                             {/* <div className='row mt-1 mb-1'>
                                 <div className='col-md-12'>
                                 <h6 className='float-end f-0-8'>Job Posted</h6>
                                 </div>
                             </div> */}
                           
                         </div>
                     </div>
                 </div>

                    </div>
                </div>
			</div>
                
                 </div>
               </div>
						<div className='row mt-2 bg-white '>
									<div className='col-md-12'>
									<TopCompaniesCard></TopCompaniesCard>
										</div>
										</div>
					
					
							{/* <div className='bg-white'>
								<TopCompaniesCard></TopCompaniesCard>
							</div> */}
							
							
							<div className='row mt-2 mb-2  bg-white '>
								<div className='col-md-10 col-12   '>
									<h4 className='float-start p-2 pt-4 pb-4 '>Send Company Invitation</h4>
									
								</div>
								<div className='col-md-2 col-12'>
								<button type="button" class="btn btn-primary  w-100   mb-2 mt-3 ">Start Now</button>
									
								</div>
								</div>
								<div className='row pb-5'>
								<div className='container bg-white '>
								<div className='row mt-3  mb-2'>
										<div className='col-md-3 '>
											<p className=' fs-5 text-primary ms-2 fw-bold'>Student CV</p> </div>
										<div className='col-md-9 '>
											<p className='text-muted fs-5'>Companies Invited</p> </div>
									</div>
									<div className='border-bottom-blue'></div>
									<div className='row  mt-2  '>
								<div className='col-md-9 col-12   '>
									<h5 className='mt-1 ms-2  mb-1 '>Add more student CV's here</h5>
									
								</div>
								<div className='col-md-3 col-12'>
								<button type="button" class="btn btn-primary     ">Import Students</button>
									
								</div>
								</div>
								<div className='container row pb-5 '>
									<div className='col-md-12'>
									<header className='row bg-primary text-white p-1 rounded-top shadow mt-4'>
					{/* <div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Title</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					{/* <div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>category</span>

						<i class='fas fa-sort mt-4px'></i>
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>Tags</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Name 	<i class='fas fa-sort mt-4px ms-4'></i></span>

					
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Key Skills 	<i class='fas fa-sort mt-4px ms-4'></i></span>

					
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Date <i class='fas fa-sort mt-4px ms-4'></i></span>

						
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Status <i class='fas fa-sort mt-4px ms-4'></i></span>

						
					</div>
				</header>
									</div>
									<main>
				<div className ="row align-items-center p-2 bg-light-blue  bg-table-striped ">
								<div className='col-3'>
									<small className ='fs-6'>Rahul</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-3'>
									<small className='fs-6'>Creative thinking</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>31-12-2021</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>Accepted <i class="fas fa-ellipsis-v ms-7"></i></small>
								</div>
								{/* <div className='col-2 text-center'>
									<div className='d-flex justify-content-end'>
										<Link to='' className='btn btn-sm  border'>
											<i class='fas fa-edit'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2'
											
										>
											<i class='fas fa-trash'></i>
										</button>
									</div>
								</div> */}
							</div>
							<div className ="row align-items-center p-2 bg-light-blue  bg-table-striped ">
								<div className='col-3'>
									<small className ='fs-6'>gupta</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-3'>
									<small className='fs-6'>Creative thinking</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>31-12-2021</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>Accepted <i class="fas fa-ellipsis-v ms-7"></i></small>
								</div>
								{/* <div className='col-2 text-center'>
									<div className='d-flex justify-content-end'>
										<Link to='' className='btn btn-sm  border'>
											<i class='fas fa-edit'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2'
											
										>
											<i class='fas fa-trash'></i>
										</button>
									</div>
								</div> */}
							</div>
					
				</main>
								</div>
				
				
								</div></div>
								
								<div>
								
			</div>
									
						
							</div>
						

							</div>
					</div>

								{/* load more */}
							

							
						
						</div>
					</section>
					<SideBar>
						<ProfileName />
						<CandidateCards hello={{ hello: 'yes' }}></CandidateCards>
						<Skills></Skills>
						<FeaturedCompanies></FeaturedCompanies>
						<Designations />
						<Locations />
						<Company></Company>
					</SideBar>
				</div>
			</div>
		);
	}
}




export default CampusDashboard;
