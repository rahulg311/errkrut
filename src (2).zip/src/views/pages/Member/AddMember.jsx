import React, { useEffect, useState } from "react";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import Company from "../../../components/Contact/Company";
import Option from "../../../components/Cart/Option";
import { Link } from "react-router-dom";
import { getLoggedInUser, getAuthToken } from "../../../classes/index";
import {
  END_POINT,
  GET_ACCESS_LEVEL,
  GET_ALL_MEMBERS,
  UPDATE_ADD_MEMBER,
  CREATE_ADD_MEMBER,
} from "../../../routes/api_routes";
import { notification } from "../../../classes/messages";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import Section from "../../../components/hoc/Section";
import Main from "../../../components/hoc/Main";
import SideBar from "../../../components/hoc/SideBar";
import Loading from "../../../components/common/Loading";
import useFetch from "../../../hooks/useFetch";

const AddMember = ({ history }) => {
  const { data, loading, error, doFetch } = useFetch();
  const [memberList, setMemberList] = useState({});
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [designation, setDesignation] = useState("");
  const [level, setLevel] = useState("");
  const [postloading, setPostLoading] = useState(false);
  const [edit_id, setEditId] = useState(null);
  const [memberId, setMemberId] = useState(null);
  const [user, setUser] = useState(null);

  const getMember = async () => {
		const result = await getLoggedInUser();
		let token = await getAuthToken();
		fetch(END_POINT + GET_ALL_MEMBERS + "/" + result.id, {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		})
			.then((response) => response.json())
			.then((data) => {
				setMemberList(data?.data);

			});
	}
  useEffect(async () => {
		const result = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		};

		setUser(result);
    console.log(result)
		if(result?.company_id){
			doFetch(END_POINT + GET_ACCESS_LEVEL + '?company_id=' + result.company_id);

		}else{

			doFetch(END_POINT + GET_ACCESS_LEVEL + '?campus_id=' + result.id);
		}
		getMember();
	}, []);

  const editAddMember = async (obj) => {
    console.log( obj);
    setEditId(obj.id);
    setMemberId(obj.member_id)
    setName(obj.name);
    setEmail(obj.email);
    setDesignation(obj.designation);
    setLevel(data?.data.filter(opt => opt.name === obj.access_level)[0].id);
  };

  const cancelMember = () => {
    setEditId(false);
    setName(" ");
    setEmail(" ");
    setDesignation(" ");
    setLevel(" ");
  };


  const handleOnSave = async () => {
		console.log(name, email, designation, level);
		setPostLoading(true);
		const result = await getLoggedInUser();
		let token = await getAuthToken();
    const formdata = new FormData();

    let url='';
    if(edit_id){
      url = UPDATE_ADD_MEMBER;
      formdata.append('member_id', memberId);
    }else{
      url = CREATE_ADD_MEMBER;
      formdata.append('user_id', result.id);
      formdata.append('email', email);
    }
		

		formdata.append('name', name);
		formdata.append('designation', designation);
		formdata.append('access_level', level);

		const requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

    fetch(END_POINT + url, requestOptions)
			.then((response) => response.json())
			.then((data) => {
        console.log(data)
				if (data.status == 'success') {
					let notify = notification({ message: data.message, type: 'success' });
					notify();
					setPostLoading(false);
					history.push('/recruiter/members');
				} else {
					data.message.forEach((element) => {
						let notify = notification({ message: element, type: 'error' });
						notify();
						setPostLoading(false);
					});
				}
			})
			.catch((error) => console.log('error', error));
  }

  return (
    <Section>
      <Main>
        <header className="border-bottom border-primary py-2 border-2">
          <h4>Add Member </h4>
        </header>
        <main className="mt-4">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">
              Name
            </label>
            <input
              type="email"
              class="form-control"
              id="exampleFormControlInput1"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">
              Email
            </label>
            <input
              type="email"
              class="form-control"
              id="exampleFormControlInput1"
              disabled={edit_id}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">
              Designation
            </label>
            <input
              type="email"
              class="form-control"
              id="exampleFormControlInput1"
              value={designation}
              onChange={(e) => setDesignation(e.target.value)}
            />
          </div>

          <select
            class="form-select"
            aria-label="Default select example"
            value={level}
            onChange={(e) => setLevel(e.target.value)}
          >
            <option value="">Access Level</option>
            {data != null &&
              data?.data?.map((opt) => {
                return <option value={opt.id}>{opt.name}</option>;
              })}
          </select>
          <div className="text-end mt-5">
            {edit_id && (
              <button
                type="button"
                className="btn btn-outline-primary px-4 mr-10"
                onClick={(e) => {
                  cancelMember();
                }}
              >
                Cancel
              </button>
            )}
            <button
              className="btn bg-primary text-white px-5"
              disabled={postloading}
              onClick={(e) => handleOnSave(e)}
            >
              {postloading ? (
                <div
                  className="spinner-border spinner-border-sm"
                  role="status"
                ></div>
              ) : edit_id ? (
                "Save"
              ) : (
                "Send Verification Link"
              )}
            </button>
          </div>

          <div className="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mt-3 mb-3 f-0-9"></div>

          {/* Member lists */}
          <h4 className="text-primary f-r-16">Edit Member</h4>

          {loading == true && <Loading />}

          {Object.keys(memberList).length != 0 &&
            memberList?.map((member) => {
              return (
                <div className=" mt-2">
                  <div class="mb-1 d-flex">
                    <h5 class=" f-r-14 mt-1">{member.name}</h5>
                    <button
                      type="button"
                      className="btn btn-outline-primary f-r-12 btn-sm px-5 ms-auto float-end"
                      onClick={(e) => {
                        editAddMember(member);
                      }}
                    >
                      Edit
                    </button>
                  </div>
                  <div class="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mb-3 f-0-9"></div>
                </div>
              );
            })}

          {/* Member lists */}
        </main>
      </Main>
      <SideBar>
        <ProfileName></ProfileName>
        <ActionButtons />
        <Company></Company>
      </SideBar>
    </Section>
  );
};

export default AddMember;
