import React from 'react'

const EditQuestion = () => {
    return (
        <div>
            
        </div>
    )
}

export default EditQuestion
