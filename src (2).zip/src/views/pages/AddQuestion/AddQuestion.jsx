import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { END_POINT } from '../../../routes/api_routes';
import QuestionForm from './AddQuestion/QuestionForm';
import Loading from '../../../components/common/Loading';
import useFetch from '../../../hooks/useFetch';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';
import SideBar from '../../../components/hoc/SideBar';

const AddQuestion = () => {
	const { data, loading, error } = useFetch(END_POINT + 'get_question_attr');
	React.useEffect(() => {
		console.log('data', data);
	}, [data]);
	return (
		<div className='container'>
			<Section>
				<Main>{loading ? <Loading /> : <QuestionForm data={data?.data} />}</Main>
				<SideBar>
					<ProfileName />
					<ActionButtons />
					<Company />
				</SideBar>
			</Section>
		</div>
	);
};

export default AddQuestion;
