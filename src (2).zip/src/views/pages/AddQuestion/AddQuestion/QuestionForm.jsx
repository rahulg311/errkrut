import React, { useState } from 'react';
import MultiSelect from '../MultiSelect';
import { getAuthToken, getLoggedInUser } from '../../../../classes/index';
import { AddQuestion, END_POINT, QUESTION_IMPORT } from '../../../../routes/api_routes';
import { notification } from '../../../../classes/messages';
import { routePushed } from '../../../../classes/browserHistory';
import { useHistory } from 'react-router';
import usePost from "../../../../hooks/usePost";
import ImportQuestionModal from "../../../../components/Recruiter/ImportQuestionModal";


const QuestionForm = ({ data }) => {
	const [question, setQuestion] = useState('');
	const [importQuestionModal, setQuestionModal] = useState(false);

	const [multiSelectTags, setMultiSelectTags] = useState([]);
	const [hint, setHint] = useState('');
	const [questionType, setQuestionType] = useState('subjective');
	const [explanation, setExplanation] = useState('');
	const [accessType, setAccessType] = useState(1);
	const [createdBy, setCreatedBy] = useState('');
	const [options, setOptions] = useState([]);
	const [optionsError, setOptionsError] = useState('');
	const [attributes, setAttributes] = useState([]);
	const [attributesError, setAttributesError] = useState('');
	const [optiondata, setOptionData] = useState([{
		value: 'true',
		is_correct: 0,
		weightage: '',
		id: new Date().getMilliseconds(),
	}, {
		value: 'false',
		is_correct: 0,
		weightage: '',
		id: new Date().getMilliseconds(),
	}]);
	const { response, isLoading, error, doPost } = usePost();
	const history = useHistory()

	const form_fields = [];
	const closeImportModal = () => setQuestionModal(false);
	const showImportModal = () => setQuestionModal(true);
	const handleImportSubmit = async (file) => {
		const user = await getLoggedInUser();
		const formData = new FormData();
		formData.append("company_id", user.id);
		formData.append("file", file);
		let token = await getAuthToken();
		const requestOptions = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			headers: { 'Authorization': 'Bearer ' + token }

		};

		doPost(`${QUESTION_IMPORT}`, formData, requestOptions).then((result) => {
			let notify = "";
			if (result.status == "success") {
				notify = notification({
					type: 'success',
					message: result.message,
				});
			}
			else {
				notify = notification({
					type: 'error',
					message: 'Something went wrong',
				});
			}
			notify();
		});

		closeImportModal();
	}
	const handleChange = (e, regex = '', type = '') => {
		const that = this;
		if (e.target) {
			let ivalue = e.target.value;
			let iname = e.target.name;
			setAttributes(...attributes, { iname: ivalue });
		}
	};


	const handleSubmit = async (e) => {
		e.preventDefault();
		let token = await getAuthToken();
		let user = await getLoggedInUser();
		let is_form_valid = true;

		// console.log(multiSelectTags);
		// console.log(accessType);
		// console.log(JSON.stringify(options));

		const formData = {
			access_type: accessType,
			created_by: user.id,
			options: JSON.stringify((questionType == "True-False") ? optiondata : options),
			question_tags: multiSelectTags,
		};

		if (e.target.question.value === '') {
			let notify = notification({ message: 'please add Question title', type: 'error' });
			notify();
			is_form_valid = false;
			return;
		}

		data?.map((item) => {
			if (item.name !== 'question_tags' &&
				item.name !== 'Complexity'
			)
				if (e.target[item.name]?.value) {
					formData[item.name] = e.target[item.name]?.value;
				}
				else {
					let notify = notification({ message: `please add ${item.name} value`, type: 'error' });
					notify();
					is_form_valid = false;
					return;
				}
		});


		if (e.target.hint.value === '') {
			let notify = notification({ message: 'please add hint', type: 'error' });
			notify();
			is_form_valid = false;
			return;
		}

		if (multiSelectTags.length === 0) {
			let notify = notification({ message: 'please select question tags', type: 'error' });
			notify();
			is_form_valid = false;
			return;
		}

		if (e.target.explanation.value === '') {
			let notify = notification({ message: 'please add explanation', type: 'error' });
			notify();
			is_form_valid = false;
			return;
		}

		formData.question = e.target.question.value
		formData.hint = e.target.hint.value;
		formData.explanation = e.target.explanation.value;


		if (questionType.toLowerCase().replaceAll(" ", "") == 'singlechoice' || questionType.toLowerCase().replaceAll(" ", "") == 'sortanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'multiplechoicequestion' || questionType.toLowerCase().replaceAll(" ", "") == 'matchanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'fillintheblank' || questionType.toLowerCase().replaceAll(" ", "") == 'dropdownselect' || questionType.toLowerCase().replaceAll(" ", "") == 'surveytype') {

			if (options.length == 0) {
				let notify = notification({ message: `Please add some options`, type: 'error' });
				notify();
				is_form_valid = false;
				return;
			} else {
				setOptionsError('');
			}


			if (options.some((e) => e.value == '')) {
				let notify = notification({
					message: `Please fill all answer fields`,
					type: 'error',
				});
				notify();
				is_form_valid = false;
				return;
			}


			if (!options.some((e) => e.is_correct == 1) && options.length >= 1) {
				let notify = notification({
					message: `Please select one correct answer`,
					type: 'error',
				});
				notify();
				is_form_valid = false;
				return;
			} else {
				setOptionsError('');
			}
		}

		if (is_form_valid) {
			fetch(END_POINT + AddQuestion, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					Accept: 'application/json',
					Authorization: 'Bearer ' + token,
					'Content-Type': 'application/json',
				},
			})
				.then((res) => {
					return res.json();
				})
				.then((data) => {
					if (data.status == 'success') {
						let notify = notification({ message: data.message, type: 'success' });
						notify();
						history.push('/recruiter/questions');
					} else {
						data.message.forEach((message) => {
							let notify = notification({ message: message, type: 'error' });
							notify();
						})

					}
				})
				.catch((err) => console.log(err));
		}
	};

	const handleMultiSelect = (data) => {
		setMultiSelectTags(data);
	}

	React.useEffect(() => { }, [options]);

	return (
		<>
			<ImportQuestionModal
				is_modal={importQuestionModal}
				closeModal={closeImportModal}
				handleSubmit={handleImportSubmit}
			/>
			<form method='POST' className='px-1 py-3' onSubmit={handleSubmit}>
				<div>
					<div className='d-flex align-items-center justify-content-between'>
						<h4 className='text-dark'>Add Question</h4>
						<button type='button' className='btn btn-primary' onClick={showImportModal}> Import File</button>
					</div>
					<div className='border-gray-line mt-2 mb-2'></div>

					{/* Question Title */}
					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Question title</label>
						</div>
						<div className='col-md-12'>

							<input
								type='text'
								value={question}
								onChange={(e) => setQuestion(e.target.value)}
								className='form-control'
								name='question'

							/>
						</div>
					</div>
					{/* Question Title */}

					{/* Question Fields */}
					<div className='row mt-2 w-100'>
						{data?.map((field) => {
							if (field.type.toLowerCase() == 'radio' &&
								field.name == 'Difficulty'
							) {
								return (
									<>
										<div>
											<label className='text-dark'>{field.title}</label>
										</div>

										<div className='d-flex'>
											{field.options.split(',').map((option, index) => {
												return (
													<div class='form-check my-1	 me-2 '>
														<input
															class='form-check-input'
															type='radio'
															name={field.name}
															id={field.name + index}
															value={option}
														/>
														<label class='form-check-label' for={field.name + index}>
															{option}
														</label>
													</div>
												);
											})}
										</div>
									</>
								);
							} else if (field.type.toLowerCase() === 'text') {
								return (
									<div className='my-2'>
										<div>
											<label className='text-dark'>{field.title}</label>
										</div>
										<div className=''>
											<input type='text' className='form-control' name={field.name} />
										</div>
									</div>
								);
							} else if (field.type == 'MultiSelect') {
								const options = field.options.split(',');
								return (
									<div className='my-2'>
										<div className='w-100'>
											<div>
												<label className='text-dark'>{field.title}</label>
											</div>
											<div>
												<MultiSelect options={options} handleMultiSelect={handleMultiSelect} />
											</div>
										</div>
									</div>
								);
							} else if (
								field.type.toLowerCase() == 'dropdown' ||
								field.type.toLowerCase() == 'select'
							) {
								return (
									<div className='mb-3'>
										<div>
											<label className='text-dark'>{field.title}</label>
										</div>
										<div>
											<select
												class='form-select px-4 mt-1'
												name={field.name}
												onChange={(e) => { if (field.name == 'question_type') { setQuestionType(e.target.value) } }}
											>
												{field.options.split(',').map((option) => {
													return <option value={option}>{option}</option>;
												})}
											</select>
										</div>
									</div>
								);
							} else if (field.type.toLowerCase() == 'number') {
								return (
									<div>
										<div className='my-3'>
											<label className='text-dark'>{field.title}</label>
										</div>
										<div className=''>
											<input
												type='number'
												className='form-control'
												name={field.name}

											/>
										</div>
									</div>
								);
							}
						})}
					</div>

					{/* Question Fields */}

					{/* Question Attributes */}

					{/* dynamic fields here */}

					{form_fields.length > 0 ? form_fields.map((v, k) => {
						return <>
							<div className="mt-3 mb-3">{v.title}
								{v.fields}</div>
						</>
					}) : ''}

					{/* dynamic fields here */}


					{/* Question Attributes */}


					{/* question tags */}
					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Hint</label>
						</div>
						<div className='col-md-12'>
							<textarea
								value={hint}
								onChange={(e) => setHint(e.target.value)}
								className='form-control'
								name='hint'

							></textarea>
						</div>
					</div>

					<div className='row mt-2 w-100'>
						<div className='col-md-12'>
							<label className='text-dark'>Explanation</label>
						</div>
						<div className='col-md-12'>
							<textarea
								value={explanation}
								onChange={(e) => setExplanation(e.target.value)}
								className='form-control'
								name='explanation'

							></textarea>
						</div>
					</div>

					<div className='row mt-2 w-100'>
						{[].map((ele, index) => (
							<div className='col-md-6'>
								<div className='col-md-12'>
									<label className='text-dark'>Option {index + 1}</label>
								</div>
								<div className='col-md-12'>
									<input type='text' className='form-control' name={`option${index}`} />
								</div>
							</div>
						))}
					</div>
					{
						(questionType.toLowerCase().replaceAll(" ", "") == 'true-false' &&
							<>
								{optiondata.map((val, i) => {
									return <section key={i} className='row mb-2 align-items-center'>
										<div className='col-3'>
											<span className='mt-2px'>{String.fromCharCode(i + 97)}</span>
											<input
												class='form-check-input mx-2'
												type='radio'
												name='flexRadioDefault'
												id='flexRadioDefault1'
												value={val}
												onChange={(e) => {
													const newOptions = [...optiondata].map((e) => {
														return {
															...e,
															is_correct: 0,
														};
													});
													newOptions[i].is_correct = e.target.checked ? 1 : 0;
													setOptionData(newOptions);
												}}
											/>
										</div>
										<div className='col-6 justify-content-between align-items-center'>
											<input
												type='text'
												className='form-control me-2'
												value={val.value}
												onChange={(e) => {
													const newOptions = [...optiondata];
													setOptionData[i].value = e.target.value;
													setOptions([...newOptions]);
												}} readOnly
											/>
										</div>

										<div className='col-3 justify-content-between align-items-center'>
											<div className='d-flex align-items-start'>

												<input
													type='text'
													min="0"
													className='form-control me-2'
													onChange={(e) => {
														/* const newOptions = [...options].map((e) => {
															return {
																...e,
																weightage: 0,
															};
														}); */
														const newOptions = optiondata;
														newOptions[i].weightage = e.target.value;
														setOptionData(newOptions);
													}}
												/>

											</div>
										</div>
									</section>;
								})}
							</>

						)
					}

					{(questionType.toLowerCase().replaceAll(" ", "") == 'singlechoice' || questionType.toLowerCase().replaceAll(" ", "") == 'multiplechoicequestion' || questionType.toLowerCase().replaceAll(" ", "") == 'sortanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'matchanswers' || questionType.toLowerCase().replaceAll(" ", "") == 'fillintheblank' || questionType.toLowerCase().replaceAll(" ", "") == 'dropdownselect' || questionType.toLowerCase().replaceAll(" ", "") == 'surveytype') &&
						<div className='row mt-2 w-100'>
							<p
								className='text-dark mb-1 cursor'
								onClick={() => {
									setOptions([
										...options,
										{
											value: '',
											is_correct: 0,
											weightage: '',
											id: new Date().getMilliseconds(),
										},
									]);
									setOptionsError('');
								}}
							>

								<button className="btn btn-primary btn-sm" type="button">
									<span>Add Option</span>
									<span>
										<i className='las la-plus'></i>
									</span>
								</button>
							</p>

							{/* label options */}
							{options.length > 0 &&
								<section className='row mb-2 align-items-center'>
									<span className='mt-2px col-3'>Correct Option</span>
									<span className='mt-2px col-6'>Option</span>
									<span className='mt-2px col-3'>Points</span>
								</section>
							}
							{/* label options */}

							{options.map((option, i) => {
								return (
									<section key={option.id} className='row mb-2 align-items-center'>
										<div className='col-3'>
											<span className='mt-2px'>{String.fromCharCode(i + 97)}</span>
											<input
												class='form-check-input mx-2'
												type='checkbox'
												name='flexRadioDefault'
												id='flexRadioDefault1'
												value={option.value}
												onChange={(e) => {
													/* const newOptions = [...options].map((e) => {
														return {
															...e,
															is_correct: 0,
														};
													}); */
													const newOptions = options;
													newOptions[i].is_correct = e.target.checked ? 1 : 0;
													setOptions(newOptions);
												}}
											/>
										</div>
										<div className='col-6 justify-content-between align-items-center'>
											<input
												type='text'
												className='form-control me-2'
												onChange={(e) => {
													const newOptions = [...options];
													newOptions[i].value = e.target.value;
													setOptions([...newOptions]);
												}}
											/>
										</div>

										<div className='col-3 justify-content-between align-items-center'>
											<div className='d-flex align-items-start'>

												<input
													type='text'
													min="0"
													className='form-control me-2'
													onChange={(e) => {
														/* const newOptions = [...options].map((e) => {
															return {
																...e,
																weightage: 0,
															};
														}); */
														const newOptions = options;
														newOptions[i].weightage = e.target.value;
														setOptions(newOptions);
													}}
												/>
												<button
													type='button'
													class='btn-close mt-auto mb-auto'
													aria-label='Close'
													onClick={() => {
														const newOptions = [...options].filter((e) => e.id !== option.id);
														setOptions([...newOptions]);
														setOptionsError('');
													}}
												></button>

											</div>
										</div>
									</section>
								);
							})}

							<small className='text-danger mt-2'>{optionsError}</small>
						</div>

					}

					{/* border */}
					<div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>
					{/* border */}


					<div className='row mt-3 w-100'>
						{/* <div className='col-md-6'>
							<button
								href='javascript:void(0)'
								className='btn btn-outline-primary ml-auto mr-auto d-block '
							>
								Add Questions
							</button>
						</div> */}
						<div className='col-md-12'>
							<button type='submit' className='btn btn-primary ms-auto d-block'>
								Save
							</button>
						</div>
					</div>
				</div>
			</form>
		</>
	);
};

export default QuestionForm;