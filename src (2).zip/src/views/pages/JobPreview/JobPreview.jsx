import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { formatTitle, getObjFromArrBykey } from '../../../classes';
import Parser from 'react-html-parser';

class JobPreview extends Component {

    render() {

        const { formData, handleSubmit, setStep } = this.props;

        let skillSet = '';
        if (formData.skill_set.length > 0) {
            if (Array.isArray(formData.skill_set)) {
                skillSet = formData.skill_set.join(', ');
            } else {
                skillSet = formData.skill_set.split(',').join(', ');
            }

        } else {
            skillSet = formData.skill_set;
        }

        let location = '';
        if (formData.jobCityLoc.length > 0) {
            if (Array.isArray(formData.jobCityLoc)) {
                location = formData.jobCityLoc.join(', ');
            } else {
                location = formData.jobCityLoc.split(',').join(', ');
            }

        } else {
            location = formData.jobCityLoc;
        }

        return (
            <div className="main-container position-relative">

                <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                    <div className="container">
                        <div className="row mt-4">

                            {/* Content */}

                            <div className="container">


                                <div className="row">

                                    <div className="col-md-12">
                                        <h4 className="text-primary mt-2 mb-2 f-Poppins-Medium ">Create A Job</h4>
                                    </div>

                                    <div className="border-blue"></div>

                                    <div className="row">
                                        <div className="col-md-12  mt-4  mb-2 text-primary f-Poppins-Medium">
                                            <h6>Promote This Job</h6>
                                        </div>
                                        <div className="col-md-12 f-Poppins-Medium">
                                            <p className=" f-Poppins-Medium">You Can upgrade you plan or get the expansion Pack <span><NavLink to="/plans" target="_blank">Click here</NavLink></span></p>
                                        </div>
                                        <div className="border-blue mt-2 mb-2" ></div>
                                        <div className="row">
                                            <div className="col-md-12 mt-4  mb-2 text-primary f-Poppins-Medium">
                                                <h6>Job Preview</h6>
                                            </div>
                                        </div>

                                        {/* job details */}
                                        <div className='col-md-12 '>
                                            <div className='row'>
                                                <div className='col-md-12'>
                                                    <section className='card shadow border-0 rounded-4 py-3 px-4'>
                                                        <header className='d-flex'>
                                                            <div className='me-3'>
                                                                <img
                                                                    src='/assets/imgs/dummy-logo.png'
                                                                    className='img-fluid box-shadow br-5 h-50px'
                                                                />
                                                            </div>
                                                            <div className="mt-auto mb-auto">
                                                                <h6 className='font-bold'>
                                                                    {formData.job_title}
                                                                </h6>
                                                                <p>{/* {tj.company_name} */}</p>
                                                            </div>
                                                        </header>
                                                        <main>

                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>
                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
                                                                        <i class='las la-briefcase  text-sky-blue font-bold'></i>
                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Experience</p>
                                                                        <small className='ms-3'>
                                                                            {formData.min_work_exp + "-" + formData.max_work_exp} Years
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
                                                                        <i class='las la-map-marker   text-sky-blue font-bold'></i>
                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Location</p>
                                                                        <small className='ms-3'>
                                                                            {formData.jobCountryLoc}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
                                                                        <i class='las la-rupee-sign   text-sky-blue font-bold'></i>
                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Salary</p>
                                                                        <small className='ms-3'>
                                                                            {formData.ctc_from}   - {formData.ctc_to}(L.P.A)
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>
                                                            {/* section */}

                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
                                                                        <i class='las la-edit text-sky-blue font-bold'></i>
                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Skillset</p>
                                                                        <small className='ms-3'>
                                                                            {console.log(formData.skill_set)}
                                                                            {formData.skill_set && formData.skill_set?.join(', ')}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>
                                                            {/* section */}

                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
                                                                        <i class='las la-user-check text-sky-blue font-bold'></i>
                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Vacancy</p>
                                                                        <small className='ms-3'>
                                                                            {formData.number_of_vaccancy}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium text-capitalize'>Job Function</p>
                                                                        <small className='ms-3'>
                                                                            {formData.job_function}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium text-capitalize'>Qualification</p>
                                                                        <small className='ms-3'>
                                                                            {formData.qualification}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>
                                                            {/* section */}


                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium text-capitalize' >Designation</p>
                                                                        <small className='ms-3'>
                                                                            {formData.designation}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>

                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Nature of Employment</p>
                                                                        <small className='ms-3 text-capitalize'>
                                                                            {formatTitle(formData.nature_of_employment)}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>
                                                            {/* section */}

                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>
                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Job Description</p>

                                                                        {formData.is_jd_form == false &&
                                                                            <small className='ms-3'>
                                                                                {getObjFromArrBykey(formData.job_descriptions_options, { key: 'id', value: formData.job_description })?.title}
                                                                            </small>
                                                                        }

                                                                        {formData.is_jd_form == true &&
                                                                            <div className="ms-2">
                                                                                <p>JD Title: {formData?.jd_title}</p>
                                                                                <p>Purpose: {formData?.purpose}</p>
                                                                                <p>Industry: {formData?.industry}</p>
                                                                                <p>Job Summary: {formData?.summary}</p>
                                                                                <p>Preferred Skills: {formData?.preffered_skills}</p>
                                                                                <p>Desired Qualification: {formData?.desired_qualification}</p>
                                                                                <p>JD Responsibilities: {Parser(formData?.job_responsibilities)}</p>
                                                                            </div>
                                                                        }



                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>


                                                            {/* section */}
                                                            <section className='d-md-flex mt-1'>
                                                                <div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
                                                                    {/* detail */}
                                                                    <div className='d-flex align-items-center mt-auto mb-auto f-0-9'>

                                                                        <p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Rounds</p>
                                                                        <small className='ms-3'>
                                                                            {(formData.rounds).length}
                                                                        </small>
                                                                    </div>
                                                                    {/* detail */}
                                                                </div>
                                                            </section>

                                                        </main>
                                                        <hr className='mt-md-3 mt-0' />

                                                    </section>
                                                </div>
                                            </div>
                                        </div>
                                        {/* job details */}

                                        <div className="row mt-2 mb-2 m-0 p-0">

                                            <div className="col-md-6 p-0">
                                                <button className="btn btn-primary d-block btn-block mr-auto" onClick={(e) => setStep(2)}>
                                                    Back
                                                </button>
                                            </div>

                                            <div className="col-md-6 p-0">
                                                <button className="btn btn-primary d-block btn-block ms-auto" onClick={handleSubmit}>
                                                    Post The Job
                                                </button>
                                            </div>
                                        </div>

                                    </div>

                                </div>


                            </div>
                        </div>

                        {/* Content */}

                    </div>

                </div>
            </div>


        );
    }

}

export default JobPreview;