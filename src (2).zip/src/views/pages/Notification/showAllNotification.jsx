import React, { useEffect } from 'react';
import Company from '../../../components/Contact/Company';
import { logout, getLoggedInUser } from '../../../classes';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Main from '../../../components/hoc/Main';
import Section from '../../../components/hoc/Section';
import SideBar from '../../../components/hoc/SideBar';
import useFetch from "../../../hooks/useFetch";
import { END_POINT, GET_NOTIFICATION } from "../../../routes/api_routes";

const ShowAllNotification = () => {
    const RecruiterNotificationList = useFetch();
    const getNotificationList = async () => {
        const result = await getLoggedInUser();
        
        RecruiterNotificationList.doFetch(END_POINT + `${GET_NOTIFICATION}/${result?.id}`);
    };
    useEffect(async () => {
        await getNotificationList();

    }, [])
    const NotificationAll = ({ notification }) => {
        console.log(notification)
        return <>
            <li className={`noti row ${notification.status === 0 ? "notiunread" : "notiread"}`}>
                <div className="left col-md-1">
                    <h4 className="avatar text-center text-uppercase">{notification.name.substring(0, 1)}</h4>
                </div>
                <div className="right col-md-10">
                    <h4 className="job-title"><a>{notification.name}</a></h4>
                    <p className="job-desc">Sent You a Messsage</p>
                </div>

                {/* <div className="close col-md-1 allnoticlose">
                    <i className="fa fa-close"></i>
                </div> */}
            </li></>;
    }
    return (
        <Section>
            <Main>
                <div className='d-flex '>
                    <h4 className='text-primary'>All Notifications</h4>
                    {/* <div className='align-items-start d-flex flex-wrap ms-auto'>
                        <select
                            class='form-select w-auto me-1 mb-1 form-select-sm text-primary f-0-8'
                            aria-label='Default select example'
                            name="experience">
                            <option selected value="0" >All</option>
                            <option value='1'>Liked Posts</option>
                            <option value='2'>Applied Job</option>
                            <option value='3'>Unread</option>
                        </select>
                    </div>
                    <button type='button' class='btn btn-primary btn-sm w-25'>
                        Filter
                    </button> */}
                </div>
                <div className="border-bottom-blue mb-2 mt-2"></div>
                <div>
                    {
                        RecruiterNotificationList?.data?.data.map((noti, index) => {
                            return <NotificationAll notification={noti} />;
                        })
                    }
                </div>

            </Main>
            <SideBar>
                <ProfileName />
                <ActionButtons />
                <Company />
            </SideBar>
        </Section>
    );
};

export default ShowAllNotification;
