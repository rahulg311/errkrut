
import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';

class Campus10 extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
    <div className="container pb-5">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="bg-white ">
            <div className="container ">
               <div>
                  <h4 className="f-Poppins-Medium m-2 pt-3 text-primary">Add Access Level</h4>
                  <div className="border-gray-line mt-2 mb-2"></div>
                  <div className='w-70 w-x-100'>
                  
                  <div className="row mt-2 mb-2">
                     <div className="col-md-12">
                        <label className=" text-primary mt-2 font-bold">
                        Access Level Name
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter  Access Level Name"
                           />
                     </div>
                    
                  </div>
                  
                  <div className="row mt-2 mb-2">
                     <div className="col-md-11 col-10 ">
                         <p className='fw-bold'>Container 4</p>
                         <p className='mt-1'>Using color to add meaning only provides a visual </p>
                        
                     </div>
                     <div className="col-md-1 col-2">
                     <div class="form-check form-switch h5">
  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
 
</div>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-11 col-10 ">
                         <p className='fw-bold'>Container 4</p>
                         <p className='mt-1'>Using color to add meaning only provides a visual </p>
                        
                     </div>
                     <div className="col-md-1 col-2">
                     <div class="form-check form-switch h5">
  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
 
</div>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-11 col-10 ">
                         <p className='fw-bold'>Container 4</p>
                         <p className='mt-1'>Using color to add meaning only provides a visual </p>
                        
                     </div>
                     <div className="col-md-1 col-2">
                     <div class="form-check form-switch h5">
  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
 
</div>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-11 col-10 ">
                         <p className='fw-bold'>Container 4</p>
                         <p className='mt-1'>Using color to add meaning only provides a visual </p>
                        
                     </div>
                     <div className="col-md-1 col-2">
                     <div class="form-check form-switch h5">
  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
 
</div>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-11 col-10 ">
                         <p className='fw-bold'>Container 4</p>
                         <p className='mt-1'>Using color to add meaning only provides a visual </p>
                        
                     </div>
                     <div className="col-md-1 col-2">
                     <div class="form-check form-switch h5">
  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
 
</div>
                     </div>
                  </div>
                  <div className='row'>
                      <div className='col-md-12'>
                      <button type="button" class="btn btn-primary float-end ps-5 pe-5">Save</button>
                      </div>
                  </div>
                 
                  
                  
                  
                  
                  
              
                  {/* border */}
                  <div className="border-dashed1 mt-4 mb-2"></div>
                  {/* border */}
                   

                  <div className="row  mb-2">
                     <div className="col-md-12">
                     <h4 className="f-Poppins-Medium  text-primary">Edit Access Level</h4>
                     </div>
                    
                  </div>
                  <div className='pb-5'>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-10 col-10">
                     <h6 className='mt-1'>Level 1</h6>
                     </div>
                     <div className="col-md-2 col-2">
                     <button type="button" class="btn btn-outline-primary float-end ps-4 pe-4">Edit</button>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-10 col-10">
                     <h6 className='mt-1'>Level 2</h6>
                     </div>
                     <div className="col-md-2 col-2">
                     <button type="button" class="btn btn-outline-primary float-end ps-4 pe-4">Edit</button>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-10 col-10">
                     <h6 className='mt-1'>Level 3</h6>
                     </div>
                     <div className="col-md-2 col-2">
                     <button type="button" class="btn btn-outline-primary float-end ps-4 pe-4">Edit</button>
                     </div>
                 
              
            </div> </div>
            </div></div></div></div>
            </div>
            {/* submit button */}
            {/* form ends here */}
        
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>

);
}
}
export default  Campus10;