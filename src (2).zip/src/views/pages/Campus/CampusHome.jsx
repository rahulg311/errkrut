import { useState, useEffect } from "react";
import CampusHomeCard from "../../../components/Campus/CampusHomeCards";
import TopCompaniesCard from "../../../components/Cards/TopCompaniesCard";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import { NavLink } from "react-router-dom";
import ImportStudentsModal from "../../../components/Campus/ImportStudentsModal";
import StudentCVList from "../../../components/Campus/StudentCVList";
import CampniesInvited from "../../../components/Campus/CampaniesInvited";
import CoordinatorList from "../../../components/Campus/CoordinatorList";
import { notification } from '../../../classes/messages';
import {
  END_POINT,
  USER_IMPORT,
  STUDENT_LISTING,
  USER_DELETE,
  RESEND_INVITATION,
  GET_INVITED_COMPANY_LISTING,
} from "../../../routes/api_routes";
import usePost from "../../../hooks/usePost";
import useFetch from "../../../hooks/useFetch";
import { getLoggedInUser, getAuthToken } from "../../../classes";
import CampusActionButtons from "../../../components/Sidebars/Campus/CampusActionButton";

const CampusHome = () => {
  const [importModal, setImportModal] = useState(false);
  const [tab, setTab] = useState("student-profile");
  const closeImportModal = () => setImportModal(false);
  const showImportModal = () => setImportModal(true);
  const { response, isLoading, error, doPost } = usePost();
  const studentCvListAPI = useFetch();
  const studentDeleteAPI = usePost();
  const resendInvitationAPI = usePost();
  const invitedCompaniesListAPI = useFetch();
  const [studentsCheckboxList, setStudentsCheckboxList] = useState([]);

  const handleStudentsCheckState = (data) => setStudentsCheckboxList(data);

  const handleStudentRowAPI = async (type, studentProfile) => {
    const user = await getLoggedInUser();
    let token = await getAuthToken();
    const formData = new FormData();
    formData.append("campus_id", user.id);
    formData.append("id", studentProfile.id);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json", 'Authorization': 'Bearer ' + token },
    };
    if (type === "delete_user") {
      studentDeleteAPI.doPost(`${USER_DELETE}`, formData, requestOptions);
    } else if (type == "resend_invitation") {
      resendInvitationAPI.doPost(
        `${RESEND_INVITATION}`,
        formData,
        requestOptions
      );
    } else {
      console.log("view profile");
    }
  };

  const handleImportSubmit = async (file) => {
    const user = await getLoggedInUser();
    let token = await getAuthToken();
    const formData = new FormData();
    formData.append("campus_id", user.id);
    formData.append("file", file);
    const requestOptions = {
      method: "POST",
      body: formData,
      headers: {
        // "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
      },
    };
    // doPost(`${USER_IMPORT}`, formData, requestOptions);
    fetch(`${END_POINT}${USER_IMPORT}`, requestOptions).then((response) => response.json()).then((data) => {
      if (data.status == 'success') {
        getStudentListing();
      }
      let notify = notification({
        type: data.status,
        message: data.message,
      });
      notify();
      window.location.reload(false);
    });
    closeImportModal();
  };

  const getStudentListing = async () => {
    const user = await getLoggedInUser();
    studentCvListAPI.doFetch(END_POINT + `${STUDENT_LISTING}/${user.id}`);
  };

  const handleCompaniesRowAPI = async (type, companiesProfile) => {
    // API needs to be updated
    const user = await getLoggedInUser();
    let token = await getAuthToken();
    const formData = new FormData();
    formData.append("campus_id", user.id);
    formData.append("id", companiesProfile.id);
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
      },
    };
    if (type === "delete_student") {
      studentDeleteAPI.doPost(`${USER_DELETE}`, formData, requestOptions);
    } else if (type == "resend_invitation") {
      resendInvitationAPI.doPost(
        `${RESEND_INVITATION}`,
        formData,
        requestOptions
      );
    } else {
      console.log("view profile");
    }
  };

  const getInvitedCompaniesListing = async () => {
    const user = await getLoggedInUser();
    invitedCompaniesListAPI.doFetch(
      END_POINT + `${GET_INVITED_COMPANY_LISTING}/${user.id}`
    );
  };

  useEffect(() => {
    if (tab === "coordinators") {
      
    } else if (tab === "companies-invited") {
      getInvitedCompaniesListing();
    } else if (tab === "student-profile") {
      getStudentListing();
    }
  }, [tab]);

  useEffect(() => {
    if (
      (response && response.status == "success") ||
      (studentDeleteAPI && studentDeleteAPI.response && studentDeleteAPI.response.status == "success") ||
      (resendInvitationAPI && resendInvitationAPI.response && resendInvitationAPI.response.status == "success")
    )
      getStudentListing();
  }, [response, studentDeleteAPI?.response, resendInvitationAPI?.response]);

  return (
    <>
      <ImportStudentsModal
        is_modal={importModal}
        closeModal={closeImportModal}
        handleSubmit={handleImportSubmit}
      />
      <div className="main-container position-relative">
        <div className="container">
          <div className="row gx-5">
            <div className="col-lg-9">
              <CampusHomeCard showSeeAll={true} />
              <TopCompaniesCard />
              <div className="d-flex bg-white  justify-content-between align-items-center p-4 mt-3 mb-3 rounded-4">
                <h1 className="custom-heading f-r-12">Send Company Invitation</h1>
                <NavLink
                  to="/send-company-invite"
                  className="btn f-r-10 btn-primary btn-sm ps-4 pe-4 font-bold"
                >
                  Start Now
                </NavLink>
              </div>
              <div className="bg-white p-4 rounded-4 ">
                <div className="d-flex border-bottom-blue pb-3 w-100 border-bottom-bold">
                  <button
                    onClick={() => setTab("student-profile")}
                    className={`f-1-2 mr f-r-12 poppins-bold border-none bg-white ${tab === "student-profile" ? "text-sky-blue" : "text-gray"
                      }`}
                  >
                    Student profiles
                  </button>
                  <button
                    onClick={() => setTab("companies-invited")}
                    className={`f-1-2 f-r-12 mr poppins-bold border-none bg-white ${tab === "companies-invited"
                      ? "text-sky-blue"
                      : "text-gray"
                      }`}
                  >
                    Companies Invited
                  </button>
                  <button
                    onClick={() => setTab("coordinators")}
                    className={`f-1-2 f-r-12 mr poppins-bold border-none bg-white ${tab === "coordinators" ? "text-sky-blue" : "text-gray"
                      }`}
                  >
                    Coordinators
                  </button>
                </div>
                {tab === "student-profile" && (
                  <div className="d-flex bg-white justify-content-end align-items-center mt-3 rounded-4">
                    <button
                      onClick={showImportModal}
                      className="btn btn-primary f-r-12 btn-sm ps-4 pe-4 font-bold poppins-bold"
                    >
                      Import Students
                    </button>
                  </div>
                )}
                <div className="p-2 p-none1">
                  {tab === "student-profile" ? (
                    <StudentCVList
                      data={studentCvListAPI?.data?.data}
                      loading={studentCvListAPI.loading}
                      handleStudentRowAPI={handleStudentRowAPI}
                      isEditable={true}
                      setSelectedCheckboxList={handleStudentsCheckState}
                      selectedCheckboxList={studentsCheckboxList}
                    />
                  ) : tab === "companies-invited" ? (
                    <CampniesInvited
                      data={invitedCompaniesListAPI?.data?.data}
                      loading={invitedCompaniesListAPI.loading}
                      handleCompaniesRowAPI={handleCompaniesRowAPI}
                    />
                  ) : (
                    <CoordinatorList />
                  )}
                </div>
              </div>
            </div>

            <div className="col-lg-3 pt-2 pb-2">
              <ProfileName />
              <CampusActionButtons />
              <Company></Company>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CampusHome;
