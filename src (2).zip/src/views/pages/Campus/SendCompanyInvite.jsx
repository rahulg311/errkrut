import React, { useEffect, useState } from "react";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import ActionButtons from "../../../components/Sidebars/Recruiter/ActionButtons";
import Loading from "../../../components/common/Loading";
import useFetch from "../../../hooks/useFetch";
import { END_POINT, GET_COMPANY_LISTING } from "../../../routes/api_routes";
import { useHistory } from "react-router";
import { notification } from "../../../classes/messages";
import {
  getCompSubCategory,
  getCompanyCategory,
} from "../../../store/actions/signup";
import { connect } from "react-redux";

const SendCompanyInvite = ({
  comp_category_res,
  getCompanyCategory,
  comp_sub_category_res,
  getCompSubCategory,
}) => {
  const companiesListAPI = useFetch();
  const [selectAllCheck, setSelectAllCheck] = useState(false);
  const [selectedCheckboxList, setSelectedCheckboxList] = useState([]);
  const [companyFilters, setCompanyFilters] = useState({
    company_name: "",
    location: "",
    category: "",
    sub_category: "",
  });
  const history = useHistory();

  const handleCompanyFilters = (e) => {
    e.preventDefault();
    const ivalue = e.target.value;
    const iname = e.target.name;
    setCompanyFilters({ ...companyFilters, [iname]: ivalue });
  };

  const fetchCompSubCategory = (event) => {
    if (event) {
      getCompSubCategory(event.target.value);
    }
  };

  async function getCompaniesListing(filter = {}) {
    let route = `${GET_COMPANY_LISTING}`;
    if (Object.keys(filter).length) {
      let filterRoute = Object.keys(filter).reduce(
        (accumulator, currentVal) => {
          return (accumulator =
            accumulator + `"${currentVal}":"${filter[currentVal]}", `);
        },
        "?filter={"
      );
      route = route + filterRoute.substring(0, filterRoute.length - 2) + "}";
    }
    companiesListAPI.doFetch(END_POINT + route);

  }

  useEffect(() => {
    if (
      companiesListAPI &&
      companiesListAPI.data &&
      companiesListAPI.data.data
    ) {
      const checkboxData = companiesListAPI.data.data.map((item) => {
        return {
          id: item.id,
          selected: false,
        };
      });
      setSelectedCheckboxList(checkboxData);
    }
  }, [companiesListAPI?.data]);

  const handleSingleCheckbox = (id) => {
    const checkboxData = selectedCheckboxList.map((checkbox) => {
      if (checkbox.id == id) {
        return {
          ...checkbox,
          selected: !checkbox.selected,
        };
      }
      return checkbox;
    });
    setSelectedCheckboxList(checkboxData);
  };

  const handleSelectAll = (checkValue) => {
    setSelectAllCheck(checkValue);
    if (checkValue) {
      setSelectedCheckboxList((values) =>
        values.map((checkbox) => ({ ...checkbox, selected: true }))
      );
      return;
    }
    setSelectedCheckboxList((values) =>
      values.map((checkbox) => ({ ...checkbox, selected: false }))
    );
  };
  
  const handleInvite =()=> {
    if(selectedCheckboxList && selectedCheckboxList.some((checkbox) => checkbox.selected == true )) {
      const filteredIds = selectedCheckboxList.filter((checkbox) => checkbox.selected ).map(filterdData => filterdData.id);
      const companyData = companiesListAPI.data.data.filter((data) => filteredIds.includes(data.id));

      history.push({
        pathname: "/send-campus-message",
        state: {companyData}
      });
    } else {
      let notify = notification({ message: 'Select company name to send invite', type: 'error' });
			notify();
    }
  }

  const handleSingleInvite = (id) => {
    const companyData = companiesListAPI.data.data.filter((data) => data.id == id);
    history.push({
      pathname: "/send-campus-message",
      state: {companyData}
    });
  }

  const clearFilter = () => {
    getCompaniesListing();
    
    setCompanyFilters(
      {company_name: "",
      location: "",
      category: "",
      sub_category: "",} )
  }

  useEffect(() => {
    getCompanyCategory();
    getCompaniesListing();
  }, []);

  const InvitationList = ({ data, loading }) => {
    return (
      <div className="col-md-12 mt-3">
        <div>
          <header className="row bg-primary text-white p-2  rounded-top shadow">
            <div className=" col-1  p-0 d-flex justify-content-between align-item-center">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  checked={selectAllCheck}
                  value={selectAllCheck}
                  onChange={() => handleSelectAll(!selectAllCheck)}
                />
              </div>
            </div>
            <div className=" p-0 ps-1 col-4 d-flex justify-content-between align-item-center">
              <span className="d-flex f-r-10">Company Name<i className="fas fa-sort mt-4px ps-1"></i></span>
            
            </div>

            <div className=" col-4 d-flex justify-content-between align-item-center">
              <span className="d-flex f-r-10">Location<i className="fas fa-sort mt-4px ps-1"></i></span>
             
            </div>

            <div className="col-3 d-flex justify-content-between align-item-center"></div>
          </header>
          <main>
            {loading ? (
              <Loading className="my-3" />
            ) : data && data.length ? (
              <>
                {data.map((profile, idx) => {
                  const even = idx % 2 == 0;
                  return (
                    <div
                      key={idx}
                      className={`row align-items-center p-2 ${
                        even ? "bg-light-blue" : "bg-table-striped"
                      }`}
                    >
                      <div className=" col-1 p-0 col-md-1  d-flex justify-content-between align-item-center">
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            checked={
                              selectedCheckboxList &&
                              selectedCheckboxList.length &&
                              selectedCheckboxList.filter(
                                (checkbox) => checkbox.id === profile.id
                              )[0]?.selected
                            }
                            value={
                              selectedCheckboxList &&
                              selectedCheckboxList.length &&
                              selectedCheckboxList.filter(
                                (checkbox) => checkbox.id === profile.id
                              )[0]?.id
                            }
                            id={profile?.id}
                            onChange={(e) => {
                              handleSingleCheckbox(e.target.value);
                            }}
                          />
                        </div>
                      </div>
                      <div className="col-3 col-md-3  p-0 ">
                        <small className="f-r-10">{profile?.company_name}</small>
                      </div>

                      <div className="col-4 col-md-4 p-0 ">
                        <small className="f-r-10">{profile?.address}</small>
                      </div>

                      <div className="col-4 col-md-3 p-0 justify-content-end">
                        <button
                         onClick={() => handleSingleInvite(profile.id)}
                          className="btn f-r-10 btn-primary float-end btn-sm  poppins-bold"
                        >
                          Send Invite
                        </button>
                      </div>
                    </div>
                  );
                })}
              </>
            ) : (
              <div className="row justify-content-center align-items-center p-4 bg-light-blue">
                <div className="text-center font-bold text-sky-blue">
                  No Campany Found
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    );
  };

  return (
    <div className="main-container position-relative">
      <div className="container">
        <div className="row gx-5">
          <div className="col-lg-9">
            <div className="bg-white mt-5 rounded-5 pt-5 pb-4  ps-4 pe-4">
              <div className="border-bottom-blue pb-3 w-100 border-bottom-bold">
                <div className="d-flex justify-content-between">
                  <h3 className="text-blue font-bold f-r-17 ">Company List</h3>
                  <div>
                    <button
                      onClick={() => clearFilter() }
                      className="btn btn-primary btn-sm f-r-12 ps-1 pe-1 me-1 font-bold poppins-bold"
                    >
                      Clear Filter
                    </button>

                    <button
                      onClick={() => getCompaniesListing(companyFilters)}
                      className="btn btn-primary btn-sm f-r-12 ps-1 pe-1 font-bold poppins-bold"
                    >
                      Filter
                    </button>
                    
                  </div>
                </div>
                <div className="row pt-2 ">
                  <div className="col-md-3 col-6">
                    <div>
                    <label className="f-r-12">Company Category</label>
                    <select
                          className="form-control f-r-12"z
                          name="category"
                          onChange={(e) => {
                            handleCompanyFilters(e);
                            fetchCompSubCategory(e);
                          }}
                          value={companyFilters.category}
                        >
                          <option value="" selected disabled>
                            --Company Category--
                          </option>
                          {comp_category_res?.data &&
                            comp_category_res?.data.map((opt) => {
                              return (
                                <option value={opt.id} key={opt.id}>
                                  {opt.title}
                                </option>
                              );
                            })}
                        </select>
                    </div>

                  </div>
                  <div className="col-md-3 col-6">
                    <div>
                    <label className="f-r-12">Company Sub Category</label>
                    <select
                          className="form-control f-r-12"
                          name="sub_category"
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters.sub_category}
                        >
                          <option value="" selected disabled>
                            --Company subCategory--
                          </option>
                          {comp_sub_category_res?.data &&
                            comp_sub_category_res?.data.map((opt) => {
                              return (
                                <option value={opt.id} key={opt.id}>
                                  {opt.title}
                                </option>
                              );
                            })}
                        </select>
                    </div>
                  </div>
                  <div className="col-md-3 col-6 ">
                    <div>
                    <label className="f-r-12">Company Name</label>
                    <input
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters?.company_name}
                          type="text"
                          className="form-control"
                          name="company_name"
                          placeholder="Company Name"
                        />
                    </div>
                    </div>
                    <div className="col-md-3 col-6">
                    <div>
                    <label className="f-r-12">Location</label>
                    <input
                          onChange={(e) => handleCompanyFilters(e)}
                          value={companyFilters?.location}
                          type="text"
                          className="form-control"
                          name="location"
                          placeholder="Location"
                        />
                    </div>
                    </div>
               
                </div>
              </div>
              <div className="d-flex justify-content-between align-items-end mt-5">
                <div className="text-blue font-bold">Select All</div>
                <button
                  onClick={handleInvite}
                  className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold f-r-12"
                >
                  Send Invite
                </button>
              </div>
              <InvitationList
                data={companiesListAPI?.data?.data}
                loading={companiesListAPI?.loading}
              />
            </div>
          </div>
          <div className="col-lg-3 pt-2 pb-2">
            <ProfileName />
            <ActionButtons />
            <Company></Company>
          </div>
        </div>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => {
  const { comp_category_res, comp_sub_category_res } = state.common;
  return {
    comp_category_res,
    comp_sub_category_res,
  };
};

function mapDispatchToProps(dispatch) {
  return {
    getCompanyCategory: () => dispatch(getCompanyCategory()),
    getCompSubCategory: (id) => dispatch(getCompSubCategory(id)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SendCompanyInvite);
