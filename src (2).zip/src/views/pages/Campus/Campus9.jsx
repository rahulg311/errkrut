
import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';

class Campus9 extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
    <div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="bg-white ">
            <div className="bg-white p-4 ">
               <div>
                  <h5 className="f-Poppins-Medium m-2">Edit Campus Profile</h5>
                  <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-4 mb-4"></div>
                  <div className='w-90 w-x-100'>
                  <div className="row">
                     <div className="col-md-10 col-9">
                        <p className="f-Poppins-Medium fs-14 fw-bold">Upload Campus  Logo</p>
                     </div>

                     
                     <div className="col-md-2 col-3 d-flex align-items-center">
                        <p className="f-Poppins-Medium text-primary fs-14 font-bold ">Upload</p>
                        <i class="las la-upload ms-1 text-sky-blue  f-1-1"></i>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className=" text-primary mt-2 font-bold fs-13">
                        Company Name
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Company Name"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        GST No
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter GST No"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6 font-bold fs-13">
                        <label className="mt-2 ">
                        Email
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="gupta@gmail.com"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        Phone Number
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="+919670888935"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13 ">
                        Company Name
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='text'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter Your Company Name"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        Website
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="http://Guptag.com"
                           />
                     </div>
                  </div>
                  {/* border */}
                  <div className='border-dashed1 mt-1 '></div>
                  {/* border */}
       
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className=" text-primary mt-2 font-bold fs-13">
                        Address line 1
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Address line 1"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        Address line 2
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Address line 2"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13 ">
                        Country
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Country"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        State
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your State"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        Town/City
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='text'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Town/City"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2 font-bold fs-13">
                        Postcode/ZIP
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Postcode/ZIP"
                           />
                     </div>
                  </div>
                  {/* border */}
                  <div className='border-dashed1 mt-1 '></div>
                  {/* border */}
                  <div className="row">
                     <div className="col-md-12">
                        <label className="mt-2 font-bold fs-13">
                        Company Summary
                        </label>
                        <textarea className="w-100 h-100p ps-2 pt-1 ">
                            ( 500 words )
                        </textarea>
                     </div>
                  </div>
                  {/* submit button */}
                  <div className="row mt-2 mb-5">
                     <div className="col-md-10  col-8">
                        <button href="" className="btn btn-outline-primary ml-auto mr-auto ps-6 pe-6 d-block mt-2 ">Discard</button>
                     </div>
                     <div className="col-md-2 col-4">
                        <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2  ps-6 pe-6">Save</button>
                     </div>
                  </div>
               </div>
               </div>
      </div>
               </div>
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className='container bg-white pt-3 pb-4 mt-4'>
               <div className=" mt-4 w-90 w-x-100 ">
                  <div>
                     <h5 className="f-Poppins-Medium m-2">Edit Recruitment Head Profile</h5>
                     <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className=" text-primary mt-2 font-bold">
                           Name
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter your  Name"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           Designation
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter GST No"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2 font-bold ">
                           Email
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="gupta@gmail.com"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           Phone Number
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="+919670888935"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2 font-bold ">
                           E-mail2
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='text'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter Your Company Name"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           Experience
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="3 yaers"
                              />
                        </div>
                     </div>
                     {/* border */}
                     <div className='border-dashed1 mt-1 '></div>
                     {/* border */}
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className=" text-primary mt-2 font-bold">
                           Address line 1
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter your Address line 1"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           Address line 2
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Enter your Address line 2"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2 font-bold ">
                           Country
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Select your Country"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           State
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Select your State"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2font-bold">
                           Town/City
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='text'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Select your Town/City"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2 font-bold">
                           Postcode/ZIP
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="Select your Postcode/ZIP"
                              />
                        </div>
                     </div>
                     {/* border */}
                     <div className='border-dashed1 mt-1 '></div>
                  
                     {/* border */}
                     <div className="row">
                        <div className="col-md-12 font-bold">
                           <label className="mt-2 ">
                           CompanySummary
                           </label>
                           <textarea className="w-100 h-100p ps-2 pt-1">
                           ( 500 words )
                           </textarea>
                        </div>
                     </div>
                     {/* submit button */}
                     <div className="row mt-2 mb-5">
                     <div className="col-md-10  col-8">
                        <button href="" className="btn btn-outline-primary ml-auto mr-auto ps-6 pe-6 d-block mt-2 ">Discard</button>
                     </div>
                     <div className="col-md-2 col-4">
                        <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2  ps-6 pe-6">Save</button>
                     </div>
                  </div>
                     {/* submit button */}
                  </div>
               </div>
               
               {/* endEdit hiring sector */}
               {/* <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div> */}
               {/* submit button */}
                {/* submit button */}


             
                 
                     {/* submit button */}
              
            </div>
            <div className='container bg-white pt-3 pb-4 mt-4'>

            <div className="w-90 w-x-100 mt-2 bg-white pb-4 ">
                        <div className="row pt-4 ">
                              <div className="col-md-12 col-12 ">
                                 <h4 className="f-Poppins-Medium">Recruiment Coordinators</h4>
                              </div>
                              </div>
                              <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>

                              <div className='container mt-5'>
                           
                              
                             
                 
                              <div className='row mt-2'>
                              <div className='col-md-12'>
                                  <p className='float-start fs-5 mb-2 col-md-8 col-12 '>Sam Deo</p>
                                  <i class="fas fa-trash-alt float-end f-2 text-danger mb-2 ms-3 "></i>
                                  <div class="dropdown">
  <button class="btn  btn-outline-secondary dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Access Level 1
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1</a></li>
    <li><a class="dropdown-item" href="#">2</a></li>
    <li><a class="dropdown-item" href="#">3</a></li>
  </ul>
</div>

                                  

                              </div>
                         
                              </div>
                              <div className='border-dashed1 mt-1 '></div>
                              <div className='row mt-2'>
                              <div className='col-md-12'>
                                  <p className='float-start fs-5 mb-2 col-md-8 col-12 '>Sam Deo</p>
                                  <i class="fas fa-trash-alt float-end f-2 text-danger mb-2 ms-3 "></i>
                                  <div class="dropdown">
  <button class="btn  btn-outline-secondary dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Access Level 1
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1</a></li>
    <li><a class="dropdown-item" href="#">2</a></li>
    <li><a class="dropdown-item" href="#">3</a></li>
  </ul>
</div>

                                  

                              </div>
                         
                              </div>
                              <div className='border-dashed1 mt-1 '></div>
                              <div className='row mt-2'>
                              <div className='col-md-12'>
                                  <p className='float-start fs-5 mb-2 col-md-8 col-12 '>Sam Deo</p>
                                  <i class="fas fa-trash-alt float-end f-2 text-danger mb-2 ms-3 "></i>
                                  <div class="dropdown">
  <button class="btn  btn-outline-secondary dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Access Level 1
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1</a></li>
    <li><a class="dropdown-item" href="#">2</a></li>
    <li><a class="dropdown-item" href="#">3</a></li>
  </ul>
</div>

                                  

                              </div>
                         
                              </div>
                              <div className='border-dashed1 mt-1 '></div>
                              <div className='row mt-2'>
                              <div className='col-md-12'>
                                  <p className='float-start fs-5 mb-2 col-md-8 col-12 '>Sam Deo</p>
                                  <i class="fas fa-trash-alt float-end f-2 text-danger mb-2 ms-3 "></i>
                                  <div class="dropdown">
  <button class="btn  btn-outline-secondary dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Access Level 1
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1</a></li>
    <li><a class="dropdown-item" href="#">2</a></li>
    <li><a class="dropdown-item" href="#">3</a></li>
  </ul>
</div>

                                  

                              </div>
                         
                              </div>
                              <div className='border-dashed1 mt-1 '></div>
                              <div className='row mt-2'>
                              <div className='col-md-12'>
                                  <p className='float-start fs-5 mb-2 col-md-8 col-12 '>Sam Deo</p>
                                  <i class="fas fa-trash-alt float-end f-2 text-danger mb-2 ms-3 "></i>
                                  <div class="dropdown">
  <button class="btn  btn-outline-secondary dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Access Level 1
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1</a></li>
    <li><a class="dropdown-item" href="#">2</a></li>
    <li><a class="dropdown-item" href="#">3</a></li>
  </ul>
</div>

                                  

                              </div>
                         
                              
                           
                         
                              </div>
                              <div className='border-dashed1 mt-1 '></div>
                              </div>
                              
                    
                <div className="row mt-2 mb-5">
                     <div className="col-md-10  col-8">
                        <button href="" className="btn btn-outline-primary ml-auto mr-auto ps-6 pe-6 d-block mt-2 ">Discard</button>
                     </div>
                     <div className="col-md-2 col-4">
                        <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2  ps-6 pe-6">Save</button>
                     </div>
                  </div>
            </div> </div>
            
            </div>
            {/* submit button */}
            {/* form ends here */}
        
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>

);
}
}
export default  Campus9;