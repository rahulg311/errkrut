
import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';

class Campus11 extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
    <div className="container pb-5">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="bg-white ">
            <div className="container pt-1  ">
               <div>
                  <h4 className="f-Poppins-Medium m-2 text-primary">Add Recruitment Coordinators</h4>
                  <div className="border-gray-line mt-2 mb-2"></div>
                  <div className='w-70 w-x-100'>
                  
                  <div className='row'>
                  <div className="col-md-12">
                        <label className=" text-primary mt-2 font-bold">
                        Name
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Full Name"
                           />
                     </div>
                     </div>
                     <div className='row'>
                     <div className="col-md-12">
                        <label className="  mt-2 font-bold">
                      Email
                        </label>
                        <input
                           type='email'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Email Id"
                           />
                     </div>
                     </div>
                     <div className='row'>
                     <div className="col-md-8">
                        <label className=" text-primary mt-2 font-bold">
                     Designation
                        </label>
                        <input
                           type='email'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Email Id"
                           />
                     </div>
                     <div className="col-md-4">
                     <div className='row'>
                        <div className='col-12'>
                        <label className=" text-primary mt-2 font-bold float-0start">
                 Access Level
                        </label>
                        <i class="fas fa-plus float-end text-primary mt-2"></i>
                        </div>
                     </div>
                        <select class="form-select" aria-label="Default select example">
  <option selected>Level 1</option>
  <option value="1">Level 2</option>
  <option value="2">Level 3</option>
  <option value="3">Level 4</option>
  {/* <br />
 
  <option >  <button type="button" class="btn btn-outline-primary">Primary</button></option> */}
</select>
                     </div>
                     </div>
                  
                
                  <div className='row pb-5'>
                      <div className='col-md-12'>
                      <button type="button" class=" rounded-0 btn btn-primary float-end ps-5 pe-5 mt-2 mb-2">Send Verification Link</button>
                      </div>
                  </div>
                 
                  
                  
                  
                  
                  
              
                 
            </div></div></div></div>
            </div>
            {/* submit button */}
            {/* form ends here */}
        
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>

);
}
}
export default  Campus11;