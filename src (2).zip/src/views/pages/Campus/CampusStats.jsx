import { useState, useEffect } from "react";
import CampusHomeCard from "../../../components/Campus/CampusHomeCards";
import TopCompaniesCard from "../../../components/Cards/TopCompaniesCard";
import Company from "../../../components/Contact/Company";
import ProfileName from "../../../components/Sidebars/Candidate/ProfileName";
import { NavLink } from "react-router-dom";
import ImportStudentsModal from "../../../components/Campus/ImportStudentsModal";
import StudentCVList from "../../../components/Campus/StudentCVList";
import CampniesInvited from "../../../components/Campus/CampaniesInvited";
import CoordinatorList from "../../../components/Campus/CoordinatorList";
import { notification } from '../../../classes/messages';
import {
  END_POINT,
  USER_IMPORT,
  STUDENT_LISTING,
  DOWNLOAD_RESUME,
  USER_DELETE,
  RESEND_INVITATION,
  GET_COORDINATOR_LIST,
} from "../../../routes/api_routes";
import usePost from "../../../hooks/usePost";
import useFetch from "../../../hooks/useFetch";
import { getLoggedInUser, getAuthToken } from "../../../classes";
import CampusActionButtons from "../../../components/Sidebars/Campus/CampusActionButton";

const CampusStats = () => {
  
  const { response, isLoading, error, doPost } = usePost();
  const studentCvListAPI = useFetch();
  const studentDeleteAPI = usePost();
  const resendInvitationAPI = usePost();
  const [studentsCheckboxList, setStudentsCheckboxList] = useState([]);

  const handleStudentsCheckState = (data) => {setStudentsCheckboxList(data); console.log(data)};

  const handleStudentRowAPI = async (type, studentProfile) => {
    const user = await getLoggedInUser();
    const formData = new FormData();
    formData.append("campus_id", user.id);
    formData.append("id", studentProfile.id);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    };
    if (type === "delete_user") {
      studentDeleteAPI.doPost(`${USER_DELETE}`, formData, requestOptions);
    } else if (type == "resend_invitation") {
      resendInvitationAPI.doPost(
        `${RESEND_INVITATION}`,
        formData,
        requestOptions
      );
    } else {
      console.log("view profile");
    }
  };

  const handleDownloadCV = async () => {
    
    if(studentsCheckboxList && studentsCheckboxList.some((checkbox) => checkbox.selected == true )) {
      let filteredIds = studentsCheckboxList.filter((checkbox) => checkbox.selected ).map(filterdData => filterdData.id);
     

        if (filteredIds.length != 0) {
          let token = await getAuthToken();
          const user = await getLoggedInUser();
          console.log(user)
          const formData = new FormData();
          formData.append("campus_id", user.id);
          formData.append("user_id", "[" + filteredIds + "]");
          const requestOptions = {
              method: "POST",
              headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
      }
          };
          doPost(`${DOWNLOAD_RESUME}`, formData, requestOptions).then((response) => {
            
              if (response.status == "success") {
                  const link = document.createElement('a');
                  link.download = "";
                  link.target="_blank";
                  let str = response.url.replace(/[\\]/g, '');
                  link.href = str;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
              }else{
                let notify = notification({ message: response.message , type: 'error' });
                notify();

              }
          })
      }
      else {
          let notify = notification({ message: "Please Select Candidate List", type: 'error' });
          notify();
      }
    }

   
  };

  const getStudentListing = async () => {
    
    const user = await getLoggedInUser();
    let token = await getAuthToken();

    const requestOptions = {
      method: "GET",
      headers: { 
        "Content-Type": "application/json" ,
        'Authorization': 'Bearer ' + token
      },
    };
    studentCvListAPI.doFetch(END_POINT + `${STUDENT_LISTING}/${user.id}`, requestOptions);
  };

  useEffect(() => {
    
    getStudentListing();
  }, []);

  async function download_stats_handler(){
		let token = await getAuthToken();

		var requestOptions = {
			method: 'POST',
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
			
		};

		fetch(END_POINT + 'exportJobStats', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				
				if (result.status == "success") {
					const link = document.createElement('a');
					link.download = "";
					let str = result.excel_url.replace(/[\\]/g, '');
					link.href = str;
					document.body.appendChild(link);
					link.click();
					document.body.removeChild(link);
				}
			})
			.catch((error) => console.log('error', error));

	}

  return (
    <>
      <div className="main-container position-relative">
        <div className="container">
          <div className="row gx-5">
            <div className="col-lg-9">
              <div className="bg-white text-end p-4 mt-3 mb-3 rounded-4">
                <button className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold" onClick={download_stats_handler}>
                  Download Stats
                </button>
              </div>
              <CampusHomeCard showSeeAll={false} />
              
              <div className="bg-white p-4 rounded-4 mb-6">
                <div className="row mt-3 mb-4">
                  <div className="col-md-4  col-12 mt-1 ">
                      <h3 className="text-primary  mb-2 f-Poppins-Medium ms-4 "> Candidates List</h3>
                  </div>
                  <div className="border-blue1 "></div>
                </div>
                <div className="d-flex bg-white justify-content-between align-items-center mt-3 rounded-4">
                  <h5 className="mb-2 f-Poppins-Medium ms-4 "> Download Candidates Details</h5>
                  <button
                    onClick={handleDownloadCV}
                    className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                  >
                    Download
                  </button>
                </div>
                <div>
                    <StudentCVList
                      data={studentCvListAPI?.data?.data}
                      loading={studentCvListAPI.loading}
                      handleStudentRowAPI={handleStudentRowAPI}
                      isEditable={true}
                      setSelectedCheckboxList={handleStudentsCheckState}
                      selectedCheckboxList={studentsCheckboxList}
                    />
                </div>
              </div>
            </div>

            <div className="col-lg-3 pt-2 pb-2">
              <ProfileName />
              <CampusActionButtons/>
              <Company></Company>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CampusStats;
