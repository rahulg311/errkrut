import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';

class Campus2 extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-1  ">
            <div className=" ">
               
              
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className=" row bg-white mt-2   ">
                   <div className='container'>
                 <div className='row mt-2 '>
                 <div className='col-md-4 mb-2  '>
					<div className='cards  bg-blue br-5 text-white p-2 h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>70</p>
						<p className='fs-18 position-abs b-2 r-2 text-right m-0 float-end mt-5 font-bold pb-1 '><span className='ms-5'> Total</span> <br /> Student Cv</p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-greenesh-blue br-5 text-white p-2 h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>12</p>
						<p className='fs-18 position-abs b-2 r-2 text-right m-0 float-end mt-5 font-bold  pb-1  '><span className=''> Companies</span> <br /> <span className='ms-5'> Invited</span> </p>
					</div>
				</div>
                <div className='col-md-4 mb-2 '>
					<div className='cards bg-dark-pink br-5 text-white p-2 h-100 mr-2'>
						<p className='fs-28 position-abs t-2 l-2 m-0 font-bold float-start '>10</p> 
						<p className='fs-18 position-abs b-2 r-2 text-right m-0 float-end mt-5 font-bold  pb-1 '><span className=''> Recreuitment</span> <br /><span className='ms-5'> Members</span></p>
					</div>
				</div>
                 </div>
                 </div>
               </div>
               <div className='row bg-white mt-2'>
               <div className='col-md-12'>
									<TopCompaniesCard></TopCompaniesCard>
										</div>
               </div>

               <div className='row bg-white mt-2'>
               <div className='col-md-10 col-12   '>
									<h4 className='float-start p-2 pt-5 pb-5 '>Send Company Invitation</h4>
									
								</div>
								<div className='col-md-2 col-12'>
								<button type="button" class="btn btn-primary  w-100   mb-4 mt-4 ">Start Now</button>
									
								</div>
               </div>
               <div className='row bg-white mt-2 pt-3 pb-3'>
               <div className='col-md-3 '>
											<h4 className='text-primary ms-2'>Student Cv</h4> </div>
										<div className='col-md-9 '>
											<p className='text-muted fs-5'>Companies Invited</p> </div>
								
                                         
               </div>
               <div className='border-bottom-blue'></div>

               <div className='row  bg-white '>
								<div className='col-md-10 col-12 mt-2 mb-1  '>
									<p className=' fs-5 fw-bold mt-1 ms-2  mb-1 '>Add more student CV's here</p>
									
								</div>
								<div className='col-md-2 col-12 mt-2 mb-1'>
								<button type="button" class="btn btn-primary   w-100   ">Add Student</button>
									
								</div>
								</div>
                      
                    
                                <div className=' row pb-5 bg-white  '>
									<div className='container '>
									<header className='row bg-primary text-white p-1 rounded-top shadow m-2'>
					{/* <div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Title</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					{/* <div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>category</span>

						<i class='fas fa-sort mt-4px'></i>
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>Tags</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Name 	<i class='fas fa-sort mt-4px ms-4'></i></span>

					
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Key Skills 	<i class='fas fa-sort mt-4px ms-4'></i></span>

					
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Date <i class='fas fa-sort mt-4px ms-4'></i></span>

						
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span>Status <i class='fas fa-sort mt-4px ms-4'></i></span>

						
					</div>
				</header>
									</div>
									<main>
				<div className ="row align-items-center p-2 bg-light-blue  bg-table-striped ms-2 me-2">
								<div className='col-3'>
									<small className ='fs-6'>Rahul</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-3'>
									<small className='fs-6'>Creative thinking</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>31-12-2021</small>
								</div>
                                <div className='col-3 dropdown'>
									<small className='fs-6'>Accepted <i class="fas fa-ellipsis-v ms-7 " id="dropdownMenuButton1"></i></small>
                                    <ul class="dropdown-menu" >
    <li><a class="dropdown-item" href="#">View CV</a></li>
    <li><a class="dropdown-item" href="#">Resend Invitation</a></li>
    <li><a class="dropdown-item" href="#">Edit</a></li>
    <li><a class="dropdown-item  text-danger" href="#">Delete</a></li>
  </ul>
								</div>
								{/* <div className='col-2 text-center'>
									<div className='d-flex justify-content-end'>
										<Link to='' className='btn btn-sm  border'>
											<i class='fas fa-edit'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2'
											
										>
											<i class='fas fa-trash'></i>
										</button>
									</div>
								</div> */}
							</div>
							<div className ="row align-items-center p-2 bg-light-blue  bg-table-striped ms-2 me-2">
								<div className='col-3'>
									<small className ='fs-6'>gupta</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-3'>
									<small className='fs-6'>Creative thinking</small>
								</div>
								<div className='col-3'>
									<small className='fs-6'>31-12-2021</small>
								</div>
								<div className='col-3 dropdown'>
									<small className='fs-6'>Accepted <i class="fas fa-ellipsis-v ms-7 " id="dropdownMenuButton1"></i></small>
                                    <ul class="dropdown-menu" >
    <li><a class="dropdown-item" href="#">View CV</a></li>
    <li><a class="dropdown-item" href="#">Resend Invitation</a></li>
    <li><a class="dropdown-item" href="#">Edit</a></li>
    <li><a class="dropdown-item  text-danger" href="#">Delete</a></li>
  </ul>
								</div>
								{/* <div className='col-2 text-center'>
									<div className='d-flex justify-content-end'>
										<Link to='' className='btn btn-sm  border'>
											<i class='fas fa-edit'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2'
											
										>
											<i class='fas fa-trash'></i>
										</button>
									</div>
								</div> */}
							</div>
					
				</main>
							
                              
                                </div>
            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default Campus2;