import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';

import { connect } from 'react-redux';
import Loading from '../../../components/common/Loading';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import { errorPrettify, formatTitle, getLoggedInUser } from '../../../classes';
import { getAuthToken } from "../../../classes/index";
import { appliedCandidates } from '../../../store/actions/appliedcandidates';
import { changeJobStatus } from '../../../store/actions/jobs';

import AppliedCandidatesCard from './AppliedCandidatesCard';
import { Recruiter_User_Type_ID } from '../../../config/constants';
import { notification } from '../../../classes/messages';
import { interviewSchedule } from '../../../store/actions/interview';

import { END_POINT, GET_ALL_MEMBERS, } from "../../../routes/api_routes";

class AppliedCandidates extends Component {

	state = {
		jobs: [],
		interviewOpt: '',
		page_num: 1,
		per_page: 2000,
		request_type: 'save',
		loading: false,
		no_data: false,
		active_status: 'Saved Jobs',
		job_titles: [],
		user_id: null,
		all_jobs: [],
		job_statuses: [],
		is_modal: false,
		modal_job_id: null,
		modal_round_id: null,
		modal_user_id: null,
		modal_job_app_id: null
	}

	async componentWillMount() {
		this.getJobs();
		let user = await getLoggedInUser();
		if (user) {
			this.setState({
				user_id: user.id
			});
		}

		let token = await getAuthToken();
		fetch(END_POINT + GET_ALL_MEMBERS + "/" + user.id, {
			method: 'GET',
			headers: { 'Authorization': 'Bearer ' + token }
		})
			.then((response) => response.json())
			.then((res) => {
				let interviewOpt = res.data.map(row => {
					return (

						<option value={row.member_id}>{row.name}</option>

					)
				})
				this.setState({ interviewOpt: interviewOpt })
			});
	}

	saveProfile = async (job) => {

	}

	resetInitialState = () => {
		this.setState({
			jobs: [],
			all_jobs: [],
			is_modal: false,
			modal_job_id: null,
			modal_round_id: null,
			modal_user_id: null,
			modal_job_app_id: null,
			job_statuses: [],
			page_num: 1
		});
	}

	scheduleInterview = async (e) => {
		e.preventDefault();
		let notify;
		let interview = new FormData();
		interview.append('user_id', this.state.modal_user_id);
		interview.append('job_id', this.state.modal_job_id);
		interview.append('round_id', this.state.modal_round_id);
		interview.append('job_app_id', this.state.modal_job_app_id);


		if (Object.keys(e.target).length > 0)
			Object.keys(e.target).map((key) => {
				if (e.target[key].value)
					interview.append(e.target[key].name, e.target[key].value);
			});
		await this.props.interviewSchedule(interview);
		if (this.props?.schedule_interview_res?.status == 'success') {
			this.resetInitialState();
			notify = notification({ type: 'success', message: this.props?.schedule_interview_res?.message });
			this.getJobs();
		} else {
			notify = notification({ type: 'error', message: errorPrettify(this.props?.schedule_interview_res?.message) });
		}
		if (notify)
			notify();

	}

	startQuiz = async (quiz) => {
		console.log(quiz)
	}


	changeJobStatus = async (job, is_reject = false) => {

		let obj = {};
		obj['round_id'] = job.round_id;
		obj['user_id'] = job.user_id;
		obj['job_id'] = job.job_id;
		obj['owner'] = Recruiter_User_Type_ID;
		obj['status'] = job.current_status;
		obj['job_app_id'] = job.job_app_id;

		if (is_reject) {
			obj['is_reject'] = job.is_reject;
		}

		if (obj.status == 'quiz_passed' || obj.status == 'interview') {
			this.setState({
				is_modal: true,
				modal_job_id: obj.job_id,
				modal_round_id: obj.round_id,
				modal_user_id: obj.user_id,
				modal_job_app_id: obj.job_app_id
			});
		} else {
			this.jobStatusChange(obj);
		}
	}

	jobStatusChange = async (obj) => {

		if (obj.status != 'round_complete') {
			let notify;
			await this.props.changeJobStatus(obj);

			console.log(this.props.change_job_status_res);

			if (this.props.change_job_status_res?.status == 'success') {
				notify = notification({ type: 'success', message: 'Status has been changed successfully!' });
				//window.location.reload();
				this.resetInitialState();
				this.getJobs();
			} else {
				notify = notification({ type: 'error', message: errorPrettify(this.props.change_job_status_res?.message) });
			}
			if (notify)
				notify();
		}

	}

	handleChange = (obj) => {

		let filterd = [];

		this.setState({
			loading: true,
			jobs: []
		});

		if (obj.type == 'filter_by_title') {
			if (this.state.all_jobs.length > 0) {
				if (obj.value == 'all') {
					filterd = this.state.all_jobs;
				} else {
					filterd = this.state.all_jobs.filter((job) => {
						if (job.job_title.indexOf(obj.value) !== -1) {
							return job;
						}
					});
				}
			}
		}

		if (obj.type == 'filter_by_status') {

			if (this.state.all_jobs.length > 0) {
				filterd = this.state.all_jobs.filter((job) => {
					console.log(job.current_status)
					if (job.current_status?.indexOf(obj.value) !== -1) {
						return job;
					}
				});
			}

		}

		this.setState({
			loading: false
		})

		if (filterd.length > 0) {
			this.setState({
				jobs: filterd
			})
		}


	}


	/* load more jobs */
	loadMore = () => {
		let page = this.state.page_num;
		this.setState({
			page_num: page + 1
		}, () => {
			this.getJobs();
		});
	}
	/* load more jobs */

	/* get jobs */
	getJobs = async () => {

		let user = await getLoggedInUser();
		if (user) {
			this.setState({
				loading: true
			});
			let obj = {};
			obj['company_id'] = user.company_id;
			//obj['request_type'] = this.state.request_type;
			obj['page_num'] = this.state.page_num;
			obj['per_page'] = this.state.per_page;
			await this.props.appliedCandidates(obj);
			this.setState({
				loading: false
			});

			if (this.props?.comp_applied_jobs_resp?.status) {

				if (this.props.comp_applied_jobs_resp?.data?.length > 0) {
					let jt = [];
					/* set job title filters */
					this.props.comp_applied_jobs_resp?.data.map((j) => {

						if (jt.indexOf(j.job_title) === -1) {
							jt.push(j.job_title)
						}
					});
					if (jt.length > 0)
						this.setState({
							job_titles: jt
						});

					/* set job title filters */

					if (this.props.comp_applied_jobs_resp?.data.length < this.state.per_page) {
						this.setState({
							no_data: true
						})
					}

					this.setState(prevState => ({
						jobs: [...prevState.jobs, ...this.props.comp_applied_jobs_resp.data],
						all_jobs: [...prevState.jobs, ...this.props.comp_applied_jobs_resp.data]
					}), () => {
						let jobs = [];
						this.state.all_jobs?.map((v) => {
							if (jobs.indexOf(v.current_status) === -1 && v.current_status != null) {
								jobs.push(v.current_status);
							}
						});
						this.setState(prevState => ({
							job_statuses: jobs
						}));
					});

				} else {
					this.setState({
						no_data: true
					})
				}

			}

		}

	}
	/* get jobs */

	closeModal = () => {
		this.setState({
			is_modal: false
		})
	}



	render() {

		return (


			<div>


				<Section>
					<Main>

						{/* modal */}
						{this.state.is_modal &&
							<>
								<div class="modal fade-in" style={{ display: 'block' }}>
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<form onSubmit={(e) => { this.scheduleInterview(e) }}>
												<div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">Schedule Interview</h5>
													<span className='f-2 cursor' onClick={(e) => this.closeModal()}>&times;</span>
												</div>
												<div class="modal-body">

													<div className='row'>
														<div className='col-md-12'>
															<label className='text-dark'>Interviewer Name</label>
														</div>
														<div className='col-md-12'>
															<select
																class="form-select"
																aria-label="Default select example"
																name='interviewer_id'
																required
															>
																<option>--Select Interviewer--</option>
																{this.state.interviewOpt}
															</select>
														</div>
													</div>

													<div className='row mt-1'>
														<div className='col-md-12'>
															<label className='text-dark'>Interview Date & Time</label>
														</div>
														<div className='col-md-12'>
															<input
																type='datetime-local'
																className='form-control'
																name='interview_date_time'
																required
															/>
														</div>
													</div>

													<div className='row mt-1'>
														<div className='col-md-12'>
															<label className='text-dark'>Interview Location</label>
														</div>
														<div className='col-md-12'>
															<input
																type='text'
																className='form-control'
																name='interview_location'
																required
															/>
														</div>
													</div>

												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" onClick={(e) => this.closeModal()}>Close</button>
													<button type="submit" class="btn btn-primary">Schedule</button>
												</div>
											</form>
										</div>
									</div>
								</div>

								<div class="modal-backdrop fade show"></div>
							</>
						}
						{/* modal */}

						{/* filters */}
						<div className='row mt-3 mb-4 align-items-center'>
							<div className=' col-12 col-lg-5  mb-1'>
								<h5 className="text-blue">Candidates Applied</h5>
							</div>

							{/* filter 1 */}
							<div className="position-relative me-1   filter-btn col-12  mb-1 col-lg-3">

								<div class="dropdown shadow w-100">
									<button class="btn btn-default w-100 text-primary ps-4 pe-4 btn-sm dropdown-toggle btn-toggle btn-block w-200px" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Filter by Job Title
									</button>
									<div class="dropdown-menu w-100 p-0" aria-labelledby="dropdownMenuButton">
										<div className="w-90 me-auto ms-auto border-bottom-blue"></div>

										<a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ type: 'filter_by_title', value: 'all' })}>
											All Jobs
										</a>

										{this.state.job_titles.length > 0 && this.state.job_titles.map((job) => {
											return <a class="dropdown-item" href="javascript:void(0)" onClick={(e) => this.handleChange({ type: 'filter_by_title', value: job })}>{job}</a>
										})}

									</div>
								</div>
							</div>
							{/* filter 1 */}

							{/* filter 2 */}
							<div className="position-relative filter-btn col-12 col-lg-3">

								<div class="dropdown shadow w-100 p-0">
									<button class="btn w-100 btn-default text-primary ps-4 pe-4 btn-sm dropdown-toggle btn-toggle btn-block w-200px" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<span>Filter By Job Status</span>
									</button>
									<div class="dropdown-menu w-100 shadow p-0" aria-labelledby="dropdownMenuButton">
										<div className="w-90 me-auto ms-auto border-bottom-blue"></div>

										{this.state.job_statuses?.length > 0 && this.state.job_statuses?.map((status) => {
											return <a class="dropdown-item text-capitalize" href="javascript:void(0)" onClick={(e) => this.handleChange({ type: 'filter_by_status', value: status })}>{formatTitle(status)}</a>
										})
										}

									</div>
								</div>
							</div>
							{/* filter 2 */}

						</div>
						{/* filters */}

						{/* jobs list */}
						{this.state.loading &&
							<div className='mt-2'>
								<Loading />
							</div>
						}

						{(this.state.jobs.length > 0) ?
							<AppliedCandidatesCard
								title=''
								jobs={this.state.jobs}
								changeJobStatus={this.changeJobStatus}
								saveProfile={this.saveProfile}
								startQuiz={this.startQuiz}
							/>
							:
							<h5 className="text-blue text-center">No Jobs Found.</h5>
						}

						{/* jobs list */}


						{/* load more */}
						{this.state.no_data == false &&
							<button className="btn btn-primary btn-sm d-block me-auto ms-auto mt-2 mb-2" onClick={() => { this.loadMore() }}>
								<i class="las la-angle-double-down"></i> Load More
							</button>
						}
						{this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}
						{/* load more */}

					</Main>
					<SideBar>
						<ProfileName />
						<ActionButtons />
						<CandidateCards />
						<Skills />
						<FeaturedCompanies />
						<Designations />
						<Locations />
						<Company />
					</SideBar>
				</Section>


			</div>
		);
	}
}


const mapStateToProps = (state) => {

	const { comp_applied_jobs_resp } = state.appliedcandidatesreducer;
	const { change_job_status_res, schedule_interview_res } = state.common;

	return {
		comp_applied_jobs_resp,
		change_job_status_res,
		schedule_interview_res
	}
};

function mapDispatchToProps(dispatch) {
	return {
		appliedCandidates: (data) => dispatch(appliedCandidates(data)),
		changeJobStatus: (data) => dispatch(changeJobStatus(data)),
		interviewSchedule: (data) => dispatch(interviewSchedule(data)),
	};
}


export default connect(mapStateToProps, mapDispatchToProps)(AppliedCandidates);