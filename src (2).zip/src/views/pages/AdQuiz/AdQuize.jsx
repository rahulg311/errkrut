import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import CandidateCards from './../../../components/Sidebars/Candidate/CandidateCards';
import Quizes from './../Quizes/Quizes';
import PlanCard from './../../../components/SelectPlan/PlanCard';

class AdQuize extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
   <div class="col-lg-9">
   <div class="container bg-white rounded-4 pt-3 pb-7">
      <ul></ul>
      <form method="post">
         <div class="bg-white">
            <div>
               <div className='row'>
               <div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
                  						<select class="form-select w-35 text-primary fw-bold border-blue1" aria-label="Default select example">
                                              
  <option className='text-primary fw-bold' selected>Candidate Quize</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>
						
						</div>
					</div>
               </div>
               <div class="border-bottom-blue mb-2 mt-2"></div>

               <div className='w-80'>

   
               <div class="row mt-1 ">
                  <div class="col-md-12"><label class="text-primary">Quiz title</label></div>
                  <div class="col-md-12"><input type="text" class="form-control input-border fs-12 " name="title" required="" value="" placeholder='Enter your Quize title here'/></div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-7">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Quiz Duration(In Minutes)</label></div>
                        <div class="col-md-12"><input type="number" class="form-control input-border fs-12 mt-0" name="duration" min="0" required="" value="" placeholder='Enter your Quize Duration here'/></div>
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="row mt-1">
                        <div class="col-md-12">
                           <label class="text-dark">Evaluation</label>
                           <select class="form-select form-select-md input-border fs-12" name="evaluation" required="" placeholder='auto'>
                              <option value="">Auto</option>
                              <option value="1">Automatic</option>
                              <option value="0">Manual</option>
                           </select>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-12">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Quiz Instruction</label></div>
                        <div class="col-md-12"><textarea class="form-control input-border fs-12" name="quiz_instructions" required="" placeholder='Enter your Quiz Instruction here'></textarea></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-12">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Quiz Success Message</label></div>
                        <div class="col-md-12"><textarea class="form-control input-border fs-12" name="quiz_instructions" required="" placeholder='Enter your Quiz Success Message here'></textarea></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-12">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Quiz Failure Message</label></div>
                        <div class="col-md-12"><textarea class="form-control input-border fs-12" name="quiz_instructions" required="" placeholder='Enter your Quiz Failure Message here'></textarea></div>
                     </div>
                  </div>
               </div>
              
               <div class="row mt-1 ">
                  <div class="col-md-12"><label class="text-dark">Passing Marks</label></div>
                  <div class="col-md-12"><input type="number" class="form-control input-border fs-12" name="passing_marks" min="0" required="" value="" placeholder='Enter your Passing Marks'/></div>
               </div>
            
               <div class="row mt-4 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Retake Quiz</label>
                  <select class="form-select w-50 border-blue1 mt-1 mb-1 text-primary" aria-label="Default select example">
  <option selected>None</option>
 
  <option value="1">1</option>
  <option value="2">2</option>

</select>
                  </div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="quiz_retake"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Show Result</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="show_result"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Check Answer</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="check_answer"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Partial Markings</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="partial_marking"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Randomize Questions</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="randomize_questions"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Randomize Question Between Section</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="randomize_question_bs"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Randomize Section Questions</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="randomize_section_questions"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Randomize Section</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="randomize_section"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Randomize Options</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="randomize_options"/></div>
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Negative Marking</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="negative_marking"/></div>
                     </div>
                  </div>
               </div>
               <div class="new2 border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2 f-0-9"></div>
               <div class="row mt-1 ">
                  <div class="col-md-6 col-6"><label class="text-dark">Create Section Quize</label></div>
                  <div class="col-md-6 col-6">
                     <div class="ms-auto d-table mt-auto mb-auto">
                        <div class="form-check form-switch ms-auto"><input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="negative_marking"/></div>
                     </div>
                  </div>
               </div>
               <div className='container'>
              
                   <div class="row mt-1 ">
                  <div class="col-md-12"><label class="text-primary">Section Name</label></div>
                  <div class="col-md-12"><input type="text" class="form-control input-border fs-12 " name="title" required="" value="" placeholder=' Quize Part 1'/></div>
               </div> 
               
               <div class="row mt-1 ">
                  <div class="col-md-12"><label class="">Number of Questions</label></div>
                  <div class="col-md-12"><input type="text" class="form-control input-border fs-12 " name="title" required="" value="" placeholder='10'/></div>
               </div> 
               <div class="row mt-1 ">
                  <div class="col-md-6">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Correct Marks Per Question</label></div>
                        <div class="col-md-12"><input type="number" class="form-control input-border fs-12 mt-0" name="duration" min="0" required="" value="" placeholder='Set the  Marks awarded per Question '/></div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="row mt-1">
                        <div class="col-md-12"><label class="text-dark">Negative Marks Per Question</label></div>
                        <div class="col-md-12"><input type="type" class="form-control input-border fs-12 mt-0" name="duration" min="0" required="" value="" placeholder='Set the  Marks deducted per Question'/></div>
                     </div>
                  </div>
               </div>

               <div class="row mt-4">
                  <div class="col-md-12"><button type="submit" class="btn btn-primary d-block  ps-5 pe-5">Save Section</button></div>
               </div>            
               </div>
               
               
               
               
               
              
            </div>
         </div></div>
      </form>
   </div>            
</div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default AdQuize;