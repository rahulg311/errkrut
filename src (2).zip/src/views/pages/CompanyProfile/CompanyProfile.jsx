import React, { useEffect } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import useFetch from '../../../hooks/useFetch';
import { END_POINT } from '../../../routes/api_routes';
import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import Loading from '../../../components/common/Loading';
import Profile from "../../../components/CompanyProfile/Profile"
import Summary from '../../../components/CompanyProfile/Summary';
import HiringSector from '../../../components/CompanyProfile/HrProfile';
import PastPostJobs from '../../../components/CompanyProfile/PastPostJobs';
import { getLoggedInUser } from '../../../classes';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import HrProfile from '../../../components/CompanyProfile/HrProfile';
import CompanyMembers from '../../../components/CompanyProfile/CompanyMembers';
import DeleteAccount from '../../../components/Login/DeleteAccount';

const CompanyProfile = (props) => {
	const { data, loading, error, doFetch } = useFetch();

	useEffect(async () => {
		let user_id;
		if (props.match.params?.id) {
			user_id = props.match.params.id;
		} else {
			const user = await getLoggedInUser();
			user_id = user.id;
		}

		doFetch(END_POINT + `get_profile/${user_id}`);
	}, []);

	return (
		<div className='main-container position-relative '>
			<Section>
				<Main classNam="p-1">
					{loading ? (
						<Loading size='27px' className='my-4' />
					) : (
						<main>

							{data != null &&
								data?.map((item) => {
									if (item.CardTitle === 'Company Profile') {
										return <Profile data={item} />;
									} else if (item.CardTitle === 'Summary') {
										return <Summary data={item} />;
									} else if (item.CardTitle === 'HR Profile') {
										return <HrProfile data={item} />;
									}else if (item.CardTitle === 'Hiring Sector') {
										return <HiringSector data={item} />;
									}
								})}

							<hr className='mt-6' />
							<PastPostJobs />

							<CompanyMembers/>
							<DeleteAccount></DeleteAccount>
						</main>
					)}
				</Main>

				<SideBar>
					<ProfileName />
					<ActionButtons />
					<CandidateCards />
					<Skills />
					<FeaturedCompanies />
					<Designations />
					<Locations />
					<Company />
				</SideBar>
			</Section>
		</div>
	);
};

export default CompanyProfile;
