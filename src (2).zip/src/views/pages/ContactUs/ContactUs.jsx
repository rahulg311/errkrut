import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import Designations from './../../../components/Sidebars/Candidate/Designations';
import { getAuthToken } from '../../../classes/index';
import { END_POINT } from '../../../routes/api_routes';
import { notification } from "../../../classes/messages";

import MapContainer from './../../../components/MapContainer'



class ContactUs extends Component {
	state = {
		name: '', email: '', organization: '', phoneno: '', message: ''
	}
	// Handle fields change
	handleChange = (e) => {
		if (e.target) {
			let ivalue = e.target.value;
			let iname = e.target.name;
	  
			this.setState({ [iname]: ivalue });
		}	
	}

	handle_submit = async (e) => {
		e.preventDefault();

		let token = await getAuthToken();

		var formData = new FormData();
		formData.append("name", this.state.name);
		formData.append("email", this.state.email);
		formData.append("orgnization", this.state.organization);
		formData.append("phone_number", this.state.phoneno);
		formData.append("message", this.state.message);

		var requestOptions = {
			method: 'POST',
			body: formData,
			headers: {
			  'Accept': 'application/json',
			  'Authorization': 'Bearer ' + token
			}
		  };

		fetch(END_POINT + 'contact_us', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				console.log(result)
				let notify = notification({
					message: result.message,
					type: "success",
				});
				notify();
				this.setState({name: '', email: '', organization: '', phoneno: '', message: ''})

			})
			.catch((error) => {
				let notify = notification({
					message: error,
					type: "error",
				  });
				  notify();
			}
			);
	}
	render() {
		return (
			<div className="container">
				<div className="row">
					<div className="col-md-9 p-0">
						<div className="p-1  ">
							<div className=" ">
								{/* submit button */}
								{/* start Edit hr profile  */}
								<div className=" row  mt-2   ">
									<div className='container'>
										<div className='bg-white pt-2 pb-4 px-2 '>
											<div className='container'>
												<div className='row'>
													<div className='col-md-12'>
														<h4 className='text-primary'>Contact Us</h4>
														<p className='mt-2'>Thank you for interest <br /> Please fill out the form to inquire initiate dialogue and help us understand your brief Requirements.</p>
													</div>
												</div>
											</div>
										</div>

										<div className='row mt-4'>
											<div className='col-lg-6 col-12 mb-3  '>
												<div className='p-2 h-100 bg-white '>
													<h6 className='text-primary'>Address</h6>
													<p className='fs-12'>M-3, South Extension, Part-II,<br/> Main Ring Road,<br/> New Delhi – 110049. India.</p>

												</div>
											</div>
											<div className='col-lg-6 col mb-3 '>
												<div className='p-2 h-100 bg-white '>
													<h6 className='text-primary'>Write to us at</h6>
													<p className='fs-12'><a href="mailto:info@panaceaebizz.com">info@panaceaebizz(dot)com</a></p>
													<h6 className='text-primary mt-1'>on give us a call on</h6>
													<p className='fs-12'><a href="tel:+911145000144">+91 11 45000144</a></p>

												</div>
											</div>
											<div className='col-lg-4 col mb-4 d-none'>
												<div className='p-2 h-100 bg-white  '>
													<h6 className='text-primary'>Candidates Guide</h6>
													<p className='fs-12'><a className='text-dark' href="#">click here</a></p>
													<h6 className='text-primary mt-1'>Recruiter Guide</h6>
													<p className='fs-12'><a className='text-dark' href="#">click here</a></p>


												</div>
											</div>
										</div>




										<div className='row '>
											<div className='col-lg-6 mb-3'>
												<div className='container  bg-white h-100'>
													<form onSubmit={(e) => this.handle_submit(e)}>
														<div className="mb-3 pt-2">
															<label for="name" className="form-label text-primary">Name</label>
															<input type="text" className="form-control border-color-blue" id="name" name="name" 
															placeholder='Name' value={this.state.name} onChange={(e) => this.handleChange(e)} required/>

														</div>
														<div className="mb-3 mt-1">
															<label for="email" className="form-label">Email </label>
															<input type="email" className="form-control border-color-blue" placeholder='example@gmail.com' 
															id="email" name="email"  value={this.state.email} onChange={(e) => this.handleChange(e)} required/>

														</div>
														<div className="mb-3 mt-1">
															<label for="organization" className="form-label">Organisation </label>
															<input type="text" className="form-control border-color-blue" placeholder='Company Name' 
															id="organization" name="organization" value={this.state.organization} onChange={(e) => this.handleChange(e)} required/>

														</div>

														<div className="mb-3 mt-1">
															<label for="phoneno" className="form-label">Phone Number </label>
															<input type="number" className="form-control border-color-blue" placeholder='Phone No' id="phoneno" 
															name="phoneno" value={this.state.phoneno} onChange={(e) => this.handleChange(e)} required/>

														</div>
														<div className="mb-3 mt-1">
															<label for="message" className="form-label">Message</label>
															<textarea className="form-control border-color-blue" id="message" rows="3" name="message" placeholder='Enter your message here' 
															 value={this.state.message} onChange={(e) => this.handleChange(e)} required></textarea>
														</div>
														<div className="row mt-4 mb-3">
															<div className="col-md-12"><button type="submit" className=" mb-2 btn btn-primary float-end  ps-5 pe-5">Submit</button></div>
														</div>
													</form>

												</div>
											</div>
											<div className='col-lg-6'>
												<MapContainer></MapContainer>
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* submit button */}
							{/* form ends here */}
						</div>
					</div>
					{/* sidebar */}
					<div className="col-md-3">
						<ProfileName />
						<ActionButtons />
						<Company />
					</div>
					{/* sidebar */}
				</div>
			</div>
		);
	}
}
export default ContactUs;