import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import Designations from './../../../components/Sidebars/Candidate/Designations';

class ContectUs extends Component {
   // Handle fields change
   handleChange = (e) => {
   }
   render() {
      return (
         <div className="container">
            <div className="row">
               <div className="col-md-9 p-0">
                  <div className="p-1  ">
                     <div className=" ">
                        {/* submit button */}
                        {/* start Edit hr profile  */}
                        <div className=" row  mt-2   ">
                           <div className='container'>
                              <div className='bg-white pt-2 pb-4 px-2 '>
                                 <div className='container'>
                                    <div className='row'>
                                       <div className='col-md-12'>
                                          <h4 className='text-primary'>Contect Us</h4>
                                          <p className='mt-2'>Thank you for interest <br /> Please fill out the form to inquire initiate dialogue and understand your brief <br /> Requirements.</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                              <div className='row mt-4'>
                                 <div className='col-4 '>
                                    <div className='containe pb-2 pt-2 bg-white '>
                                       <h6 className='text-primary'>Address</h6>
                                       <p className='fs-12'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel suscipit id reiciendis, iure eum deserunt repellendus.</p>

                                    </div>
                                 </div>
                                 <div className='col-4 '>
                                    <div className='container pb-2 pt-2 bg-white '>
                                       <h6 className='text-primary'>Write to us at</h6>
                                       <p className='fs-12'>info@gmail.com</p>
                                       <h6 className='text-primary mt-1'>on give us a call on</h6>
                                       <p className='fs-12'>+9670***935</p>

                                    </div>
                                 </div>
                                 <div className='col-4 '>
                                    <div className='container pb-2 pt-2 bg-white  '>
                                       <h6 className='text-primary'>Candidates Guide</h6>
                                       <p className='fs-12'><a className='text-dark' href="#">click here</a></p>
                                       <h6 className='text-primary mt-1'>Recruiter Guide</h6>
                                       <p className='fs-12'><a className='text-dark' href="#">click here</a></p>

                                    </div>
                                 </div>
                              </div>




                              <div className='row mt-3'>
                                 <div className='col-md-6'>
                                    <div className='container  bg-white'>
                                       <div class="mb-3 pt-2">
                                          <label for="exampleInputEmail1" class="form-label text-primary">Name</label>
                                          <input type="text" class="form-control border-color-blue" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder='rahul' />

                                       </div>
                                       <div class="mb-3 mt-1">
                                          <label for="exampleInputEmail1" class="form-label">Email </label>
                                          <input type="email" class="form-control border-color-blue" placeholder='rahual@gmail.com' id="exampleInputEmail1" aria-describedby="emailHelp" />

                                       </div>
                                       <div class="mb-3 mt-1">
                                          <label for="exampleInputEmail1" class="form-label">Organisation </label>
                                          <input type="text" class="form-control border-color-blue" placeholder='Company name' id="exampleInputEmail1" aria-describedby="emailHelp" />

                                       </div>

                                       <div class="mb-3 mt-1">
                                          <label for="exampleInputEmail1" class="form-label">Phone Number </label>
                                          <input type="number" class="form-control border-color-blue" placeholder='+96700000000' id="exampleInputEmail1" aria-describedby="emailHelp" />

                                       </div>
                                       <div class="mb-3 mt-1">
                                          <label for="exampleFormControlTextarea1" class="form-label">Message</label>
                                          <textarea class="form-control border-color-blue" id="exampleFormControlTextarea1" rows="3" placeholder='Enter your message here'></textarea>
                                       </div>
                                       <div class="row mt-4 mb-3">
                                          <div class="col-md-12"><button type="submit" class=" mb-2 btn btn-primary float-end  ps-5 pe-5">Submit</button></div>
                                       </div>


                                    </div>
                                 </div>
                                 <div className='col-md-6'>

                                 </div>
                              </div>
                              
                              <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                                 <div className='container'>
                                    <div className='row'>
                                       <div className='col-md-12'>
                                          <p className='fw-bold fs-22 float-start text-primary'>Send Assessment</p>
                                       </div>
                                       <div className='border-bottom-blue mt-2 mb-2'></div>
                                    </div>
                                    <div className='w-75 w-100-xs'>
                                       <div className='row'>
                                          <div className='col-12'>
                                             <label for="exampleInputEmail1" class="form-label text-primary">Select Assessment</label>
                                             <select class="form-select" aria-label="Default select example">
                                                <option selected>Add Asseseement</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                             </select>
                                          </div>
                                          <div className='col-12 mt-2'>
                                             <label for="exampleInputEmail1" class="form-label text-primary">Select Candidates</label>
                                             <select class="form-select" aria-label="Default select example">
                                                <option selected>Add Candidates</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                             </select>
                                          </div>
                                       </div>
                                       <div className='row mt-2'>
                                          <div className='col-12'>
                                             <button type="button" class="btn btn-primary float-end end rounded-0">Send Assessment</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                                 <div className='containe'>
                                    <div className="row  mb-2">
                                       <div className="col-md-7 mt-2  col-12 mb-1">
                                          <h3 className="text-primary f-Poppins-Medium ms-4 ">View Assessment Result</h3>
                                       </div>
                                       <div className="col-md-5   ">
                                          <select class="p-1 text-primary ms-1 fs-12  " aria-label="Default select example">
                                             <option selected>ALL Assessment</option>
                                             <option value="1">One</option>
                                             <option value="2">Two</option>
                                             <option value="3">Three</option>
                                          </select>
                                          <select class="p-1 text-primary ms-1 fs-12 " aria-label="Default select example">
                                             <option selected>Status</option>
                                             <option value="1">Pass</option>
                                             <option value="2">Fail</option>
                                          </select>
                                          <button type="button" class="btn fs-12 btn-primary ps-4 pe-4 pt-1 pb-1 ms-1 m-2 rounded-0 ">Fliter</button>
                                       </div>
                                    </div>
                                    <div className="border-blue1  mb-2  "></div>
                                    <div className='row'>
                                       <div className='col-12'>
                                          <button type="button" class="btn btn-outline-secondary float-start">Download Data</button>
                                          <a className='float-end' href=""> Select All</a>
                                       </div>
                                    </div>
                                    <div className=''>
                                       <section class=" card shadow border-0 rounded-4 py-3 px-4 overflow-hidden mt-3">
                                          <header class="d-flex"
                                          >
                                             <div class="me-3 d-flex">
                                                <span class="bg-dark-pink px-20px  py-1px rounded me-3px text-light f-2 shadow">
                                                   <a class="text-light" href="/job/152/youtube-tutor">S</a>
                                                </span>
                                             </div>
                                             <div class="mt-auto mb-auto">
                                                <h6 class="font-bold">Rahul</h6>
                                                <p>Designations</p>
                                             </div>
                                             <div class="ms-auto ">
                                                <div class="form-check ">
                                                   <input class="form-check-input float-end fs-20" type="checkbox" value="" id="flexCheckDefault" />
                                                </div>
                                                <h5 className='mt-2 '>Score : 81%</h5>
                                             </div>
                                          </header>
                                          <div className='new2 mt-3 mb-2 '></div>
                                          <div className='row '>
                                             <div className='col-12'>
                                                <p className='float-start text-primary fw-bold'>Assessment name 1</p>
                                                <p className='float-end text-success fw-bold'>Status : Pass</p>
                                             </div>
                                             <div className='col-12 mt-2'>
                                                <p className='float-start '>Section 1</p>
                                                <p className='float-end '>80%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 2</p>
                                                <p className='float-end '>60%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 3</p>
                                                <p className='float-end '>40%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                          </div>
                                       </section>
                                       <section class=" card shadow border-0 rounded-4 py-3 px-4 overflow-hidden mt-3">
                                          <header class="d-flex"
                                          >
                                             <div class="me-3 d-flex">
                                                <span class="bg-dark-pink px-20px  py-1px rounded me-3px text-light f-2 shadow">
                                                   <a class="text-light" href="/job/152/youtube-tutor">S</a>
                                                </span>
                                             </div>
                                             <div class="mt-auto mb-auto">
                                                <h6 class="font-bold">Rahul</h6>
                                                <p>Designations</p>
                                             </div>
                                             <div class="ms-auto ">
                                                <div class="form-check ">
                                                   <input class="form-check-input float-end fs-20" type="checkbox" value="" id="flexCheckDefault" />
                                                </div>
                                                <h5 className='mt-2 '>Score : 81%</h5>
                                             </div>
                                          </header>
                                          <div className='new2 mt-3 mb-2 '></div>
                                          <div className='row '>
                                             <div className='col-12'>
                                                <p className='float-start text-primary fw-bold'>Assessment name 1</p>
                                                <p className='float-end text-success fw-bold'>Status : Pass</p>
                                             </div>
                                             <div className='col-12 mt-2'>
                                                <p className='float-start '>Section 1</p>
                                                <p className='float-end '>80%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 2</p>
                                                <p className='float-end '>60%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 3</p>
                                                <p className='float-end '>40%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                          </div>
                                       </section>
                                       <section class=" card shadow border-0 rounded-4 py-3 px-4 overflow-hidden mt-3">
                                          <header class="d-flex"
                                          >
                                             <div class="me-3 d-flex">
                                                <span class="bg-dark-pink px-20px  py-1px rounded me-3px text-light f-2 shadow">
                                                   <a class="text-light" href="/job/152/youtube-tutor">S</a>
                                                </span>
                                             </div>
                                             <div class="mt-auto mb-auto">
                                                <h6 class="font-bold">Rahul</h6>
                                                <p>Designations</p>
                                             </div>
                                             <div class="ms-auto ">
                                                <div class="form-check ">
                                                   <input class="form-check-input float-end fs-20" type="checkbox" value="" id="flexCheckDefault" />
                                                </div>
                                                <h5 className='mt-2 '>Score : 81%</h5>
                                             </div>
                                          </header>
                                          <div className='new2 mt-3 mb-2 '></div>
                                          <div className='row '>
                                             <div className='col-12'>
                                                <p className='float-start text-primary fw-bold'>Assessment name 1</p>
                                                <p className='float-end text-success fw-bold'>Status : Pass</p>
                                             </div>
                                             <div className='col-12 mt-2'>
                                                <p className='float-start '>Section 1</p>
                                                <p className='float-end '>80%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 2</p>
                                                <p className='float-end '>60%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                             <div className='col-12 mt-1'>
                                                <p className='float-start '>Section 3</p>
                                                <p className='float-end '>40%</p>
                                             </div>
                                             <div className='new2  mb-2  '></div>
                                          </div>
                                       </section>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     {/* submit button */}
                     {/* form ends here */}
                  </div>
               </div>
               {/* sidebar */}
               <div className="col-md-3">
                  <ProfileName />
                  <ActionButtons />
                  <Company />
               </div>
               {/* sidebar */}
            </div>
         </div>
      );
   }
}
export default ContectUs;