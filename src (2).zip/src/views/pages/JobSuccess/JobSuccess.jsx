import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';

class JobSuccess extends Component {

    render() {

        let message = this.props.location.state?.message;
        let subtitle = this.props.location.state?.subtitle;
        let image = this.props.location.state?.image;
        return (


            <div className="container">
                <div className="row">

                    <div className="col-md-9 p-0">
                        <div className="bg-white br-5 pt-4 pb-4 ps-4 pe-4">

                            <div className="col-md-12 text-center">

                                <img className="w-100" src={`${(image)?image:`/assets/imgs/add-job-successful.png`}`} alt="THANKU" />

                                <h4>{message?message:'You have Successfully Done.'}</h4>

                                {
                                    subtitle
                                    &&
                                    <h5>{subtitle?subtitle:''}</h5>
                                }
                                <NavLink to="/">Go to homepage</NavLink>
                            </div>

                        </div>

                    </div>

                    {/* sidebar */}
                    <div className="col-md-3">
                        <div className="p-1">
                            <ProfileName />
                            <ActionButtons />
                            <Company />
                        </div>
                    </div>
                    {/* sidebar */}

                </div>
            </div>

        );
    }

}

export default JobSuccess;