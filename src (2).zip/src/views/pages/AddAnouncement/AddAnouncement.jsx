import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import { NavLink } from 'react-router-dom';
import { Route } from '../../../routes/routes';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Quizes from '../Quizes/Quizes';
import PlanCard from '../../../components/SelectPlan/PlanCard';


class AddAnouncement extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
   <div class="col-lg-9">
   <div class="container bg-white rounded-4 pt-3 pb-7">
      <ul></ul>
      <form method="post">
         <div class="bg-white">
            <div>
               <div className='row'>
               <div className='col-md-12'>
						<h4 className='text-primary'>Add Anouncement </h4>
					</div>
               </div>
               <div class="border-bottom-blue mb-2 mt-2"></div>

               <div className='w-80'>

   
               <div class="row mt-1 ">
                  <div class="col-md-12"><label class="text-primary">Subject</label></div>
                  <div class="col-md-12"><input type="text" class="border-color-blue form-control input-border fs-12 " name="title" required="" value="" placeholder='Enter your Full Name'/></div>
               </div>
               <div class="row mt-1 ">
                 
                  <div class="col-md-5">
                     <div class="row mt-1">
                        <div class="col-md-12">
                           <label class="text-primary">Select Job</label>
                           <select class="form-select border-color-blue form-select-md input-border fs-12" name="evaluation" required="" placeholder='All Job'>
                              <option value="1">UI/UX Designer</option>
                              <option value="2">Flutter Developer</option>
                              <option value="3">Social Media Manager</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-7">
                     <div class="row mt-1">
                        <div class="col-md-12"> <label class="text-primary">Candidates</label>
                           <select class="form-select border-color-blue form-select-md input-border fs-12" name="evaluation" required="" placeholder='All Candidates'>
                              <option value=""> All</option>
                              <option value="1">All Candidates</option>
                              <option value="0">Saved Candidates</option>
                              <option value="1">Applied Candidates</option>
                              <option value="0">Rejected Candidates</option>
                              <option value="0">Sam Jose</option>
                              <option value="1">Petar Griffin</option>
                              <option value="0">Dwite Shrute</option>
                           </select>
                           </div>
                       
                     </div>
                  </div>
               </div>
               <div class="row mt-1 ">
                  <div class="col-md-12">
                     <div class="row mt-1">
                        <div class="col-md-12"><div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Message</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="5"></textarea>
</div></div>
                       
                     </div>
                  </div>
               </div>

















               
               <div class="row mt-1 ">
                  <div class="col-md-12">
                  <div class="col-md-12 mt-3">
                  <button type="submit" class="btn btn-primary float-end d-block  ps-5 pe-5">Send</button>
                  </div>
                  </div>
               </div>
               
              
             
               
               
               
               
               
              
            </div>
         </div></div>
      </form>
   </div>            
</div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default AddAnouncement;