import React, { Component, useEffect } from 'react';
import { formatTitle, getLoggedInUser, getValueFromArr, isRecruiter, isCampus } from '../../../classes';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { jobDetail } from '../../../store/actions/jobs';
import { connect } from 'react-redux';
import moment from 'moment';
import { NavLink } from 'react-router-dom';
import SideBar from '../../../components/hoc/SideBar';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import { routePushed } from '../../../classes/browserHistory';
import LikeSaveJob from '../../../components/LikeSaveJob/LikeSaveJob';
import PostedOn from '../../../components/PostedOn';
import QuestionariesModel from '../../../components/CadidateAppliedJobs/QuestionariesModel'

class JobDetail extends Component {

   state = {
      job_id: null,
      job_details: {},
      user_id: null,
      qmodel: false,
      articleStructuredData: {}
   }
   showQuestionModal = () => {
      this.setState({
         qmodel: true,
      });
   };

   closeQuestionModal = () => {
      this.setState({
         qmodel: false,
      });
   }

   componentWillMount = async () => {
      window.scrollTo(0, 0);
      const user = await getLoggedInUser();
      if (this.props.match.params?.id) {
         this.setState({
            job_id: this.props.match.params?.id,
            user_id: user?.id
         }, () => {
            this.getJobDetail()
         });
      }

   }

   getJobDetail = async () => {
      const user = await getLoggedInUser();
      await this.props.jobDetail({ job_id: this.state.job_id, user_id: user?.id });
      let resp = this.props.job_detail;


      if (resp?.status == 'success') {
         Object.keys(resp.data[0]).map((key) => {
            this.setState({
               job_details: {
                  ...this.state.job_details,
                  [key]: resp.data[0][key],
               },
               articleStructuredData: {
                  "@context": "https://schema.org",
                  "@type": "JobPosting",
                  title: this.state.job_details?.job_title,
                  description: this.state.job_details?.purpose,
                  datePosted: this.state.job_details?.publish_start,
                  validThrough: this.state.job_details?.publish_start,
                  employmentType: this.state.job_details?.nature_of_employment == 'FULL TIME' ? 'FULL_TIME' : 'PART_TIME',
                  skills: [this.state.job_details?.skill_set],
                  applicantLocationRequirements: {
                     "@type": "Country",
                     name: "India"
                  },
                  jobLocationType: "",
                  hiringOrganization: {
                     "@type": "Organization",
                     "name": this.state.job_details?.company_name,
                     "logo": (this.state.job_details?.company_logo) ? getValueFromArr(this.state.job_details?.company_logo, 0) : `/assets/imgs/dummy-logo.png`
                  },
                  "experienceRequirements": {
                     "@type": "OccupationalExperienceRequirements",
                     "monthsOfExperience": this.state.job_details?.min_work_exp * 12
                  },
                  "qualifications": "NA",
                  "occupationalCategory": "NA",
                  "responsibilities": "NA",
                  "jobLocation": {
                     "@type": "Place",
                     "address": {
                        "@type": "PostalAddress",
                        "addressLocality": this.state.job_details?.job_location,
                        "addressRegion": "NA",
                        "postalCode": "NA",
                        "addressCountry": "India",
                        "streetAddress": "NA"
                     }
                  },
                  baseSalary: {
                     "@type": "MonetaryAmount",
                     "currency": "INR",
                     "value": {
                        "@type": "QuantitativeValue",
                        "value": this.state.job_details?.ctc_to,
                        "unitText": "YEAR"
                     }
                  },
               }
            });
         });
      }

   }

   render() {
      let hrName; let hrDesignation; let showHrDetails = false;
      
      if(this.state.job_details.hr_details != null){
         let hr_details = JSON.parse(this.state.job_details.hr_details);
         hrName = hr_details.hr_name;
         hrDesignation = hr_details.hr_designation;
         showHrDetails = true
      }
      
      return (
         <>
            <QuestionariesModel
               is_modal={this.showQuestionModal}
               closeModal={this.closeQuestionModal}
               jobState={this.state}
               jobData={this.state.job_details}
            />
            <script type="application/ld+json">
               {JSON.stringify(this.state.articleStructuredData)}
            </script>
            <div className="container">
               <div className="row">
                  <div className="col-md-9 p-0 ">

                     {/* job detail starts here */}
                     <div className=" bg-white br-5 ">
                        <div className="br-5 shadow">
                           <div className="container pt-2 pb-2">

                              {/* header starts here */}
                              <div className="row mb-2">
                                 <div className="col-md-11 col-10">
                                    <header className='d-flex '>
                                       <div className='me-3'>
                                          
                                          <img
                                             src={(this.state.job_details?.company_logo) ? JSON.parse(this.state.job_details?.company_logo) : `/assets/imgs/dummy-logo.png`}
                                             className='img-fluid shadow br-5 h-60p'
                                          />
                                       </div>
                                       <div>
                                          <h4 className='font-bold f-Poppins-Medium'>{this.state.job_details?.job_title}</h4>
                                          <p className="f-Poppins-Regular f-1-1">{this.state.job_details?.company_name}</p>
                                       </div>
                                    </header>
                                 </div>

                              </div>
                              {/* header ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-briefcase  text-sky-blue f-1-4 pe-1 ' />
                                    <p className=""><span className="text-primary f-Poppins-Medium   f-1 me-2">Experience</span><span className=" f-Poppins-Light font-bold f-r-11 ">{this.state.job_details?.min_work_exp} - {this.state.job_details?.max_work_exp} Yrs.</span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-map-marker   text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium f-1 me-2">Locations</span><span className="f-Poppins-Light font-bold f-r-11 ">{this.state.job_details?.city}</span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-rupee-sign  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Salary</span><span className="f-Poppins-Light font-bold f-r-11 ">
                                       {this.state.job_details?.ctc_from} - {this.state.job_details?.ctc_to} L.P.A
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-user-minus  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Vacancy</span><span className="f-Poppins-Light font-bold f-r-11 ">
                                       {this.state.job_details?.number_of_vaccancy}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-user-edit  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light font-bold f-r-11 text-break">
                                       {this.state.job_details?.skill_set}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-user-graduate  text-sky-blue f-1-4  pe-1' />
                                    <p><span className="text-primary f-Poppins-Medium  f-1 me-2">Designation</span><span className="f-Poppins-Light font-bold f-r-11 ">
                                       {this.state.job_details?.designation}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-tasks  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Job Function</span><span className="f-Poppins-Light font-bold f-r-11 ">
                                       {this.state.job_details?.job_function}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-graduation-cap  text-sky-blue f-1-4  pe-1' />
                                    <p className="    "><span className="text-primary f-Poppins-Medium  f-1 me-2">Qualification</span><span className="f-Poppins-Light font-bold f-r-11 ">
                                       {this.state.job_details?.qualification}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-clock  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Nature of Employment</span><span className="f-Poppins-Light font-bold f-r-11 text-uppercase">
                                       {formatTitle(this.state.job_details?.nature_of_employment)}
                                    </span> </p>
                                 </div>
                              </div>
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-clock  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Job Type</span><span className="f-Poppins-Light font-bold f-r-11">
                                       {formatTitle(this.state.job_details?.job_type)}
                                    </span> </p>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {/* row starts here */}
                              <div className="row mb-1">
                                 <div className="col-12 d-flex">
                                    <i class='las la-clipboard-list  text-sky-blue f-1-4  pe-1' />
                                    <p className=""><span className="text-primary f-Poppins-Medium  f-1 me-2">Description</span></p>
                                 </div>

                                 <div className='col-12'>
                                    <div>
                                       <p className='mb-1 mt-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Title
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.title}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium f-1 me-2">
                                             Purpose
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.purpose}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Industry
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.industry}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Job Responsibilites
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.job_responsibilities}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Preferred Skills
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.preffered_skills}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Desired Qualification
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.desired_qualification}
                                          </span>
                                       </p>

                                       <p className='mb-1 f-0-9'>
                                          <span className="text-primary f-Poppins-Medium  f-1 me-2">
                                             Job Summary
                                          </span>
                                          <span className="f-Poppins-Light">
                                             {this.state.job_details?.summary}
                                          </span>
                                       </p>
                                    </div>
                                 </div>
                              </div>
                              {/* row ends here */}

                              {this.state.job_details?.hr_details != undefined && <div class="row mb-1">
                                 <div class="col-12 d-flex">
                                    <i class="las la-clipboard-list  text-sky-blue f-1-4  pe-1"></i>
                                    <p class="">
                                       <span class="text-primary f-Poppins-Medium  f-1 me-2">HR Details</span>
                                       <span class="f-Poppins-Light font-bold f-r-11 ">{JSON.parse(this.state.job_details?.hr_details).hr_name} ({JSON.parse(this.state.job_details?.hr_details).hr_designation})</span>
                                    </p>
                                 </div>
                              </div>}


                              {this.state.job_details?.show_website_link ? <div class="row mb-1">
                                 <div class="col-12 d-flex">
                                    <i class="las la-globe text-sky-blue f-1-4 pe-1"></i>
                                    <p class="">
                                       <span class="text-primary f-Poppins-Medium  f-1 me-2">Website Link</span>
                                       <span class="f-Poppins-Light font-bold f-r-11"><a href={this.state.job_details?.website_link} target="_blank">{this.state.job_details?.website_link}</a></span>
                                    </p>
                                 </div>
                              </div> : ""}



                              {/* skills badges starts here */}
                              <div className="row">
                                 <div className="col-md-12 p-0">
                                    <div className="bg-whitept-3 pb-3 px-3 br-5">
                                       <div className="row">
                                          <div className="col-md-12 mt-1">
                                             {this.state.job_details?.skill_set?.split(',').map((value) => {
                                                return <span class="badge badge-default cursor me-1 f-Poppins-Medium"><a href={`/search/${value}`}> {value} </a></span>
                                             })}
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              {/* skills badges ends here */}


                              <div className="row ">
                                 <div className="col-md-10">
                                    <section className='d-flex justify-content-between mt-1'>
                                       <div className='d-flex align-items-center mb-md-0'>
                                          <div className='d-flex align-items-center'>
                                             <img src='/assets/imgs/fire.png' />
                                          </div>
                                          <small className='ps-2 f-1'><PostedOn date={this.state.job_details?.created_at} /></small>
                                       </div>
                                    </section>
                                 </div>
                              </div>


                              <div className="thin mt-2 mb-4"></div>



                              {/* job footer starts here */}


                              {(!isRecruiter() && !isCampus()) &&
                                 <>
                                    <hr className='mt-md-3 mt-0' />
                                    <footer>
                                       <div className=' align-items-center w-100 ' >
                                          <LikeSaveJob job_id={this.state.job_id} />

                                          <div className='row '>
                                             <div className='col-lg-9'></div>
                                             <div className='col-12 col-lg-3 float-end'>
                                                <div className='d-flex justify-content-end align-items-center w-100'>
                                                   {this.state.user_id == null &&
                                                      <p className="text-danger d-block me-1">You must be logged in to apply this job</p>
                                                   }
                                                   {
                                                      this.state.job_details?.applied ?
                                                         (<button type='button' className='btn btn-primary btn-sm text-light px-4'>
                                                            Applied
                                                         </button>)
                                                         : (this.state.job_details?.q_education_qualification != null || this.state.job_details?.q_salary != null || this.state.job_details?.q_skill_set != null
                                                            ? <button
                                                               onClick={() => this.showQuestionModal()}
                                                               className="btn ms-1 btn-primary btn-sm ps-4 pe-4 w-100"
                                                            >
                                                               Apply Now
                                                            </button>
                                                            : (<NavLink to={`/apply-job/${this.state.job_details?.job_id}/${this.state.job_details?.job_title}/${this.state.job_details?.company_name}/${(this.state.job_details?.company_logo) ? btoa(getValueFromArr(this.state.job_details?.company_logo, 0)) : ''}`} className='btn btn-primary btn-sm text-light px-4'>
                                                               Apply Now
                                                            </NavLink>))


                                                   }



                                                </div>
                                             </div>
                                          </div>

                                       </div>
                                    </footer>
                                 </>
                              }
                              {/* job footer starts here */}



                           </div>


                           {/* submit button */}
                           {/* form ends here */}
                        </div>
                     </div>
                     {/* job detail ends here */}

                  </div>
                  {/* sidebar */}
                  <SideBar>
                     <ProfileName />
                     <ActionButtons />
                     <CandidateCards />
                     <Skills />
                     <FeaturedCompanies />
                     <Designations />
                     <Locations />
                     <Company />
                  </SideBar>
                  {/* sidebar */}
               </div>
            </div>

         </>
      );
   }
}

const mapStateToProps = (state) => {

   const { job_detail } = state.common
   return {
      job_detail
   }
};

function mapDispatchToProps(dispatch) {
   return {
      jobDetail: (formData) => dispatch(jobDetail(formData)),
   };
}

export default connect(mapStateToProps, mapDispatchToProps)(JobDetail);