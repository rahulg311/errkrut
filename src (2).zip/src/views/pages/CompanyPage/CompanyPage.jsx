import React, { Component } from 'react';
import { getAllJobs } from '../../../store/actions/jobs';
import { connect } from "react-redux";
import { NavLink } from 'react-router-dom';
import { convertToSlug, getValueFromArr, ReadMore, isRecruiter, isCampus } from '../../../classes';
import Loading from '../../../components/common/Loading';

class CompanyPage extends Component {

	state = {
		top_jobs: [],
		loader: false,
		no_data: false
	}

	componentWillMount() {
		this.getAllJobs();
	}

	/* get jobs */
	getAllJobs = async () => {

		this.setState({
			loader: true
		})
		let company_id = this.props.match.params.id

		let buff = new Buffer(company_id, 'base64');
		let base64ToStringNew = buff.toString('ascii');

		await this.props.getAllJobs(base64ToStringNew);
		console.log(this.props)
		if (this.props.jobsData) {
			this.setState({
				loader: false
			})

			if (this.props.jobsData?.status == 'success' && this.props.jobsData?.data.length > 0)
				this.setState(prevState => ({
					top_jobs: [...prevState.top_jobs, ...this.props.jobsData.data],
				}));
			else
				this.setState({
					no_data: true
				});
		}
	}

	/* get jobs */

	render() {


		let topjobs =

			this.state.top_jobs &&

			this.state.top_jobs.map((tj, i) => {
				return <div className="col-md-3 p-1 mb-3">
					{/* Cards */}
					<div className={`cards card bg-white rounded-4 shadow position-relative w-100 p-2 bg-center mt-2 h-100`} >
						<div className="card-header bg-transparent">
							<div className="d-flex align-items-start flex-column ">

								{/* row */}
								<div className="d-flex">
									<div className="">
										<div>
											<h3>
											<NavLink to={`/job/${tj.id}/${convertToSlug(tj.job_title)}`}>
												<p className="m-0 f-0-9 ">{tj.job_title}</p>
											</NavLink>
											</h3>
										</div>
									</div>
								</div>
							</div>
						</div>
						{/* row */}
						<div className="card-body pt-0">
							<div className="mt-1 mb-1 w-90">

								{/* row */}
								<div className="d-flex flex-column flex-lg-row">

									<div className="mt-auto mb-auto col-md-6">
										<p className=" m-0 f-0-8 fw-bold"><i class="las la-briefcase  f-0-8"></i> Experience</p>
									</div>
									<div className="mt-auto mb-auto">
										<p className=" m-0 f-0-8 ">{tj.min_work_exp} - {tj.max_work_exp} Yrs.</p>
									</div>
								</div>
								{/* row */}
								<hr/>
								{/* row */}
								<div className="d-flex flex-column flex-lg-row">

									<div className="mt-auto mb-auto col-md-5">
										<p className=" m-0 f-0-8 fw-bold"><i class="las la-map-marker  f-0-8"></i> Location</p>
									</div>
									<div className="mt-auto mb-auto">
										<p className=" m-0 f-0-8 text-break">{tj.city}</p>
									</div>
								</div>
								{/* row */}
								<hr/>
								{/* row */}
								<div className="d-flex flex-column flex-lg-row">

									<div className="mt-auto mb-auto col-md-5">
										<p className=" m-0 f-0-8 fw-bold"><i class="las la-pencil-alt  f-0-9"></i> Skillset</p>
									</div>
									<div className="mt-auto mb-auto">
										<p className=" m-0 f-0-8 text-break">{ReadMore(tj.skill_set, 55)}</p>
									</div>
								</div>
								{/* row */}
								<hr/>
								{/* row */}
								<div className="d-flex flex-column flex-lg-row">

									<div className="mt-auto mb-auto col-md-5">

										<p className=" m-0 f-0-8 fw-bold"><i class="las la-rupee-sign f-1-1"></i> Salary</p>
									</div>
									<div className="mt-auto mb-auto">
										<p className=" m-0 f-0-8 text-break">{tj.ctc_from} - {tj.ctc_to}  L.P.A</p>
									</div>
								</div>
								{/* row */}
								<hr/>
								{/* row */}
								<div className="d-flex flex-column flex-lg-row">

									<div className="mt-auto mb-auto col-md-6">
										<p className=" m-0 f-0-8 fw-bold"><i class="las la-user-check f-1-1"></i> Vacancies</p>
									</div>
									<div className="mt-auto mb-auto">
										<p className=" m-0 f-0-8 text-break">{tj.number_of_vaccancy}</p>
									</div>
								</div>
								{/* row */}


							</div>
						</div>
						<div className="card-footer bg-transparent border-0">
							{/* row */}
							{(!isRecruiter() && !isCampus()) && <div className="mt-auto me-auto ms-auto w-100 ">
								<NavLink to={`/job/${tj.id}/${convertToSlug(tj.job_title)}`} className="btn btn-primary w-100 ">
									View Details
								</NavLink>
							</div>}
							{isCampus() && <div className="mt-auto me-auto ms-auto w-100 ">
								<NavLink to={`/job/${tj.id}/${convertToSlug(tj.job_title)}`} className="btn btn-primary w-100 ">
									View Details
								</NavLink>
							</div>}
							{/* row */}

						</div>
					</div>
					{/* Cards */}
				</div >
			}

			);

		return (

			<div className="container pt-4 pb-4 px-4 rounded-4 overflow-hidden" >
				<div className="row ">
					<div className="col-12 ">
						<div className="position-relative">

							<img src={('/assets/imgs/company-header.png')} className='img-fluid rounded-4 h-r' alt="" />
							<div className="position-absolute" style={{ left: '30px', bottom: '40px' }}>
								<h2 className='text-white'>Current Openings</h2>
							</div>
						</div>
					</div>
				</div>
				<div className="row">
					<div className="col-md-12">
						<div className="row">
							{topjobs}
						</div>
						{this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}
						{this.state.no_data && <div className="container"><div className="center"><p className='mt-3 mx-auto h5'>There are currently no openings</p></div></div>}
					</div>
				</div>
			</div>
		);

	}


}

const mapStateToProps = (state) => {
	const { jobsData } = state.common
	return {
		jobsData
	}

};
function mapDispatchToProps(dispatch) {
	return {
		getAllJobs: (obj) => dispatch(getAllJobs(obj)),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(CompanyPage);