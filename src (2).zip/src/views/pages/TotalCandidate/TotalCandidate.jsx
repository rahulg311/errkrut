import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
class TotalCandidate extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="">
         <div className="container">
                  <div className="row mt-3 mb-4">
                     <div className="col-md-7  col-12">
                        <h3 className="text-primary mt-3 mb-2 f-Poppins-Medium ms-4 ">Total Candidates</h3>
                     </div>
                     <div className="col-md-5  mt-2">
                        <select class="p-1 text-primary ms-1  " aria-label="Default select example">
                           <option selected>ALL JOB</option>
                           <option value="1">One</option>
                           <option value="2">Two</option>
                           <option value="3">Three</option>
                        </select>
                        <select class="p-1 text-primary ms-1  " aria-label="Default select example">
                           <option selected>ALL</option>
                           <option value="1">One</option>
                           <option value="2">Two</option>
                           <option value="3">Three</option>
                        </select>
                      
                        <button type="button" class="btn btn-primary ps-4 pe-4 pt-1 pb-1 ms-1 m-2  ">Fliter</button>
                     </div>
                     <div className="border-blue1  "></div>
                  </div>

                  <div className=" shadow ">
                     <div className="container ">
                        <div className="row p-2">
                           <div className="col-md-11 col-10">
                              <header className='d-flex '>
                                 <div className='me-3 mt-2'>
                                    <img
                                       src='/assets/imgs/dummy-logo.png'
                                       className='img-fluid box-shadow br-5 h-60p'
                                       />
                                 </div>
                                 <div>
                                    <h4  className='font-bold mb-1 mt-2 f-Poppins-Medium'>Sam Doe</h4>
                                    <p className="f-Poppins-Regular f-1-1">Current Designation
</p>
                                 </div>
                              </header>
                           </div>
                           <div className="col-md-1 col-2">
                              <div class="form-check">
                                 <input class="form-check-input p-2" type="checkbox" value="" id="flexCheckDefault"/>
                              </div>
                           </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h6 className="text-primary">Applied For : UI/UX Designer
</h6>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12 col-12 d-flex mt-2">
                                <p className="text-primary pe-2 f-Poppins-Regular">Portfolio
</p><p className="text-primary f-Poppins-Regular">SamDoe.pdf
</p>
                            </div>
                        </div>
                        <div className="row w-80 w-100-xs mt-1 ">
                           <div className="col-md-4 col-12 d-flex">
                              <i class='las la-briefcase  text-sky-blue f-1-4 pe-1 '/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium   f-1 me-2">Experience</span><span className=" f-Poppins-Light font-bold f-0-8   ">0-5 Year</span> </p>
                           </div>
                           <div className="col-md-4  col-12 d-flex">
                              <i class='las la-map-marker   text-sky-blue f-1-4 '/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium   f-1 me-2">Locations</span><span className="f-Poppins-Light font-bold ">Bengalurur</span> </p>
                           </div>
                           <div className="col-md-4   col-12 d-flex">
                              <i class='las la-rupee-sign  text-sky-blue f-1-4 1'/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium  f-1 me-2">Salary</span><span className="f-Poppins-Light font-bold ">Not Disclosed</span> </p>
                           </div>
                        </div>
                        <div className="row mt-1">
                           <div className="col-md-12 col-12 d-flex ">
                              <i class='las la-briefcase  text-sky-blue f-1-4  pe-1'/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light font-bold ">Adobe XD, Photoshop, Illustrator, Prototyping, Interaction design</span> </p>
                           </div>
                        </div>
                        <div className="row mt-1">
                           <div className="col-md-3 col-12 d-flex ">
                              <i class='las la-user-check  text-sky-blue f-1-4  pe-1'/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium  f-1 me-2">Vacancy</span><span className="f-Poppins-Light font-bold ">8</span> </p>
                           </div>
                           <div className="col-md-4 col-12 d-flex ">
                              <i class='las la-briefcase  text-sky-blue f-1-4  pe-1'/>
                              <p className=" f-0-8    "><span  className="text-primary f-Poppins-Medium  f-1 me-2">Skill Set</span><span className="f-Poppins-Light font-bold ">8</span> </p>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 p-0">
                              <div className="bg-whitept-3 pb-3 px-3 br-5">
                                 <div className="row">
                                    <div className="col-md-12 mt-1">
                                       <span class="badge badge-default cursor me-1 f-Poppins-Medium">UI</span>
                                       <span class="badge badge-default cursor me-1 f-Poppins-Medium">UX</span>
                                       <span class="badge badge-default cursor me-1 ms-2 f-Poppins-Medium">User Flow</span>
                                       <span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Design</span>
                                       <span class="badge badge-default cursor me-1   f-Poppins-Medium">User Interface Design</span>
                                       <span class="badge badge-default cursor me-1  ms-3 f-Poppins-Medium">UI/UX Product Design</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div className="row ">
                           <div className="col-md-10">
                              <section className='d-flex justify-content-between mt-1'>
                                 <div className='d-flex align-items-center mb-md-0'>
                                    <div className='d-flex align-items-center'>
                                       <img src='/assets/imgs/fire.png' />
                                    </div>
                                    <small className='ps-2 f-1'> Posted 3 days ago</small>
                                 </div>
                              </section>
                           </div>
                           <div className="col-md-2  col-12 ">
                              <h6 className="text-primary  text-center mt-2"> View Details</h6>
                           </div>
                        </div>
                        <div className="thin mt-2 mb-4"></div>
                        <div className="row mb-2">
                           <div className="col-md-8 col-12 d-flex mb-2 ">
                           <button type="button" class="btn bg-red btn-danger ps-4 pe-4">Reject</button>
                           </div>
                           <div className="col-md-4  col-12 ">
                           <button type="button" class="btn btn-outline-primary me-1  float-start">Save Profile</button>
                              <button type="button" class="btn btn-primary float-end">Call interview </button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default TotalCandidate;