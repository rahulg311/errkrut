import React, { useState, useEffect } from 'react';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import Company from '../../../components/Contact/Company';
import Option from '../../../components/Cart/Option';
import { Link, NavLink } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import { getLoggedInUser, getAuthToken } from '../../../classes';
import { Recruiter_User_Type_ID, Candidate_User_Type_ID, Campus_User_Type_ID } from '../../../config/constants';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';
import SideBar from '../../../components/hoc/SideBar';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import { ADD_BILLING_DETAILS, END_POINT, DELETE_BILLING, APPLY_COUPON } from '../../../routes/api_routes';
import { notification } from '../../../classes/messages';
import { routePushed } from '../../../classes/browserHistory';
const CheckOut = (props) => {
	let [address, setAddress] = useState([]);
	let [coupon, setcoupon] = useState("");
	let [couponstatus, setcouponstatus] = useState("");
	let [discount, setdiscount] = useState({ "discount": "0%", "amount": 0 });
	let [user, setuser] = useState([]);
	let [totalPrice, setTotalPrice] = useState(0);
	let [plan, setPlan] = useState({});
	const [isSelected, setisSelected] = useState(null);
	const [selectedAddress, setSelectedAddress] = useState(null);
	const history = useHistory();
	useEffect(async () => {
		const user = await getLoggedInUser();
		setuser(user);
		const localPlan = JSON.parse(localStorage.getItem('PLAN'));
		const totalPrice = localStorage.getItem('PLAN_TOTAL_PRICE');
		setTotalPrice(totalPrice);
		setPlan(localPlan);
		const newAddress = JSON.parse(localStorage.getItem('BILLING-ADRESS'));
		if (newAddress) {
			setAddress(newAddress);
			selectAddress(newAddress[0])
		}
	}, []);

	const proceedToPayment = async (e) => {

		if (selectedAddress) {
			let formdata = new FormData();
			formdata.append('billing_id', selectedAddress.id);
			formdata.append('selected_plan_id', plan?.id);
			formdata.append('amount', totalPrice - discount.amount);
			let token = await getAuthToken();

			var requestOptions = {
				method: 'POST',
				body: formdata,
				redirect: 'follow',
				headers: {
					'Authorization': 'Bearer ' + token
				}
			};

			fetch(END_POINT + ADD_BILLING_DETAILS, requestOptions)
				.then((response) => response.json())
				.then((data) => {
					if (data.status == 'success') {
						localStorage.setItem('SELECTED-BILLING-ADDRESS', JSON.stringify(selectedAddress));
						localStorage.setItem('SELECTED-GST-Details', JSON.stringify(data.data.gsts));
						localStorage.setItem('SELECTED-Discount', JSON.stringify(discount));
						if (user.user_type == Recruiter_User_Type_ID) {
							history.push('/payment-information');
						}
						else if (user.user_type == Candidate_User_Type_ID) {
							history.push('/payment');
						} else if (user.user_type == Campus_User_Type_ID) {
							history.push('/campus-payment-information');
						}
					} else {
						data.message.forEach((e) => {
							const notify = notification({ message: e, type: 'error' });
							notify();
						});
					}
				})
				.catch((error) => { });
		}

	}
	const deleteaddress = async (id) => {
		let user = await getLoggedInUser();
		let token = await getAuthToken();
		var formdata = new FormData();
		formdata.append('user_id', user.id);
		formdata.append('id', id);
		const response = await fetch(END_POINT + DELETE_BILLING, {
			method: 'POST',
			body: formdata,
			headers: { 'Authorization': 'Bearer ' + token },
		});
		const json = await response.json();
		if (json?.status == 'success') {
			let notify = notification({ type: 'success', message: "Address Deleted Successfully" });
			notify();
			let oldStorageData = JSON.parse(localStorage.getItem('BILLING-ADRESS'));
			let index = oldStorageData ? oldStorageData.findIndex(p => p.id == id) : -1;
			if (index >= 0) {
				oldStorageData.splice(index, 1);
				localStorage.setItem('BILLING-ADRESS', JSON.stringify([...oldStorageData]))
				setAddress(oldStorageData);
			}
		}
	}

	const selectAddress = (address) => {
		if (address) {
			setSelectedAddress(address);
			setisSelected(address.id);
		}

	}

	const applycoupon = async (e) => {
		let user = await getLoggedInUser();
		let token = await getAuthToken();
		var formdata = new FormData();
		formdata.append('user_id', user.id);
		formdata.append('coupon', coupon);
		formdata.append('amount', totalPrice);
		const response = await fetch(END_POINT + APPLY_COUPON, {
			method: 'POST',
			body: formdata,
			headers: { 'Authorization': 'Bearer ' + token },
		});
		const json = await response.json();
		if (json?.status == 'success') {
			setcouponstatus({ "status": 1, msg: "You get " + json?.message.discount + " Discount" });
			setdiscount({ "discount": json?.message.discount, "amount": totalPrice - parseFloat(json?.message.amount.replace(/,/g, '')) });
		}
		else {
			setcouponstatus({ "status": 0, msg: json?.message });
		}
	}

	return (
		<Section>
			<Main>
				<section className='bg-white py-2 rounded-3'>
					<h4>Billing Details</h4>
					<section className='row my-4'>
						{address.length >= 1 &&
							address.map((address, i) => {
								let odd = i % 2 === 0;
								return (
									<div className={`col-md-5 col-12 mb-3 p-3 me-2 cursor  rounded ${isSelected == address.id ? 'bg-primary text-white' : 'border border-primary'
										}`} onClick={(e) => { selectAddress(address) }}>
										<div>
											<div className='d-flex mb-2 justify-content-between align-items-center'>
												<h5 className='d-flex justify-content-between'>Address {i + 1}</h5>

												<div>
													<Link
														to={user.user_type != Candidate_User_Type_ID ? (user.user_type != Campus_User_Type_ID ? '/billing-details/' + address.id : '/billing-detail/' + address.id) : '/billing-detail/' + address.id}
														className={`btn btn-sm ${odd ? 'text-light' : 'text-dark'}`}
													>
														<i class='las la-edit h3'></i>
													</Link>
													<button className={`btn btn-sm ${odd ? 'text-light' : 'text-dark'}`} onClick={() => { deleteaddress(address.id) }}>
														<i class='far float-end la-trash h6' ></i>
													</button>
												</div>
											</div>
											{
												user.user_type !== Candidate_User_Type_ID && (<p className='my-2'>
													<span className='fw-bold'>Company Name:</span> {address.company_name}
												</p>)
											}

											<p>
												<span className='fw-bold'>Address:</span> {address.address_line1}
											</p>
											<p>
												<span className='fw-bold'>Phone:</span> {address.phone_number}
											</p>
										</div>
									</div>
								);
							})}

						<div class="new2 mt-3 mb-2 "></div>

						<div className='col-md-5 col-12 mb-3 mt-1 d-flex cursor' onClick={(e) => { routePushed((user.user_type === Candidate_User_Type_ID ? '/billing-detail' : user.user_type === Campus_User_Type_ID ? '/campus-billing-details' : '/billing-details'), props) }}>
							<h5 className='text-primary'>Add New Address +</h5>
						</div>
					</section>
				</section>
				<section className='mt-5 rounded-3'>
					<h4 className='d-flex justify-content-between  mb-4'>Your Order</h4>
					<div className='d-flex justify-content-between mb-1'>
						<p>{plan?.name} Plan</p>
						<p>&#8377; {plan?.price}</p>
					</div>
					<div className='d-flex justify-content-between mb-1'>
						<p>Expansion Pack</p>
						<p>&#8377; 0</p>
					</div>
					<div className='d-flex justify-content-between mb-1'>
						<div className='col-md-12 d-flex'>
							<input className='col-md-10 coupon input-border' type="text" onChange={(e) => setcoupon(e.target.value)} placeholder='Coupon Code' />
							<button onClick={applycoupon} className='col-md-2 btn btn-primary px-5'>Apply</button>
						</div>
					</div>
					<div className='d-flex justify-content-between mb-1'>
						<p className={couponstatus.status ? 'text-success' : 'text-danger'}>{couponstatus.msg}</p>
					</div>
					<div class="new2 mt-3 mb-2 "></div>
					<div className='d-flex justify-content-between'>
						<p>Sub total</p>
						<p>&#8377; {totalPrice}</p>
					</div>
					<div className='d-flex justify-content-between'>
						<p>Promocode Discount {discount.discount}</p>
						<p>&#8377; {discount.amount}</p>
					</div>
					<div class="new2 mt-3 mb-2 "></div>
					<div className='d-flex justify-content-between fw-bolder'>
						<h5>Total</h5>
						<h5>&#8377; {totalPrice - discount.amount} </h5>
					</div>
					<div class="new2 mt-3 mb-2 "></div>
					<div className='d-flex'>
						<div className='col-md-6'>
							<h6>Payment Method</h6>
							<img width="150px" src="./assets/imgs/paytm.png" />
						</div>
						<div class='col-md-6 text-end mt-5'>
							<button onClick={(e) => proceedToPayment(e)} class='btn btn-primary px-5' disabled={(isSelected == null) ? true : false}>
								Proceed to Payment
							</button>
						</div>
					</div>
				</section>
			</Main>
			<SideBar>
				<ProfileName></ProfileName>
				<ActionButtons />
				<Company></Company>
			</SideBar>
		</Section>
	);
};

export default CheckOut;
