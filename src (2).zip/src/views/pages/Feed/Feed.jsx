import React, { Component } from 'react';
import CompaniesCard from '../../../components/Cards/CompaniesCard';
import TopCompaniesCard from '../../../components/Cards/TopCompaniesCard';
import TopJobsCard from '../../../components/Cards/TopJobsCard';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Search from '../../../components/Search';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import JobsList from '../../../components/Cards/JobsList';

import { getJobs } from '../../../store/actions/jobs';
import { connect } from "react-redux";
import { isLoggedIn, isRecruiter, isCampus } from '../../../classes';
import SideBar from '../../../components/hoc/SideBar';
import Loading from '../../../components/common/Loading';


class Feed extends Component {

	state = {
		jobs: [],
		page_num: 1,
		limit_page: 5,
		loader: false,
		no_data: false
	}

	async componentWillMount() {
		this.getTopJobs();
		/* if recruiter */
		if (isRecruiter())
			this.props.history.push('/recruiter');
		/* if recruiter */
		/* if recruiter */
		if (isCampus())
			this.props.history.push('/campus');
		/* if recruiter */
	}


	/* get top jobs */
	getTopJobs = async () => {

		let obj = {};
		obj['page_num'] = this.state.page_num;
		obj['limit_page'] = this.state.limit_page;

		this.setState({
			loader: true
		});

		await this.props.getJobs(obj);

		if (this.props.data) {
			this.setState(prevState => ({
				loader: false,
				jobs: [...prevState.jobs, ...this.props.data?.data],
			}));
		}

	}

	/* load more */
	loadMore = () => {
		let page = this.state.page_num;
		this.setState({
			page_num: page + 1
		}, () => {
			this.getTopJobs();
		});
	}

	render() {
		return (
			<div className='container'>
				<div className='row gx-5 gy-5'>
					<section className='col-lg-9'>
						<div>
							<div>
								<TopCompaniesCard></TopCompaniesCard>
							</div>
							<div className='mt-4'>
								<TopJobsCard></TopJobsCard>
							</div>

							{isLoggedIn() && 
							<div className='bg-white pt-4 pb-4 px-4 mt-4 rounded-4'>

								<JobsList title='Recommended Jobs' jobs={this.state.jobs} />

								{/* load more */}

								{this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}

								{(this.state.no_data == false && this.state.jobs.length > 0) &&
									<button className="btn btn-primary btn-sm d-block me-auto ms-auto mt-2 mb-2" onClick={() => { this.loadMore() }}>
										<i class="las la-angle-double-down"></i> Load More
									</button>
								}

								{(this.state.jobs.length == 0) &&
									<p className="text-primary text-center">No Jobs Fouond</p>
								}

								{/* load more */}
							</div>}

							<div className='mt-4'>
								<CompaniesCard></CompaniesCard>
							</div>
							<Search />
						</div>
					</section>
					<SideBar>
						<ProfileName />
						<CandidateCards hello={{ hello: 'yes' }}></CandidateCards>
						<Skills></Skills>
						<FeaturedCompanies></FeaturedCompanies>
						<Designations />
						<Locations />
						<Company></Company>
					</SideBar>
				</div>
			</div>
		);
	}
}


const mapStateToProps = (state) => {
	//console.log(state);
	const { data } = state.common
	return {
		data
	}
};

function mapDispatchToProps(dispatch) {
	return {
		getJobs: (obj) => dispatch(getJobs(obj)),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(Feed);
