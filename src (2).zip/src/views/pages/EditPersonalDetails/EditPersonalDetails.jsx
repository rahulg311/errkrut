import React, { Component } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
class EditCompanyProfile extends Component {
// Handle fields change
handleChange = (e) => {
}
render() {
return (
<div className="container">
   <div className="row">
      <div className="col-md-9 p-0">
         <div className="p-4">
            <div className="bg-white p-4 mb-4">
               <div>
                  <h5 className="f-Poppins-Medium m-2">Edit Personal Details</h5>
                  <div className="border-gray-line mt-2 mb-2"></div>
                  {/*
                  <div className="row">
                     <div className="col-md-10 col-9">
                        <p className="f-Poppins-Medium">Upload Company Logo</p>
                     </div>
                     <div className="col-md-2 col-3 d-flex align-items-center">
                        <p className="f-Poppins-Medium text-primary ">Upload</p>
                        <i class="las la-upload ms-1 text-sky-blue f-1-1"></i>
                     </div>
                  </div>
                  */}
                  <div className="w-90 w-xs-100">
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className=" text-primary mt-2">
                           Name
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="gupta g"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2">
                           Designation
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="UX Designer"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2 ">
                           E mail
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="gupta@gmail.com"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2">
                           Phone Number
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="+919670888935"
                              />
                        </div>
                     </div>
                     <div className="row mt-2 mb-2">
                        <div className="col-md-6">
                           <label className="mt-2 ">
                           Experience
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='text'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="3 year"
                              />
                        </div>
                        <div className="col-md-6">
                           <label className="mt-2">
                           Salary (in lakhs per annum)
                           </label>
                           <input
                              type='text'
                              className='form-control input-border'
                              onKeyUp={this.handleChange}
                              name='email'
                              validateType='emailormobile'
                              validateMsg='Please Enter Correct Email or Mobile'
                              placeholder="7 lpa"
                              />
                        </div>
                     </div>
                     {/* submit button */}
                     <div className="row mt-2 mb-2">
                        <div className="col-md-10  col-8">
                           <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                        </div>
                        <div className="col-md-2 col-4">
                           <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                        </div>
                     </div>
                     {/* submit button */}
                  </div>
               </div>
               {/*
               <div className="bg-white p-4 mt-4">
                  <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-4 mb-4"></div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className=" text-primary mt-2">
                        Address line 1
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Address line 1"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2">
                        Address line 2
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Enter your Address line 2"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className="mt-2 ">
                        Country
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Country"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2">
                        State
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your State"
                           />
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-6">
                        <label className="mt-2">
                        Town/City
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='text'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Town/City"
                           />
                     </div>
                     <div className="col-md-6">
                        <label className="mt-2">
                        Postcode/ZIP
                        </label>
                        <input
                           type='text'
                           className='form-control input-border'
                           onKeyUp={this.handleChange}
                           name='email'
                           validateType='emailormobile'
                           validateMsg='Please Enter Correct Email or Mobile'
                           placeholder="Select your Postcode/ZIP"
                           />
                     </div>
                  </div>
                  <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-2"></div>
                  <div className="row">
                     <div className="col-md-12">
                        <label className="mt-2">
                        Company Summary
                        </label>
                        <textarea className="w-100 h-100p">
                        ( 500 words )
                        </textarea>
                     </div>
                  </div>
                  <div className="row mt-2 mb-2">
                     <div className="col-md-10  col-8">
                        <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                     </div>
                     <div className="col-md-2 col-4">
                        <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                     </div>
                  </div>
               </div>
               */}
               {/* submit button */}
               {/* start Edit hr profile  */}
               <div className="bg-white mt-5 w-xs-100 w-90">
                  <div>
                     <h5 className="f-Poppins-Medium m-2 ">Summary</h5>
                     <div className="border-gray-line mt-2 mb-2"></div>
                     <div className="row">
                        <div className="col-md-12">
                           <label className="mt-2 text-primary">
                           Summary
                           </label>
                           <textarea className="w-100 h-100p p-2">
                           Say Something About yourself
                           </textarea>
                        </div>
                        <div className="row mt-2 mb-2 ">
                           <div className="col-md-12">
                              <h6>Key Skills</h6>
                              <p className="f-Poppins-Light mt-1 f-0-9 p-0">Select atleast 3 key skills so we can help you match your profile</p>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 border-gray-line ms-2">
                              <div className="mt-1 mb-1 ">
                                 <span class="badge badge-default cursor me-1 bg-primary text-white">UI</span> <span class="badge badge-default cursor me-1 bg-primary text-white">UX</span> <span class="badge badge-default cursor me-1 bg-primary text-white">User Flow</span>
                              </div>
                           </div>
                        </div>
                        <div className="row mt-2 mb-2 ">
                           <div className="col-md-12">
                              <h6>Software Skill</h6>
                              <p className="f-Poppins-Light mt-1 f-0-9 p-0">Select atleast 3 Software Skills so we can help you match your profile</p>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 border-gray-line ms-2">
                              <div className="mt-1 mb-1 ">
                                 <span class="badge badge-default cursor me-1 bg-primary text-white">UI</span> <span class="badge badge-default cursor me-1 bg-primary text-white">UX</span> <span class="badge badge-default cursor me-1 bg-primary text-white">User Flow</span>
                              </div>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 ">
                              <div className="mt-1 mb-1 ">
                                 <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                 <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">User Interface Design</span> <span class="badge badge-default cursor me-1">UI/UX Product design</span>
                              </div>
                           </div>
                        </div>
                        <div className="row">
                           <div className="col-md-12 ">
                              <div className="mt-1 mb-1 ">
                                 <span class="badge badge-default cursor me-1">UI</span> <span class="badge badge-default cursor me-1">UX</span> <span class="badge badge-default cursor me-1">User Flow</span>
                                 <span class="badge badge-default cursor me-1">UI/UX Designer</span> <span class="badge badge-default cursor me-1">User Interface Design</span> <span class="badge badge-default cursor me-1">UI/UX Product design</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     {/* submit button */}
                     <div className="row mt-2 mb-2">
                        <div className="col-md-10  col-8">
                           <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                        </div>
                        <div className="col-md-2 col-4">
                           <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                        </div>
                     </div>
                     {/* submit button */}
                  </div>
               </div>
               {/* end Edit hr profile  */}
               {/* start Edit hiring sector */}
               <div className="bg-white  mt-4">
                  <div>
                     <h5 className="f-Poppins-Medium m-2">Edit Career Profile</h5>
                     <div className="border-gray-line mt-2 mb-2"></div>
                     <div>
                        <div className="w-90 w-xs-100">
                           <div className="row">
                              <div className="col-md-10 col-10">
                                 <h6 >Attach Resume</h6>
                                 <p className="pt-2">Upload your resume for a better chance of recruiters noticing you</p>
                              </div>
                              <div className="col-md-2 col-2">
                                 <p className="text-primary">Upload <i class="las la-file-import"></i></p>
                              </div>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                           <div className="row">
                              <div className="col-md-10 col-10">
                                 <h6 >Attach Resume</h6>
                                 <p className="pt-2">Upload your resume for a better chance of recruiters noticing you</p>
                              </div>
                              <div className="col-md-2 col-2">
                                 <p className="text-primary">Upload <i class="las la-file-import"></i></p>
                              </div>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                           <div className="row">
                              <div className="col-md-10 col-10">
                                 <h6 >Attach Portfolio</h6>
                                 <p className="pt-2">Upload your resume for a better chance of recruiters noticing you</p>
                              </div>
                              <div className="col-md-2 col-2">
                                 <p className="text-primary">Upload <i class="las la-file-import"></i></p>
                              </div>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                           <div className="row">
                              <div className="col-md-10 col-10">
                                 <h6 >Attach Publications</h6>
                                 <p className="pt-2">Upload your resume for a better chance of recruiters noticing you</p>
                              </div>
                              <div className="col-md-2 col-2">
                                 <p className="text-primary">Upload <i class="las la-file-import"></i></p>
                              </div>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                           <div className="row">
                              <div className="col-md-10 col-10">
                                 <h6 >Attach Certificates</h6>
                                 <p className="pt-2">Upload your resume for a better chance of recruiters noticing you</p>
                              </div>
                              <div className="col-md-2 col-2">
                                 <p className="text-primary">Upload <i class="las la-file-import"></i></p>
                              </div>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-1 mb-1"></div>
                           <div>
                              <form>
                                 <div class="form-group">
                                    <label>Linked Profiles</label>
                                    <div class="input-group"> <input type="text" class="ms-2 form-control coupon" name="" placeholder="Link your profile"/> <span class="input-group-append"> <button className="btn ms-2 btn-primary btn-apply coupon">Add</button> </span> </div>
                                 </div>
                              </form>
                           </div>
                           <div className="border-solid border-bottom-0 border-right-0 border-left-0 border-color-blue mt-2 mb-4"></div>
                        </div>
                        <div className="w-90 mt-5 w-xs-100">
                           <div>
                              <h5 className="f-Poppins-Medium m-2">Add or Edit Employment</h5>
                              <div className="border-gray-line mt-2 mb-2"></div>
                              <div className="row">
                                 <div className="col-md-10 col-9">
                                    <p className="f-Poppins-Medium">Current Company</p>
                                 </div>
                                 <div className="col-md-2 col-3 d-flex align-items-center">
                                    <p className="f-Poppins-Medium text-primary ">Upload</p>
                                    <i class="las la-upload ms-1 text-sky-blue f-1-1"></i>
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className=" text-primary mt-2">
                                    Company Name
                                    </label>
                                    <input
                                       type='text'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Enter your Company Name"
                                       />
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Designation
                                    </label>
                                    <input
                                       type='text'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="UX Designer"
                                       />
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className="mt-2 ">
                                    Joining Date
                                    </label>
                                    <input
                                       type='date'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Select Joining Date
                                       "
                                       />
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Leaving Date
                                    </label>
                                    <input
                                       type='date'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Select Leaving Date
                                       "
                                       />
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className="mt-2 ">
                                    Select Notice Period
                                    </label>
                                    <input
                                       type='date'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='text'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Select Joining Date
                                       "
                                       />
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Curent Salary (in lakhs per annum)
                                    </label>
                                    <input
                                       type='text'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Select Leaving Date
                                       "
                                       />
                                 </div>
                                 <div className="row w-100 p-0 m-0">
                                    <div className="col-md-12">
                                       <label className="mt-2 text-primary">
                                       Job Profile (500 words)
                                       </label>
                                       <textarea className="w-100 h-100p p-2">
                                       Give a brief on your job profile
                                       </textarea>
                                    </div>
                                 </div>
                                 {/* ADD BUTTON  */}
                                 <div className="row p-0 m-0">
                                    <div className="col-md-12">
                                       <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                          <button class="btn btn-primary me-md-2 mt-2" type="button">Add</button>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="container shadow m-2 mt-5">
                                    <div className="row ">
                                       <div className="col-md-10 col-10  mt-2 mb-2">
                                          <header className='d-flex'>
                                             <div className='me-3'>
                                                <img
                                                   src='/assets/imgs/dummy-logo.png'
                                                   className='img-fluid box-shadow br-5 h-60p'
                                                   />
                                             </div>
                                             <div>
                                                <h5 className='font-bold '>Designation</h5>
                                                <p>Company Name</p>
                                                <p>June 2017 to June 2019</p>
                                             </div>
                                          </header>
                                       </div>
                                       <div className="col-md-2 col-2 mt-2" >
                                          <h4><i class="lar la-edit text-primary"></i></h4>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="container shadow m-2 mt-5">
                                    <div className="row ">
                                       <div className="col-md-10 col-10  mt-2 mb-2">
                                          <header className='d-flex'>
                                             <div className='me-3'>
                                                <img
                                                   src='/assets/imgs/dummy-logo.png'
                                                   className='img-fluid box-shadow br-5 h-60p'
                                                   />
                                             </div>
                                             <div>
                                                <h5 className='font-bold '>Designation</h5>
                                                <p>Company Name</p>
                                                <p>June 2017 to June 2019</p>
                                             </div>
                                          </header>
                                       </div>
                                       <div className="col-md-2 col-2 mt-2" >
                                          <h4><i class="lar la-edit text-primary"></i></h4>
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row mt-2 mb-2">
                                    <div className="col-md-10  col-8">
                                       <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                                    </div>
                                    <div className="col-md-2 col-4">
                                       <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                                    </div>
                                 </div>
                              </div>
                              <div>
                                 <h5 className="f-Poppins-Medium m-2">Add or Edit Employment</h5>
                                 <div className="border-gray-line mt-2 mb-2"></div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Education Level
                                    </label>
                                    <select class="form-select mt-2 " aria-label="Default select example">
                                       <option selected>Select Education Level</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                       <option value="3">Three</option>
                                    </select>
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Select Education Level
                                    </label>
                                    <select class="form-select mt-2 " aria-label="Default select example">
                                       <option selected>Select Course</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                       <option value="3">Three</option>
                                    </select>
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className="mt-2 ">
                                    Specialization
                                    </label>
                                    <select class="form-select mt-2 " aria-label="Default select example">
                                       <option selected>Select Specialization</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                       <option value="3">Three</option>
                                    </select>
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    University/Institute
                                    </label>
                                    <select class="form-select mt-2 " aria-label="Default select example">
                                       <option selected>Select Specialization</option>
                                       <option value="1">One</option>
                                       <option value="2">Two</option>
                                       <option value="3">Three</option>
                                    </select>
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Select University/Institute
                                    </label>
                                    <input
                                       type='text'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='text'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Enter Year of Passing"
                                       />
                                 </div>
                                 <div className="col-md-6">
                                    <label className="mt-2">
                                    Grades
                                    </label>
                                    <input
                                       type='text'
                                       className='form-control input-border'
                                       onKeyUp={this.handleChange}
                                       name='email'
                                       validateType='emailormobile'
                                       validateMsg='Please Enter Correct Email or Mobile'
                                       placeholder="Enter Grades
                                       "
                                       />
                                 </div>
                              </div>
                              <div className="row">
                                 <div className="col-md-12">
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                       <button class="btn btn-primary me-md-2 mt-2" type="button">Add</button>
                                    </div>
                                 </div>
                              </div>
                              <div className="container shadow  mt-5">
                                 <div className="row ">
                                    <div className="col-md-10 col-10  mt-2 mb-2">
                                       <header className='d-flex'>
                                          <div className='me-3'>
                                             <img
                                                src='/assets/imgs/dummy-logo.png'
                                                className='img-fluid box-shadow br-5 h-60p'
                                                />
                                          </div>
                                          <div>
                                             <h5 className='font-bold '>Designation</h5>
                                             <p>Company Name</p>
                                             <p>June 2017 to June 2019</p>
                                          </div>
                                       </header>
                                    </div>
                                    <div className="col-md-2 col-2 mt-2" >
                                       <h4><i class="lar la-edit text-primary"></i></h4>
                                    </div>
                                 </div>
                              </div>
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-10  col-8">
                                    <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                                 </div>
                                 <div className="col-md-2 col-4">
                                    <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                                 </div>
                              </div>
                              <div className="mt-5" >
                                 <div className="row">
                                    <div className="col-md-12">
                                       <h4>Language</h4>
                                       <select class="form-select mt-2 " aria-label="Default select example">
                                          <option selected>Open this select menu</option>
                                          <option value="1">One</option>
                                          <option value="2">Two</option>
                                          <option value="3">Three</option>
                                       </select>
                                    </div>
                                 </div>
                                 <div className="row mt-2 ">
                                    <div className="col-md-11 col-10">
                                       <h6>Read</h6>
                                    </div>
                                    <div className="col-md-1 col-2">
                                       <div class="form-check form-switch">
                                          <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row mt-2 ">
                                    <div className="col-md-11 col-10">
                                       <h6>Write</h6>
                                    </div>
                                    <div className="col-md-1 col-2">
                                       <div class="form-check form-switch">
                                          <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row mt-2 ">
                                    <div className="col-md-11 col-10">
                                       <h6>Speak</h6>
                                    </div>
                                    <div className="col-md-1 col-2">
                                       <div class="form-check form-switch">
                                          <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                                       </div>
                                    </div>
                                 </div>
                                 <div className="row">
                                    <div className="col-md-3">
                                       <div className="cards position-relative   bg-blue br-5 text-white h-90px mt-2 ">
                                          <p className="f-Poppins-Regular  text-center pt-1 ps-2  f-0-9">Functional Areas</p>
                                          <h1 className="text-center">a</h1>
                                          <p className="f-Poppins-Light pb-1 ps-2  mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                       </div>
                                    </div>
                                    <div className="col-md-3">
                                       <div className="cards position-relative   bg-greenesh-blue  br-5 text-white h-90px mt-2 ">
                                          <p className="f-Poppins-Regular  pt-1 ps-2  f-0-9 text-center">
                                             Hindi
                                          </p>
                                          <h1 className="text-center">अ</h1>
                                          <p className="f-Poppins-Light pb-1 ps-2  mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                       </div>
                                    </div>
                                    <div className="col-md-3">
                                       <div className="cards position-relative  bg-dark-pink br-5 text-white h-90px mt-2 ">
                                          <p className="f-Poppins-Regular  pt-1 ps-2 text-center  f-0-9">Tamil</p>
                                          <h1 className="text-center">க</h1>
                                          <p className="f-Poppins-Light pb-1 ps-2  mt-3 f-0-9 text-center ">Read, Write, Speak</p>
                                       </div>
                                    </div>
                                    <div className="col-md-3">
                                       <div className="cards position-relative   bg-blue br-5 text-white h-90px mt-2 ">
                                          <p className="f-Poppins-Regular  pt-1 ps-2  f-0-9 text-center">Kannada</p>
                                          <h1 className="text-center">ಅ</h1>
                                          <p className="f-Poppins-Light pb-1 ps-2  mt-3 f-0-9  text-center">Read, Write, Speak</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              {/* submit button */}
                              <div className="row mt-2 mb-2">
                                 <div className="col-md-10  col-8">
                                    <button href="" className="btn btn-outline-primary ml-auto mr-auto d-block mt-2 ">Discard</button>
                                 </div>
                                 <div className="col-md-2 col-4">
                                    <button href="" className="btn btn-primary ml-auto mr-auto d-block mt-2 ">Save</button>
                                 </div>
                              </div>
                           </div>
                        </div>
                        {/* submit button */}
                     </div>
                  </div>
                  <div>
                     <div>
                     </div>
                  </div>
               </div>
            </div>
            {/* submit button */}
            {/* form ends here */}
         </div>
      </div>
      {/* sidebar */}
      <div className="col-md-3">
         <ProfileName />
         <ActionButtons />
         <Company />
      </div>
      {/* sidebar */}
   </div>
</div>
);
}
}
export default EditCompanyProfile;