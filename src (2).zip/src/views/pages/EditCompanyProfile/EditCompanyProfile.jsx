import React, { useEffect, useState } from 'react';
import Company from '../../../components/Contact/Company';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import useFetch from '../../../hooks/useFetch';
import { END_POINT } from '../../../routes/api_routes';

import SideBar from '../../../components/hoc/SideBar';
import Section from '../../../components/hoc/Section';

import MultiSelect from './MultiSelect';
import { getLoggedInUser, getAuthToken, isJson, reSetLoggedInUser, MimeIcon } from '../../../classes';
import { notification } from '../../../classes/messages';
import { Mobile_Validation_Regex } from '../../../config/constants';
import Loading from '../../../components/common/Loading';
import { Link, NavLink } from 'react-router-dom';
import CompanyMembers from '../../../components/CompanyProfile/CompanyMembers';
const EditCompanyProfile = ({ match }) => {
	const [loadingOnSubmit, setLoadingOnSubmit] = useState(false);
	const { data, loading, error, doFetch } = useFetch();
	const [multiSelectTags, setMultiSelectTags] = useState([]);
	const [user, setUser] = useState(null);

	useEffect(async () => {
		const user = await getLoggedInUser();
		setUser(user);
		doFetch(END_POINT + 'edit_profile/' + user.id);
	}, []);


	const handleMultiSelect = (values) => {
		const isInArray = multiSelectTags.some((tag) => tag.name === values.name);
		if (isInArray) {
			const newMultiSelectTags = multiSelectTags.map((tag) => {
				if (tag.name === values.name) {
					return values;
				}
				return tag;
			});
			setMultiSelectTags(newMultiSelectTags);
		} else {
			setMultiSelectTags([...multiSelectTags, values]);
		}
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		setLoadingOnSubmit(true);
		const user = await getLoggedInUser();
		const token = await getAuthToken();
		let formValid = true;

		var formdata = new FormData();
		formdata.append('user_id', user.id);

		Array.from(e.target).map((value) => {

			if (value.name == 'hr_phone') {
				if (!Mobile_Validation_Regex.test(value.value)) {
					const notify = notification({ message: 'Please Enter Valid HR Mobile Number', type: 'error' });
					notify();
					formValid = false;
				}
				else {
					formValid = true;
				}
			}


			if (value.name && value.value) {
				if (value.type != 'file') {
					formdata.append('group_id', value.id);
					formdata.append(value.name, value.value);
				}
			}

			if (value.type == 'file') {

				let fname = value.name;
				if (value.files instanceof File || value.files instanceof FileList) {

					for (let i = 0; i < value.files.length; i++) {
						if (value.files[i] instanceof File) {
							if (formdata.get(fname) == null) {
								formdata.append(fname, value.files[i]);
							}
						}


					}

				}
			}

		});

		Object.keys(multiSelectTags).map((key) => {
			const key2 = Object.keys(multiSelectTags[key])[0];
			const value = multiSelectTags[key][key2];
			const id = multiSelectTags[key]['id'];
			if (formdata.get('group_id') == null) {
				formdata.append('group_id', id);
			}
			formdata.append(key2, JSON.stringify(value));

		});

		var requestOptions = {
			method: 'POST',
			body: formdata,
			headers: {
				Authorization: 'Bearer ' + token,
			},
		};
		if (formValid) {
			fetch(END_POINT + 'update_profile', requestOptions)
				.then((response) => response.json())
				.then((result) => {

					if (result.status === 'success') {

						let usr = {};
						if (result?.logo) {
							usr['logo'] = JSON.stringify(result.logo);

							reSetLoggedInUser(usr);
						}

						const notify = notification({
							message: 'Profile updated successfully',
							type: 'success',
						});
						notify();
						setLoadingOnSubmit(false);
					} else {
						result.message.forEach((error) => {
							const notify = notification({
								message: error,
								type: 'error',
							});
							notify();
						});
						setLoadingOnSubmit(false);
					}
				})
				.catch((error) => {
					const notify = notification({
						message: 'Something went wrong',
						type: 'error',
					});
					setLoadingOnSubmit(false);
					notify();
				});
		}
		else {
			setLoadingOnSubmit(false);
		}
	};

	const removeDuplicates = (myArr, prop) => {
		return myArr.filter((obj, pos, arr) => {
			return arr.map((mapObj) => mapObj[prop]).indexOf(obj[prop]) === pos;
		});
	};

	return (
		<Section>
			<div className='col-lg-9'>
				{loading ? (
					<Loading className='center' />
				) : (
					<div className=''>


						{data != null && data?.map((item) => {


							if (item.CardTitle == 'Edit Company Profile') {

								return (
									<div className='bg-white p-4 rounded-4'>
										<form action='' onSubmit={(e) => handleSubmit(e)}>
											<div>
												<h5 className='f-Poppins-Medium mb-2'>Edit Company Profile</h5>
												<div className='row gy-2'>
													{ }
													{removeDuplicates(item.values, 'id').map((value) => {
														if (value.type == 'Textarea') {
															return (
																<div className='col-md-12 order-5'>
																	<div className='form-group'>
																		<label className='f-Poppins-Medium my-1'>
																			{value.title}
																		</label>
																		<textarea
																			name={value.name}
																			data-group_id={value.group_id}
																			className='form-control'
																			rows='3'
																			id={value.group_id}
																		>{value.value}</textarea>
																	</div>
																</div>
															);
														} else if (value.type == 'Dropdown') {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary my-1'>{value.title}</label>
																	<select
																		className='form-select'
																		name={value.name}
																		id={value.group_id}
																	>
																		{JSON.parse(value.attr_options).map((val) => {
																			return <option defaultValue={val}>{val}</option>;
																		})}
																	</select>
																</div>
															);
														} else if (value.type == 'File') {
															return (
																<>
																	<div className="d-flex">

																		<div className='col-md-6'>
																			<label className=' text-primary my-1'>{value.title}</label>
																			<input
																				type={value.type}
																				className='form-control input-border'
																				name={value.name}
																				id={value.group_id}
																			/>
																		</div>

																		{/* file icon */}
																		{value.value != '' && (typeof value.value === 'object' ||
																			!Array.isArray(value.value)) &&
																			value.value !== null && JSON.parse(value.value).map((k) => {
																				return <a href={k} target="_blank" className="font-bold me-2">
																					<p className="m-0 text-center">
																						<span className="f-4 d-block">
																							{MimeIcon(k)}
																						</span>
																						<span className="d-block">View</span>
																					</p>
																				</a>


																			})}
																		{/* file icon */}

																		{value.name?.includes('logo') == true && isJson(user?.logo) && JSON.parse(user?.logo)?.map((imgs) => {
																			return <a target="_blank" href={(imgs) ? imgs : `/assets/imgs/dummy-logo.png`}><img
																				src={(imgs) ? imgs : `/assets/imgs/dummy-logo.png`}
																				className='ms-2 box-shadow h-70px w-auto'
																			/></a>;
																		})}
																	</div>

																</>
															);
														} else {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary my-1'>{value.title}</label>
																	<input
																		type={value.type}
																		className='form-control input-border'
																		name={value.name}
																		id={value.group_id}
																		defaultValue={value.value}
																	/>
																</div>
															);
														}
													})}
												</div>
											</div>
											<div className='d-flex mt-2 mb-'>

												<div className="me-auto">
													<NavLink to="/company-profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
												</div>

												<button
													type='submit'
													className='btn btn-primary btn-sm px-5 ms-auto'
													disabled={loadingOnSubmit}
												>
													{loadingOnSubmit ? <Loading /> : 'Save'}
												</button>

											</div>
										</form>
									</div>
								);
							}

							if (item.CardTitle == 'Edit Hiring Sector') {
								return (
									<div className='bg-white p-4 mt-4 rounded-4'>
										<form action='' onSubmit={(e) => handleSubmit(e)}>
											<div className=''>
												<h5 className='f-Poppins-Medium mb-2'>Edit Hiring Sector</h5>
												<div className='row'>
													{item.values.map((value, i) => {

														if (value.type == 'MultiSelect') {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary my-1'>{value.title}</label>

																	{value.attr_options &&
																		<MultiSelect
																			options={JSON.parse(value.attr_options)}
																			handleMultiSelect={handleMultiSelect}
																			id={value.group_id}
																			selectedOptions={value.value}
																			name={value.name}
																		/>
																	}
																</div>
															);
														} else {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary mt-2'>{value.title}</label>
																	<input
																		type={value.type}
																		className='form-control input-border'
																		name={value.name}
																		id={value.group_id}
																		data-group_id={value.group_id}
																		defaultValue={value.value}
																	/>
																</div>
															);
														}
													})}
												</div>
											</div>
											<div className='d-flex mt-2 mb-'>

												<div className="me-auto">
													<NavLink to="/company-profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
												</div>

												<button
													type='submit'
													className='btn btn-primary btn-sm px-5 ms-auto'
													disabled={loadingOnSubmit}
												>
													{loadingOnSubmit ? <Loading /> : 'Save'}
												</button>

											</div>
										</form>
									</div>
								);
							}

							/* Edit HR Profile */

							if (item.CardTitle == 'Edit HR Profile') {
								return (
									<div className='bg-white p-4 mt-4 rounded-4'>
										<form action='' onSubmit={(e) => handleSubmit(e)}>
											<div className=''>
												<h5 className='f-Poppins-Medium mb-2'>{item.CardTitle}</h5>
												<div className='row'>
													{item.values.map((value, i) => {

														if (value.type == 'MultiSelect') {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary my-1'>{value.title}</label>

																	{value.attr_options &&
																		<MultiSelect
																			options={JSON.parse(value.attr_options)}
																			handleMultiSelect={handleMultiSelect}
																			id={value.group_id}
																			selectedOptions={value.value}
																			name={value.name}
																		/>
																	}
																</div>
															);
														} else if (value.type == 'Textarea') {
															if (value.title != 'HR Address') {
																return (
																	<div className='col-md-6'>
																		<label className=' text-primary mt-2'>{value.title}</label>
																		<textarea
																			className='form-control input-border'
																			name={value.name}
																			id={value.group_id}
																			data-group_id={value.group_id}
																		>{value.value}</textarea>
																	</div>
																);
															}

														} else {
															return (
																<div className='col-md-6'>
																	<label className=' text-primary mt-2'>{value.title}</label>
																	<input
																		type={value.type}
																		className='form-control input-border'
																		name={value.name}
																		id={value.group_id}
																		data-group_id={value.group_id}
																		defaultValue={value.value}
																	/>
																</div>
															);
														}
													})}
												</div>
											</div>

											<div className='d-flex mt-2 mb-'>

												<div className="me-auto">
													<NavLink to="/company-profile" className="btn btn-outline-primary btn-sm ml-auto mr-auto d-block ">Discard</NavLink>
												</div>

												<button
													type='submit'
													className='btn btn-primary btn-sm px-5 ms-auto'
													disabled={loadingOnSubmit}
												>
													{loadingOnSubmit ? <Loading /> : 'Save'}
												</button>

											</div>
										</form>
									</div>
								);
							}

						})}

						{/* Edit Members */}
						<div className='bg-white mt-4 p-4 rounded-4'>
							<CompanyMembers />
						</div>
						{/* Edit Members */}

					</div>
				)}
			</div>
			<SideBar>
				<ProfileName />
				<ActionButtons />
				<Company />
			</SideBar>
		</Section>
	);
};

export default EditCompanyProfile;
