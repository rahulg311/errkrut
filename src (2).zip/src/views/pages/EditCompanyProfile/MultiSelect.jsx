import React, { useState } from 'react';

const MultiSelect = ({ options, handleMultiSelect, name, id, selectedOptions }) => {
	const [search, setSearch] = useState('');
	const [filterItems, setFilterItems] = useState([]);
	const [items, setItems] = useState([]);
	const [selectedItems, setSelectedItems] = useState([]);

	const handleRemoveSelectedItem = (value) => {
		const filterItems = [...selectedItems].filter((e) => e !== value);
		setSelectedItems(filterItems);
	};

	const handleAddSelectedItem = (value) => {
		const filterItems = [...new Set([...selectedItems, value])];
		setSelectedItems(filterItems);
	};

	React.useEffect(() => {
		const newArray = [...items].filter((item) => item.includes(search));
		setFilterItems(newArray);
	}, [search]);

	React.useEffect(() => {

		if (options != null) {
			if (options?.length >= 1) {
				setItems(options);
			} else {
				setItems([]);
			}
		}
	}, [options]);

	React.useEffect(() => {
		selectedItems.length >= 1 &&
			handleMultiSelect({ [name]: [...selectedItems], id: id, name: name });
	}, [selectedItems]);

	React.useEffect(() => {
		if (selectedOptions) {
			const data = JSON.parse(selectedOptions);
			data?.length >= 1 && setSelectedItems(data);
		}
	}, [selectedOptions]);

	return (
		<div className='position-relative'>
			<div className='position-relative'>
				<input
					placeholder='search'
					className='form-control'
					value={search}
					onChange={(e) => setSearch(e.target.value)}
				/>
				{search && (
					<button
						type='button'
						class='btn-close translate-right-middle'
						style={{ right: '10px' }}
						onClick={() => setSearch('')}
						aria-label='Close'
					></button>
				)}
			</div>
			<main className='w-40'>
				{search && filterItems.length >= 1
					? filterItems.map((item, i) => (
						<div className='list-group '>
							<li className='list-group-item list-group-item-action'>
								<div class='form-check'>
									<input
										class='form-check-input'
										type='checkbox'
										checked={selectedItems.includes(item)}
										value={item}
										id={item}
										onChange={(e) => {
											e.target.checked
												? setSelectedItems([...selectedItems, item])
												: handleRemoveSelectedItem(e.target.value);
										}}
									/>
									<label class='form-check-label h-100 w-100' for={item}>
										{item}
									</label>
								</div>
							</li>
						</div>
					))
					: search && (
						<button
							className='btn bg-secondary bg-opacity-10 mt-1 fs-13'
							onClick={() => handleAddSelectedItem(search)}
							type="button"
						>
							create a new tag
						</button>
					)}
			</main>
			<div className='mt-2'>
				{selectedItems.map((item) => {
					return (
						<span
							class='badge mb-2 border text-dark p-1 me-1 fs-13 rounded-pill'
						>
							{item}
							<span className='cursor ps-1' onClick={() => handleRemoveSelectedItem(item)}> X </span>
						</span>
					);
				})}
			</div>
		</div>
	);
};

export default MultiSelect;
