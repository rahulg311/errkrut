import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser, MimeIcon } from '../../../classes';
import { parseArrayToHTML } from '../../../classes/handleHtml';
import { notification } from '../../../classes/messages';
import Loading from '../../../components/common/Loading';
import { changePassword } from '../../../store/actions/password';
import { connect } from 'react-redux';
import ProfileName from '../../../components/Sidebars/Candidate/ProfileName';
import SideBar from '../../../components/hoc/SideBar';
import CandidateCards from '../../../components/Sidebars/Candidate/CandidateCards';
import Skills from '../../../components/Sidebars/Candidate/Skills';
import FeaturedCompanies from '../../../components/Sidebars/Candidate/FeaturedCompanies';
import Designations from '../../../components/Sidebars/Candidate/Designations';
import Locations from '../../../components/Sidebars/Candidate/Locations';
import Company from '../../../components/Contact/Company';
import Header from '../../../components/common/Header';
import ActionButtons from '../../../components/Sidebars/Recruiter/ActionButtons';
import Section from '../../../components/hoc/Section';
import Main from '../../../components/hoc/Main';

class ChangePassword extends Component {

    state = {
        current_password: '',
        new_password: '',
        confirm_password: '',
        is_loader: false
    }

    handleChange = (e) => {
        if (e) {
            this.setState({
                [e.target.name]: e.target.value
            });
        }
    }


    handleSubmit = (e) => {

        e.preventDefault();

        let notify;

        if (this.state.current_password && this.state.confirm_password && this.state.new_password) {

            this.updatePassword();

        } else {
            notify = notification({ message: 'Please confirm password and new password', type: 'error' });
        }

        if (notify)
            notify();

    }

    updatePassword = async () => {

        let notify;

        this.setState({
            is_loader: true
        });

        let user = await getLoggedInUser();

        if (user) {
            let fdata = {};
            fdata['user_id'] = user.id;
            fdata['current_password'] = this.state.current_password;
            fdata['new_password'] = this.state.new_password;
            fdata['confirm_password'] = this.state.confirm_password;
            await this.props.changePassword(fdata);
            console.log(this.props.change_password_res);

            if (this.props.change_password_res) {
                this.setState({
                    is_loader: false
                });

                if (this.props.change_password_res?.status == 'success') {
                    notify = notification({ message: JSON.stringify(this.props.change_password_res?.message), type: 'success' });

                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    notify = notification({ message: JSON.stringify(this.props.change_password_res?.message), type: 'error' });
                }
            }


        }

        if (notify)
            notify();

    }


    render() {

        return (

            <Section>

                <Main>
                    {/* Content */}
                    <div className='col-md-9'>


                        <div className="mb-5">
                            <div className="bg-white  mb-5">


                                <div>
                                    <h5 className="f-Poppins-Medium mt-2 mb-2">
                                        Change Password
                                    </h5>
                                    <div className="border-gray-line mt-2 mb-2"></div>
                                    <form method="POST" onSubmit={(e) => { this.handleSubmit(e) }} name="changePasswordForm">

                                        <div className="w-90 w-xs-100">


                                            {/* current password */}
                                            <div class='row mb-2'>
                                                <div class='col-md-12'>
                                                    <label className='f-1 text-blue'>Current Password</label>
                                                </div>
                                                <div class='col-md-12'>
                                                    <input type="password" className="form-control" name="current_password"
                                                        onChange={(e) => { this.handleChange(e) }}
                                                    />
                                                </div>
                                            </div>
                                            {/* current password */}


                                            {/* new password */}
                                            <div class='row mb-2'>
                                                <div class='col-md-12'>
                                                    <label className='f-1 text-blue'>New Password</label>
                                                </div>
                                                <div class='col-md-12'>
                                                    <input type="password" className="form-control" name="new_password"
                                                        onChange={(e) => { this.handleChange(e) }}
                                                    />
                                                </div>
                                            </div>
                                            {/* new password */}

                                            {/* confirm password */}
                                            <div class='row mb-2'>
                                                <div class='col-md-12'>
                                                    <label className='f-1 text-blue'>Confirm Password</label>
                                                </div>
                                                <div class='col-md-12'>
                                                    <input type="password" className="form-control" name="confirm_password"
                                                        onChange={(e) => { this.handleChange(e) }}
                                                    />
                                                </div>
                                            </div>
                                            {/* confirm password */}



                                            {/* submit button */}
                                            <div className="d-flex mt-2 mb-2">

                                                <div className="ms-auto">
                                                    <button type="submit" className="btn btn-primary ms-auto d-block btn-sm">Update Password</button>
                                                    {(this.state.is_loader) && <Loading />}
                                                </div>

                                            </div>
                                            {/* submit button */}
                                        </div>

                                    </form>
                                </div>

                            </div>

                        </div>

                    </div>
                    {/* Content */}
                </Main>

                {/* Sidebar */}

                <SideBar>
                    <ProfileName />
                    <ActionButtons />
                    <CandidateCards hello={{ hello: 'yes' }} />
                    <Skills />
                    <FeaturedCompanies />
                    <Designations />
                    <Locations />
                    <Company />
                </SideBar>

                {/* Sidebar */}


            </Section>


        );

    }

}


/* state to props */
const mapStateToProps = (state) => {
    const { change_password_res } = state.common;
    return {
        change_password_res
    };
};
function mapDispatchToProps(dispatch) {
    return {
        changePassword: (formData) => dispatch(changePassword(formData))
    };
}
/* state to props */


export default connect(mapStateToProps, mapDispatchToProps)(ChangePassword);