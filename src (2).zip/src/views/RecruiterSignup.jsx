import React, { Component } from 'react';
import Step1 from '../Components/RecruiterSignup/Step1';
import Step2 from '../Components/RecruiterSignup/Step2';

class Signup extends Component {

    state = {
        step: 1
    };

    constructor(props) {
        super(props);
        //console.log(this.props.match.params);
    }

    componentWillMount() {
        if (this.props.match.params) {
            //this.setState({ currentState: this.props.match.params.state });
        }
    }

    nextStep = () => {
        const step = this.state.step;
        this.setState({
            step: step + 1,
        });
    };

    prevStep = () => {
        const step = this.state.step;
        this.setState({
            step: step - 1,
        });
    };

    render() {

        console.log(this.state.currentState);

        return (
            <div>

                {this.state.step == 1 && (
                    <Step1
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                    />
                )}

                {this.state.step == 2 && (
                    <Step2
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                    />
                )}

            </div>

        );
    }

}

export default Signup;