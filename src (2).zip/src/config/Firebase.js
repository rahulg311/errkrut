import firebase from 'firebase/app';
import 'firebase/auth';

const firebaseConfig = {
	apiKey: 'AIzaSyD3q-3jRj4ZHQ9DW2_04R3p_S9UU5GVl1U',
	authDomain: 'erukrut-web.firebaseapp.com',
	projectId: 'erukrut-web',
	storageBucket: 'erukrut-web.appspot.com',
	messagingSenderId: '991472562663',
	appId: '1:991472562663:web:27cdf3cb084afe4bb1cd42',
	measurementId: 'G-CPZ0C4T0MT',
};

firebase.initializeApp(firebaseConfig);
export const fbAuth = firebase.auth();
