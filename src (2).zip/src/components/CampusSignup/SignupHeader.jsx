import React from 'react';
import { NavLink } from 'react-router-dom';
import Step1 from '../RecruiterSignup/Step1';
class SignupHeader extends React.Component {
	render() {
		return (
			<div>
				<NavLink to="/">
					<img
						src={process.env.PUBLIC_URL + '/assets/imgs/logo.png'}
						className='img-fluid logo-1'
					/>
				</NavLink>
				<h4 className='font-bold my-3'>Sign Up as Campus</h4>

				<p>
					Are you a Recruiter?{' '}
					<NavLink className='ms-1' to="/recruiter-signup">
						Sign Up Here
					</NavLink>
				</p>
				 <p>
                    Are you Candidate?{' '}
                    <NavLink className='ms-1' to="/candidate-signup">
                        Sign Up Here
                    </NavLink>
                </p>


				<p>
					Already Registered?{' '}
					<NavLink className='ms-1' to="/login">
						Login Here
					</NavLink>
				</p>

			</div>
		);
	}
}
export default SignupHeader;