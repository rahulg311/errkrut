import moment from 'moment';
import React, { Component } from 'react';

class PostedOn extends Component {
    render() {
        {/*console.log(moment.utc(this.props.date).valueOf())*/}
        return this.props.date != null && <small className='ms-1'>Posted {moment.utc(this.props.date).startOf('seconds').fromNow()} </small>;
    }
}

export default PostedOn;