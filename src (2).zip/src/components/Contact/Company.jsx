import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { isRecruiter, is, isCampus } from '../../classes';

class Company extends Component {

	render() {

		return (

			<div className='row mx-0 mt-3'>
				{isRecruiter() &&
					<div className="mb-2 p-0">
						<p className="p-0">Want to reach out to more candidates?</p>
						<NavLink className="p-0" to="/plans">Click here</NavLink>
					</div>
				}
				{isCampus() && 
					<div className="mb-2 p-0">
						<p className="p-0">Want to reach out to more companies?</p>
						<NavLink className="p-0" to="/campus-plans">Click here</NavLink>
					</div>
				}
				<div className='col-md-12 p-0'>
					<section className='bg-primary p-3 rounded'>
						<header>
							<img src='/assets/imgs/logo.png' className='img-fluid h-30px' />
						</header>
						<main>
							<section className='d-none'>
								<div className='mt-2 mb-1'>
									<small className='text-white f-0-7'>Download Erekrut App Now</small>
								</div>
								<div className='d-flex'>
									<Link to="/"><img src='/assets/imgs/play-store.png' className='img-fluid me-2 h-30px' /></Link>
									<Link to="/"><img src='/assets/imgs/app-store.png' className='img-fluid h-30px' /></Link>
								</div>
							</section>

							<section className='text-white mb-2 my-3 f-0-7'>

								<p className='mb-1 '>
									<span>Phone Number</span> : <span><a className='text-white' href='tel:+91 11 45000144'>+91 11 45000144</a></span>
								</p>
								<p className='mb-1 '>
									<span>Email :</span> <span><a className='text-white' href='mailto:info@panaceaebizz(dot)com'>info@panaceaebizz(dot)com</a></span>
								</p>
							</section>
							<section className="p-3">
								<div className="row">


									<ul className='nav contact-link col-md-6 flex-column'>
										<li className='nav-item d-block'>
											<Link to='/' className='nav-link text-white'>
												Home
											</Link>
										</li>
										<li className='nav-item d-block'>
											<Link to='/' className='nav-link text-white'>
												About
											</Link>
										</li>
										<li className='nav-item d-block'>
											<Link to='/contact-us' className='nav-link text-white'>
												Contact us
											</Link>
										</li>

									</ul>

									<ul className='nav nav-sm contact-link col-md-6 flex-column p-0'>
									<li className='nav-item d-block'>
											<Link to='/' className='nav-link text-white'>
												Terms & Conditions
											</Link>
										</li>
										<li className='nav-item d-block'>
											<Link to='/' className='nav-link text-white'>
												Privacy Policy
											</Link>
										</li>
									</ul>


								</div>

								<ul className='nav my-2 d-flex justify-content-center'>
									<li className='nav-item'>
										<a className='nav-link text-white' aria-current='page' href='https://www.facebook.com/erekrut/' target={'_blank'}>
											<i className='f-1-5 text-white la la-facebook'></i>
										</a>
									</li>
									<li className='nav-item'>
										<a className='nav-link text-white' href='https://www.instagram.com/p/CQnlsZQhctp/' target={'_blank'}>
											<i className='f-1-5 text-white la la-instagram'></i>
										</a>
									</li>
									<li className='nav-item'>
										<a className='nav-link text-white' href='https://www.linkedin.com/company/erekrut/' target={'_blank'}>
											<i className='f-1-5 text-white la la-linkedin'></i>
										</a>
									</li>
								</ul>


							</section>
							<footer>
								<p className='m-0 f-0-6 text-center text-white'>
									Copyright {(new Date().getFullYear())} All rights reserved
								</p>
							</footer>
						</main>
					</section>
				</div>
			</div>
		);
	}

}

export default Company;