import React from 'react'

const Option = ({title,styleClasses}) => {
    return (
			<button className={`btn d-flex align-items-center py-2 ${styleClasses}`}>
				<small>{title}</small>
				<i class='las la-plus ms-1'></i>
			</button>
		);
}

export default Option
