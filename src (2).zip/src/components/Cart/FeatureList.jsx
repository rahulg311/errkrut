import React, { useState, useEffect } from 'react';
import { selectFeatures } from '../../store/actions/ExpendPlan';
import { useDispatch } from 'react-redux';

const FeatureList = ({ feature }) => {
	let dispatch = useDispatch();

	let [selectedPriceIndex, setSelectPriceIndex] = useState(0);
	const increaseSelectPricePriceIndex = () => {
		let pricingLength = feature.pricing.length - 1;
		if (selectedPriceIndex >= pricingLength) {
			setSelectPriceIndex(selectedPriceIndex );
			handleSelectFeature(selectedPriceIndex );
		} else {
			setSelectPriceIndex(selectedPriceIndex + 1);
			handleSelectFeature(selectedPriceIndex + 1);
		}
	};
	const decreaseSelectPricePriceIndex = () => {
		if (selectedPriceIndex <= 0) {
			setSelectPriceIndex(0);
			handleSelectFeature(0);
		} else {
			setSelectPriceIndex(selectedPriceIndex - 1);
			handleSelectFeature(selectedPriceIndex - 1);
		}
	};

	useEffect(() => {
		let index = feature.selectedPriceIndex == undefined ? 0 : feature.selectedPriceIndex;
		setSelectPriceIndex(index);
	}, []);

	let handleSelectFeature = (index) => {
		let newFeature = {
			...feature,
			selectedPriceIndex: index,
		};
		dispatch(selectFeatures(newFeature));
	};


	return (
		<li class='fs-15 list-group-item px-0 py-3 border-0 border-bottom-dotted d-flex justify-content-between align-items-center'>
			<span>{feature.feature_name}</span>
			<div class='d-flex justify-content-end align-items-center'>
				<p className='me-2'>{feature.pricing[selectedPriceIndex].price}</p>
				<div>
					<div class='btn-group' role='group' aria-label='Second group'>
						<button
							type='button'
							class='btn-sm btn btn-white shadow-sm'
							onClick={decreaseSelectPricePriceIndex}
						>
							-
						</button>
						<button type='button' class='btn-sm btn btn-primary'>
							{feature.pricing[selectedPriceIndex].max_range}
						</button>
						<button
							type='button'
							class='btn-sm btn btn-white shadow-sm'
							onClick={increaseSelectPricePriceIndex}
						>
							+
						</button>
					</div>
				</div>
			</div>
		</li>
	);
};

export default FeatureList;
