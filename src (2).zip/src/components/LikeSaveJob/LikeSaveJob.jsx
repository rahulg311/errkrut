import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getLoggedInUser } from '../../classes';
import { notification } from '../../classes/messages';
import { LIKE_JOB_MSG, SAVE_JOB_MSG } from '../../config/constants';
import { convertToSlug, getValueFromArr } from '../../classes';
import { likeAndSaveJob } from '../../store/actions/jobs';
import {
    FacebookShareButton,
    TwitterShareButton,
    LinkedinShareButton,
    WhatsappShareButton,
    FacebookIcon,
    TwitterIcon,
    LinkedinIcon,
    WhatsappIcon,
    PinterestIcon,
    VKIcon,
} from "react-share";

class LikeSaveJob extends Component {

    componentWillMount() {

    }

    likeSaveJob = async (type, MSG) => {

        let user = await getLoggedInUser();

        if (user) {

            let obj = {};
            obj['job_id'] = this.props.job_id;
            obj['type'] = type;
            obj['user_id'] = user.id;

            await this.props.likeAndSaveJob(obj);

            console.log(this.props.like_save_job_res);

            if (this.props.like_save_job_res?.status == 'success') {
                let notify = notification({ message: this.props.like_save_job_res?.message, type: 'success', position: 'bottom-right' });
                notify();
            }

        }

    }

    bookmarkJob = async (type, MSG) => {

        let user = await getLoggedInUser();

        if (user) {

            let obj = {};
            obj['job_id'] = this.props.job_id;
            obj['type'] = type;
            obj['user_id'] = user.id;

            await this.props.likeAndSaveJob(obj);

            console.log(this.props.like_save_job_res);

            if (this.props.like_save_job_res?.status == 'success') {
                let notify = notification({ message: MSG, type: 'success', position: 'bottom-right' });
                notify();
            }

        }

    }




    render() {

        return (
            <>

                <div className='d-flex  mb-2'>
                    <span onClick={() => this.likeSaveJob(1, LIKE_JOB_MSG)}>
                        <i class='las la-thumbs-up f-2 pe-1 cursor' />
                    </span>

                    <span onClick={() => this.bookmarkJob(2, SAVE_JOB_MSG)}>
                        <i class='las la-bookmark f-2 pe-1 cursor' />
                    </span>
                </div>
                <div className='d-flex flex-column flex-lg-row w-50 align-items-lg-center mb-2'>
                    <div className='d-flex fw-bold me-3 '>
                        Share:
                    </div>
                    <div className='d-flex flex-row w-100 '>
                        <FacebookShareButton className='me-2' beforeOnClick={()=> document.title = this.props.job_title}
                            url={`${window.location.protocol}//${window.location.host}/job/${this.props.job_id}/${convertToSlug(this.props.job_title)}`}
                            title={this.props.job_title}
                            quote={this.props.job_title}
                        >
                            <FacebookIcon
                                size={'25'}
                            />

                        </FacebookShareButton>
                        <TwitterShareButton className='me-2'
                            title={`Apply for ${this.props.job_title}`}
                            url={`${window.location.protocol}//${window.location.host}/job/${this.props.job_id}/${convertToSlug(this.props.job_title)}`}
                        >
                            <TwitterIcon
                                size={'25'}
                            />
                        </TwitterShareButton>

                        <WhatsappShareButton className='me-2'
                            title={`Apply for ${this.props.job_title}`}
                            separator=":: "
                            url={`${window.location.protocol}//${window.location.host}/job/${this.props.job_id}/${convertToSlug(this.props.job_title)}`}
                        >
                            <WhatsappIcon size={'25'} />
                        </WhatsappShareButton>
                        <LinkedinShareButton
                            title={`Apply for ${this.props.job_title}`}
                            url={`${window.location.protocol}//${window.location.host}/job/${this.props.job_id}/${convertToSlug(this.props.job_title)}`}
                            windowWidth={750}
                            windowHeight={600}
                        >
                            <LinkedinIcon
                                size={'25'}

                            />
                        </LinkedinShareButton>
                    </div>
                </div>
            </>
        );
    }
}


const mapStateToProps = (state) => {

    const { like_save_job_res } = state.common;

    return {
        like_save_job_res
    }
};

function mapDispatchToProps(dispatch) {
    return {
        likeAndSaveJob: (data) => dispatch(likeAndSaveJob(data)),
    };
}


export default connect(mapStateToProps, mapDispatchToProps)(LikeSaveJob);