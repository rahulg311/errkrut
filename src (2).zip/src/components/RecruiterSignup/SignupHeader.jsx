import React from "react";
import { NavLink } from "react-router-dom";
import { Campus_User_Type_ID } from "../../config/constants";

class SignupHeader extends React.Component {
  render() {
    const { userType } = this.props;
    const CustomNavLink = ({ link, title, description }) => {
      return (
        <p>
          {description}{" "}
          <NavLink className="ms-1" to={link}>
            {title}
          </NavLink>
        </p>
      );
    };
    return (
      <div>
        <NavLink to="/">
          <img
            src={process.env.PUBLIC_URL + "/assets/imgs/logo.png"}
            className="img-fluid logo-1"
          />
        </NavLink>
        <h4 className="mt-3 font-bold my-3">
          Sign Up as {`${userType === Campus_User_Type_ID ? "Educational Institute" : "Recruiter"}`}
        </h4>
        <CustomNavLink link="/candidate-signup" description="Are you Candidate?" title="Sign Up Here" />
        <CustomNavLink
          link={`${userType === Campus_User_Type_ID ? '/recruiter-signup' : '/campus-signup'}`}
          description={` Are you a ${userType === Campus_User_Type_ID ? "Recruiter?" : "Campus?"}`}
          title="Sign Up Here"
        />
        <CustomNavLink link="/login" description="Already Registered?" title="Login Here" />
      </div>
    );
  }
}

export default SignupHeader;
