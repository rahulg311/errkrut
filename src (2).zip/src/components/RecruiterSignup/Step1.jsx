
import React, { useState } from 'react';
import { fbAuth } from '../../config/Firebase';
import firebase from 'firebase';
import { socialLogin } from '../../store/actions/signup';
import { useDispatch, useSelector } from 'react-redux';
import { notification } from '../../classes/messages';
import { routeChanged } from '../../classes/browserHistory';
import { APP_Prefix, Recruiter_User_Type_ID } from '../../config/constants';

import IntroStep1 from '../../components/Intros/Signup/IntroStep1';

import SignupHeader from './SignupHeader';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEye } from '@fortawesome/free-solid-svg-icons'
import { faEyeSlash } from '@fortawesome/free-solid-svg-icons'


const Step1 = ({
	userType,
	handleChange,
	trySignup,
	errors,
	props,
	step1
}) => {

	const dispatch = useDispatch();

	const [passwordShown, setPasswordShown] = useState(false);
	const [passwordCShown, setCPasswordShown] = useState(false);
	const eye_open = <FontAwesomeIcon icon={faEye} />
	const eye_close = <FontAwesomeIcon icon={faEyeSlash} />

	const togglePasswordVisiblity = () => {
		setPasswordShown(passwordShown ? false : true);
	};
	const toggleCPasswordVisiblity = () => {
		setCPasswordShown(passwordCShown ? false : true);
	};

	const { data } = useSelector(state => state.common);


	let handleRegistrationWithGoogle = async() => {

		var provider = new firebase.auth.GoogleAuthProvider();

		let response = await fbAuth.signInWithPopup(provider);
		let user = response.user;
		//console.log(user);

		//console.log(user.displayName);

		let authUser = {};
		authUser['name'] = user.displayName;
		authUser['login_type'] = 'google';
		authUser['email'] = user.email;
		authUser['user_type'] = Recruiter_User_Type_ID;
		authUser['id'] = Recruiter_User_Type_ID;
		authUser['avatar'] = user.photoURL;

		//console.log(authUser)

		let data = await socialLogin(authUser);

		//console.log(data);

		/* login success */

		if (data) {

			let auth_profile = {
				name: data.data.name,
				email: data.data.email,
				mobile: data.data.mobile,
				id: data.data.id,
				user_type: Recruiter_User_Type_ID,
				company_id: data.company_id
			};

			localStorage.setItem(APP_Prefix + 'auth_token', JSON.stringify(data.data.token));

			localStorage.setItem(APP_Prefix + 'auth_profile', JSON.stringify(auth_profile));

			/* login token storage */

			let notify = notification({ message: data.message, type: 'success' });

			notify();

			routeChanged('/', props, 1);

		}

		/* login success */
	}

	let handleRegistrationWithFacebook = () => {
		var provider = new firebase.auth.FacebookAuthProvider();
		fbAuth.signInWithPopup(provider).then((response) => {
			let user = response.user;
			//console.log(user);
		})
	};


	return (
		<div className="container-fluid vh-100">

			<div className="row">
				<div className="col-md-6 p-0">
					<IntroStep1></IntroStep1>
				</div>
				<div className="col-md-6 p-0">
					<div className="bg-light-blue vh-100 bg-no-repeat bg-40-size" style={{ backgroundImage: process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-right.png')", backgroundPosition: "bottom right" }}>
						<div className="pt-5 pb-5 ps-2 pe-6 w-65 ms-auto me-auto vh-100 position-relative">

							<SignupHeader userType={userType}></SignupHeader>

							{/* row */}
							<div className="mt-30px">
								<h5 className="text-dark">Step 1 of 3</h5>

								<form method="POST" action="" name="">
									<div className="row mb-2 mt-2">
										<div className="col-md-12">
											<label className="text-dark">Email*</label>
										</div>
										<div className="col-md-12">
											<input type="text" className="form-control" name="email" required="" onKeyUp={handleChange} validateType="email" validateMsg="Please Correct Email" />
										</div>
									</div>

									<div className="row mb-2">
										<div className="col-md-12">
											<label>Password*</label>
										</div>
										<div className="col-md-12">

											<div class="input-group mb-3">
											<input
												type={passwordShown ? "text" : "password"}
												className='form-control'
												placeholder='******'
												name='password'
												onKeyUp={handleChange}
												style={{ "z-index": 0 }}
											/>
											<div className="end-0 me-2 position-absolute top-8px">
												<a href="javascript:void(0)" onClick={togglePasswordVisiblity}>{passwordShown ? eye_close : eye_open}</a>
											</div>
										</div>
										</div>
									</div>

									<div className="row mb-2">
										<div className="col-md-12">
											<label>Confirm Password*</label>
										</div>
										<div className="col-md-12">

											<div class="input-group mb-3">
											<input
												type={passwordCShown ? "text" : "password"}
												className='form-control'
												placeholder='******'
												name='confirmPassword'
												onKeyUp={handleChange}
												style={{ "z-index": 0 }}
											/>
											<div className="end-0 me-2 position-absolute top-8px">
												<a href="javascript:void(0)" onClick={toggleCPasswordVisiblity}>{passwordCShown ? eye_close : eye_open}</a>
											</div>
										</div>
										</div>
									</div>

									<div className="row mb-2">
										<div className="col-md-12">

											<a href="javascript:void(0)" className="btn btn-primary ms-auto me-auto d-block w-50" onClick={step1}>Next</a>

										</div>
									</div>

									{/* social icon */}
									<div className="row mt-4">
										<div className="col-md-12">
											<h6 className="text-center">or Signup with</h6>
										</div>

										<div className='container mt-4  d-flex justify-content-center'>

											<img className="img-fluid box-shadow h-40px br-5 cursor me-2" src={process.env.PUBLIC_URL + "/assets/icons/google.png"} onClick={handleRegistrationWithGoogle} />

											<img className="img-fluid box-shadow h-40px br-5 cursor me-2" src={process.env.PUBLIC_URL + "/assets/icons/fb.png"} onClick={handleRegistrationWithFacebook} />

											<img className="img-fluid box-shadow h-40px br-5 cursor" src={process.env.PUBLIC_URL + "/assets/icons/linkedin.png"} />

										</div>


									</div>
									{/* social icon */}
								</form>
							</div>

							<div className="col-md-12 text-center mt-2 mb-2 fw-bold"><a href="/">Go Back to Homepage</a></div>
							{/* row */}

						</div>
					</div>
				</div>
			</div>

		</div>
	);
}

export default Step1;