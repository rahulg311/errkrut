import React, { Component } from 'react';


class MapContainer extends Component {

	render() {

		return (
			<div style={{ height: '70vh', width: '100%' }}>
			  <iframe className='w-100 h-100' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3504.0690464727672!2d77.22215231541063!3d28.567689282443517!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce3da5ee3183f%3A0x214bee4685d29ef8!2sEREKRUT%20-%20Recruitment%20Made%20Easy!5e0!3m2!1sen!2sin!4v1642768464938!5m2!1sen!2sin" frameborder="0" style={{border:0}} allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
			</div>
		);
	}
}

export default MapContainer;