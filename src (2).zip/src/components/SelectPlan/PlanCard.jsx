import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { getLoggedInUser } from '../../classes';
import { Candidate_User_Type_ID, Recruiter_User_Type_ID } from '../../config/constants';

const PlanCard = (props) => {
	const dispatch = useDispatch()
	const history = useHistory()
	const [currentPlan, setcurrentPlan] = useState(null);

	useEffect(async () => {
		let user = await getLoggedInUser();
		setcurrentPlan(user.plan_id);
	});

	let onSelectPlan = async () => {
		let user = await getLoggedInUser();
		localStorage.setItem('PLAN', JSON.stringify(props.plan));
		if (user.user_type == Candidate_User_Type_ID) {
			history.push(`/expand-plans/${props.plan.id}`);
		}
		else if (user.user_type == Recruiter_User_Type_ID) {
			history.push(`/expand-plan/${props.plan.id}`);
		}

	}

	return (
		<div className='col-lg-4 col-12 mt-lg-0 mt-5'>
			<section className='card border-0 rounded-top-5 rounded-4 bg-white'>
				<header className={`${props.cardName} card-header text-light`}>
					<p className='text-end'>{props.plan.name}</p>
					<div>
						<div className='mb-1 d-flex '>
							<h3>₹</h3>
							<h1 className='fw-bolder mb-0'>{props.plan.price}</h1>
						</div>
						<small className='mb-1'>Upto {props.plan.validity} Days</small>
						<div>{props.plan.name == 'Amateur' && props.plan.id == currentPlan && <small>Your Current Plan</small>}</div>
					</div>
				</header>
				<main className='p-2'>
					<header className='mb-3'>
						<h6 className='border-bottom border-danger pb-1'>{props.plan.name} Inlcudes</h6>
					</header>
					<main>
						<ul className='ps-4'>
							{props.plan.features.map((feature) => {
								let text;
								text = '0' == feature[0] ? feature.slice(1) : feature;
								return <li className='mb-3 fs-14'>{text}</li>;
							})}
						</ul>
					</main>
				</main>
				{props.plan.name == 'Amateur' && (
					<footer className='p-2 mb-2 d-none'>
						<div

							className='bg-light-blue vh-100 bg-no-repeat bg-30-size'
							style={{
								backgroundImage:
									process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-left 2.png')",
								backgroundPosition: 'top right',
								width: '300px',
								position: 'relative',
								right: '20px',
							}}
						></div>

					</footer>
				)}
				{/* {props.plan.name !== 'Amateur' && ( */}
				<footer className='p-2 mb-2'>
					<button
						class='btn btn-primary w-100'
						onClick={onSelectPlan}
						disabled={(props.plan.id == currentPlan) ? true : false}
					>
						Upgrade to {props.plan.name}
					</button>
					{props.plan.id == currentPlan && <p className="text-danger mt-2 text-center">Your Current Plan</p>}
				</footer>
				{/* )} */}
			</section>
		</div>
	);
}

export default PlanCard

