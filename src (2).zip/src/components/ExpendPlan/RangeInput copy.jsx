import React, { createRef, useState, useEffect } from 'react';

const RangeInput = ({ min, max, pricing, setSelectIndex, current }) => {

	const rangeRef = createRef();
	const [rangeValue, setRangeValue] = useState(0);
	const [sortedPricing, setSortedPricing] = useState([]);

	useEffect(() => {
		const sorted = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
		sorted.length >= 1 &&
			(rangeRef.current.style.backgroundSize =
				(99 * (sorted[rangeValue].max_range - min)) / (max - min) + '% 100%');
		setSortedPricing(sorted);
	}, [pricing, rangeValue]);

	useEffect(() => {
        let value = current;
        const sortedPricing = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
        if (sortedPricing.length > 0) {
            sortedPricing.find((price, i) => {
                if (value >= price.min_range) {
                    setRangeValue(i);
                    setSelectIndex(i);
                }
            });
        }

    }, []);

	return (
		<div>
			<section
				className='d-flex w-100  position-relative h-27px'
				style={{ marginLeft: '0px' }}
			>
				{sortedPricing.length >= 1 &&
					sortedPricing.map((price, i) => {
						let totallength;
						const maxRange = toString(price.max_range);
						totallength =
							price.max_range.length <= 2 && i == sortedPricing.length - 1
								? 96
								: price.max_range.length > 2 &&
								  price.max_range.length <= 4 &&
								  i == sortedPricing.length - 1
								? 92
								: price.max_range.length > 4 &&
								  price.max_range.length <= 6 &&
								  i == sortedPricing.length - 1
								? 91
								: 1 == sortedPricing.length && maxRange.length >= 2
								? 90
								: 91;
						return (
							<div
								key={i}
								className={`box mb-2 arrow-bottom rounded ${i <= rangeValue && 'active'}`}
								style={{
									left: ((price.max_range - min) * totallength) / (max - min) + '%',
								}}
							>
								{price.max_range}
							</div>
						);
					})}
			</section>

			<input
				ref={rangeRef}
				onChange={(e) => {
					const value = e.target.value;
					[...sortedPricing].find((price, i) => {
						if (+value <= +sortedPricing[0].max_range) {
							setRangeValue(0);
							setSelectIndex(0);
						} else if (i >= 1 && value >= price.min_range && value >= price.min_range) {
							setRangeValue(i);
							setSelectIndex(i);
						}
					});
				}}
				type='range'
				min={min}
				max={max}
				className='form-range-fill'
				value={sortedPricing.length >= 1 && sortedPricing[rangeValue].max_range}
			/>
			<div className='d-flex justify-content-between mt-1'>
				<small>{min}</small>
				<small>{max}</small>
			</div>
		</div>
	);
};

export default RangeInput;
