import React, { createRef, useState, useEffect } from 'react';

const RangeInput = ({ min, max, pricing, setSelectIndex, setquantity, current, feature }) => {

	const rangeRef = createRef();
	const [rangeValue, setRangeValue] = useState(0);
	const [value, setvalue] = useState(0);
	const [sortedPricing, setSortedPricing] = useState([]);

	useEffect(() => {
		const sorted = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
		sorted.length >= 1 &&
			(rangeRef.current.style.backgroundSize =
				(99 * (sorted[rangeValue].max_range - min)) / (max - min) + '% 100%');

		if (feature.feature_name == "Connect with Recruiters") {
			rangeRef.current.style.backgroundSize =
				((100 * (value == 0 ? current : value)) / max + '% 100%');
		}
		setSortedPricing(sorted);
	}, [pricing, rangeValue, value]);

	useEffect(() => {
		let value = parseInt(current);
		const sortedPricing = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
		if (sortedPricing.length > 0) {
			sortedPricing.find((price, i) => {
				if (value == parseInt(price.max_range)) {
					setRangeValue(i);
					setSelectIndex(i);
				}
			});
		}

	}, []);


	const closest = (arr, num) => {
		return arr.reduce((acc, val) => {

			if (val && acc)
				if (Math.abs(parseInt(val.max_range) - parseInt(num)) < Math.abs(parseInt(acc.max_range))) {
					return parseInt(val.max_range) - parseInt(num);
				} else {
					return parseInt(acc.max_range);
				}
		}) + parseInt(num);
	}

	return (
		<div>
			<section
				className='d-flex w-100  position-relative h-27px'
				style={{ marginLeft: '0px' }}
			>
				{sortedPricing.length >= 1 &&
					sortedPricing.map((price, i) => {
						let totallength;
						const maxRange = toString(price.max_range);
						totallength =
							price.max_range.length <= 2 && i == sortedPricing.length - 1
								? 96
								: price.max_range.length > 2 &&
									price.max_range.length <= 4 &&
									i == sortedPricing.length - 1
									? 92
									: price.max_range.length > 4 &&
										price.max_range.length <= 6 &&
										i == sortedPricing.length - 1
										? 91
										: 1 == sortedPricing.length && maxRange.length >= 2
											? 90
											: 91;
						return (
							<div
								key={i}
								className={`box mb-2 arrow-bottom rounded ${i <= rangeValue && 'active'}`}
								style={{
									left: ((price.max_range - min) * totallength) / (max - min) + '%',
								}}
							>
								{price.max_range}
							</div>
						);
					})}


			</section>
			<input

				ref={rangeRef}
				onChange={(e) => {
					const value = parseInt(e.target.value);
					setvalue(value);
					setquantity(value);
					if (feature.feature_name == "Connect with Recruiters") {
						setSelectIndex(rangeValue, (value == 0 ? current : value));
					}


					if (value <= parseInt(current)) {


						const ind = sortedPricing.reduce((a, b) => {
							return Math.abs(b.max_range - parseInt(current)) <= Math.abs(parseInt(a.max_range) - parseInt(current)) ? b : a;
						});
						let index = sortedPricing.findIndex((v) => { return (parseInt(v.max_range) == parseInt(ind.max_range)) });

						setRangeValue(index);
						setSelectIndex(index, value);


					} else {
						let index = sortedPricing.findIndex((v) => { return (parseInt(v.max_range) == parseInt(value)) });
						if (index > 0) {

							setRangeValue(index);
							setSelectIndex(index, value);
						} else {

							[...sortedPricing].find((price, i) => {
								if (i >= 1 && value >= parseInt(price.max_range) && value >= parseInt(price.max_range)) {
									setRangeValue(i);
									setSelectIndex(i, value);
								}
							});
						}
					}
				}}
				type='range'
				min={min}
				max={max}
				className='form-range-fill'
				value={feature.feature_name == "Connect with Recruiters" ? (value == 0 ? current : value) : sortedPricing.length >= 1 && sortedPricing[rangeValue].max_range}
			/>
			<div className='d-flex justify-content-between mt-1'>
				<small>{min}</small>
				<small>{max}</small>
			</div>
		</div>
	);
};

export default RangeInput;
