import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import RangeInput from './RangeInput';
import { selectFeatures } from '../../store/actions/ExpendPlan';
import RangeInputExpand from './RangeInputExpand';
const FeatureCard = ({ feature, ISUpgrade, currentPlanFeature }) => {

	let dispatch = useDispatch();
	const [selectIndex, setSelectIndex] = useState(0);
	const [price, setPrice] = useState(0);
	const [previousPrice, setpreviousPrice] = useState(0);
	const [quantity, setquantity] = useState(0);


	useEffect(() => {


		let price = feature.pricing.sort((a, b) => a.max_range - b.max_range)[selectIndex].price;
		if (currentPlanFeature && previousPrice == 0) {
			if (currentPlanFeature.feature_title == "Connect with Recruiters") {
				setpreviousPrice(currentPlanFeature.ammount * currentPlanFeature.quantity);

			}
			else {
				setpreviousPrice(currentPlanFeature.ammount);

			}
		}
		setPrice(price);


		if (feature.feature_name == "Connect with Recruiters") {

			if (currentPlanFeature && previousPrice == 0) {
				setPrice(currentPlanFeature.ammount * (quantity <= currentPlanFeature.quantity ? currentPlanFeature.quantity : quantity));
				//setPrice(price * (quantity <= feature.current ? feature.current : quantity));
			}
			else {
				setPrice(price * (quantity <= feature.current ? feature.current : quantity));
			}
		}



	}, [selectIndex, quantity]);


	let handleSetSelectIndex = (index, qty) => {
		let newFeature = {
			...feature,
			selectedPriceIndex: index,
			quantity: qty,
		};
		dispatch(selectFeatures(newFeature));
		setSelectIndex(index);
	};

	return (

		< section className='col-lg-6 mb-3' >
			<section className='card p-2 border-primary px-4 rounded-4'>
				<header className='d-flex justify-content-between'>
					<div>
						<h6 className='mb-1 me-2'>{feature.feature_name}</h6>
					</div>
					<div className='d-flex align-items-center'>
						<h6>{price !== 'free' && '₹'}</h6>

						<h5>{price - previousPrice}</h5>
					</div>
				</header>
				<main>
					{ISUpgrade &&
						<RangeInputExpand
							pricing={feature.pricing}
							feature={feature}
							setquantity={setquantity}
							min={(ISUpgrade) ? feature?.min_number : feature.min_number}
							max={feature.max_number}
							setSelectIndex={handleSetSelectIndex}
							currentPlanFeature={currentPlanFeature}
							ISUpgrade={ISUpgrade} />
					}
					{!ISUpgrade && <RangeInput
						pricing={feature.pricing}
						setquantity={setquantity}
						feature={feature}
						min={(ISUpgrade) ? feature?.min_number : feature.min_number}
						max={feature.max_number}
						current={feature.current}
						setSelectIndex={handleSetSelectIndex}
					/>}
				</main>
			</section>
		</section >
	);
};

export default FeatureCard;

