import React, { createRef, useState, useEffect } from 'react';

const RangeInputExpand = ({ min, max, pricing, setSelectIndex, currentPlanFeature, setquantity, ISUpgrade }) => {

    //min = currentPlanFeature?.quantity;

    const rangeRef = createRef();
    const [rangeValue, setRangeValue] = useState(0);
    const [value, setvalue] = useState(0);
    const [prevalue, setprevalue] = useState(0);
    const [sortedPricing, setSortedPricing] = useState([]);
    useEffect(() => {
        const sorted = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
        sorted.length >= 1 &&
            (rangeRef.current.style.backgroundSize =
                (99 * (sorted[rangeValue].max_range - min)) / (max - min) + '% 100%');
        if (currentPlanFeature.feature_title == "Connect with Recruiters") {
            rangeRef.current.style.backgroundSize =
                ((100 * (value == 0 ? currentPlanFeature.quantity : value)) / max + '% 100%');
        }
        setSortedPricing(sorted);

    }, [pricing, rangeValue, value]);

    useEffect(() => {
        let value = parseInt(currentPlanFeature?.quantity);
        setprevalue(value);


        const sortedPricing = pricing.length >= 1 && pricing.sort((a, b) => a.max_range - b.max_range);
        if (sortedPricing.length > 0) {
            sortedPricing.find((price, i) => {
                if (value == parseInt(price?.max_range)) {
                    setRangeValue(i);
                    setSelectIndex(i);
                }
            });
        }

    }, []);

    return (
        <div>
            <section
                className='d-flex w-100  position-relative h-27px'
                style={{ marginLeft: '0px' }}
            >
                {sortedPricing.length >= 1 &&
                    sortedPricing.map((price, i) => {
                        let totallength;
                        const maxRange = toString(price.max_range);
                        totallength =
                            price.max_range.length <= 2 && i == sortedPricing.length - 1
                                ? 96
                                : price.max_range.length > 2 &&
                                    price.max_range.length <= 4 &&
                                    i == sortedPricing.length - 1
                                    ? 92
                                    : price.max_range.length > 4 &&
                                        price.max_range.length <= 6 &&
                                        i == sortedPricing.length - 1
                                        ? 91
                                        : 1 == sortedPricing.length && maxRange.length >= 2
                                            ? 90
                                            : 91;

                        return (

                            <div
                                key={i}
                                className={`box mb-2 arrow-bottom rounded ${i <= rangeValue && 'active'}`}
                                style={{
                                    left: ((price.max_range - min) * totallength) / (max - min) + '%',
                                }}
                            >
                                {price.max_range}
                            </div>
                        );
                    })}
            </section>

            <input
                ref={rangeRef}
                onChange={(e) => {
                    if (currentPlanFeature?.feature_title == "Connect with Recruiters" && prevalue > e.target.value) {
                        setvalue(prevalue);
                        setquantity(prevalue);
                        setSelectIndex(0, prevalue);
                        return 0;
                    }
                    const value = parseInt(e.target.value);
                    setvalue(value);
                    setquantity(value);
                    if (currentPlanFeature?.feature_title == "Connect with Recruiters") {
                        setSelectIndex(rangeValue, (value == 0 ? currentPlanFeature?.quantity : value));
                    }

                    if (value <= parseInt(currentPlanFeature?.quantity)) {

                        const ind = sortedPricing.reduce((a, b) => {
                            return Math.abs(parseInt(b.max_range) - parseInt(currentPlanFeature?.quantity)) <= Math.abs(parseInt(a.max_range) - parseInt(currentPlanFeature?.quantity)) ? b : a;
                        });
                        let index = sortedPricing.findIndex((v) => { return (parseInt(v.max_range) == parseInt(ind.max_range)) });
                        setRangeValue(index);
                        setSelectIndex(index, value);
                    } else {
                        let index = sortedPricing.findIndex((v) => { return (parseInt(v.max_range) == value) });
                        if (index > 0) {
                            setRangeValue(index);
                            setSelectIndex(index, value);
                        } else {
                            [...sortedPricing].find((price, i) => {
                                if (i >= 1 && value >= parseInt(price.max_range) && value >= parseInt(price.max_range)) {
                                    setRangeValue(i);
                                    setSelectIndex(i, value);
                                }
                            });
                        }
                    }
                }}
                type='range'
                min={min}
                max={max}
                className='form-range-fill'
                // value={sortedPricing.length >= 1 && sortedPricing[rangeValue].max_range}
                value={currentPlanFeature.feature_title == "Connect with Recruiters" ? (value == 0 ? currentPlanFeature?.quantity : value) : sortedPricing.length >= 1 && sortedPricing[rangeValue].max_range}
            />
            <div className='d-flex justify-content-between mt-1'>
                <small>{min}</small>
                <small>{max}</small>
            </div>
        </div>
    );
};

export default RangeInputExpand;
