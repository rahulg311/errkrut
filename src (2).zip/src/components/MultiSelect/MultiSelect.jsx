import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';

const MultiSelect = (props) => {

    const [search, setSearch] = useState('');
    const [filterItems, setFilterItems] = useState([]);
    const [fieldname, setFieldName] = useState('');
    const [items, setItems] = useState([]);

    useEffect(() => {
        // console.log(props.options);
        if (props.options)
            setItems(props.options);
        setFieldName(props.name);



        let items = props.SelectedValues?.split(',');

        //console.log(items);

        if (items)
            setSelectedItems(items);


        /* props.SelectedValues?.split(',').map((item) => {
 
            //setSelectedItems(props.SelectedValues?.split(','));
        }); */

    }, []);

    const [selectedItems, setSelectedItems] = useState([]);

    const handleRemoveSelectedItem = (value) => {
        const filterItems = [...selectedItems].filter((e) => e !== value);
        setSelectedItems(filterItems);
    };

    const setItemsHandleChange = (item) => {
        setSelectedItems([...selectedItems, item]);
        setSearch('');
    }

    const handleAddSelectedItem = (value) => {
        const filterItems = [...new Set([...selectedItems, value])];
        setSelectedItems(filterItems);
        setSearch('');
    };

    useEffect(() => {
        if (selectedItems)
            props.handleChange({ target: { name: fieldname, value: selectedItems.join(',') } });
    }, [selectedItems]);


    React.useEffect(() => {
        // console.log(items);
        const newArray = [...items]?.filter((item) => item.toLowerCase().includes(search.toLowerCase()));
        setFilterItems([...new Set(newArray)]);
    }, [search]);


    return (
        <div className='position-relative'>
            <div className='position-relative'>
                <input
                    className='form-control form-control-sm text-blue'
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder={fieldname.replace("_", " ")}
                />
                {search && (
                    <button
                        type='button'
                        class='btn-close translate-right-middle'
                        style={{ right: '10px' }}
                        onClick={() => setSearch('')}
                        aria-label='Close'
                    ></button>
                )}
            </div>
            <main className='w-100'>
                {search && filterItems.length >= 1
                    ? filterItems.map((item, i) => (
                        <div className='list-group position-absolute w-100 z-9'>
                            <li className='list-group-item list-group-item-action w-100'>
                                <div class='form-check'>
                                    <input
                                        class='form-check-input'
                                        type='checkbox'
                                        checked={selectedItems.includes(item)}
                                        value={item}
                                        id={i}
                                        onChange={(e) => {
                                            e.target.checked
                                                ? setItemsHandleChange(item)
                                                : handleRemoveSelectedItem(e.target.value);
                                        }}
                                    />
                                    <label class='form-check-label h-100 w-100' for={i}>
                                        {item}
                                    </label>
                                </div>
                            </li>
                        </div>
                    ))
                    : search && (
                        <button
                            className='btn bg-secondary bg-opacity-10 mt-1 fs-13 text-capitalize'
                            onClick={() => handleAddSelectedItem(search)}
                        >
                            Create New {fieldname.replace(/_/g, " ")}
                        </button>
                    )}
            </main>

            <div className='mt-2'>
                {selectedItems.map((item) => {
                    return item &&
                        <span class='badge border text-dark p-1 me-1 fs-13 rounded-pill'>
                            {item}
                            <span className="ms-1 cursor text-danger" onClick={() => handleRemoveSelectedItem(item)}>X</span>
                        </span>
                })}
            </div>

        </div>
    );
};

export default MultiSelect;
