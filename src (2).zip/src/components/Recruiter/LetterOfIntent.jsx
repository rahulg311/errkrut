import React, { useState, useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { DELETE_LOI, END_POINT, GET_LETTER_INTENT } from '../../routes/api_routes';
import Loading from '../common/Loading';
import { Link } from 'react-router-dom';
import { notification } from '../../classes/messages';
import { FileNameFromURL, getLoggedInUser, MimeIcon, ReadMore, getAuthToken } from '../../classes';
import moment from 'moment';

const LetterOfIntent = () => {

	const { data, loading, error, doFetch } = useFetch();
	const [user, setUser] = useState({})
	useEffect(async () => {
		const user = await getLoggedInUser()
		setUser(user)
		doFetch(END_POINT + `${GET_LETTER_INTENT}/${user.id}`);
	}, [])

	const handleDeleteLoi = async (id) => {
		const token = await getAuthToken();
		const requestOptions = {
			method: 'GET',
			redirect: 'follow',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + `${DELETE_LOI}/${id}`, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				const notify = notification({ message: result.message, type: result.status });
				notify();

				doFetch(END_POINT + `${GET_LETTER_INTENT}/${user.id}`);
			})
			.catch((error) => console.log('error', error));
	}

	return (
		<div className='col-md-12 mt-3'>
			<div>
				<header className='row bg-primary text-white p-1 rounded-top shadow'>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex '>Title 		<i class='fas fa-sort mt-4px ms-1'></i></span>

				
					</div>


					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex '>Content <i class='fas fa-sort mt-4px ms-1'></i></span>

					
					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex '>Date <i class='fas fa-sort mt-4px ms-1'></i></span>

						
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex '>File <i class='fas fa-sort mt-4px ms-1'></i></span>

					
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex '>Action <i class='fas fa-sort mt-4px ms-1'></i></span>

						
					</div>
				</header>
				<main>
					{loading ?
						<Loading className="my-3" />
						: data?.data.map((data, i) => {
							const odd = i % 2 == 0;
							return (
								<div
									className={`row align-items-center p-2 ${odd ? 'bg-table-striped' : 'bg-light-blue'
										}`}
								>
									<div className='col-2'>
										<small className='f-r-12 d-flex '>{data.title}</small>
									</div>

									<div className='col-3'>
										<small className='f-r-12 d-flex '>{ReadMore(data?.content, 100)}</small>
									</div>
									<div className='col-3'>
										<small className='f-r-12 d-flex '>{data?.created_at && moment(data?.created_at).format('MMMM Do YYYY h:mm a')}</small>
									</div>

									<div className='col-2'>
										{data?.file && <a className='f-1 f-r-10' href={data?.file} target={`_blank`}>{MimeIcon(data?.file)} View</a>}
									</div>
									<div className='col-2 text-center p-0'>
										<div className=' justify-content-end'>
											<Link to={`/edit-loi/${data.id}`} className='btn btn-sm   ms-2  border f-r-12'>
												<i class='fas fa-edit f-r-10'></i>
											</Link>
											<button
												className='btn btn-sm text-danger border ms-1 ms-2  border f-r-12'
												onClick={() => handleDeleteLoi(data.id)}
											>
												<i class='fas fa-trash f-r-10'></i> 
											</button>
										</div>
									</div>
								</div>
							);
						})

					}

				</main>
			</div>
		</div>
	);
};

export default LetterOfIntent;
