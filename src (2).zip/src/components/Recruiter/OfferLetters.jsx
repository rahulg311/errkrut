import React, { useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT, GET_OFFER_LETTERS } from '../../routes/api_routes';
import { notification } from '../../classes/messages';
import Loading from '../common/Loading';
import { Link } from 'react-router-dom';
import { getLoggedInUser } from '../../classes';

const OfferLetters = ({ history }) => {
	const { data, loading, error,doFetch } = useFetch();

	useEffect(async () =>{
		const user = await getLoggedInUser();
		console.log('user :>> ', user);
		doFetch(END_POINT + `${GET_OFFER_LETTERS}/${user.id}`);
		
	},[])

	const handleDeleteOfferLetter = async (id) => {
		const user = await getLoggedInUser();
		var requestOptions = {
			method: 'POST',
			redirect: 'follow',
		};
		fetch(END_POINT + `delete_offer_letter/${id}`, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				const notify = notification({
					message: result.message,
					type: result.status,
				});
				notify();
				doFetch(END_POINT + `get_offer_letters/${user.id}`);
			})
			.catch((error) => console.log('error', error));
	};

	return (
		<div className='mt-3'>
			{loading ? (
				<Loading></Loading>
			) : (
				data?.data.map((item, index) => {
					console.log(data)
					return (
						<section className='card p-4 rounded-4 shadow mb-3'>
							<header className='d-flex justify-content-between align-item-center mb-3'>
								<h5 className='mb-0'>{item.job_offer_title}</h5>
								<div>
									<Link to={`/edit-offer-letter/${item.id}`} className='btn btn-sm   ms-2  border f-r-12'>
										<i class='fas fa-edit'></i>
									</Link>
									<button
										className='btn btn-sm text-danger border ms-3 ms-2  border f-r-12'
										onClick={() => handleDeleteOfferLetter(item.id)}
									>
										<i class='fas fa-trash'></i>
									</button>
								</div>
							</header>
							<main>
								<p>{item.job_offer_content}</p>
							</main>
						</section>
					);
				})
			)}
		</div>
	);
};

export default OfferLetters;
// get_offer_letters;
