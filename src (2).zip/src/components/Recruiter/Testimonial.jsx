import React, { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT } from '../../routes/api_routes';
import Loading from '../common/Loading';

import { notification } from '../../classes/messages';
import EditTestimonialModal from './EditTestimonialModal';
const Testimonial = () => {
	const { data, loading, error,doFetch } = useFetch(END_POINT + 'getall_testimonial');
	const [testimonial,setTestimonial] = React.useState({});
	const [user, setUser] = useState({});

	const getTestimonial=()=>{
		doFetch(END_POINT + 'getall_testimonial');
	}

	const handleDelete = (id) => {
		const url = END_POINT + 'delete_testimonial/' + id;
		var requestOptions = {
			method: 'POST',
		};
		fetch(url, requestOptions)
			.then((res) => res.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({
						message: data.message,
						type: 'success',
						
					});
					doFetch(END_POINT + 'getall_testimonial');
					notify();
				}
			})
			.catch((err) => console.log(err));
	};

	return (
		<div className='mt-3'>
			{loading ? (
				<Loading className='my-4' />
			) : (
				data?.data.map((data) => {
					return (
						<section className='card border-0 shadow rounded-4 p-2 mb-4'>
							<header className='p-1 bg-transparent d-flex align-items-center justify-content-between'>
								<div className='d-flex'>
									<img
										src='https://images.fastcompany.net/image/upload/w_1280,f_auto,q_auto,fl_lossy/w_596,c_limit,q_auto:best,f_auto/fc/3034007-inline-i-applelogo.jpg'
										alt=''
										className='w-65px shadow bg-white p-1 h-60px rounded-4'
									/>
									<div className='mt-2px ms-4'>
										<h4>{data.name}</h4>
										<p>{data.company_name}</p>
									</div>
								</div>
								<div>
									<button
										data-bs-target='#EditTestimonialModal'
										data-bs-toggle='modal'
										className='btn  border'
										onClick={() => {
											//console.log('data', data);
											setTestimonial(data);
										}}
									>
										<i class='fas fa-edit'></i>
									</button>
									<button
										className='btn text-danger border-0 ms-3'
										onClick={() => {
											handleDelete(data.id);
										}}
									>
										<i class='fas fa-trash'></i>
									</button>
								</div>
							</header>
							<main className='p-1'>
								<p>{data.description}</p>
							</main>
						</section>
					);
				})
			)}
			<EditTestimonialModal testimonial={testimonial} getTestimonial={getTestimonial} />
		</div>
	);
};

export default Testimonial;
