import React, { useState, useEffect } from 'react';
import { END_POINT } from '../../routes/api_routes';
import Loading from '../common/Loading';
import { getLoggedInUser, getAuthToken } from '../../classes';

import { Link } from 'react-router-dom';

const Quiz = () => {
	const [loading, setLoading] = useState(true);
	const [quiz, setQuiz] = useState([]);
	const [newData, setNewData] = useState([])
	const [search, setSearch] = useState('');
	useEffect(async () => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			redirect: 'follow',

			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}

		};

		fetch(END_POINT + `getall_quiz/${user.company_id}`, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				
				setLoading(false);
				setQuiz(result.data);
				setNewData(result.data);
			})
			.catch((error) => {
				setLoading(false);
			});
	}, []);

	const SearchChangeHandler = (e) => {
		setSearch(e.target.value)
	}
	const QuestionSearch = () => {
		setLoading(true);
		const newdata = quiz.filter((item) => item.title.toLowerCase().includes(search.toLowerCase()))
		setNewData(newdata);
		setLoading(false);
	}

	return (
		<div className='col-md-12 mt-3'>
			<div class="input-group mb-3">
				<input type="search" class="form-control" placeholder="Search" aria-label="search" aria-describedby="basic-addon2" onChange={SearchChangeHandler}/>
				<div class="input-group-append">
					<button onClick={QuestionSearch} class="btn bg-primary text-white" type="button">Search</button>
				</div>
			</div>	
			<div>
				
				<header className='row bg-primary text-white p-1 rounded-top shadow'>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12'>Title <i class='fas fa-sort mt-4px ms-1'></i></span>

						
					</div>
					{/* <div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>category</span>

						<i class='fas fa-sort mt-4px'></i>
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>Tags</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12' >Sections <i class='fas fa-sort mt-4px ms-1'></i></span>

					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12'>Questions  <i class='fas fa-sort mt-4px ms-1'></i></span>

						
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex'>Action 	<i class='fas fa-sort mt-4px ms-1'></i></span>

					
					</div>
				</header>
  				{loading ? (
						<div className='mt-2'>
							<Loading />{' '}
						</div>
					) : (
						newData.map((data, i) => {
							//console.log('quiz', quiz);
							const odd = i % 2 == 0;
							return (
								<div
								className={`row align-items-center p-2 ${
									odd ? 'bg-table-striped': 'bg-light-blue'
								}`}
								>
								<div className='col-3'>
									<small className='f-r-12'>{data.title}</small>
								</div>
								<div className='col-2'>
									<small className='f-r-12'>{data.no_of_sections}</small>
								</div>
								<div className='col-4'>
									{data.no_of_questions.map((data) => {
										return (
											<div className='mb-7px'>
												<small className='me-4 f-r-12'>Name ({data.section_name})</small>
												<small className='f-r-12'> Question ({data.no_of_questions})</small>
											</div>
										);
									})}
								</div>
								<div className='col-3 text-center'>
									<Link
										to={`/edit-quiz/${data.id}`}
										className='btn btn-sm py-2px px-5px btn-outline-primary'
									>
										<i class='fas fa-edit f-r-12'></i>
									</Link>
								</div>

							</div>
							
							);
						})
					)}
 
					
				<main>
					
				</main>
			</div>
		</div>
	);
};

export default Quiz;
