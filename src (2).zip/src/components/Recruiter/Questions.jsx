import React, { useState, useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT } from '../../routes/api_routes';
import Loading from '../common/Loading';
import { Link } from 'react-router-dom';
import { notification } from '../../classes/messages';
import { getLoggedInUser, getAuthToken } from '../../classes';
import moment from 'moment';
import QuestionFiltered from './QuestionFiltered';

const Questions = () => {

	const { data, loading, error, doFetch } = useFetch();
	const [user, setUser] = useState({})
	const [newData, setNewData] = useState([])
	const [search, setSearch] = useState('')
	const [questionsShow, setQuestionsShow] = useState(false)
	useEffect(async () => {
		const user = await getLoggedInUser()
		setUser(user)
		doFetch(END_POINT + `getall_Question/${user.id}`);
	}, [])

	const handleDeleteQuestion = async (id) => {
		var formdata = new FormData();
		let token = await getAuthToken();
		formdata.append('qid', id);
		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
			headers: { 'Authorization': 'Bearer ' + token }
		};

		fetch(END_POINT + 'delete_question', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				const notify = notification({ message: result.message, type: result.status });
				notify();

				doFetch(END_POINT + `getall_Question/${user.id}`);
			})
			.catch((error) => console.log('error', error));
	}

	const SearchChangeHandler = (e) => {
		setSearch(e.target.value)
	}
	const QuestionSearch = () => {
		const newdata = data.data.filter((item) => item.question.toLowerCase().includes(search.toLowerCase()))
		setNewData(newdata)
		setQuestionsShow(true)
	}
	return (
		<div className='col-md-12 mt-3'>
			<div style={{ width: '100%' }}>
				<input type="search" style={{ marginBottom: '10px', borderRadius: '0px', width: '80%', height: '35px' }}
					onChange={SearchChangeHandler} />
				<button onClick={QuestionSearch} style={{ width: '20%', height: '35px', border: "3px" }} className=' bg-primary text-white'>Search</button>
			</div>
			<div>
				<header className='row bg-primary text-white p-1 rounded-top shadow'>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12'>Title <i class='fas fa-sort mt-4px ms-1'></i></span>


					</div>
					{/* <div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>category</span>

						<i class='fas fa-sort mt-4px'></i>
					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span>Tags</span>

						<i class='fas fa-sort mt-4px'></i>
					</div> */}
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12' >Type <i class='fas fa-sort mt-4px ms-1'></i></span>

					</div>
					<div className=' col-3 d-flex justify-content-between align-item-center'>
						<span className='f-r-12'>Date  <i class='fas fa-sort mt-4px ms-1'></i></span>


					</div>
					<div className=' col-2 d-flex justify-content-between align-item-center'>
						<span className='f-r-12 d-flex'>Action 	<i class='fas fa-sort mt-4px ms-1'></i></span>


					</div>
				</header>
				<main>
					{loading ?
						<Loading className="my-3" />
						: <QuestionFiltered questionsShow={questionsShow} data={data} newData={newData} handleDeleteQuestion={handleDeleteQuestion} />
					}

				</main>
			</div>
		</div>
	);
};

export default Questions;
