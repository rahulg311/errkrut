import React from 'react';
import { END_POINT } from '../../routes/api_routes';
import { notification } from '../../classes/messages';

const EditTestimonialModal = ({ testimonial, getTestimonial }) => {
	const [testimonialName, setTestimonialName] = React.useState('');
	const [description, setDescription] = React.useState('');
	const [companyName, setCompanyName] = React.useState('');

	const handleSubmitForm = (e) => {
		e.preventDefault();

		var formdata = new FormData();
		formdata.append('id', testimonial.id);
		formdata.append('user_id', testimonial.user_id);
		formdata.append('name', testimonialName);
		formdata.append('company_name', companyName);
		formdata.append('description', description);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			redirect: 'follow',
		};

		fetch(END_POINT + `update_testimonial`, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				if (result.status === 'success') {
					const notify = notification({ message: result.message, type: result.status });
					notify();
					getTestimonial()
				} else {
					result.message.forEach((message) => {
						const notify = notification({ message: message, type: result.status });
						notify();
					});
				}
			})
			.catch((error) => console.log('error', error));
	};

	React.useEffect(() => {
		setTestimonialName(testimonial.name);
		setDescription(testimonial.description);
		setCompanyName(testimonial.company_name);
	}, [testimonial]);

	return (
		<div>
			<div
				class='modal fade'
				id='EditTestimonialModal'
				tabindex='-1'
				aria-labelledby='EditTestimonialModal'
				aria-hidden='true'
			>
				<div class='modal-dialog'>
					<div class='modal-content'>
						<div class='modal-header'>
							<h5 class='modal-title' id='exampleModalLabel'>
								Edit Testimonial
							</h5>
							<button
								type='button'
								class='btn-close'
								data-bs-dismiss='modal'
								aria-label='Close'
							></button>
						</div>
						<div class='modal-body' onSubmit={handleSubmitForm}>
							<form>
								<div class='form-group mb-2'>
									<label for='exampleInputEmail1'>Name</label>
									<input
										type='text'
										class='form-control'
										id='exampleInputEmail1'
										aria-describedby='emailHelp'
										placeholder='Enter Name'
										value={testimonialName}
										onChange={(e) => setTestimonialName(e.target.value)}
									/>
								</div>
								<div class='form-group mb-2'>
									<label for='exampleInputEmail1'>Company Name</label>
									<input
										type='text'
										class='form-control'
										id='exampleInputEmail1'
										aria-describedby='emailHelp'
										placeholder='Enter Name'
										value={companyName}
										onChange={(e) => setCompanyName(e.target.value)}
									/>
								</div>
								<div class='mb-2'>
									<label for='exampleFormControlTextarea1'>Description</label>
									<textarea
										class='form-control'
										id='exampleFormControlTextarea1'
										rows='3'
										value={description}
										onChange={(e) => setDescription(e.target.value)}
									></textarea>
								</div>
								<div className='text-end'>
									<button type='button' class='btn btn-secondary me-2' data-bs-dismiss='modal'>
										Close
									</button>
									<button type='submit' class='btn btn-primary'>
										Edit
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default EditTestimonialModal;
