import React, { useState, useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT } from '../../routes/api_routes';
import Loading from '../common/Loading';
import {Link} from 'react-router-dom';
import { notification } from '../../classes/messages';
import { getLoggedInUser } from '../../classes';
import moment from 'moment';

const QuestionFiltered = ({data, newData, handleDeleteQuestion, questionsShow}) => {

	return (
		<>
             {questionsShow? newData.map((data, i) => {
						const odd = i % 2 == 0;
						return (
							<div
								className={`row align-items-center p-2 ${
									odd ? 'bg-table-striped': 'bg-light-blue'
								}`}
							>
								<div className='col-3'>
									<small className='f-r-12'>{data.question}</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-2'>
									<small className='f-r-12'>{data?.question_type}</small>
								</div>
								<div className='col-4'>
									<small className='f-r-12'>{moment(data?.created_at).format('MMMM Do YYYY h:mm a')}</small>
								</div>
								<div className='col-3 text-center'>
									<div className='justify-content-end'>
										<Link to={`/edit-question/${data.id}`} className='btn btn-sm ms-2  border f-r-12 ' className='f-r-12'>
											<i class='fas fa-edit fs-10'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2 f-r-12'
											onClick={() => handleDeleteQuestion(data.id)}
										>
											<i class='fas fa-trash fs-10'></i>
										</button>
									</div>
								</div>
							</div>
						);
					}): 
                    data?.data.map((data, i) => {
						const odd = i % 2 == 0;
						return (
							<div
								className={`row align-items-center p-2 ${
									odd ? 'bg-table-striped': 'bg-light-blue'
								}`}
							>
								<div className='col-3'>
									<small>{data.question}</small>
								</div>
								{/* <div className='col-2'>
									<small>{data?.category}</small>
								</div>
								<div className='col-2'>
									<small>{data?.tags}</small>
								</div> */}
								<div className='col-3'>
									<small>{data?.question_type}</small>
								</div>
								<div className='col-4'>
									<small>{moment(data?.created_at).format('MMMM Do YYYY h:mm a')}</small>
								</div>
								<div className='col-2 text-center'>
									<div className=' justify-content-end'>
										<Link to={`/edit-question/${data.id}`} className='btn btn-sm  ms-2  border f-r-12'>
											<i class='fas fa-edit'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border ms-2 f-r-12'
											onClick={() => handleDeleteQuestion(data.id)}
										>
											<i class='fas fa-trash'></i>
										</button>
									</div>
								</div>
							</div>
						);
					})
                }
		</>
	);
};

export default QuestionFiltered;
