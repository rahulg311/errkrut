import { React, useEffect, useState } from "react";
import Loading from "../common/Loading";
import moment from "moment";
import { EditUserModal } from "./EditUserModal";

const CandidateList = ({ data, loading, handleSingleCheck, handleAllCheck, isChecked }) => {

  return (
    <div className="col-md-12 mt-3">
      <div>
        <header className="row bg-primary text-white p-1 rounded-top shadow">
          <div className=" col-1 d-flex justify-content-between align-item-center p-00 p-0">
            <span><input type="checkbox" onChange={handleAllCheck} /></span>
          </div>

          <div className=" col-2 d-flex justify-content-between align-item-center p-00">
            <span className="d-flex  f-r-12">Name   <i className="fas fa-sort mt-4px ms-1 f-r-12"></i></span>

          
          </div>

          <div className=" col-3 d-flex justify-content-between align-item-center p-00">
            <span className="d-flex f-r-12 ">Key Skills   <i className="fas fa-sort mt-4px ms-1 f-r-12"></i></span>
          </div>


          <div className=" col-3 d-flex justify-content-between align-item-center p-00">
            <span className="d-flex f-r-12 ">Experience   <i className="fas fa-sort mt-4px ms-1 f-r-12"></i></span>

          
          </div>
          <div className=" col-3 d-flex justify-content-between align-item-center p-00">
            <span className="d-flex f-r-12">Location   <i className="fas fa-sort mt-4px ms-1 f-r-12"></i></span>

          </div>
        </header>
        <main>
          {loading ? (
            <Loading className="my-3" />
          ) : data && data.length ? (
            <>
              {data.map((profile, idx) => {
                const even = idx % 2 == 0;
                return (
                  <div
                    className={`row align-items-center  ${even ? "bg-light-blue" : "bg-table-striped"
                      }`}
                  >
                    <div className="col-1 col-lg-1 p-00 ps-1">
                      <input type="checkbox" checked={isChecked.includes(parseInt(profile?.id))} value={profile?.id} name={profile?.name} onChange={handleSingleCheck} />
                    </div>

                    <div className="col-3 col-lg-2 p-00">
                      <small className=" f-r-12 text-break  ">{profile?.name}</small>
                    </div>

                    <div className="col-3 col-lg-3 p-00">
                      <small className="text-break f-r-12" >{profile?.skill_set}</small>
                    </div>
                    
                    <div className="col-2 col-lg-3 p-00">
                      <small className=" f-r-12 ">{profile.experience}</small>
                    </div>
                    
                    <div className="col-3 col-lg-3 p-00">
                      <small className=" f-r-12 ">{profile.location}</small>
                    </div>

                  </div>
                );
              })}
            </>
          ) : (
            <div className="row justify-content-center align-items-center p-4 bg-light-blue">
              <div className="text-center font-bold text-sky-blue">
                No Candidate have been added here
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CandidateList;
