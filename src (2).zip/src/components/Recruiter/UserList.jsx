import { React, useEffect, useState } from "react";
import Loading from "../common/Loading";
import moment from "moment";
import { EditUserModal } from "./EditUserModal";

const UserList = ({ data, loading, handleStudentRowAPI, handleSingleCheck, handleAllCheck, handleSingleAssessment, isChecked }) => {

  return (
    <div className="col-md-12 mt-3">
      <div>
        <header className="row text-white rounded-top shadow">
        <table class="table border-none1 bg-primary ">
  <thead>
    <tr className="border-none1">
      <th scope=""><input className="f-10" type="checkbox" onChange={handleAllCheck} /></th>
      <th scope="col">   <span className="f-r-12 d-flex text-white ">Name <i className=" fas fa-sort mt-4px f-r-12 ms-1"></i></span></th>
      <th scope="col">  <span className="f-r-12 d-flex text-white">Key.Skills <i className="fas ms-1 fa-sort mt-4px f-r-12"></i></span></th>
     
     <th scope="col">            <span className="f-r-12 d-flex text-white">Date   <i className="fas ms-1 fa-sort mt-4px f-r-12"></i></span></th>
    <th scope="col"> <span className="f-r-12 d-flex text-white">Status    <i className="fas fa-sort mt-4px f-r-12 ms-1"></i></span></th>
    </tr>
  </thead>
  </table>
          {/* <div className=" col-1 d-flex justify-content-between align-item-center">
            <span className="f-r-12"><input className="f-r-12" type="checkbox" onChange={handleAllCheck} /></span>
          </div>
          <div className=" col-2 d-flex justify-content-between align-item-center">
            <span className="f-r-12 d-flex ">Name <i className=" fas fa-sort mt-4px f-r-12 ms-1"></i></span>

            
          </div>

          <div className=" col-4 d-flex justify-content-between align-item-center">
            <span className="f-r-12 d-flex">Key-Skills <i className="fas ms-1 fa-sort mt-4px f-r-12"></i></span>

            
          </div>
          <div className=" col-2 d-flex justify-content-between align-item-center">
            <span className="f-r-12 d-flex">Date   <i className="fas ms-1 fa-sort mt-4px f-r-12"></i></span>

          
          </div>
          <div className=" col-2 d-flex justify-content-between align-item-center">
            <span className="f-r-12 d-flex">Status    <i className="fas fa-sort mt-4px f-r-12 ms-1"></i></span>

         
          </div>
          <div className=" col-2 d-flex justify-content-between align-item-center">

          </div> */}
        </header>
        <main>
          {loading ? (
            <Loading className="my-3" />
          ) : data && data.length ? (
            <>
              {data.map((profile, idx) => {
                const even = idx % 2 == 0;
                return (
                  <div
                    className={`row align-items-center p-2 ${even ? "bg-light-blue" : "bg-table-striped"
                      }`}
                  >
                    <div className="col-1">
                      <input type="checkbox" checked={isChecked.includes(parseInt(profile?.id))} value={profile?.id} name={profile?.name} onChange={handleSingleCheck} />
                    </div>
                    <div className="col-3">
                      <small>{profile?.name}</small>
                    </div>

                    <div className="col-2">
                      <small>{profile?.key_skills}</small>
                    </div>
                    <div className="col-3">
                      <small>
                        {profile?.created_at &&
                          moment(profile?.created_at).format(
                            "MMMM Do YYYY h:mm a"
                          )}
                      </small>
                    </div>
                    <div className="col-2 d-flex justify-content-between">
                      <div className="">
                        <small>{profile.status}</small>
                      </div>

                    </div>
                    <div className="col-1 d-flex justify-content-between">
                      <div className="">
                        <EditUserModal handleSingleAssessment={handleSingleAssessment} profile={profile} handleStudentRowAPI={handleStudentRowAPI} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          ) : (
            <div className="row justify-content-center align-items-center p-4 bg-light-blue">
              <div className="text-center font-bold text-sky-blue">
                No Users have been added here
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default UserList;
