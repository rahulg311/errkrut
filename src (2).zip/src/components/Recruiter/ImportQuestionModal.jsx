import { useEffect, useState } from "react";
import { END_POINT, GET_QUESTION_SAMPLE } from "../../routes/api_routes";
import useFetch from "../../hooks/useFetch";
import { useRef } from "react";


const ImportQuestionModal = ({ is_modal, closeModal, handleSubmit }) => {
    const { data, loading, error, doFetch } = useFetch();
    const [jobData, setJobData] = useState(null);

    useEffect(() => {
        getTemplateUrl();
    }, []);

    const handleFileUpload = (e) => {
        setJobData(e.target.files[0])
    };

    const getTemplateUrl = () => {
        doFetch(END_POINT + `${GET_QUESTION_SAMPLE}`);
    };

    return (
        is_modal && (
            <>
                <div className="modal fade-in" style={{ display: "block" }}>
                    <div
                        className="modal-dialog modal-dialog-centered modal-lg"
                        role="document"
                    >
                        <div className="modal-content">
                            <form
                                onSubmit={(e) => {
                                    e.preventDefault();
                                    handleSubmit(jobData);
                                }}
                            >
                                <div className="modal-header align-items-center d-flex justify-content-between border-0">
                                    <a
                                        href={`${data}`}
                                        className="btn-sm ps-4 pe-4 poppins-medium" download
                                    >
                                        Download the excel template
                                    </a>
                                    <span
                                        classNameName="f-2 cursor"
                                        onClick={(e) => closeModal()}
                                    >
                                        &times;
                                    </span>
                                </div>
                                <div className="modal-body">
                                    <div className="d-flex flex-column align-items-start">
                                        <div class="mb-3">
                                            <div className="d-flex ps-4 pe-4 flex-column justify-content-between">
                                                <label htmlFor="" className="text-sky-blue py-1">
                                                    Select File
                                                </label>
                                                <div class="input-group mb-3">
                                                    <input
                                                        type="file"
                                                        class="form-control  input_file"
                                                        id="inputGroupFile02"
                                                        hidden
                                                        accept=".xls,.xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                                                        onChange={handleFileUpload}
                                                    />
                                                    <span className="input_file p-1">{jobData?.name}</span>
                                                    <label
                                                        class="input-group-text btn btn-primary rounded-0 btn-sm ps-4 pe-4 pt-1 poppins-bold"
                                                        for="inputGroupFile02"
                                                    >
                                                        Browse File
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer border-0">
                                    <button
                                        type="button"
                                        className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                                        onClick={(e) => closeModal()}
                                    >
                                        Close
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                                    >
                                        Import Question
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div className="modal-backdrop fade show"></div>
            </>
        )
    );
};

export default ImportQuestionModal;
