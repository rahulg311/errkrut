import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { END_POINT } from './../../routes/api_routes';
import { notification } from './../../classes/messages';
import useFetch from './../../hooks/useFetch';
import Loading from './../../components/common/Loading';
import { getLoggedInUser } from '../../classes';
import { getAuthToken } from '../../classes/index';

const Members = () => {
	const { data, loading, error,doFetch } = useFetch();
	const [user, setUser] = useState({});
	useEffect(async() =>{
		const user=await getLoggedInUser()
		setUser(user)
		doFetch(END_POINT + `getall_members/${user.id}`);
	},[])

	const handleDelete = async(id) => {
		let token = await getAuthToken();
		const url = END_POINT + 'delete_member/' + id;
		var requestOptions = {
			method: 'POST',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};
		fetch(url, requestOptions)
			.then((res) => res.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({
						message: data.message,
						type: 'success',
					});
					notify();
					doFetch(END_POINT + `getall_members/${user.id}`);
				}
			})
			.catch((err) => console.log(err));
	};

	return (
		<div className='container mt-2 '>
			<table class='table	'>
				<thead className='shadow-none bg-primary text-white'>
					<tr>
						<th  scope='col' className='f-r-8'>#</th>
						<th scope='col' className='f-r-8'>Name</th>
						<th scope='col' className='f-r-8'>email</th>
						<th scope='col' className='f-r-8'>designation</th>
						<th scope='col' className='f-r-8'>access_level</th>
						<th scope='col' className='f-r-8'></th>
						
					</tr>
				</thead>
				<tbody>
					{loading ? (
						<Loading />
					) : (
						data?.data.map((member, index) => {
							return (
								<tr>
									<th scope='row 'className='f-r-8' >{index + 1}</th>
									<td className='f-r-8'>{member.name}</td>
									<td className='f-r-8'>{member.email}</td>
									<td className='f-r-8'>{member.designation}</td>
									<td className='f-r-8'>{member.access_level}</td>
									<td className=' d-flex p-0 pt-1'>
										<Link
											to={`/add-member`}
											className='btn btn-sm  border p-0'
										>
											<i class='fas fa-edit f-r-8'></i>
										</Link>
										<button
											className='btn btn-sm text-danger border p-0 ms-2  '
											onClick={() => handleDelete(member.id)}
										>
											<i class='fas fa-trash f-r-8 '></i>
										</button>
									</td>
								</tr>
							);
						})
					)}
				</tbody>
			</table>
		</div>
	);
};

export default Members;
