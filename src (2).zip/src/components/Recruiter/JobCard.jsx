import React from 'react'
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getValueFromArr } from '../../classes';
import PostedOn from '../PostedOn';

const JobCard = ({ job, deleteJob }) => {

	return (
		<div className='cards position-relative mt-4 w-100 br-5 pt-3 pb-3 ps-4 pe-4 shadow  rounded-4 overflow-hidden'>
			<div className='d-flex align-items-center'>
				<div className='me-2'>
					<img src={(job?.logo) ? JSON.parse(job?.logo, 0) : `/assets/imgs/dummy-logo.png`} className='img-fluid box-shadow br-5 h-60p' />
				</div>
				<div className=''>
					<h5 className='font-bold mb-1'>{job.job_title}</h5>
					<p>{job.company_name}</p>
				</div>
				<div className='ms-auto'>
					<i className='la la-trash fs-28 cursor text-danger abs-centery-y' onClick={() => deleteJob(job?.id, job?.company_id)}></i>
				</div>
			</div>

			<div className='pe-3'>
				<div className='row mt-2 mb-1'>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-12'>
								<p className=' m-0 f-0-8 '>
									<span className='me-1 vertical-middle font-bold text-sky-blue'>
										<i class='las la-briefcase  text-sky-blue f-1-1'></i>
									</span>
									<span className='font-bold text-sky-blue'>Experience</span>
									<span className='ps-1'>{job.min_work_exp}-{job.min_work_exp} Years</span>
								</p>
							</div>
						</div>
					</div>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-12'>
								<p className=' m-0 f-0-8 '>
									<span className='me-1 vertical-middle font-bold text-sky-blue'>
										<i class='las la-map-marker  text-sky-blue f-1-1'></i>
									</span>
									<span className='font-bold text-sky-blue'>Location</span>
									<span className='ps-1'>{job.city}</span>
								</p>
							</div>
						</div>
					</div>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-12 '>
								<p className=' m-0 f-0-8 '>
									<span className='me-1 vertical-middle font-bold text-sky-blue'>
										<i class='las la-rupee-sign text-sky-blue f-1-1'></i>
									</span>
									<span className='font-bold text-sky-blue'>Salary</span>
									<span className='ps-1'>{job.ctc_from} - {job.ctc_to} L.P.A</span>
								</p>
							</div>
						</div>
					</div>
				</div>

				<div className='row mt-1 mb-1'>
					<div className='col-md-12'>
						<div className='row'>
							<div className='col-md-2 col-5 '>
								<p className='font-bold m-0 f-0-8 text-sky-blue'>
									<span className='me-1 vertical-middle'>
										<i class='las la-briefcase  text-sky-blue f-1-1'></i>
									</span>
									<span>Skillset</span>
								</p>
							</div>
							<div className='col-md-9 col-7 ps-0'>
								<p className='m-0 f-0-8 text-break'>{job.skill_set}</p>
							</div>
						</div>
					</div>
				</div>
				<div className='row mt-1 mb-1'>
					<div className='col-md-3'>
						<div className='row'>
							<div className='col-md-12'>
								<p className='m-0 f-0-8'>
									<span className='me-1 vertical-middle font-bold text-sky-blue'>
										<i class='las la-user-check text-sky-blue f-1-1'></i>
									</span>
									<span className='font-bold text-sky-blue'>Vacancy</span>
									<span className='ps-1'>{job.number_of_vaccancy}</span>
								</p>
							</div>
						</div>
					</div>

					<div className='col-md-6'>
						<div className='row'>
							<div className='col-md-12'>
								<p className='m-0 f-0-8'>
									<span className='me-1 vertical-middle font-bold text-sky-blue'>
										<i class='las la-file-invoice text-sky-blue f-1-1'></i>
									</span>
									<span className='font-bold text-sky-blue'>Candidates Applied</span>
									<span className='ps-1'>{job?.candidates_applied}</span>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className='row mt-2 mb-2'>
				<div className='col-md-12'>
					{job?.skill_set?.split(',').map((value) => {

						return <span class="badge badge-default cursor me-1 f-Poppins-Medium"><a href={`/search/${value}`}> {value} </a></span>

					})}
				</div>
			</div>
			<div className='row mt-2 mb-2'>
				<div className='col-md-3 mb-2'>
					<div className='cards bg-greenesh-blue br-5 text-white p-1 h-100'>
						<div className='row'>
							<div className='col-md-4'>{job?.likes}</div>
							<div className='col-md-8 text-end'>Likes</div>
						</div>
					</div>
				</div>
				<div className='col-md-3 mb-2'>
					<div className='cards bg-blue br-5 text-white p-1 h-100'>
						<div className='row'>
							<div className='col-md-4'>{job?.candidates_applied}</div>
							<div className='col-md-8 text-end'>Candidates Applied</div>
						</div>
					</div>
				</div>
				<div className='col-md-3 mb-2'>
					<div className='cards bg-purple br-5 text-white p-1 h-100'>
						<div className='row'>
							<div className='col-md-4'>{job?.quiz_taken}</div>
							<div className='col-md-8 text-end'>Quiz Taken</div>
						</div>
					</div>
				</div>
				<div className='col-md-3 mb-2'>
					<div className='col-md-12 cards bg-warning br-5 text-white p-1 h-100'>
						<div className='row'>
							<div className='col-md-4'>{job?.saved}</div>
							<div className='col-md-8 text-end'>Saved</div>
						</div>
					</div>
				</div>
			</div>
			<div className='row mt-2 mb-2 align-items-center'>
				<div className='col-md-4 mb-4 d-flex'>
					<div className=''>
						<img src='/assets/imgs/fire.png' className='w-28px' />
					</div>

					<div className='ms-2'>
						<span className=' text-dark-gray'><PostedOn date={job.created_at} /> </span>
					</div>
				</div>

				<div className='col-md-8'>
					<div className='ms-auto float-end '>
						<Link
							className='btn btn-sm ps-4 pe-4 me-2 btn-border'
							to={`/edit-job/${job.id}`}
						>
							Edit
						</Link>
						<Link
							className='btn btn-primary btn-sm ps-4 pe-4'
							to={`/jobstats`}
						>
							View Stats
						</Link>
					</div>

				</div>
			</div>
		</div>
	);
};

export default JobCard
