import React, { useEffect } from 'react';
import JobCard from './JobCard';

import { useDispatch, useSelector } from 'react-redux';
import { getAllJobs } from '../../store/actions/jobs';
import { getLoggedInUser } from '../../classes';
import { getAuthToken } from '../../classes/index';
import { END_POINT, DELETE_JOB } from "../../routes/api_routes";
import { notification } from '../../classes/messages';
const Jobs = () => {
	const { jobsData: jobData } = useSelector((state) => state.common);

	const dispatch = useDispatch();

	useEffect(async () => {
		const user = await getLoggedInUser();
		if (user) {
			dispatch(getAllJobs(user.company_id));
		}
	}, []);

	useEffect(async () => {

	}, [jobData]);

	const deleteJob = async (id, company_id) => {
		let token = await getAuthToken();
		var formData = {
			job_id: id,
			company_id: company_id,
		};
		const response = await fetch(END_POINT + DELETE_JOB, {
			method: 'POST',
			body: JSON.stringify(formData),
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token,
				'Content-Type': 'application/json'
			}
		});
		response.json().then((data) => {
			if (data.status == 'success') {
				const notify = notification({ message: data.message, type: 'success' });
				notify();
			}
			else {
				const notify = notification({ message: "Something went Wrong", type: 'error' });
				notify();
			}
		});
	}
	return (
		<div className='col-md-12'>
			<div class='tab-content'>
				<div id='jobs' class='tab-pane active'>
					<div className='row'>
						<div className='col-md-12'>
							{jobData.data?.length >= 1 &&
								jobData.data.map((job) => {
									return <JobCard job={job} deleteJob={deleteJob} ></JobCard>;
								})}
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Jobs;
