import { useEffect, useState } from "react";
import { END_POINT, GET_ASSESSMENT, SEND_ASSESSMENT } from "../../routes/api_routes";
import useFetch from "../../hooks/useFetch";
import usePost from "../../hooks/usePost";
import { useRef } from "react";
import { getLoggedInUser, getAuthToken } from "../../classes";
import { notification } from '../../classes/messages';
import Select from 'react-select';

const AddAssessmentModal = ({ is_modal, closeModal, isChecked, alluserlist }) => {
    const options = [];

    const { data, loading, errors, doFetch } = useFetch();
    const { response, isLoading, error, doPost } = usePost();
    const AssessmentList = useFetch();
    const [selectedUser, setselectedUser] = useState([]);
    const defaultdata = [];
    const getAssessmentList = async () => {
        const user = await getLoggedInUser();
        await AssessmentList.doFetch(END_POINT + `${GET_ASSESSMENT}/${user.company_id}`);
    };
    const [selectedassessment, setselectedassessment] = useState(1);
    const handleSelectedAssessment = e => {
        setselectedassessment(e.target.value);
    };

    useEffect(() => {
        getAssessmentList();

    }, []);
    const handleSubmit = async () => {
        let userlist = [];
        selectedUser.map((user) => { userlist.push(user.value) });
        if (selectedassessment != 0 && userlist.length != 0) {
            const user = await getLoggedInUser();
            let token = await getAuthToken();
            const formData = new FormData();
            formData.append("company_id", user.company_id);
            formData.append("assessment_id", selectedassessment);
            formData.append("students_id", userlist);
            const requestOptions = {
                method: "POST",
                headers: { "Content-Type": "application/json", 'Authorization': 'Bearer ' + token },
            };
            doPost(`${SEND_ASSESSMENT}`, formData, requestOptions);
            const notify = notification({ message: "Assessment Request Send", type: 'success' });
            notify();
            closeModal();
        }
        else {
            const notify = notification({ message: "Please Select Valid Data", type: 'error' });
            notify();
        }

    };
    return (
        is_modal && (
            <>
                <div className="modal fade-in" style={{ display: "block" }}>
                    <div
                        className="modal-dialog modal-dialog-centered modal-lg"
                        role="document"
                    >
                        <div className="modal-content">
                            <form
                                onSubmit={(e) => {

                                    e.preventDefault();
                                    handleSubmit();
                                }}
                            >
                                <div className="modal-header align-items-center d-flex justify-content-between border-0">
                                    <h2>
                                        Send Assessment
                                    </h2>
                                    <span
                                        classNameName="f-2 cursor"
                                        onClick={(e) => closeModal()}
                                    >
                                        &times;
                                    </span>
                                </div>
                                <div className="modal-body">
                                    <div className='bg-white pt-4 pb-4 px-2 rounded-4 mt-2'>
                                        <div className='container'>
                                            <div className='w-75 w-100-xs'>
                                                <div className='row'>
                                                    <div className='col-12'>
                                                        <label for="exampleInputEmail1" class="form-label text-primary">Select Assessment</label>

                                                        <select onChange={handleSelectedAssessment} class="form-select" aria-label="Default select example">
                                                            <option value="">
                                                                Select Assissment
                                                            </option>
                                                            {
                                                                AssessmentList?.data?.data.map((ass, id) => {
                                                                    return (
                                                                        <option value={ass.id}>
                                                                            {ass.title}
                                                                        </option>
                                                                    );
                                                                })
                                                            }
                                                        </select>
                                                    </div>
                                                    <div className='col-12 mt-2'>
                                                        <label for="exampleInputEmail1" class="form-label text-primary">Select Candidates</label>
                                                        {

                                                            alluserlist.map((user, id) => {
                                                                if (isChecked.includes(user.id)) {
                                                                    defaultdata.push({ "value": user.id, "label": user.name });
                                                                }
                                                                options.push({ "value": user.id, "label": user.name })

                                                            }),
                                                            (selectedUser.length == 0 && isChecked.length != 0) && setselectedUser(defaultdata)
                                                        }
                                                        <Select
                                                            defaultValue={defaultdata}
                                                            onChange={setselectedUser}
                                                            options={options}
                                                            isMulti={true}
                                                        />

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer border-0">
                                    <button
                                        type="button"
                                        className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                                        onClick={(e) => closeModal()}
                                    >
                                        Close
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                                    >
                                        Send Assessment
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="modal-backdrop fade show"></div>
            </>
        )
    );
};

export default AddAssessmentModal;
