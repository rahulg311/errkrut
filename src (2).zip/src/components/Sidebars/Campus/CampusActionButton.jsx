import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getLoggedInUser } from '../../../classes';
import { Recruiter_User_Type_ID } from '../../../config/constants';

class CampusActionButtons extends Component {

	render() {
		return (
			<>
					<div className="mt-3 mb-5">
						<div className="row mx-0">
							{/* columns */}
							<div className="col-md-4 ps-0">
								{/* Cards  */}
								<NavLink to="/profile" className="text-white">
									<div className="cards d-flex item-center position-relative mt-2 bg-blue br-5 text-white p-1 h-10vh mr-2 cursor">
										<p className="f-0-7  m-0 w-100 text-center font-bold ">Upload CV </p>
										<span className="f-1 font-bold vertical-middle">+</span>
									</div>
								</NavLink>
								{/* Cards */}
							</div>
							{/* columns */}

							{/* columns */}
							<div className="col-md-4 ps-0">
								{/* Cards */}
								<NavLink to="/send-company-invite" className="text-white">
									<div className="cards d-flex item-center position-relative mt-2 bg-purple br-5 text-white p-1 h-10vh mr-2 cursor" >
										<p className="f-0-7  m-0 w-100 text-center font-bold ">Add Company invite </p>
										<span className="f-1 font-bold vertical-middle">+</span>
									</div>
								</NavLink>
								{/* Cards */}
							</div>
							{/* columns */}

							{/* columns */}
							<div className='col-md-4 ps-0'>
								{/* Cards */}
								<NavLink to='/add-coordinator' className='text-white'>
									<div className='cards d-flex item-center position-relative mt-2 bg-dark-pink br-5 text-white  h-10vh mr-2 cursor'>
										<p className='f-0-7  m-0 w-100 text-center font-bold '>Add Coordinators </p>
										<span className='f-1 font-bold vertical-middle'>+</span>
									</div>
								</NavLink>
								{/* Cards */}
							</div>
							{/* columns */}
						</div>
					</div>
				
			</>
		);
	}
}

export default CampusActionButtons;
