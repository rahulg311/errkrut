import React, { Component } from 'react';

class RightSidebar extends Component {

    render() {

        return (

            <div>

            </div>


        );

    }


}

export default RightSidebar;