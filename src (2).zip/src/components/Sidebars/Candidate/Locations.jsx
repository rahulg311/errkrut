import React, { Component } from 'react';
import { getLocations } from '../../../store/actions/locations';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { isRecruiter } from '../../../classes';

class Locations extends Component {

    state = {
        locations: []
    }


    componentDidMount() {

        this.getLocations();

    }

    getLocations = async () => {
        await this.props.getLocations();
        this.setState({
            locations: this.props.location_res.data
        });
    }


    render() {
        return (
            <>
                {!isRecruiter() &&
                    <div className="row mx-0 mt-4">
                        <div className="col-md-12 p-0">
                            <div className="bg-white mb-4 pt-3 pb-3 px-3 br-5">
                                <h6>
                                    <span className="font-bold">Search By Locations</span>
                                </h6>

                                <div className="row mt-2">
                                    <div className="col-md-12">
                                        {this.state.locations && Object.keys(this.state.locations).map((key) => {
                                            return <span class='badge badge-default cursor me-1 mb-1'>
                                                <NavLink to={`/search/${this.state.locations[key]}`}> {this.state.locations[key]} </NavLink>
                                            </span>
                                        })}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        );

    }
}


const mapStateToProps = (state) => {
    //console.log(state);
    const { location_res } = state.common
    return {
        location_res
    }
};
function mapDispatchToProps(dispatch) {
    return {
        getLocations: () => dispatch(getLocations()),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Locations);