import React, { Component } from 'react';
import { getCompanies } from '../../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { isRecruiter, getValueFromArr } from '../../../classes';

class FeaturedCompanies extends Component {

	state = {
		top_companies: [],
	};


	componentDidMount() {
		this.getTopCompanies();
	}

	getTopCompanies = async () => {
		await this.props.getCompanies();
		console.log(this.props.data);
		if (this.props.data?.status == 'success') {
			this.setState({
				top_companies: this.props.data.data,
			});
		}
	};


	render() {
		return (
			<>
				{!isRecruiter() &&
					<div className="mt-5">
						<div className='row mx-0'>
							<div className='col-md-12 p-0'>
								<div className='bg-white rounded mb-2 pt-3 pb-3 px-3'>
									<h6 className='mb-3'>
										<span className='font-bold'>Featured Companies</span>
									</h6>

									<div className='row gy-4 bg-white '>

										{this.state.top_companies.length > 0 && this.state.top_companies?.map((tc, i) => {
											return i < 8 && <div className='col-4'>
												<NavLink to={`/company/` + tc.id}>
													<img
														src={(tc?.logo) ? getValueFromArr(tc?.logo,0) : `/assets/imgs/dummy-logo.png`}
														className="img-fluid w-100 shadow br-5 h-40px box-shadow"
													/>
												</NavLink>
											</div>;
										})}

									</div>


								</div>
							</div>
						</div>
					</div>
				}
			</>
		);

	}
}

const mapStateToProps = (state) => {
	const { data } = state.common;
	return {
		data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		getCompanies: () => dispatch(getCompanies()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(FeaturedCompanies);