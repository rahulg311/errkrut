import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { getSkills } from '../../../store/actions/skills';
import { connect } from 'react-redux';
import { isRecruiter } from '../../../classes';

class Skills extends Component {

	state = {
		skills: []
	}

	componentDidMount() {

		this.getSkills();

	}

	getSkills = async () => {
		await this.props.getSkills();
		this.setState({
			skills: this.props.skillsdata.data
		});
	}

	render() {
		return (
			<>
				{!isRecruiter() &&
					<div className='mt-45px'>
						<div className='row mx-0'>
							<div className='col-md-12 p-0'>
								<div className='bg-white pt-3 pb-3 px-3 br-5'>
									<h6>
										<span className='font-bold '>Search By Skill</span>
									</h6>

									<div className='row'>
										<div className='col-md-12 mt-2'>

											{this.state.skills && Object.keys(this.state.skills).map((key) => {
												return <span class='badge badge-default cursor me-1 mb-1'>
													<a href={`/search/${this.state.skills[key]}`}> {this.state.skills[key]} </a>
												</span>
											})}

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				}
			</>
		);

	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { skillsdata } = state.common
	return {
		skillsdata
	}
};
function mapDispatchToProps(dispatch) {
	return {
		getSkills: () => dispatch(getSkills()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(Skills);