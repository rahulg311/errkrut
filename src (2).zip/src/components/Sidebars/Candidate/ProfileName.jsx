import React, { Component } from 'react';
import ProfileStrength from './ProfileStrength';

import { getProfile } from '../../../store/actions/profile';

import { getLoggedInUser, isRecruiter } from '../../../classes/index';

import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import { } from '../../..//';

class ProfileName extends Component {
	state = {
		profile: null,
		user_id: null
	};

	componentWillMount() {
		this.getUserId();
	}

	getUserId = async () => {
		const result = await getLoggedInUser();
		if (result)
			this.setState(
				{
					user_id: parseInt(result?.id),
					company_name: result?.company_name
				},
				async () => {
					await this.getProfile();
				},
			);
	};

	getProfile = async () => {
		let id = this.state.user_id;
		await this.props.getProfile(id);
		if (this.props.data) {
			this.setState({
				profile: this.props.data.user_data,
			});
		}
	};

	render() {
		return (
			<>
				<div className='d-flex justify-content-between'>
					<div>
						<h5>
							<span className='font-bold'>
								Hello  {this.state.profile && this.state.profile?.name} {this.state.user_id == null && <span>User</span>}
							</span>
							<span>
								<img src='/assets/imgs/hand-wave.png' className='img-fluid h-26px' />
							</span>
						</h5>
						<p>{isRecruiter() && this.state?.company_name && this.state?.company_name}{!isRecruiter() ? this.state.profile?.designation : ''}</p>
					</div>

					{this.state.user_id != null &&
						<Link to={!isRecruiter() ? "/edit-profile" : `/edit-company-profile/:${this.state.user_id}`}>
							<i class='fas fa-edit fs-20'></i>
						</Link>
					}

				</div>

				<>
					{/* strength */}

					<div className='mt-3 mb-3'>

						<p className='d-flex justify-content-between'>
							<span className='font-bold mr-2'>Profile Strength</span>
							<span className='font-bold text-primary'>
								{this.state.profile && this.state.profile.strength}{this.state.user_id == null && `--`}%
							</span>
						</p>

						<div class='progress mt-1 h-13px'>
							<div
								class='progress-bar  bg-primary'
								style={{ width: `${(this.state.user_id == null) ? 60 : this.state.profile && this.state.profile.strength}%` }}
							></div>
						</div>

					</div>

					{this.state.user_id != null &&
						<div className='mt-3 mb-3'>

							<p className='d-flex justify-content-between f-0-8'>
								<span className='font-bold mr-2 text-danger float-left'>
									{this.state.profile && this.state.profile.missing_details} Details Missing
								</span>{' '}

								<Link to={!isRecruiter() ? "/edit-profile" : `/edit-company-profile/:${this.state.user_id}`}>
									<span className='font-bold text-dark float-right cursor'>Add Details</span>
								</Link>
							</p>

						</div>
					}
					{/* strength */}

					{this.state.user_id == null &&
						<p className="text-danger">You have not logged in</p>
					}

				</>

			</>
		);
	}
}

const mapStateToProps = (state) => {
	const { data } = state.common;
	return {
		data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		getProfile: (id) => dispatch(getProfile(id)),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileName);
