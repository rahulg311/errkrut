import React, { Component } from 'react';
import { getLoggedInUser, isCampus, isRecruiter } from '../../../classes';

class CandidateCards extends Component {

    state = {
        user_id: null
    };

    componentWillMount() {
        this.getUserId();
    }

    getUserId = async () => {
        const result = await getLoggedInUser();

        if (result)
            this.setState(
                {
                    user_id: parseInt(result?.id)
                });
    };

    render() {
        return (
            <>
                {!isRecruiter() && !isCampus() &&
                    <div className="mt-3">
                        <div className="row mx-0">
                            {/* columns */}
                            <div className="col-md-4 p-0 mb-md-0 mb-2">
                                {/* Cards */}
                                <div className="cards position-relative mt-2 bg-blue br-5 text-white p-1 h-100 me-lg-2 d-flex align-items-start flex-column">
                                    <p className="f-1-1 m-0 font-bold text-start">{(this.state.user_id != null) ? 20 : `--`}</p>
                                    <p className="f-0-7 text-end mb-0 mt-auto">Search Apperance</p>
                                </div>
                                {/* Cards */}
                            </div>
                            {/* columns */}

                            {/* columns */}
                            <div className="col-md-4 p-0 mb-md-0 mb-3">
                                {/* Cards */}
                                <div className="cards position-relative mt-2 bg-greenesh-blue br-5 text-white p-1 h-100 me-lg-2 d-flex align-items-start flex-column">
                                    <p className="f-1-1 m-0 font-bold text-start">{(this.state.user_id != null) ? 20 : `--`}</p>
                                    <p className="f-0-7 text-end mb-0 mt-auto">Recruiter's Auction</p>
                                </div>
                                {/* Cards */}
                            </div>
                            {/* columns */}

                            {/* columns */}
                            <div className="col-md-4 p-0 mb-md-0 mb-3">
                                {/* Cards */}
                                <div className="cards position-relative mt-2 bg-warning br-5 text-white p-1 h-100 d-flex align-items-start flex-column">
                                    <p className="f-1-1 m-0 font-bold text-start">{(this.state.user_id != null) ? 20 : `--`}</p>
                                    <p className="f-0-7 text-end mb-0 mt-auto w-100">Messages</p>
                                </div>
                                {/* Cards */}
                            </div>
                            {/* columns */}
                        </div>
                    </div>
                }
            </>
        );

    }
}


export default CandidateCards;