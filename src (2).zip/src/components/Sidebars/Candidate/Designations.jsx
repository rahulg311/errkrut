import React, { Component } from 'react';
import { getDesignation } from '../../../store/actions/designation';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { isRecruiter } from '../../../classes';

class Designations extends Component {

	state = {
		designations: [],
	};


	componentDidMount() {
		this.getDesignations();
	}

	getDesignations = async () => {
		await this.props.getDesignation();
		//console.log(this.props.designations_data);
		if (this.props.designations_data?.status == 'success') {
			this.setState({
				designations: this.props.designations_data.data,
			});
		}
	};

	render() {
		return (
			<>
				{!isRecruiter() &&
					<div className="mt-3">
						<div className='row mx-0'>
							<div className='col-md-12 p-0'>
								<div className='bg-white rounded pt-3 pb-3 px-3 '>
									<h6>
										<span className='font-bold'>Search By Designation</span>
									</h6>

									<div className='row mt-2'>
										<div className='col-md-12'>
											{this.state.designations && Object.keys(this.state.designations).map((key) => {
												return<span class='badge badge-default cursor me-1 mb-1'> <a href={`/search/${this.state.designations[key]}`}>
													{this.state.designations[key]}
												</a></span>
											})}


										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				}
			</>
		);

	}
}


const mapStateToProps = (state) => {
	const { designations_data } = state.common;
	return {
		designations_data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		getDesignation: () => dispatch(getDesignation()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(Designations);