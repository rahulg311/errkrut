import React, { Component } from 'react';

class ProfileStrength extends Component {

    render() {

        const {profileData} = this.props;

        return (
					<>
					</>
				);
    }

}

export default ProfileStrength;