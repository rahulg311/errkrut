import { connect } from "react-redux";
import { isRecruiter } from "../../../classes";

const QuizStatus = ({ quiz_status_data, finishExam }) => {
  console.log(quiz_status_data)
  const QuizStatusCard = ({status, question_number}) => {
    return (
      <div className={`quiz-status-card ${status == 3 ? "not-attempted-status": status == 2 ? "skip-status" : "attempted-status" }`}>
        <p className="font-bold fs-18 f-Poppins-Medium">{question_number}</p>
      </div>
    );
  };

  const QuizSection = ({ sectionTitle, sectionData }) => {

    return (
      <>
        <div className="mt-3">
          <p className="font-bold fs-16  mt-2 f-Poppins-Medium">
            {sectionTitle}
          </p>
          <div className="mt-2 d-flex">
            {sectionData &&
              sectionData.length > 0 &&
              sectionData.map((cardData, idx) => (
                <QuizStatusCard
                  key={cardData.question_id}
                  status={cardData.status}
                  question_number={idx+1}
                />
              ))}
          </div>
        </div>
      </>
    );
  };

  return (
    <>
    
        <div className="row mx-0">
          <div className="col-md-12 p-0">
            <div className="bg-white mb-4 pt-3 pb-3 px-3 br-5">
              <div className="d-flex">
                <div className="mt-2">
                  <img
                    src="/assets/imgs/dummy-logo.png"
                    className="img-fluid box-shadow  h-50px"
                  />
                </div>
                <div className="quiz-title-container">
                  <p className="font-bold fs-16  mt-2 f-Poppins-Medium">
                    UI/UX Designer
                  </p>
                  <p className="fs-14">company name</p>
                </div>
              </div>
              {quiz_status_data && Object.keys(quiz_status_data).length > 0 ? (
                Object.keys(quiz_status_data).map((sectionKey, idx) => (
                  <QuizSection
                    key={idx}
                    sectionData={quiz_status_data[sectionKey].questions}
                    sectionTitle={quiz_status_data[sectionKey].section_title}
                  />
                ))
              ) : (
                <></>
              )}
              <div className="mt-5">
                <button onClick={finishExam} className="btn btn-primary">Finish Exam</button>
              </div>
            </div>
          </div>
        </div>
        
    </>
  );
};

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(QuizStatus);
