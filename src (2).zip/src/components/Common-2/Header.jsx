import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { logout, getLoggedInUser } from '../../classes';
import { routeChanged } from '../../classes/browserHistory';
import { notification } from '../../classes/messages';
import { getFirstCharacterProfile } from '../../classes/profile';
import { Recruiter_User_Type_ID, SEARCH_DATA } from '../../config/constants';
import { APP_Prefix } from '../../config/constants';
import { useHistory } from 'react-router'
import { useDispatch } from 'react-redux';
import CreateModal from '../../views/pages/CompanyTemplates/CreateModal';
const Header = (props) => {
	const [charName, setCharName] = useState('')
	const [isRecruiter, setIsRecruiter] = useState(false);
	const [isLoggedIn, setIsLoggedIn] = useState(false);
	const [value, setValue] = useState('');
	const [modal, setModal] = useState('');
	const dispatch = useDispatch();

	const history = useHistory();

	React.useEffect(async () => {
		const charName = await getFirstCharacterProfile()
		setCharName(charName)
		const result = await getLoggedInUser();
		if (result?.id)
			setIsLoggedIn(true);

		if (result?.user_type == Recruiter_User_Type_ID) {
			setIsRecruiter(true);
		}

	}, [])

	const handleChange = (e) => {
		e.preventDefault();
		if (value !== '') {
			history.push(`/search/${value}`);
			return dispatch({ type: SEARCH_DATA, data: value });
		}

	}

	const openModal = (value) => {
		setModal(value);
	}

	const closeModal = () => {
		setModal('');
	}

	return (
		<>

			{modal == 'createwebsite' && <CreateModal closeModal={() => closeModal()}/>}

			<header>
				<nav className='navbar fixed-top navbar-expand-lg navbar-light bg-ecf0f4'>
					<div className='container'>
						<NavLink activeClassName='active' to='/' className='navbar-brand w-170px'>
							<img src='/assets/imgs/logo.png' className='w-100' />
						</NavLink>
						<button
							className='navbar-toggler'
							type='button'
							data-bs-toggle='collapse'
							data-bs-target='#navbarSupportedContent'
							aria-controls='navbarSupportedContent'
							aria-expanded='false'
							aria-label='Toggle navigation'
						>
							<span className='navbar-toggler-icon'></span>
						</button>
						<div
							className='collapse navbar-collapse align-items-center'
							id='navbarSupportedContent'
						>
							<form action='' onSubmit={handleChange} className='w-lg-lg w-100 mt-lg-0 mt-3 ms-lg-2'>
								<div class='input-group input-group-sm shadow-sm'>
									<input
										type='text'
										class='form-control border-0'
										placeholder='Search Skill, Designation, Company'
										aria-label="Recipient's username"
										aria-describedby='basic-addon2'
										defaultValue={props.location?.search?.term}
										onChange={(e) => setValue(e.target.value)}
									/>
									<button
										type='submit'
										class='btn bg-secondary bg-opacity-15 border-3  input-group-text cursor'
										id='basic-addon2'
									>
										<i class='fas fa-search'></i>
									</button>
								</div>
							</form>
							<ul className='navbar-nav ms-auto mb-2 mb-lg-0 mt-md-0 mt-3'>
								<li className='nav-item me-2'>
									<NavLink activeClassName='active' to='/' exact className='nav-link'>
										Home
									</NavLink>
								</li>

								{isRecruiter == 0 && (
									<li className='nav-item me-2'>
										<NavLink activeClassName='active' to='/search' className='nav-link'>
											Jobs
										</NavLink>
									</li>
								)}

								{isRecruiter == 1 && (
									<li className='nav-item me-2'>
										<NavLink activeClassName='active' to='/plans' className='nav-link'>
											Plans
										</NavLink>
									</li>
								)}

								<li className='nav-item '>
									<NavLink activeClassName='active' to='/contact-us' className='nav-link'>
										Contact Us
									</NavLink>
								</li>
							</ul>
							<section className='ms-md-2 mt-md-0 mt-3'>

								{!isLoggedIn &&
									<>

										<NavLink to="/candidate-signup" className="me-2">Sign Up</NavLink>

										<NavLink to="/login" className="btn btn-primary btn-sm ps-4 pe-4">Login</NavLink>
									</>
								}


								{isLoggedIn &&
									<>
										<button className='btn p-1'>
											<i class='fas fa-comment fs-21'></i>
										</button>
										<button className='btn p-1 mx-2'>
											<i class='fas fa-bell fs-21'></i>
										</button>

										<div class='dropdown d-inline'>
											<button className='btn shadow p-1 dropdown-toggle'>
												<span className='bg-danger px-9px  py-4px rounded me-3px text-light'>
													{charName}
												</span>
											</button>
											<ul class='dropdown-menu' aria-labelledby='dropdownMenuButton1'>

												{isRecruiter == 0 &&
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/profile'
														>
															Profile
														</NavLink>
													</li>
												}

												{isRecruiter == 0 &&
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/my-jobs'
														>
															My Jobs
														</NavLink>
													</li>
												}



												{isRecruiter == 1 && (
													<>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/recruiter'
															>
																Dashboard
															</NavLink>
														</li>
														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/company-profile'
															>
																Profile
															</NavLink>
														</li>
														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/applied-candidates'
															>
																Candidates Applied
															</NavLink>
														</li>
														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-job'
															>
																Add Job
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-quiz'
															>
																Add Quiz
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-question'
															>
																Add Question
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-template'
															>
																Add Template
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-offer-letter'
															>
																Add Offer Letter
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/letter-intent'
																exact
															>
																Add Letter of Intent
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-testimonial'
																exact
															>
																Add Testimonial
															</NavLink>
														</li>

														<li>
															<NavLink
																activeClassName='dropdown-item'
																className='dropdown-item'
																to='/add-member'
																exact
															>
																Add Member
															</NavLink>
														</li>

														<li>
															<a
																href='javascript:void(0);'
																className='dropdown-item'
																onClick={(e) => openModal('createwebsite')}
															>
																Create Website
															</a>
														</li>


													</>
												)}

												<li>
													<NavLink
														activeClassName='dropdown-item'
														className='dropdown-item'
														to='/change-password'
													>
														Change Password
													</NavLink>
												</li>





												<li>
													<a
														activeClassName='dropdown-item'
														className='dropdown-item'
														href='javascript:void(0);'
														onClick={(e) => {
															localStorage.setItem(APP_Prefix + 'auth_token', null);
															localStorage.setItem(APP_Prefix + 'auth_profile', null);
															window.location.reload();
														}}
													>
														Logout
													</a>
												</li>
											</ul>
										</div>
									</>
								}

							</section>
						</div>
					</div>
				</nav>
			</header>
		</>
	);
}

export default Header
