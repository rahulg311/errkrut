import React, { Component } from 'react';
import { getCompanies } from '../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import Slider from 'react-slick';
import { getValueFromArr } from '../../classes';

class CompaniesCard extends Component {

	state = {
		featured_companies: []
	}

	componentDidMount() {
		this.getFeaturedCompanies();
	}

	getFeaturedCompanies = async () => {
		await this.props.getCompanies();
		if (this.props.data?.status == 'success') {
			this.setState({
				featured_companies: this.props.data.data,
			});
		}
	};

	render() {
		/* slick slider settings */
		const settings = {
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 5,
			slidesToScroll: 5,
			autoplay: true,
			autoplaySpeed: 3000,
			centerMode: true,
			centerPadding: "20px",
			responsive: [

				{
					breakpoint: 1025,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 3,
						centerMode: true,
					}
				},
				{
					breakpoint: 600,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						initialSlide: 2,
						centerPadding: "0px",
					}
				},
				{
					breakpoint: 480,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						centerPadding: "0px",
					}
				}
			]
		};
		/* slick slider settings */

		return (
			<section className="rounded-4 bg-white p-4">
				<header className='d-flex justify-content-between mb-3 p-0'>
					<h5>Companies That are Hiring</h5>
					<a className='col-3 col-lg-1' href=''>See All</a>
				</header>
				<main>

					<Slider {...settings}>
						{this.state.featured_companies.length > 0 && this.state.featured_companies?.map((tc, i) => {
							return i < 8 &&
								<div className='cards position-relative my-2 me-3 px-3 rounded-4 '>
									<div className='card d-flex justify-content-center border-0 ' style={{ height: '150px', width: '150px' }}>
										<NavLink to={`/company/` + btoa(tc.id)}>
											{console.log(tc.logo)}
											<img src={(tc.logo) ? getValueFromArr(tc.logo, 0) : `/assets/imgs/dummy-logo.png`} className='img-fluid shadow' />
										</NavLink>
									</div>
								</div>
								;
						})}
					</Slider>


				</main>
			</section>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { data } = state.common
	return {
		data
	}
};

function mapDispatchToProps(dispatch) {
	return {
		getCompanies: () => dispatch(getCompanies())
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(CompaniesCard);
