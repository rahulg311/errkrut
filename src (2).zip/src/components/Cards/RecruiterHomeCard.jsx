import React, { useState } from 'react';
import { getLoggedInUser } from '../../classes';
import { END_POINT } from '../../routes/api_routes';
import { Chart } from "react-google-charts";
import { getAuthToken } from '../../classes/index';
import Select from 'react-select'

const RecruiterHomeCard = () => {

	const [data, setData] = useState({});
	const [graphData, setgraphData] = useState({});
	const jobTitleList = [{ "value": "", "label": "All Job" }];
	const [jobList, setJobList] = useState();

	const LineChartOptions = {
		series: {
			0: { curveType: 'function', legend: { position: 'bottom' } },
			1: { curveType: 'function', legend: { position: 'bottom' } },
		},
		legend: { position: 'bottom', alignment: 'start' }
	}

	React.useEffect(async () => {
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var formdata = new FormData();
		formdata.append('user_id', user.id);
		formdata.append('company_id', user.company_id);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'recruiter_home_data', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				console.log(result);

				setData(result.data);

				let graphData = [['x', 'Candidates Appiled', 'Quiz Taken']]
				if (result.data.candidates_applied.length != 0) {
					for (let i = 0; i < result.data.candidates_applied.length; i++) {
						let quizTake;
						if (result.data.quiz_taken[i] == null || result.data.quiz_taken[i] == undefined) {
							quizTake = 0;
						} else {
							quizTake = result.data.quiz_taken[i].value;
						}
						let temp = [
							result.data.candidates_applied[i].month,
							result.data.candidates_applied[i].value,
							quizTake,
						]
						graphData.push(temp);

					}
					setgraphData(graphData);
				}


				result.data.job_titles.map(row => {
					jobTitleList.push({ "value": row.job_title, "label": row.job_title })
				})
				setJobList(jobTitleList);
			})
			.catch((error) => console.log('error', error));
	}, [])
	async function getGraphData(e) {
		setgraphData('')
		let user1 = await getLoggedInUser();
		let token = await getAuthToken();
		var formdata = new FormData();
		formdata.append('user_id', user1.id);
		formdata.append('company_id', user1.company_id);
		formdata.append('filter', e.value);

		var requestOptions = {
			method: 'POST',
			body: formdata,
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'recruiter_home_data', requestOptions)
			.then((response) => response.json())
			.then((result) => {
				console.log(result.data);
				setData(result.data);
				let graphData = [['x', 'Candidates Appiled', 'Quiz Taken']]
				for (let i = 0; i < result.data.candidates_applied.length; i++) {
					let quizTake;
					if (result.data.quiz_taken[i] == null || result.data.quiz_taken[i] == undefined) {
						quizTake = 0;
					} else {
						quizTake = result.data.quiz_taken[i].value;
					}
					let temp = [
						result.data.candidates_applied[i].month,
						result.data.candidates_applied[i].value,
						quizTake,
					]
					graphData.push(temp);

				}
				setgraphData(graphData);


			})
			.catch((error) => console.log('error', error));


	}

	return (
		<div className=" row bg-white mt-2 rounded-5">
			<div className='container'>
				<div className='bg-white pt-4 pb-4 px-2 rounded-5'>
					<div className='row'>
						<div className='col-md-12'>
							<div className='d-flex justify-content-between w-100 mb-2'>
								<h4 className='font-bold float-left'>Dashboard</h4>
								<p className='float-right mt-auto mb-auto'>
									<a href='/jobstats'>See All</a>
								</p>
							</div>
						</div>

					</div>
					<div className='row mt-4 '>
						<div className='col-md-6 cards-shadow br-5 mb-2'>

							<div className='row mt-3 mb-3'>
								<div className='col-md-5 mt-1'>

									<h6 className='font-bold float-left'>Job Stats</h6>
								</div>
								<div className='col-md-7'>
									<Select defaultValue={{ label: "All Job", value: "" }} options={jobList} onChange={getGraphData}></Select>
									{/* <select class="form-select" aria-label="Default select example"
										onChange={e => getGraphData(e)}
									>
										<option selected value="">All Job</option>
										{jobTitle}
									</select> */}
								</div>
							</div>
							<div className='row'>
								<div className='col-md-12 p-0'>
									{graphData?.length > 1 ? <Chart
										width={'100%'}
										height={'200px'}
										chartType="LineChart"
										loader={<div>Loading Chart</div>}
										data={graphData}
										options={LineChartOptions}
										rootProps={{ 'data-testid': '2' }}
									/> : "No records found!"}
								</div>
							</div>

						</div>

						<div className='col-md-6'>
							<div className='row '>
								<div className='col-md-4 mb-2   '>
									<div className='cards bg-greenesh-blue br-5 text-white ps-1 h-100 mr-2'>
										<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.total_quiz}</p>
										<p className='fs-14 position-abs b-2 r-2 me-1 text-end m-0 mt-6 font-bold pb-1'><span className=''> Total Quiz</span>  </p>
									</div>
								</div>
								<div className='col-md-4 mb-2 '>
									<div className='cards bg-blue br-5 text-white ps-1 h-100 mr-2'>
										<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.total_question}</p>
										<p className='fs-14 position-abs b-2 r-2 me-1 text-end m-0 mt-6 font-bold pb-1'><span className='float-end text-right'> Total Questions</span> </p>
									</div>
								</div>
								<div className='col-md-4 mb-2 '>
									<div className='cards bg-purple br-5 text-white ps-1  h-100 mr-2'>
										<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.total_badges}</p>
										<p className='fs-14 position-abs b-2 r-2 me-1 text-end m-0 mt-6 font-bold pb-1'><span className=''> Badges</span> </p>
									</div>
								</div>
							</div>

							<div className='row'>
								<div className='col-md-6 mb-2 '>
									<div className='pt-1 p-1 br-5 shadow'>
										<h6>{data?.posted_job} / {data?.total_job}</h6>
										<progress className='mt-1 col-md-12' id="file" value={data?.posted_job * 100 / data?.total_job} max="100">  </progress>
										<div className='row'>
											<div className='col-md-12'>
												<p className=' fs-10'>Want to post more jobs?</p>
												<p className='fs-10 text-end'><a href="#" > click here</a></p>
												<h6 className=' f-0-8 mt-1 mb-1 text-end'> Jobs Posted</h6>
											</div>
										</div>
									</div>
								</div>
								<div className='col-md-6 '>
									<div className='pt-1 p-1 br-5 shadow'>
										<h6>{data?.total_candidates}</h6>
										<progress className='mt-1 col-md-12' id="file" value={data?.total_candidates * 100 / data?.total_applicants} max="100">  </progress>
										<div className='row'>
											<div className='col-md-12'>
												<p className=' fs-10'>Want to post more jobs?</p>
												<p className='fs-10 text-end'><a href="#" > click here</a></p>
												<h6 className='text-end f-0-8 mt-1 mb-1'>Total Candidates</h6>
											</div>
										</div>
									</div>
								</div>

							</div>

						</div>
					</div>
				</div>

			</div>
		</div>
	);
};

export default RecruiterHomeCard;
