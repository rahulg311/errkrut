import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { convertToSlug, formatTitle, getValueFromArr } from '../../classes';

import { getAuthToken } from '../../classes/index';
import { getLoggedInUser } from '../../classes';
import { END_POINT } from '../../routes/api_routes';
import moment from 'moment';
import LikeSaveJob from '../LikeSaveJob/LikeSaveJob';
import { ACCEPT_REJECT, Candidate_User_Type_ID, DISABLE_STATE_TEXT, Recruiter_User_Type_ID } from '../../config/constants';

import ConfirmationModal from './../../components/CadidateAppliedJobs/ConfirmationModal';

class CandidateJobsCard extends Component {
	state = {
		start_test: false,
        confirmationModalData: {
            title: 'Ready to Start the Quiz!',
            message: 'Once the Quiz starts you cannot go back or lese the progress will be lost want to start the quiz?',
            link: '',
            button: 'Start the Quiz'
        },
	}

	showStartTest = (linkdata) => {
        this.setState({
            start_test: true,
            confirmationModalData: { ...this.state.confirmationModalData, link: linkdata }
        });
    }
	hideStartTest = () => {
        this.setState({
            start_test: false,
        });
    }

	startquiz_handler = async(tj) => {

		const user = await getLoggedInUser();
		let token = await getAuthToken();

		var requestOptions = {
			method: 'GET',
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'get_quizz_details/'+ tj?.quizz_id, requestOptions)
			.then((response) => response.json())
			.then((result) => {

				let x;
				Object.keys(result?.data).map((key) => {
					x = {
						...x,
						[key]: result?.data[key]
					};
				});

				this.setState({ quiz_details: x }, () => {
					localStorage.setItem('quiz_' + tj?.quizz_id, JSON.stringify(this.state.quiz_details));

					let job = {
						job_title: tj?.job_title,
						company_name: result.data?.company_name,
						logo: (result.data?.company_logo) ? (result.data?.company_logo) : ''
					}

					localStorage.setItem('quiz_job_' + tj?.quizz_id, JSON.stringify(job));

					localStorage.setItem(`currentTimerData` + tj?.quizz_id, '');

				});
				this.showStartTest(`/start-quiz/${tj?.job_id}/${tj?.quizz_id}/${tj?.job_app_id}`);

			})
			.catch((error) => console.log('error', error));


	}

	render() {

		const { jobs, changeJobStatus } = this.props;

		let jobsList =

			jobs &&

			jobs.map((tj) => {

				let i = ACCEPT_REJECT[Candidate_User_Type_ID].indexOf(tj.current_status);

				let accept_status = ACCEPT_REJECT[Candidate_User_Type_ID][i + 1];

				return (
					<>
						<ConfirmationModal closeModal={() => this.hideStartTest()} status={this.state} mdata={this.state.confirmationModalData} />
						<div className='col-md-12 mb-5'>
							<div className='row'>
								<div className='col-md-12'>
									<section className={`${(tj.current_status?.indexOf(DISABLE_STATE_TEXT) !== -1) ? `bg-rejected` : ``} card shadow border-0 rounded-4 py-3 px-4 overflow-hidden`} id={tj.id}>
										<header className='d-flex'>
											<div className='me-3'>
												<NavLink to={`/job/${tj.job_id}/${convertToSlug(tj.job_title)}`}>
													<img
														src={(tj?.logo) ? getValueFromArr(tj?.logo, 0) : `/assets/imgs/dummy-logo.png`}
														className='img-fluid shadow br-5 h-50px'
													/>
												</NavLink>
											</div>
											<div className="mt-auto mb-auto">
												<h6 className='font-bold'>
													{tj.job_title}
												</h6>
												<p>{tj.company_name}</p>
											</div>
											<div className="ms-auto ">
												<h6 className='font-bold text-primary text-capitalize'>
													{formatTitle(getValueFromArr(tj.btn_text, 0))}
												</h6>
											</div>
										</header>
										<main>

											{/* section */}
											<section className='d-md-flex mt-1'>
												<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
													{/* detail */}
													<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
														<i class='las la-briefcase  text-sky-blue font-bold'></i>
														<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Experience</p>
														<small className='ms-3'>
															{tj.min_work_exp} - {tj.max_work_exp} Yrs
														</small>
													</div>
													{/* detail */}
												</div>

												<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
													{/* detail */}
													<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
														<i class='las la-map-marker   text-sky-blue font-bold'></i>
														<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Location</p>
														<small className='ms-3'>
															{tj.job_location}
														</small>
													</div>
													{/* detail */}
												</div>

												<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
													{/* detail */}
													<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
														<i class='las la-rupee-sign   text-sky-blue font-bold'></i>
														<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Salary</p>
														<small className='ms-3'>
															{tj.ctc_from} - {tj.ctc_to} L.P.A
														</small>
													</div>
													{/* detail */}
												</div>
											</section>
											{/* section */}

											{/* section */}
											<section className='d-md-flex mt-1'>

												<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
													{/* detail */}
													<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
														<i class='las la-edit text-sky-blue font-bold'></i>
														<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Skillset</p>
														<small className='ms-3'>
															{tj.skill_set}
														</small>
													</div>
													{/* detail */}
												</div>
											</section>
											{/* section */}

											{/* section */}
											<section className='d-md-flex mt-1 justify-content-between'>
												<div className='d-flex'>
													<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
														{/* detail */}
														<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
															<i class='las la-user-check text-sky-blue font-bold'></i>
															<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Vacancy</p>
															<small className='ms-3'>
																{tj.number_of_vaccancy}
															</small>
														</div>
														{/* detail */}
													</div>

													<div className='d-flex align-items-start mb-md-0 mb-3 me-2'>
														{/* detail */}
														<div className='d-flex align-items-center mt-auto mb-auto f-0-9'>
															<i class='las la-thumbs-up   text-sky-blue font-bold'></i>
															<p className='mb-0 ms-1 text-primary f-Poppins-Medium'>Candidates Applied</p>
															<small className='ms-3'>
																{tj.candidates_applied}
															</small>
														</div>
														{/* detail */}
													</div>
												</div>
												<div className="">
													<NavLink className="justify-content-end" to={`/job/${tj.job_id}/${convertToSlug(tj.job_title)}`}>
														View Details
													</NavLink>
												</div>
											</section>
											{/* section */}

										</main>

										{tj.current_status == 'interview_scheduled' &&
											<div className='mt-2'>
												<p className='f-0-8'><b>Interviewer Name:</b> {tj?.interviewer_name}</p>
												<p className='f-0-8'><b>Interview Date:</b> {moment(tj?.interview_date_time).format('MMMM Do YYYY h:mm a')}</p>
												<p className='f-0-8'><b>Interview Location:</b> {tj?.interview_loc}</p>
											</div>
										}

										<hr className='mt-md-3 mt-0' />


										<footer>
											<div className='d-flex align-items-center w-100'>

												{tj.current_status != null && (ACCEPT_REJECT[Candidate_User_Type_ID].indexOf(tj.current_status) !== -1) &&
													<>
													{console.log(tj.current_status)}
														{(tj.current_status === "offer_letter_sent" || tj.current_status === "interview_scheduled") &&
															<>
																<div className='d-flex me-2'>
																	<button className="btn btn-sm btn-info text-white" type="button" onClick={(e) => { changeJobStatus(tj) }}>Accept</button>
																</div>
																<div className='d-flex'>
																	<button className="btn btn-sm btn-danger text-white" type="button" onClick={(e) => { changeJobStatus(tj, true) }}>Reject</button>
																</div>
															</>
														}

													</>
												}

												{(tj.round_type == "quizz" && tj.current_status != "quiz_failed") && <div className="d-flex justify-content-start w-35">
														<button onClick={() => this.startquiz_handler(tj)} className='btn btn-primary btn-sm text-light px-4'>Start the Test</button>
													</div>
													}
												<div className='d-flex justify-content-end w-100'>
													<button type='button' className='btn btn-primary btn-sm text-light px-4'>
														Applied
													</button>
												</div>
											</div>
										</footer>


									</section>
								</div>
							</div>
						</div>
					</>
				);

			});

		return (
			<>
				<div className='bg-white rounded-4'>
					<div className='row'>
						{this.props.title && (
							<div className='col-md-12 mb-4'>
								<div className='d-flex justify-content-between'>
									<h5 className='font-bold'>{this.props.title}</h5>
									<p className="mt-auto mb-auto">
										<NavLink to='/search'>See All</NavLink>
									</p>
								</div>
							</div>
						)}

						{/* job list here */}
						{jobsList}
						{/* job list here */}

					</div>
				</div>
			</>
		);

	}

}

export default CandidateJobsCard;