import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { convertToSlug, getValueFromArr } from '../../classes';
import { getLoggedInUser } from '../../classes';
import moment from 'moment';
import LikeSaveJob from '../LikeSaveJob/LikeSaveJob';
import PostedOn from '../PostedOn';
import QuestionariesModel from '../../components/CadidateAppliedJobs/QuestionariesModel';
import { Candidate_User_Type_ID } from '../../config/constants';



class JobsList extends Component {
	state = {
		isLoggedIn: false,
		candidate_login: false,
		qmodel: false,
		currentjob: []

	}
	showQuestionModal = (tj) => {
		this.setState({
			qmodel: true,
			currentjob: tj
		});
	};

	closeQuestionModal = () => {
		this.setState({
			qmodel: false,
		});
	}

	componentWillMount = async () => {
		let user = await getLoggedInUser();

		if (user?.id) this.setState({ isLoggedIn: true });
		if (user?.user_type == Candidate_User_Type_ID) this.setState({ candidate_login: true });

	}
	render() {
		const { jobs } = this.props;
		let jobsList =
			jobs &&
			jobs?.map((tj) => {

				return (
					<>
						<div className='col-md-12 mb-5'>
							<div className='row'>
								<div className='col-md-12'>
									<section className='card shadow border-0 rounded-4 py-2 px-2 overflow-hidden'>
										<header className='d-flex'>
											<div className='me-3'>
												<NavLink to={`/job/${tj.job_id}/${convertToSlug(tj.job_title)}`}>
													<img
														src={(tj?.company_logo) ? JSON.parse(tj?.company_logo, 0) : `/assets/imgs/dummy-logo.png`}
														className='img-fluid shadow br-5 h-60p'
													/>

												</NavLink>
											</div>
											<div className="mt-auto mb-auto">
												<h6 className='font-bold'>
													{tj.job_title}
												</h6>
												<p>{tj.company_name}</p>
											</div>
										</header>
										<main>

											{/* section */}
											<section className='d-md-flex mt-1 flex-column'>
												<div className='container align-items-start px-1 py-1 mb-md-0 mb-0 me-2'>
													{/* detail */}
													<div className='row'>
														<div className='d-flex flex-columns'>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium'><i class='las la-briefcase text-primary font-bold'></i> {tj.min_work_exp} - {tj.max_work_exp} Yrs</p>
															</div>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium'><i class='las la-map-marker text-primary font-bold'></i>
																	{/* {tj.city} */}
																	{tj.city && Object.keys(tj.city.split(',')).map((key) => {
																		return <span class='small badge badge-default me-1 mb-1'>
																			{tj.city.split(',')[key]}
																		</span>
																	})}
																</p>
															</div>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium'><i class='las la-rupee-sign text-primary font-bold'></i> {tj.ctc_from} - {tj.ctc_to}</p>
															</div>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium'><i class='las la-user-check  text-primary font-bold'></i> {tj.number_of_vaccancy}</p>
															</div>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium'><i class='las la-thumbs-up  text-primary font-bold'></i> {tj.candidates_applied}</p>
															</div>
														</div>
													</div>
													{/* detail */}
												</div>

												<div className='container align-items-start px-1 py-1  mb-md-0 mb-lg-3 me-2 bg-light-blue d-none'>
													{/* detail */}
													<div className='row'>
														<div className="col-lg-3 col-6">
															<p className='mb-0  text-primary f-Poppins-Medium'><i class='las la-map-marker text-sky-blue font-bold'></i> Location</p>
														</div>
														<div className="col-lg-9 col-6">
															<small className='ms-3 d-block'>
																{tj.city}
															</small>
														</div>
													</div>
													{/* detail */}
												</div>

												<div className='container align-items-start px-1 py-1  mb-md-0 mb-lg-3 me-2 d-none'>

													{/* detail */}
													<div className='row'>
														<div className="col-lg-3 col-7">
															<p className='mb-0  text-primary f-Poppins-Medium'><i class='las la-rupee-sign  text-sky-blue font-bold'></i> Salary</p>
														</div>
														<div className="col-lg-9 col-5 ">
															<small className='ms-3 d-block'>
																{tj.ctc_from} - {tj.ctc_to} L.P.A
															</small>
														</div>
													</div>
													{/* detail */}

												</div>
												<div className='container align-items-start px-1 py-1  mb-md-0 me-2'>

													{/* detail */}
													<div className='row'>
														<div className=''>
															<div className="me-5">
																<p className='mb-0  f-Poppins-Medium mb-2'>
																	{tj.purpose}
																</p>

																<p className='mb-0  f-Poppins-Medium'>
																	{/* {tj.skill_set.split(',')} */}

																	{tj.skill_set && Object.keys(tj.skill_set.split(',')).map((key) => {
																		return <span class='badge badge-default small me-1 mb-1'>
																			{tj.skill_set.split(',')[key]}
																		</span>
																	})}

																</p>
															</div>
															<div className="col-9 col-8 p-0 m-0">
																<small className='ms-3 d-block'>


																</small>
															</div>
														</div>
													</div>
													{/* detail */}

												</div>

												<div className='container align-items-start px-1 py-1  mb-md-0 mb-lg-3 me-2 d-none'>

													{/* detail */}
													<div className='row'>
														<div className="col-lg-3 col-9">
															<p className='mb-0  text-primary f-Poppins-Medium'><i class='las la-user-check  text-sky-blue font-bold'></i> Vacancy</p>
														</div>
														<div className="col-lg-9 col-3 p-0">
															<small className='ms-3 d-block'>
																{tj.number_of_vaccancy}
															</small>
														</div>
													</div>
													{/* detail */}

												</div>

												<div className='container align-items-start px-1 py-1  mb-md-0 mb-lg-3 me-2 bg-light-blue d-none'>

													{/* detail */}
													<div className='row'>
														<div className="col-lg-3 col-9">
															<p className='mb-0  text-primary f-Poppins-Medium'><i class='las la-thumbs-up  text-sky-blue font-bold'></i> Candidates Applied</p>
														</div>
														<div className="col-lg-9 col-3 p-0">
															<small className='ms-3 d-block'>
																{tj.candidates_applied}
															</small>
														</div>
													</div>
													{/* detail */}
												</div>
											</section>
											{/* section */}
											{(moment().startOf('day').diff(moment.utc(tj.created_at), 'days') < 5) &&
												<section className='d-flex justify-content-between mb-2 p-0'>
													<img src='/assets/imgs/fire.png' className="h-20px" />

													<PostedOn date={tj.created_at} />

													<NavLink className="ms-auto fs-13 p-0" to={`/job/${tj.job_id}/${convertToSlug(tj.job_title)}`}>

													</NavLink>
												</section>
											}
										</main>
										<hr className='mt-md-0 mt-0' />
										<footer>
											{/* <div className='flex-lg-row align-items-lg-center flex-column w-100'> */}
											<div className='align-items-lg-center  d-flex flex-column flex-lg-row mb-3 justify-content-between'>
												<LikeSaveJob job_id={tj.job_id} job_title={tj.job_title} />

												<div className='d-flex justify-content-end w-100 flex-column flex-lg-row mt-2'>
													{(this.state.isLoggedIn && tj.send === true && this.state.candidate_login) && (<NavLink to={`/send-message/${tj.user_id}/${tj.company_name}`} className='btn btn-primary p-0 p-1 fs-12 mb-2 mb-lg-0'>

														Send Message To Recruiter
													</NavLink>)}
													<NavLink to={`/job/${tj.job_id}/${convertToSlug(tj.job_title)}`} className='ms-lg-1 p-0 p-1 fs-12  btn btn-primary btn-sm text-light px-4 mb-2 mb-lg-0'>
														View Details
													</NavLink>
													{tj?.applied ?

														(this.state.candidate_login
															? <button type='button' className='btn btn-primary btn-sm text-light px-4'>
																Applied
															</button> : '')
														:
														(this.state.candidate_login
															? <NavLink to={`/apply-job/${tj?.job_id}/${tj?.job_title}/${tj?.company_name}/${(tj?.company_logo) ? btoa(JSON.parse(tj?.company_logo, 0)) : ''}`} className='ms-lg-1 btn btn-primary btn-sm text-light px-4'>
																Apply Now
															</NavLink>

															: '')}
												</div>
											</div>
											{/* </div> */}
										</footer>
									</section>
								</div>
							</div>
						</div>
					</>
				);

			});

		return (
			<>
				<QuestionariesModel
					is_modal={() => this.showQuestionModal()}
					closeModal={() => this.closeQuestionModal()}
					jobState={this.state}
					jobData={this.state.currentjob}
				/>
				<div className='rounded-4'>
					<div className='row'>
						{this.props.title && (
							<div className='col-md-12 mb-4'>
								<div className='d-flex justify-content-between'>
									<h5 className='font-bold'>{this.props.title}</h5>
									<p className="mt-auto mb-auto">
										<NavLink to='/search'>See All</NavLink>
									</p>
								</div>
							</div>
						)}

						{/* job list here */}
						{jobsList}
						{/* job list here */}

					</div>
				</div>
			</>
		);

	}

}

export default JobsList;