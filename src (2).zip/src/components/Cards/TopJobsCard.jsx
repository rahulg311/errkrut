import React, { Component } from 'react';
import { getAllJobs } from '../../store/actions/jobs';
import { connect } from "react-redux";
import { NavLink } from 'react-router-dom';
import { convertToSlug, getValueFromArr, ReadMore } from '../../classes';
import Loading from '../common/Loading';

/* slick slider */
import Slider from "react-slick";
/* slick slider */

class TopJobsCard extends Component {


    state = {
        top_jobs: [],
        page_num: 1,
        limit_page: 9,
        loader: false,
        no_data: false
    }

    componentWillMount() {
        this.getTopJobs();
    }

    /* get jobs */
    getTopJobs = async () => {

        this.setState({
            loader: true
        })

        let obj = {
            page_num: this.state.page_num,
            limit_page: this.state.limit_page,
        }
        await this.props.getJobs(obj);

        if (this.props.data) {
            this.setState({
                loader: false
            })
            if (this.props.jobsData?.status == 'success' && this.props.jobsData?.data && this.props.jobsData?.data.length > 0) {
                this.setState(prevState => ({
                    top_jobs: [...prevState.top_jobs, ...this.props.jobsData.data],
                }));
            } else
                this.setState({
                    no_data: true
                });

        }
    }
    /* get jobs */

    /* load more jobs */
    loadMore = () => {
        let page = this.state.page_num;
        this.setState({
            page_num: page + 1
        }, () => {
            this.getTopJobs();
        });
    }
    /* load more jobs */

    render() {

        /* slick slider settings */
        const settings = {
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 3,
            autoplay: true,
            autoplaySpeed: 3000,
            centerMode: true,
            centerPadding: "80px",
            responsive: [
                {
                    breakpoint: 1367,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        centerMode: true,
                    }
                },
                {
                    breakpoint: 1025,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3,
                        centerMode: true,
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        initialSlide: 2,
                        centerPadding: "0px",
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerPadding: "0px",
                    }
                }
            ]
        };
        /* slick slider settings */
        const colors = ['bg-blue', 'bg-purple', 'bg-dark-pink', 'bg-greenesh-blue', 'bg-warning', 'bg-info'];

        let index = -1;
        let topjobs =

            this.state.top_jobs &&

            this.state.top_jobs.map((tj, i) => {
                console.log(tj)
                if (index >= colors.length - 1)
                    index = -1;

                index++;

                return <div className="col-md-4 p-1">
                    {/* Cards */}
                    <div className={`cards cards-shadow position-relative w-100 br-5 p-2 bg-cover bg-center mt-2 mb-2 min-height-230  ${colors[index]}`} style={{ backgroundImage: process.env.PUBLIC_URL + 'url("/assets/imgs/box-pattern.png")' }}>

                        <div className="d-flex align-items-start flex-column min-height-230">

                            {/* row */}
                            <div className="d-flex">
                                <div className="me-1">
                                    <img src={(tj?.logo) ? JSON.parse(tj?.logo, 0) : `/assets/imgs/dummy-logo.png`} className="img-fluid w-100 shadow br-5 h-40px" />
                                </div>
                                <div className="">
                                    <div>
                                        <NavLink to={`/job/${tj.id}/${convertToSlug(tj.job_title)}`}>
                                            <p className="m-0 f-0-8 text-white">{tj.job_title}</p>
                                            <p className="m-0 f-0-7 text-white">{tj.company_name}</p>
                                        </NavLink>
                                    </div>
                                </div>
                            </div>
                            {/* row */}

                            <div className="mt-1 mb-1 w-90">

                                {/* row */}
                                <div className="d-flex">
                                    <div className="me-1 mt-auto mb-auto">
                                        <i class="las la-briefcase text-white f-0-8"></i>
                                    </div>
                                    <div className="mt-auto mb-auto col-md-5">
                                        <p className="text-white m-0 f-0-7">Experience</p>
                                    </div>
                                    <div className="mt-auto mb-auto">
                                        <p className="text-white m-0 f-0-7">{tj.min_work_exp + " - " + tj.max_work_exp + " Yrs"}</p>
                                    </div>
                                </div>
                                {/* row */}

                                {/* row */}
                                <div className="d-flex">
                                    <div className="me-1 mt-auto mb-auto">
                                        <i class="las la-map-marker text-white f-0-8"></i>
                                    </div>
                                    <div className="mt-auto mb-auto col-md-5">
                                        <p className="text-white m-0 f-0-7">Location</p>
                                    </div>
                                    <div className="mt-auto mb-auto">
                                        <p className="text-white m-0 f-0-7">{tj.city}</p>
                                    </div>
                                </div>
                                {/* row */}

                                {/* row */}
                                <div className="d-flex">
                                    <div className="me-1 mt-auto mb-auto">
                                        <i class="las la-pencil-alt text-white f-0-9"></i>
                                    </div>
                                    <div className="mt-auto mb-auto col-md-5">
                                        <p className="text-white m-0 f-0-7">Skillset</p>
                                    </div>
                                    <div className="mt-auto mb-auto">
                                        <p className="text-white m-0 f-0-7 text-break">{ReadMore(tj.skill_set, 55)}</p>
                                    </div>
                                </div>
                                {/* row */}

                            </div>

                            {/* row */}
                            <div className="mt-auto me-auto ms-auto w-100">
                                <NavLink to={`/job/${tj.id}/${convertToSlug(tj.job_title)}`} className="btn btn-default btn-block mt-1 w-100">
                                    Apply Now
                                </NavLink>
                            </div>
                            {/* row */}

                        </div>
                    </div>
                    {/* Cards */}
                </div>


            }

            );

        return (

            <div className="bg-white pt-4 pb-4 px-4 rounded-4 overflow-hidden">
                <div className="row">
                    <div className="col-md-12">
                        <div className="d-flex justify-content-between">
                            <h5 className="font-bold float-left custom-heading">Top Jobs</h5>
                            <p className="float-right mt-auto mb-auto"><a href="/search">See All</a></p>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="row">
                            <Slider {...settings}>
                                {topjobs}
                            </Slider>
                        </div>

                        {/* load more */}
                        {/* {this.state.no_data == false &&
                            <button className="btn btn-primary btn-sm d-block me-auto ms-auto mt-2 mb-2" onClick={() => { this.loadMore() }}>
                               Load More <i class="las la-angle-double-right"></i>
                            </button>
                        } */}
                        {this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}
                        {/* load more */}

                    </div>
                </div>
            </div>



        );

    }


}

const mapStateToProps = (state) => {
    const { data, jobsData } = state.common
    return {
        data,
        jobsData
    }
};
function mapDispatchToProps(dispatch) {
    return {
        getJobs: (obj) => dispatch(getAllJobs(obj)),
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(TopJobsCard);