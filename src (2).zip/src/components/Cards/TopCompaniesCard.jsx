import React, { Component } from 'react';
import { getCompanies } from '../../store/actions/companies';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import Slider from 'react-slick';
import { getValueFromArr } from '../../classes';

class TopCompaniesCard extends Component {

	state = {
		top_companies: [],
	};

	componentDidMount() {
		this.getTopCompanies();
	}

	getTopCompanies = async () => {
		await this.props.getCompanies();

		if (this.props.data?.status == 'success') {
			this.setState({
				top_companies: this.props.data.data,
			});
		}
	};

	render() {

		/* slick slider settings */
		const settings = {
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 5,
			slidesToScroll: 5,
			autoplay: true,
			autoplaySpeed: 30000,
			centerMode: true,
			centerPadding: "20px",
			responsive: [

                {
                  breakpoint: 1025,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 3,
                    centerMode: true,
                  }
                },
                {
                  breakpoint: 600,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2,
                    centerPadding: "0px",
                  }
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    centerPadding: "0px",
                  }
                }
              ]
		};
		/* slick slider settings */


		let comp = null;

		if (this.state.top_companies.length > 0) {
			comp = this.state.top_companies.map((tc, i) => (
				i < 6 && <div className='cards position-relative my-2 me-3 px-3 rounded-4 '>
					<div className='card d-flex justify-content-center border-0 ' style={{height:'150px', width: '150px' }}>
					<NavLink to={`/company/` + tc.id} >
						{tc.logo ? (
							<img src={(tc?.logo) ? getValueFromArr(tc?.logo, 0) : `/assets/imgs/dummy-logo.png`} className='img-fluid shadow' />
						) : (
							<img
								src='/assets/imgs/dummy-logo.png'
								className='img-fluid h-100p p-2px shadow rounded-4'
							/>
						)}
					</NavLink>
					</div>
				</div>
			));
		}

		return (
			<div className='bg-white pt-4 pb-4 px-4 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
							<h5 className='font-bold float-left custom-heading'>Top Companies</h5>
							<p className='float-right mt-auto mb-auto'>
								<a href='/search'>See all</a>
							</p>
						</div>
					</div>
					<div>
						<Slider {...settings}>
							{comp}
						</Slider>
					</div>
				</div>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { data } = state.common;
	return {
		data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		getCompanies: () => dispatch(getCompanies()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(TopCompaniesCard);
