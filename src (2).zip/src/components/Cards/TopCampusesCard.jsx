import React, { Component } from 'react';
import { getCampuses } from '../../store/actions/campuses';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import Slider from 'react-slick';
import { getValueFromArr } from '../../classes';

class TopCampusesCard extends Component {

	state = {
		top_campuses: [],
	};

	componentDidMount() {
		this.getTopCampuses();
	}

	getTopCampuses = async () => {
		await this.props.getCampuses();
		console.log(this.props.data);
		if (this.props.data?.status == 'success') {
			console.log(this.props.data);
			this.setState({
				top_campuses: this.props.data.data,
			});
		}
	};

	render() {

		/* slick slider settings */
		const settings = {
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 5,
			slidesToScroll: 5,
			autoplay: true,
			autoplaySpeed: 3000,
			centerMode: true,
			centerPadding: "20px",
		};
		/* slick slider settings */


		let comp = null;
		console.log(this.state.top_campuses);
		if (this.state.top_campuses.length > 0) {
			comp = this.state.top_campuses.map((tc, i) => (
				i < 6 && <div className='cards position-relative my-2 me-3 rounded-4 '>
					<NavLink to={`/send-campus-invite`} >
						{tc.logo ? (
							<img src={(tc?.logo) ? getValueFromArr(tc?.logo, 0) : `/assets/imgs/dummy-logo.png`} className='img-fluid h-100p p-2px shadow rounded-4' />
						) : (
							<img
								src='/assets/imgs/dummy-logo.png'
								className='img-fluid h-100p p-2px shadow rounded-4'
							/>
						)}
					</NavLink>
				</div>
			));
		}

		return (
			<div className='bg-white pt-4 pb-4 px-4 rounded-4'>
				<div className='row'>
					<div className='col-md-12'>
						<div className='d-flex justify-content-between w-100'>
							<h5 className='font-bold float-left custom-heading f-r-17'>Top Campuses</h5>
							<p className='float-right mt-auto mb-auto '>
								<a className="btn btn-primary btn-sm ps-3 pe-3 f-r-12" href='/send-campus-invite'>Invite Campus</a>
							</p>
						</div>
					</div>
					<div>
						<Slider {...settings}>
							{comp}
						</Slider>
					</div>
				</div>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { data } = state.common;
	return {
		data,
	};
};
function mapDispatchToProps(dispatch) {
	return {
		getCampuses: () => dispatch(getCampuses()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(TopCampusesCard);
