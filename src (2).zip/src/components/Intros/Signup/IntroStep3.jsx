
import React from 'react';

class IntroStep3 extends React.Component {

    render() {
        return (
					<div className='position-relative'>
						<div
							className='bg-blue vh-100 position-fixed w-50 t-0 l-0 r-0 b-0 w-100-xs position-relative-xs'
							style={{
								backgroundImage:
									process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-left.png')",
							}}
						>
							<div className='position-absolute abs-center-x-y w-50 text-white'>
								<h1>Tell Us</h1>
								<h2>About YourSelf</h2>

								{/* app icon */}
								<div className='row mt-4'>
									<div className='col-md-12 mb-3'>
										<h6>Download Erekrut App Now</h6>
									</div>

									<div className='col-md-4'>
										<img
											className='img-fluid'
											src={process.env.PUBLIC_URL + '/assets/imgs/app-store.png'}
										/>
									</div>

									<div className='col-md-4'>
										<img
											className='img-fluid'
											src={process.env.PUBLIC_URL + '/assets/imgs/play-store.png'}
										/>
									</div>
								</div>
								{/* app icon */}
							</div>
						</div>
					</div>
				);
    }

}

export default IntroStep3;