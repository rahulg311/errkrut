
import React from 'react';

class IntroStep2 extends React.Component {

    render() {
        return (
					<div className='position-relative'>
						<div
							className='bg-blue vh-100 position-fixed w-50 t-0 l-0 r-0 b-0 w-100-xs position-relative-xs'
							style={{
								backgroundImage:
									process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-left.png')",
							}}
						>
							<div className='position-absolute abs-center-x-y w-50 text-white'>
								<h2>Tell Us</h2>
								<h5>About the Company</h5>

								{/* row */}
								<div className='mt-5'>
									<div className='row mb-2'>
										<div className='col-md-3'>
											<img
												src={process.env.PUBLIC_URL + '/assets/icons/list-icon.png'}
												className='img-fluid'
											/>
										</div>
										<div className='col-md-9 p-0'>
											<p className='text-white'>
												Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
												nonum See more
											</p>
										</div>
									</div>

									<div className='row  mb-2'>
										<div className='col-md-3'>
											<img
												src={process.env.PUBLIC_URL + '/assets/icons/list-icon.png'}
												className='img-fluid'
											/>
										</div>
										<div className='col-md-9 p-0'>
											<p className='text-white'>
												Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
												nonum See more
											</p>
										</div>
									</div>

									<div className='row  mb-2'>
										<div className='col-md-3'>
											<img
												src={process.env.PUBLIC_URL + '/assets/icons/list-icon.png'}
												className='img-fluid'
											/>
										</div>
										<div className='col-md-9 p-0'>
											<p className='text-white'>
												Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
												nonum See more
											</p>
										</div>
									</div>
								</div>

								{/* row */}

								{/* app icon */}
								<div className='row mt-4'>
									<div className='col-md-12 mb-3'>
										<h6>Download Erekrut App Now</h6>
									</div>

									<div className='col-md-4'>
										<img
											className='img-fluid'
											src={process.env.PUBLIC_URL + '/assets/imgs/app-store.png'}
										/>
									</div>

									<div className='col-md-4'>
										<img
											className='img-fluid'
											src={process.env.PUBLIC_URL + '/assets/imgs/play-store.png'}
										/>
									</div>
								</div>
								{/* app icon */}
							</div>
						</div>
					</div>
				);
    }

}

export default IntroStep2;