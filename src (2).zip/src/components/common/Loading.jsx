import React from 'react'

const Loading = ({ className,size }) => {
	return (
		<div className={`${className} text-center`}>
			<div
				class='spinner-border spinner-border-sm'
				style={{ height: size, width: size }}
				role='status'
			>
				<span class='visually-hidden'>Loading...</span>
			</div>
		</div>
	);
};

export default Loading
