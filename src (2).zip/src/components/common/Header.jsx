import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { logout, getLoggedInUser, getAuthToken } from '../../classes';
import { routeChanged } from '../../classes/browserHistory';
import { notification } from '../../classes/messages';
import { getFirstCharacterProfile } from '../../classes/profile';
import { Recruiter_User_Type_ID, Candidate_User_Type_ID, SEARCH_DATA, Campus_User_Type_ID, SITE_DATA } from '../../config/constants';
import { APP_Prefix } from '../../config/constants';
import { useHistory } from 'react-router'
import { useDispatch } from 'react-redux';
import CreateModal from '../../views/pages/CompanyTemplates/CreateModal';
import useFetch from "../../hooks/useFetch";
import { CHECK_SITE, END_POINT, GET_NOTIFICATION } from "../../routes/api_routes";

const Header = (props) => {
	const [charName, setCharName] = useState('')
	const [isRecruiter, setIsRecruiter] = useState(false);
	const [isCandidate, setCandidate] = useState(false);
	const [isCampus, setIsCampus] = useState(false);
	const [isLoggedIn, setIsLoggedIn] = useState(false);
	const [value, setValue] = useState('');
	const [modal, setModal] = useState('');
	const dispatch = useDispatch();
	const RecruiterNotificationList = useFetch();
	const history = useHistory();

	const getNotificationList = async () => {
		const result = await getLoggedInUser();
		if (result?.id) {
			let token = await getAuthToken();
		const requestOptions = {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				'Authorization': 'Bearer ' + token
			},
		};
		console.log(requestOptions);
		RecruiterNotificationList.doFetch(END_POINT + `${GET_NOTIFICATION}/${result?.id}`, requestOptions);
	}
};

useEffect(async () => {
	await getNotificationList();
	const charName = await getFirstCharacterProfile()
	setCharName(charName)
	const result = await getLoggedInUser();
	if (result?.id)
		setIsLoggedIn(true);

	if (result?.user_type == Recruiter_User_Type_ID) {
		setIsRecruiter(true);
	} else if (result?.user_type == Campus_User_Type_ID) {
		setIsCampus(true)
	}
	if (result?.user_type == Candidate_User_Type_ID) {
		setCandidate(true);
	}

}, [])

const handleMessages = () => {
	if (isRecruiter) {
		history.push('recruiter-messages');
	} else if (isCampus) {
		history.push('campus-messages');
	}
	else {
		// for candidate
		history.push('candidate-messages');
	}
}

const handleChange = (e) => {
	e.preventDefault();
	if (value !== '') {
		history.push(`/search/${value}`);
		return dispatch({ type: SEARCH_DATA, data: value });
	}

}

const openModal = async (value) => {
	// let token = await getAuthToken();
	// const result = await getLoggedInUser();

	// const response = await fetch(END_POINT + CHECK_SITE + '/' + result.company_id, {
	// 	method: 'GET',
	// 	headers: {
	// 		'Accept': 'application/json',
	// 		'Authorization': 'Bearer ' + token
	// 	}
	// });

	// const json = await response.json();

	// return dispatch({ type: SITE_DATA, data: json });
	setModal(value);

}

const closeModal = () => {
	setModal('');
}


const Notification = ({ notification }) => {
	return <>
		<li className={`noti row ${notification.status === 0 ? "notiunread" : "notiread"}`}>
			<div className="left col-md-3">
				<h4 className="avatar text-center text-uppercase">{notification.name.substring(0, 1)}</h4>
			</div>
			<div className="right col-md-7">
				<h4 className="job-title"><a>{notification.name}</a></h4>
				<p className="job-desc">Sent You a Messsage</p>
			</div>
			{/* <div className="close col-md-2">
					<i className="fa fa-close"></i>
				</div> */}
		</li></>;
}


return (
	<>

		{modal == 'createwebsite' && <CreateModal closeModal={() => closeModal()} />}

		<header>
			<nav className='navbar fixed-top navbar-expand-lg navbar-light bg-ecf0f4'>
				<div className='container'>
					<NavLink activeClassName='active' to='/' className='navbar-brand w-170px'>
						<img src='/assets/imgs/logo.png' className='w-100' />
					</NavLink>
					<button
						className='navbar-toggler'
						type='button'
						data-bs-toggle='collapse'
						data-bs-target='#navbarSupportedContent'
						aria-controls='navbarSupportedContent'
						aria-expanded='false'
						aria-label='Toggle navigation'
					>
						<span className='navbar-toggler-icon'></span>
					</button>
					<div
						className='collapse navbar-collapse align-items-center'
						id='navbarSupportedContent'
					>
						<form action='' onSubmit={handleChange} className='w-lg-lg w-100 mt-lg-0 mt-3 ms-lg-2'>
							<div class='input-group input-group-sm shadow-sm'>
								<input
									type='text'
									class='form-control border-0'
									placeholder='Search Skill, Designation, Company'
									aria-label="Recipient's username"
									aria-describedby='basic-addon2'
									defaultValue={props.location?.search?.term}
									onChange={(e) => setValue(e.target.value)}
								/>
								<button
									type='submit'
									class='btn bg-secondary bg-opacity-15 border-3  input-group-text cursor'
									id='basic-addon2'
								>
									<i class='fas fa-search'></i>
								</button>
							</div>
						</form>
						<ul className='navbar-nav ms-auto mb-2 mb-lg-0 mt-md-0 mt-3'>
							<li className='nav-item me-2'>
								<NavLink activeClassName='active' to='/' exact className='nav-link'>
									Home
								</NavLink>
							</li>

							{isRecruiter == 0 && (
								<li className='nav-item me-2'>
									<NavLink activeClassName='active' to='/search' className='nav-link'>
										Jobs
									</NavLink>
								</li>
							)}

							{isRecruiter == 1 && (
								<li className='nav-item me-2'>
									<NavLink activeClassName='active' to='/plans' className='nav-link'>
										Plans
									</NavLink>
								</li>
							)}
							{isCandidate == 1 && (
								<li className='nav-item me-2'>
									<NavLink activeClassName='active' to='/candidate-plans' className='nav-link'>
										Plans
									</NavLink>
								</li>
							)}

							{isCampus == 1 && (
								<li className='nav-item me-2'>
									<NavLink activeClassName='active' to='/campus-plans' className='nav-link'>
										Plans
									</NavLink>
								</li>
							)}

							<li className='nav-item '>
								<NavLink activeClassName='active' to='/contact-us' className='nav-link'>
									Contact Us
								</NavLink>
							</li>
						</ul>
						<section className='ms-md-2 mt-md-0 mt-3'>

							{!isLoggedIn &&
								<>

									<NavLink to="/candidate-signup" className="me-2">Sign Up</NavLink>

									<NavLink to="/login" className="btn btn-primary btn-sm ps-4 pe-4">Login</NavLink>
								</>
							}


							{isLoggedIn &&
								<>
									<button onClick={handleMessages} className='btn p-1'>
										<i class='fas fa-comment fs-21'></i>
									</button>
									<div class='dropdown d-inline'>
										<button className='btn p-1 mx-2'>
											<i class='fas fa-bell fs-21'></i>
										</button>
										<ul class='dropdown-menu notification' aria-labelledby='dropdownMenuButton1'>
											<li className='notihead'>
												<span>Notification <a href='/notifications' className='f-right'>See All</a></span>
											</li>
											{
												RecruiterNotificationList?.data?.data.map((noti, index) => {
													if (index < 10) {
														return <Notification notification={noti} />;
													}
												})
											}
										</ul>
									</div>

									<div class='dropdown d-inline'>
										<button className='btn shadow p-1 dropdown-toggle'>
											<span className='bg-danger px-9px  py-4px rounded me-3px text-light'>
												{charName}
											</span>
										</button>
										<ul class='dropdown-menu' aria-labelledby='dropdownMenuButton1'>

											{isRecruiter == 0 &&
												<li>
													<NavLink
														activeClassName='dropdown-item'
														className='dropdown-item'
														to='/profile'
													>
														Profile
													</NavLink>
												</li>
											}

											{(isRecruiter == 0 && isCampus == 0) &&
												<li>
													<NavLink
														activeClassName='dropdown-item'
														className='dropdown-item'
														to='/my-jobs'
													>
														My Jobs
													</NavLink>
												</li>
											}



											{isRecruiter == 1 && (
												<>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/recruiter'
														>
															Dashboard
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/company-profile'
														>
															Profile
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/recruiterAccount'
														>
															My Accounts
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/applied-candidates'
														>
															Candidates Applied
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-job'
														>
															Add Job
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-quiz'
														>
															Add Quiz
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-question'
														>
															Add Question
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-template'
														>
															Add Template
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-offer-letter'
														>
															Add Offer Letter
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/letter-intent'
															exact
														>
															Add Letter of Intent
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-testimonial'
															exact
														>
															Add Testimonial
														</NavLink>
													</li>

													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-member'
															exact
														>
															Add Member
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/send-announcements'
															exact
														>
															Add Announcements
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-jobDescription'
															exact
														>
															Add Job Description
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/candidateSearch'
															exact
														>
															Candidate Search
														</NavLink>
													</li>



													<li>
														<NavLink
															href='javascript:void(0);'
															className='dropdown-item'
															to='/send-campus-invite'
															exact
														>
															Invite Campus
														</NavLink>
													</li>

													<li>
														<a
															href='javascript:void(0);'
															className='dropdown-item'
															onClick={(e) => openModal('createwebsite')}
														>
															Create Website
														</a>
													</li>


												</>
											)}

											{isCampus == 1 &&
												<>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-coordinator'
															exact
														>
															Add Coordinator
														</NavLink>
													</li>
													<li>
														<NavLink
															activeClassName='dropdown-item'
															className='dropdown-item'
															to='/add-campus-access-level'
															exact
														>
															Add Access Level
														</NavLink>
													</li>
												</>
											}

											<li>
												<NavLink
													activeClassName='dropdown-item'
													className='dropdown-item'
													to='/change-password'
												>
													Change Password
												</NavLink>
											</li>
											<li>
														<a
															href='javascript:void(0);'
															className='dropdown-item'
															onClick={(e) => openModal('createwebsite')}
														>
															Create Website
														</a>
													</li>





											<li>
												<a
													activeClassName='dropdown-item'
													className='dropdown-item'
													href='javascript:void(0);'
													onClick={(e) => {
														localStorage.setItem(APP_Prefix + 'auth_token', null);
														localStorage.setItem(APP_Prefix + 'auth_profile', null);
														window.location.reload();
													}}
												>
													Logout
												</a>
											</li>
										</ul>
									</div>
								</>
							}

						</section>
					</div>
				</div>
			</nav>
		</header>
	</>
);
}

export default Header
