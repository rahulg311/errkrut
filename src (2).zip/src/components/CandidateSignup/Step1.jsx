import React, { useState, useEffect } from 'react';
import IntroStep1 from '../Intros/Signup/IntroStep1';
import SignupHeader from './SignupHeader';
import { fbAuth } from '../../config/Firebase';
import firebase from 'firebase';
import { socialLogin } from '../../store/actions/signup';
import { useDispatch, useSelector } from 'react-redux';
import { notification } from '../../classes/messages';
import { routeChanged } from '../../classes/browserHistory';
import { APP_Prefix, Candidate_User_Type_ID } from '../../config/constants';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEye } from '@fortawesome/free-solid-svg-icons'
import { faEyeSlash } from '@fortawesome/free-solid-svg-icons'


const Step1 = ({
	handleChange,
	trySignup,
	errors,
	props
}) => {

	const dispatch = useDispatch();

	const [passwordShown, setPasswordShown] = useState(false);
	const [passwordCShown, setCPasswordShown] = useState(false);
	const eye_open = <FontAwesomeIcon icon={faEye} />
	const eye_close = <FontAwesomeIcon icon={faEyeSlash} />

	const togglePasswordVisiblity = () => {
		setPasswordShown(passwordShown ? false : true);
	};
	const toggleCPasswordVisiblity = () => {
		setCPasswordShown(passwordCShown ? false : true);
	};

	const { data } = useSelector(state => state.common);

	let handleRegistrationWithGoogle = async () => {

		var provider = new firebase.auth.GoogleAuthProvider();

		let response = await fbAuth.signInWithPopup(provider);/* .then(async(response) => { */
		let user = response.user;
		//console.log(user);

		console.log(user.displayName);

		let authUser = {};
		authUser['name'] = user.displayName;
		authUser['login_type'] = 'google';
		authUser['email'] = user.email;
		authUser['user_type'] = Candidate_User_Type_ID;
		authUser['id'] = Candidate_User_Type_ID;
		authUser['avatar'] = user.photoURL;

		//console.log(authUser)

		let data = await socialLogin(authUser);

		//socialLogin(authUser);

		//console.log(data);

		/* login success */

		if (data) {

			let auth_profile = {
				name: data.data.name,
				email: data.data.email,
				mobile: data.data.mobile,
				id: data.data.id,
				user_type: Candidate_User_Type_ID,
				company_id: data.company_id
			};

			localStorage.setItem(APP_Prefix + 'auth_token', JSON.stringify(data.data.token));

			localStorage.setItem(APP_Prefix + 'auth_profile', JSON.stringify(auth_profile));

			/* login token storage */

			let notify = notification({ message: data.message, type: 'success' });

			notify();

			routeChanged('/', props, 1);

		}

		/* login success */


		//})
	}

	let handleRegistrationWithFacebook = () => {
		var provider = new firebase.auth.FacebookAuthProvider();
		fbAuth.signInWithPopup(provider).then((response) => {
			let user = response.user;
			//console.log(user);
		})
	};

	return (
		<div className='container-fluid vh-100'>
			<div className='row'>
				<div className='col-md-6'>
					<IntroStep1></IntroStep1>
				</div>
				<div className='col-md-6'>
					<div
						className='bg-light-blue vh-100 bg-no-repeat bg-40-size'
						style={{
							backgroundImage:
								process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-right.png')",
							backgroundPosition: 'bottom right',
						}}
					>
						<div className='pt-5 pb-5 ps-2 pe-6 w-65 ms-auto me-auto vh-100 position-relative'>
							<SignupHeader></SignupHeader>
							<div className='mt-30px'>
								<h5 className='text-dark'>Step 1 of 3</h5>
								<div className='row mb-2 mt-2'>
									<div className='col-md-12'>
										<label>Email or Mobile Number*</label>
									</div>
									<div className='col-md-12'>
										<input
											type='text'
											className='form-control'
											placeholder='Enter your email or mobile number'
											onKeyUp={handleChange}
											name='email'
										/>
									</div>
								</div>
								<div className='row mb-2 mb-2'>
									<div className='col-md-12'>
										<label className=''>Password*</label>
									</div>
									<div className='col-md-12'>
										<div class="input-group mb-3">
											<input
												type={passwordShown ? "text" : "password"}
												className='form-control'
												placeholder='******'
												name='password'
												onKeyUp={handleChange}
												style={{ "z-index": 0 }}
											/>
											<div className="end-0 me-2 position-absolute top-8px">
												<a href="javascript:void(0)" onClick={togglePasswordVisiblity}>{passwordShown ? eye_close : eye_open}</a>
											</div>
										</div>
									</div>
								</div>
								<div className='row mb-2'>
									<div className='col-md-12'>
										<label className=''>Confirm Password*</label>
									</div>
									<div className='col-md-12'>
										<div class="input-group mb-3">
											<input
												type={passwordCShown ? "text" : "password"}
												className='form-control'
												placeholder='******'
												name='confirmPassword'
												onKeyUp={handleChange}
												style={{ "z-index": 0 }}
											/>
											<div className="end-0 me-2 position-absolute top-8px">
												<a href="javascript:void(0)" onClick={toggleCPasswordVisiblity}>{passwordCShown ? eye_close : eye_open}</a>
											</div>
										</div>
									</div>
									{errors.confirmPassword && (
										<p className='text-danger'>{errors.confirmPassword}</p>
									)}
								</div>
								<div className='row mb-2 mb-1'>
									<div className='col-md-12'>
										<a
											href='javascript:void(0)'
											className='btn btn-primary ms-auto me-auto d-block w-50'
											onClick={trySignup}
										>
											Next
										</a>
									</div>
								</div>
								<div className='row mt-4'>
									<div className='col-md-12'>
										<h6 className='text-center'>or Signup with</h6>
									</div>
									<div className='container mt-4  d-flex justify-content-center'>

										<img className="img-fluid box-shadow h-40px br-5 cursor me-2" src={process.env.PUBLIC_URL + "/assets/icons/google.png"} onClick={handleRegistrationWithGoogle} />

										<img className="img-fluid box-shadow h-40px br-5 cursor me-2" src={process.env.PUBLIC_URL + "/assets/icons/fb.png"} onClick={handleRegistrationWithFacebook} />

										<img className="img-fluid box-shadow h-40px br-5 cursor" src={process.env.PUBLIC_URL + "/assets/icons/linkedin.png"} />

									</div>
								</div>
							</div>
							<div className="col-md-12 text-center mt-2 mb-2 fw-bold"><a href="/">Go Back to Homepage</a></div>

						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Step1


