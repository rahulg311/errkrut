import React from 'react';
import IntroStep3 from '../Intros/Signup/IntroStep3';
import SignupHeader from './SignupHeader';
import { parseArrayToHTML } from '../../classes/handleHtml';
import { connect } from "react-redux";
import {
	getCountryCategory,
	getStateCategory,
	getCityCategory,
  } from "../../store/actions/signup";

class Step3 extends React.Component {
	componentDidMount() {
		this.props.getCountryCategory();
	  }
	
	  getStateCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getStateCategory(id);
		}
	  }
	
	  getCityCategory(e) {
		if (e) {
		  const select = e.target;
		  const id = select.children[select.selectedIndex].id;
		  this.props.getCityCategory(id);
		}
	  }
	render() {
		const { formDataField, handleChange, handleSubmit, currentStateData } = this.props;

		let form_fields = [];

		/* loop starts here */

		if (Object.keys(formDataField).length > 0) {

			Object.keys(formDataField).map((key, value) => {

				if (formDataField[key].length > 0) {

					let fieldArr = {};

					fieldArr['title'] = <h5 className='text-dark'>{key}</h5>;

					/* loop start here */
					fieldArr['fields'] = formDataField[key].map((v, k) => {

						let fieldObj = {
							name: v.name,
							type: v.type,
							class: 'form-control',
							attr_options: v.attr_options,
							title: v.title,
						};
						if (v.name === "country") {
							return (
							  <div class="row mb-2">
								<div class="col-md-12">
								  <label className="f-1">Country*</label>
								</div>
								<div class="col-md-12">
								  <select
									className="form-control"
									name={v.name}
									onChange={(e) => {
									  handleChange(e, "", "dynamic");
									  this.getStateCategory(e);
									}}
									required
								  >
									<option value="" selected disabled>
									  --Select Country--
									</option>
									{this.props.country_category_res?.data &&
									  this.props.country_category_res?.data.map((opt) => {
										return <option id={opt.id} value={opt.name}>{opt.name}</option>;
									  })}
								  </select>
								</div>
							  </div>
							);
						  }
						  if (v.name === "state") {
							return (
							  <div class="row mb-2">
								<div class="col-md-12">
								  <label className="f-1">State*</label>
								</div>
								<div class="col-md-12">
								  <select
									className="form-control"
									name={v.name}
									onChange={(e) => {
									  handleChange(e, "", "dynamic");
									  this.getCityCategory(e);
									}}
									required
								  >
									<option value="" selected disabled>
									  --Select State--
									</option>
									{this.props.state_category_res?.data &&
									  this.props.state_category_res?.data.map((opt) => {
										return <option id={opt.id} value={opt.name}>{opt.name}</option>;
									  })}
								  </select>
								</div>
							  </div>
							);
						  }
						  if (v.name === "city") {
							return (
							  <div class="row mb-2">
							  <div class="col-md-12">
								<label className="f-1">City*</label>
							  </div>
							  <div class="col-md-12">
								<select
								  className="form-control"
								  name={v.name}
								  onChange={(e) => handleChange(e, "", "dynamic")}
								  required
								>
								  <option value="" selected disabled>
									--Select City--
								  </option>
								  {this.props.city_category_res?.data &&
									this.props.city_category_res?.data.map(
									  (opt) => {
										return (
										  <option id={opt.id} value={opt.name}>{opt.name}</option>
										);
									  }
									)}
								</select>
							  </div>
							</div>
							);
						  }
						  if (v.name === "resume[]") {
							return (
							<div class="row mb-2">
								<div class="col-md-12">
									<label className="btn btn-primary btn-sm" for="resume[]" type="button">
										<span className="vertical-middle">{v.title}</span>
										<i class="las la-file-export f-1-1 vertical-middle"></i>
									</label>
									<input type="file" style={{ display: "none" }} id={v.name} multiple onChange={(e) =>handleChange(e, '', 'dynamic')} name={v.name} required/>
									<span className='ps-1'>{currentStateData[v.name] ? currentStateData[v.name][0]?.name : ''}</span>
								</div>
							</div>
							);
						  }
						return (
							<>
								<div class='row mb-2'>
									<div class='col-md-12'>
										<label className='f-1'>{v.title} {v.validation_rules[0] == "required" ? '*' : ''}</label>
									</div>
									<div class='col-md-12'>
										{parseArrayToHTML(
											fieldObj,
											(e) => handleChange(e, '', 'dynamic'),
											currentStateData ? currentStateData[v.name] : '',
										)}
									</div>
								</div>
							</>
						);

					});

					form_fields.push(fieldArr);

					/* loop end here */

				}

			});

		}

		/* loop starts here */

		return (
			<div className='container-fluid vh-100 bg-light-blue'>
				<div className='row'>
					<div className='col-md-6 p-0'>
						<IntroStep3></IntroStep3>
					</div>
					<div className='col-md-6'>
						<div
							className='bg-light-blue vh-100 bg-no-repeat bg-40-size'
							style={{
								backgroundImage:
									process.env.PUBLIC_URL + "url('/assets/imgs/signup-login-bg-right.png')",
								backgroundPosition: 'bottom right',
							}}
						>
							<div className='pt-4 pb-5 pl-2 pr-6 w-65 ms-auto me-auto vh-100'>
								<SignupHeader></SignupHeader>

								{/* row */}
								<div className='mt-2 pb-2'>

									<form method='POST' action='' name='candidateSignupStep3'>

										{/* dynamic fields here */}

										{form_fields.length > 0 ? form_fields.map((v, k) => {
											return <>
												{v.title}
												{v.fields}
											</>
										}) : ''}

										{/* dynamic fields here */}


										{/* submit button */}
										<div className='d-flex justify-content-between align-items-center'>

											<a
												href='javascript:void(0)'
												onClick={this.props.prevStep}
											>
												Back
											</a>

											<button
												type='button'
												href='javascript:void(0)'
												className='btn btn-primary'
												onClick={handleSubmit}
											>
												Submit
											</button>

										</div>
										{/* submit button */}

									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	const {
	  country_category_res,
	  state_category_res,
	  city_category_res,
	} = state.common;
	return {
	  country_category_res,
	  state_category_res,
	  city_category_res,
	};
  };
  
  function mapDispatchToProps(dispatch) {
	return {
	  getCountryCategory: () => dispatch(getCountryCategory()),
	  getStateCategory: (id) => dispatch(getStateCategory(id)),
	  getCityCategory: (id) => dispatch(getCityCategory(id)),
	};
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(Step3);
