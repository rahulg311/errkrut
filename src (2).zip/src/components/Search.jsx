import React from 'react';
import JobsList from './Cards/JobsList';
import { searchDetail } from '../store/actions/search';
import { connect } from "react-redux";
import Loading from './common/Loading';
import { getJobCategories } from '../store/actions/jobs';
import { getCompanies } from '../store/actions/companies';
import { NavLink } from 'react-router-dom';
import Slider from 'react-slick';
import { getSkills } from '../store/actions/skills';
import { getValueFromArr } from '../classes';

class Search extends React.Component {

	state = {
		jobs_data: [],
		search_type: 'all',
		page_num: 1,
		limit_page: 100,
		loader: false,
		no_data: false,
		search_value: '',
		job_categories: null,
		featured_companies: [],
		skills: [],
		search_value: ''
	}

	componentDidMount() {
		this.jobCategories();
		this.getFeaturedCompanies();
		this.getSkills();
	}

	jobCategories = async () => {
		await this.props.getJobCategories();
		if (this.props.get_job_cat_res?.status == 'success') {
			this.setState({
				job_categories: this.props.get_job_cat_res.data
			})
		}
	}

	getSkills = async () => {
		await this.props.getSkills();
		this.setState({
			skills: this.props.skillsdata.data
		});
	}

	getFeaturedCompanies = async () => {
		await this.props.getCompanies();
		//console.log(this.props.data);
		if (this.props.data?.status == 'success') {
			this.setState({
				featured_companies: this.props.data.data,
			});
		}
	};


	/* search jobs */
	search = async (str = '') => {

		this.setState({
			loader: true,
			search_value: str
		});

		let obj = {};
		obj[this.state.search_type] = this.state.search_value;
		obj['page_num'] = this.state.page_num;
		obj['limit_page'] = this.state.limit_page;

		await this.props.searchDetail(obj);

		if (this.props.search_res) {

			if (this.props.search_res?.data?.length < this.state.limit_page) {
				this.setState({
					no_data: true
				});
			}

			console.log('jobsssss ', this.props.search_res.data)

			this.setState(prevState => ({
				loader: false,
				jobs_data: [...prevState?.jobs_data, ...this.props.search_res?.data],
			}));

		}

	}
	/* search jobs */



	handleChange(e) {
		let value = e.target.value;
		this.setState({
			search_value: value
		});
	}

	updateSearchType(type) {

		this.setState({ search_type: type, page_num: 1, search_value: '' }, () => {
			this.search(this.state.search_value);
		});

	}

	loadMore = () => {
		let page = this.state.page_num;
		this.setState({
			page_num: page + 1
		}, () => {
			this.search(this.state.search_value);
		});
	}

	render() {

		/* slick slider settings */
		const settings = {
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 5,
			slidesToScroll: 5,
			autoplay: true,
			autoplaySpeed: 3000,
			centerMode: true,
			centerPadding: "20px",
			responsive: [

				{
					breakpoint: 1025,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 3,
						centerMode: true,
					}
				},
				{
					breakpoint: 600,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						initialSlide: 2,
						centerPadding: "0px",
					}
				},
				{
					breakpoint: 480,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						centerPadding: "0px",
					}
				}
			]
		};
		/* slick slider settings */

		return (
			<>
				<div className='bg-white mt-4 px-4 py-4 rounded-4'>
					<header>
						<h5 className='font-bold mb-2'>Find the Best Place to Work</h5>
					</header>
					<div>
						<div>
							<ul className='nav px-0 mt-3 '>
								<li className='nav-item' onClick={(e) => this.updateSearchType('all')}>
									<a
										className={`nav-link me-4 px-0 ${this.state.search_type == `all` ? `active` : ``
											}`}
										aria-current='page'
										href='javascript:void(0);'
									>
										Search Jobs
									</a>
								</li>
								<li className='nav-item' onClick={(e) => this.updateSearchType('company')}>
									<a
										className={`nav-link me-4 px-0 ${this.state.search_type == `company` ? `active` : ``
											}`}
										href='javascript:void(0);'
									>
										All Jobs
									</a>
								</li>
								<li className='nav-item d-none' onClick={(e) => this.updateSearchType('skill')}>
									<a
										className={`nav-link me-4 px-0 ${this.state.search_type == `skill` ? `active` : ``
											}`}
										href='javascript:void(0);'
									>
										Jobs By Skills
									</a>
								</li>
								<li className='nav-item d-none' onClick={(e) => this.updateSearchType('designation')}>
									<a
										className={`nav-link me-4 px-0 ${this.state.search_type == `designation` ? `active` : ``
											}`}
										href='javascript:void(0);'
									>
										Jobs By Designation
									</a>
								</li>
								<li className='nav-item d-none' onClick={(e) => this.updateSearchType('location')}>
									<a
										className={`nav-link me-4 px-0 ${this.state.search_type == `location` ? `active` : ``
											}`}
										href='javascript:void(0);'
									>
										Jobs By Location
									</a>
								</li>
							</ul>

							{/* horizontal line */}
							<div className='border-gray-line'></div>
							{/* horizontal line */}

							<form className='d-flex justify-content-between' onSubmit={(e) => { this.search(this.state.search_value); e.preventDefault(); }}>
								<div className='input-group mb-3 my-3'>
									<input
										type='text'
										className='form-control ps-5  mt-0'
										placeholder='Search Skill, Designation, Company'
										onChange={(e) => this.handleChange(e)}
									/>
									<img
										src='/assets/imgs/search.png'
										style={{ top: '99px !important' }}
										className='img-fluid translate-left-middle w-19px ms-1 z-9'
									/>
									<span onClick={(e) => this.search(this.state.search_value)} className='input-group-text bg-secondary bg-opacity-15 px-4 cursor'>Search</span>
								</div>
							</form>
							<div className={`${this.state.search_type == `all` ? `` : `d-none`}`}>
								{/* popular skills */}
								<div className='row mt-1'>
									<div className='col-md-12'>
										<div className='d-flex justify-content-between'>
											<p className='font-bold'>Popular Skills To Search</p>
										</div>
									</div>

									<div className='col-md-12 mt-1'>
										{this.state.skills && Object.keys(this.state.skills).map((key) => {
											return <span className='badge badge-default cursor me-1 mb-1'>
												<a href={`/search/${this.state.skills[key]}`}> {this.state.skills[key]} </a>
											</span>
										})}
									</div>
								</div>
								{/* popular skills */}
								<hr />
								<div className='row mt-4 mb-4'>
									<div className='col-md-12'>
										<div className='d-flex justify-content-between'>
											<h6 className='font-bold'>Featured Companies</h6>
											<p className='mt-auto mb-auto'>
												<NavLink to='/search'>See All</NavLink>
											</p>
										</div>
									</div>
									<div className='col-md-12'>

										<Slider {...settings}>
											{this.state.featured_companies.length > 0 && this.state.featured_companies?.map((tc, i) => {
												return i < 8 &&

													<div className='cards position-relative my-2 me-3 px-3 rounded-4 '>
														<div className='card d-flex justify-content-center border-0 ' style={{ height: '150px', width: '150px' }}>
															<NavLink to={`/company/` + tc.id}>
																<img
																	src={(tc?.logo) ? getValueFromArr(tc?.logo, 0) : `/assets/imgs/dummy-logo.png`}
																	className='box-shadow w-100 img-fluid'
																/>
															</NavLink>
														</div>
													</div>
													;
											})}
										</Slider>

									</div>
								</div>
								<hr />

								<div className='col-md-12 mt-3 mb-3'>
									<div className='row'>
										<h6 className='font-bold'>Job Catgories</h6>

										{this.state.job_categories != null && Object.keys(this.state.job_categories).map((k) => {

											return (
												<>
													<div className='col-md-4'>
														<p className='text-purple font-bold mt-1 mb-3'>{k}</p>
														<ul className='list-unstyled'>
															{this.state.job_categories[k]?.length > 0 && this.state.job_categories[k].map((arr) => {
																return <li className='mb-1'>
																	<NavLink to={`/search/${arr}`}>
																		<p className='f-0-8 text-decoration-none text-dark'>{arr}</p>
																	</NavLink>
																</li>
															})}
														</ul>
													</div>
												</>
											)

										})}

									</div>
								</div>
							</div>
						</div>
						<div className={`${this.state.search_type == `company` ? `` : `d-none`}`}>
							{/* jobs list */}
							{this.state.jobs_data.length > 0 &&
								<JobsList jobs={this.state.jobs_data} />
							}
						</div>
						{/* jobs list */}

						{/* load more */}

						{this.state.loader && <Loading className="me-auto ms-auto d-block mt-2 mb-2" />}

						{(this.state.no_data == false && this.state.jobs_data.length > 0) &&
							<button className="btn btn-primary btn-sm d-block me-auto ms-auto mt-2 mb-2" onClick={() => { this.loadMore() }}>
								<i className="las la-angle-double-down"></i> Load More
							</button>
						}
						{/* load more */}


					</div>
				</div>
			</>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log(state);
	const { search_res, get_job_cat_res, data, skillsdata } = state.common
	return {
		search_res,
		get_job_cat_res,
		data,
		skillsdata
	}
};

function mapDispatchToProps(dispatch) {
	return {
		searchDetail: (searchValule) => dispatch(searchDetail(searchValule)),
		getJobCategories: () => dispatch(getJobCategories()),
		getCompanies: () => dispatch(getCompanies()),
		getSkills: () => dispatch(getSkills()),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(Search);
