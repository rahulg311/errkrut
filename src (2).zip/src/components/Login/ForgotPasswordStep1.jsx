import React from 'react';
import { NavLink } from 'react-router-dom';

import ForgotPasswordHeader from './ForgotPasswordHeader';

class ForgotPasswordStep1 extends React.Component {

    render() {

        const { handleChange, stepOne_handler } = this.props;

        return (
            <>
                {/* row */}
                <div className="mt-5">

                    <ForgotPasswordHeader />

                    <div className="row mb-2">
                        <div className="col-md-12">
                            <label className="">Email/Mobile Number</label>
                        </div>
                        <div className="col-md-12">
                            <input type="text" className="form-control" name="email" onChange={handleChange} />
                        </div>
                    </div>

                    <div className="row mb-2">
                        <div className="col-md-12">

                            <div className="d-flex">
                                <a href="javascript:void(0)" className="btn btn-primary ms-auto d-block" onClick={stepOne_handler}>Next</a>
                            </div>

                        </div>
                    </div>

                </div>

                {/* row */}

            </>

        );

    }

}

export default ForgotPasswordStep1;