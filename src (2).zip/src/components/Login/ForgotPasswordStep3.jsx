import React from 'react';
import IntroStep1 from '../Intros/Signup/IntroStep1';
import ForgotPasswordHeader from './ForgotPasswordHeader';

class ForgotPasswordStep3 extends React.Component {

    render() {

        const { handleChange, changePassword_handler } = this.props;

        return (
            <div className="container-fluid ">

                <div className="row">
                    <div className="col-md-12 p-0">

                        <ForgotPasswordHeader />

                        {/* row */}
                        <div className="mt-5">
                            <h5 className="text-dark">Set New Password</h5>

                            
                            <div className="row mb-2">
                                <div className="col-md-12">
                                    <label className="">New Password</label>
                                </div>
                                <div className="col-md-12">
                                    <input type="password" className="form-control" placeholder="****" name="new_password" onChange={handleChange} />
                                </div>
                            </div>

                            <div className="row mb-2">
                                <div className="col-md-12">
                                    <label className="">Confirm Password</label>
                                </div>
                                <div className="col-md-12">
                                    <input type="password" className="form-control" placeholder="****" name="confirm_password" onChange={handleChange} />
                                </div>
                            </div>

                            <div className="d-flex justify-content-between align-items-center mb-2">
                                <a href="javascript:void(0)" onClick={this.props.prevStep}>Back</a>
                                <a href="javascript:void(0)" className="btn btn-primary" onClick={changePassword_handler}>Update Password</a>
                            </div>

                            {/* row */}
                        </div>
                    </div>
                </div>

            </div >
        );
    }
}

export default ForgotPasswordStep3;