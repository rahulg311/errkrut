import React from 'react';
import { NavLink } from 'react-router-dom';

class LoginHeader extends React.Component {

    render() {

        return (
            <div className="mb-3">
                <NavLink to="/">
                <img src={process.env.PUBLIC_URL + "/assets/imgs/logo.png"} className="img-fluid logo-1" />
                </NavLink>
                <h4 className="mt-3 font-bold">Login</h4>
                <p>New to Erekrut? <NavLink to="/candidate-signup">Sign Up Here</NavLink></p>
            </div>
        );

    }

}

export default LoginHeader;