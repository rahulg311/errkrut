import React from 'react';
import IntroStep1 from '../Intros/Signup/IntroStep1';
import LoginHeader from './LoginHeader';

class Step2 extends React.Component {

    render() {

        const { handleChange, tryValidate, resendOTP } = this.props;

        return (
            <div className="container-fluid vh-100">

                <div className="row">
                    <div className="col-md-12 p-0">

                        <LoginHeader />

                        {/* row */}
                        <div className="mt-5">
                            <h5 className="text-dark">Verify OTP</h5>

                            <div className="row mb-2">
                                <div className="col-md-12">
                                    <label className="">Enter OTP</label>
                                </div>
                                <div className="col-md-12">
                                    <input type="text" className="form-control" placeholder="****" name="otp" onChange={handleChange} />
                                </div>
                            </div>

                            <div className="d-flex justify-content-between align-items-center mb-2">
                                <a href="javascript:void(0)" onClick={this.props.prevStep}>Back</a>
                                <a href="javascript:void(0)" className="btn btn-primary" onClick={tryValidate}>Verify</a>
                            </div>

                            <div className="d-flex">
                                <span
                                    href='javascript:void(0)'
                                    className='ms-auto d-block float-end text-danger cursor'
                                    onClick={resendOTP}>
                                    Resend OTP
                                </span>
                            </div>

                            {/* row */}
                        </div>
                    </div>
                </div>

            </div >
        );
    }
}

export default Step2;