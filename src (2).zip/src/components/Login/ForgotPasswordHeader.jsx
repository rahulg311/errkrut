import React from 'react';
import { NavLink } from 'react-router-dom';

class ForgotPasswordHeader extends React.Component {

    render() {

        return (
            <div className="mb-3">
                <NavLink to="/">
                <img src={process.env.PUBLIC_URL + "/assets/imgs/logo.png"} className="img-fluid logo-1" />
                </NavLink>
                <h4 className="mt-3 mb-1 font-bold">Forgot Password</h4>
                <p>Already Registered? <NavLink to="/login">Login Here</NavLink></p>
            </div>
        );

    }

}

export default ForgotPasswordHeader;