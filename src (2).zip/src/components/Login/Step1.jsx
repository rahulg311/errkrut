import React from 'react';
import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import LoginHeader from './LoginHeader';
import { faEye } from '@fortawesome/free-solid-svg-icons'
import { faEyeSlash } from '@fortawesome/free-solid-svg-icons'
class Step1 extends React.Component {

    state = {
        showpassword: false
    }

    togglePasswordVisiblity = () => {
        if (this.state.showpassword == true) {
            this.setState({

                showpassword: false
            });
        } else {
            this.setState({

                showpassword: true
            });
        }
    };


    render() {

        const eye_open = <FontAwesomeIcon icon={faEye} />
        const eye_close = <FontAwesomeIcon icon={faEyeSlash} />

        const { handleChange, loginUser } = this.props;

        return (
            <>
                {/* row */}
                <div className="mt-5">

                    <LoginHeader />

                    <div className="row mb-2">
                        <div className="col-md-12">
                            <label className="">Email/Mobile Number</label>
                        </div>
                        <div className="col-md-12">
                            <input type="text" className="form-control" name="email" onChange={handleChange} />
                        </div>
                    </div>

                    <div className="row mb-2">
                        <div className="col-md-12">
                            <label className="">Password</label>
                        </div>
                        <div className="col-md-12">
                            <div class="input-group mb-3">
                                <input type={this.state.showpassword ? 'text' : 'password'} className="form-control" name="password" onChange={handleChange} style={{ "z-index": 0 }} />
                                <div className="end-0 me-2 position-absolute top-8px">
                                    <a href="javascript:void(0)" onClick={this.togglePasswordVisiblity}>{this.state.showpassword ? eye_open : eye_close}</a>
                                </div>
                            </div>


                        </div>
                    </div>

                    <div className="row mb-2">
                        <div className="col-md-12">

                            <div className="d-flex">
                                <NavLink to="/forgot-password" className="mt-auto mb-auto">Forgot Password?</NavLink>
                                <a href="javascript:void(0)" className="btn btn-primary ms-auto d-block" onClick={loginUser}>Login</a>
                            </div>

                        </div>
                    </div>

                </div>

                {/* row */}

            </>

        );

    }

}

export default Step1;