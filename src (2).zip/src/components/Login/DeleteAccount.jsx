import React, { Component } from 'react';
import { getLoggedInUser } from '../../classes';
import { connect } from 'react-redux';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { deleteAccount } from '../../store/actions/signup';
import { APP_Prefix } from '../../config/constants';

class DeleteAccount extends Component {


	async componentWillMount() {

	}


	render() {

		const deleteAccount = async () => {
			confirmAlert({
				customUI: ({ onClose }) => {
					return (
						<div className="card shadow p-3 w-100">
							<div className="card-header bg-transparent">
								<h6>
									Please Confirm
								</h6>
							</div>
							<div className="card-body">
								<p> Please confirm if you want to delete your account? You will loose access to the all your data. </p>
							</div>
							<div className="bg-transparent card-footer d-flex justify-content-end">
								<button className="btn btn-primary me-3" onClick={onClose}>No</button>
								<button className="btn btn-danger text-white"
									onClick={() => {
										handleClickDelete();
										onClose();
									}}
								>
									Yes, Delete account!
								</button>
							</div>
						</div>
					);
				}
			});
		};

		const handleClickDelete = async () => {
			let user = await getLoggedInUser();

			if (user) {

				let obj = {};
				obj['user_id'] = user.id;

				await this.props.deleteAccount(user.id);
				localStorage.setItem(APP_Prefix + 'auth_token', null);
				localStorage.setItem(APP_Prefix + 'auth_profile', null);
				window.location.reload();

			}
		}

		return (

			<div className="card p-2 rounded-4 shadow border-0">
				<div class="d-grid gap-2 col-12 col-md-6 mx-auto">
				<button class="btn btn-danger text-white " onClick={deleteAccount}>Delete Account</button>
			</div>

</div>

		);
	}
}

const mapStateToProps = (state) => {

	const { delete_user } = state.common
	return {
		delete_user
	}
};

function mapDispatchToProps(dispatch) {
	return {
		deleteAccount: (user_id) => dispatch(deleteAccount(user_id))
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(DeleteAccount);
