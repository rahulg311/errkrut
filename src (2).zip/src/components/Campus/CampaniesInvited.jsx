import React, { useState, useEffect } from "react";

import { COMPANY_LISTING, END_POINT } from "../../routes/api_routes";
import Loading from "../common/Loading";
import { Link } from "react-router-dom";
import { getLoggedInUser } from "../../classes";
import moment from "moment";
import { EditModal } from "./EditModal";


const CampniesInvited = ({ data, loading, handleCompaniesRowAPI, isEditable }) => {
 
  return (
    <div className="col-md-12 mt-3">
      <div>
        <header className="row bg-primary text-white p-1 rounded-top shadow">
          <div className=" col-4 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10">Company Name  <i class="fas fa-sort mt-4px ms-1"></i></span>

           
          </div>

          <div className=" col-4 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10"> Country  <i class="fas fa-sort mt-4px ms-1"></i></span>

         
          </div>

          <div className=" col-4 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10">Date  <i class="fas fa-sort mt-4px ms-1"></i></span>

            
          </div>
        </header>
        <main>
          {loading ? (
            <Loading className="my-3" />
          ) : data && data.length ? (
            <>
              {data.map((profile, idx) => {
                const even = idx % 2 == 0;
                return (
                  <div
                    key={profile.id}
                    className={`row align-items-center p-2 ${
                      even ? "bg-table-striped" : "bg-light-blue"
                    }`}
                  >
                    <div className="col-4">
                      <small className="f-r-10">{profile?.company_name}</small>
                    </div>

                    <div className="col-4">
                      <small className="f-r-10">{profile?.country}</small>
                    </div>

                    <div className="col-4">
                      <small className="f-r-10">
                        {profile?.created_at &&
                          moment(profile?.created_at).format(
                            "MMMM Do YYYY h:mm a"
                          )}
                      </small>
                      {isEditable && (
                      <div className="">
                       <EditModal profile={profile} handleRowAPI={handleCompaniesRowAPI}/>
                      </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </>
          ) : (
            <div className="row justify-content-center align-items-center p-4 bg-light-blue">
              <div className="text-center font-bold text-sky-blue">
               You have not send invitation to any companies 
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CampniesInvited;
