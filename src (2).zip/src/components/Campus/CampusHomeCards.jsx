import React, { useState } from 'react';
import { getAuthToken, getLoggedInUser } from '../../classes';
import { END_POINT } from '../../routes/api_routes';

const CampusHomeCard = (props) => {

	const [data, setData] = useState({});
	const [companies, setCompanies] = useState();

	React.useEffect(async () => {
		
		const user = await getLoggedInUser();
		let token = await getAuthToken();
		var requestOptions = {
			method: 'GET',
			redirect: 'follow',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};

		fetch(END_POINT + 'get_campus_dashboard_data/' + `${user.id}`, requestOptions)
			.then((response) => response.json())
			.then((result) => {
				setData(result.data);
				let companies = result.data.companies.map((row,index) => {
					return(
						<div className='col-12 pt-1 cards-shadow rounded-3 pb-1 mb-1'>
							<p className='float-start fs-10 fw-bold'>{row.company_name}</p>
							<p className='float-end fw-bold fs-10'>{row.count}</p>
						</div>
					)
				});
				setCompanies(companies);
			})
			.catch((error) => console.log('error', error));
	}, [])

	return (

		<div className='bg-white br-5 rounded-5 py-5 ps-4 pe-4 mb-3'>
			<div className=" row bg-white mt-2 ">
				<div className='container'>
					<div className='bg-white pb-4 px-2 rounded-4'>
						<div className='row'>
							<div className='col-md-12'>
								<div className='d-flex justify-content-between w-100'>
									<h4 className='font-bold float-left'>Dashboard</h4>
									{(props.showSeeAll == true) && <p className='float-right mt-auto mb-auto'>
										<a href='/campus-stats'>See All</a>
									</p>}
								</div>
							</div>

						</div>
						<div className='row mt-4  '>
							<div className='campus-dashboard-list col-md-6 cards-shadow br-5 mb-2  '>

								<div className='row mt-3 mb-1'>
									<div className='col-md-5 mt-1'>

										<h6 className='font-bold float-left'>Company List</h6>
									</div>
									
								</div>

								<div className='row'>
									<div className='col-md-12 ms-1'>
										<div className='row  me-1'>
											{companies}
										</div>
									</div>
								</div>

							</div>
							<div className='col-md-6'>
								<div className='row mb-1 '>
									<div className='col-md-4 mb-2  '>
										<div className='cards  bg-blue br-5 text-white ps-1  h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.total_student_cv}</p>
											<p className='fs-14 position-abs b-2 pe-1 text-end m-0 mt-5  font-bold pb-1 '><span className='float-end '> Total</span> <br />  <span>Students CV</span></p>
										</div>
									</div>
									<div className='col-md-4 mb-2 '>
										<div className='cards bg-greenesh-blue br-5 text-white ps-1 h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.companies_invited}</p>
											<p className='fs-14 position-abs b-2 r-2 text-end m-0 mt-5 font-bold  pb-1  '><span className='float-end me-1'>Companies</span> <br /> <span className='ms-2 me-1 float-end'> Invited</span> </p>
										</div>
									</div>
									<div className='col-md-4 mb-2 '>
										<div className='cards bg-dark-pink br-5 text-white ps-1  h-100 mr-2'>
											<p className='fs-28 position-abs t-2 l-2 m-0 font-bold '>{data?.recruitment_member}</p>
											<p className='fs-14 position-abs b-2 r-2 me-1 text-end m-0 mt-5 font-bold  pb-1 '><span className='float-end'> Recruitment</span> <br /> <span className=' float-end'> Members</span> </p>
										</div>
									</div>
								</div>
								<div className='row '>
									<div className='col-md-6 mb-2'>
										<div className='pt-1 p-1 shadow br-5'>
											<h6>{data?.companies_invite_sent}</h6>
											<progress className='mt-1 ' id="file" value={data?.companies_invite_sent} max="100"> </progress>
											<div className='row'>
												<div className='col-md-12 h-100'>
													
													<h6 className='float-end f-0-8 mt-1 mb-1'>Company Invited Sent</h6>
												</div>
											</div>
										</div>
									</div>
									<div className='col-md-6 h-100'>
										<div className='pt-1 p-1 shadow br-5'>
											<h6>{data?.email_sent}</h6>
											<progress className='mt-1' id="file" value={data?.email_sent} max="100">  </progress>
											<div className='row'>
												<div className='col-md-12'>
													<h6 className='float-end f-0-8 mt-1 mb-1'>Sent</h6>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default CampusHomeCard;
