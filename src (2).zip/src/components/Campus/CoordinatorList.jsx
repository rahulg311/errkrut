import React, { useState, useEffect } from "react";
import useFetch from "../../hooks/useFetch";
import { getLoggedInUser, getAuthToken } from "../../classes";
import Loading from "../common/Loading";
import { Link } from 'react-router-dom';
import { notification } from './../../classes/messages';
import {
  END_POINT,
  GET_COORDINATOR_LIST,
} from "../../routes/api_routes";

const CoordinatorList = () => {
  
	const { data, loading, error,doFetch } = useFetch();
	const [user, setUser] = useState({});

  useEffect(async() =>{
		const user=await getLoggedInUser()
		setUser(user)
    doFetch(END_POINT + `${GET_COORDINATOR_LIST}/${user.id}`);
	},[])

  const handleDelete = async(id) => {
		let token = await getAuthToken();
		const url = END_POINT + 'delete_member/' + id;
		var requestOptions = {
			method: 'POST',
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		};
		fetch(url, requestOptions)
			.then((res) => res.json())
			.then((data) => {
				if (data.status == 'success') {
					let notify = notification({
						message: data.message,
						type: 'success',
					});
					notify();
					doFetch(END_POINT + `${GET_COORDINATOR_LIST}/${user.id}`);
				}
			})
			.catch((err) => console.log(err));
	};


  return (
    <div className="col-md-12 mt-3">
      <div>
        <header className="row bg-primary text-white p-1 rounded-top shadow">
          
          <div className=" col-4 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10" >Name  <i className="fas fa-sort mt-4px ms-1"></i></span>
          </div>

          <div className=" col-3 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10">Email  <i className="fas fa-sort mt-4px ms-1"></i></span>
          </div>
          
          <div className=" col-3 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10">Designation  <i className="fas fa-sort mt-4px ms-1"></i></span>
          </div>

          <div className=" col-2 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10">Action  <i className="fas fa-sort mt-4px ms-1"></i></span>
          </div>

        </header>
        <main>
          {loading ? (
            <Loading className="my-3" />
          ) : data?.data && data?.data.length ? (
            <>
              {data?.data.map((profile, idx) => {
                const even = idx % 2 == 0;
                return (
                  <div
                    className={`row align-items-center pl-9 ${
                      even ? "bg-light-blue" : "bg-table-striped"
                    }`}
                  >
                    
                    <div className="col-4">
                      <small>{profile?.name}</small>
                    </div>

                    <div className="col-3">
                      <small>{profile?.email}</small>
                    </div>

                    <div className="col-3">
                        <small>{profile.designation}</small>
                    </div>

                    <div className="col-2 d-flex">
                      <Link
                        to={`/add-coordinator`}
                        className='btn btn-sm  border p-0'
                      >
                        <i class='fas fa-edit f-r-8'></i>
                      </Link>
                      <button
                        className='btn btn-sm text-danger border p-0 ms-2  '
                        onClick={() => handleDelete(profile.id)}
                      >
                        <i class='fas fa-trash f-r-8 '></i>
                      </button>
                    </div>

                  </div>
                );
              })}
            </>
          ) : (
            <div className="row justify-content-center align-items-center p-4 bg-light-blue">
              <div className="text-center font-bold text-sky-blue">
                No Coordinator have been added here
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CoordinatorList;
