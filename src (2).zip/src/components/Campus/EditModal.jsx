export const EditModal = ({  profile, handleRowAPI }) => {
    return (
      <>
        <div className="dropdown">
          <button
            type="button"
            id="dropdownMenu2"
            className="ellipsis-button"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            <i className="fas fa-ellipsis-v"></i>
          </button>

          <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <button className="dropdown-item">View Profile</button>
            <button
              className={`dropdown-item ${
              profile.status === "Invitation Sent"
                  ? ""
                  : "disabled-link"
              }`}
              onClick={() => handleRowAPI('resend_invitation',  profile)}
            >
              Resend Invitation
            </button>
            <button className="dropdown-item text-red" onClick={() => handleRowAPI('delete_user',  profile)}>
              Delete
            </button>
          </div>
        </div>
      </>
    );
  };
  