import { useState, useEffect } from "react";
import Loading from "../common/Loading";
import moment from "moment";
import { EditModal } from "./EditModal";

const StudentCVList = ({
  data,
  loading,
  handleStudentRowAPI,
  isEditable,
  selectedCheckboxList,
  setSelectedCheckboxList,
}) => {
  const [selectAllCheck, setSelectAllCheck] = useState(false);

  useEffect(() => {
    if (data && data.length > 0) {
      const checkboxData = data.map((item) => {
        return {
          ...item,
          selected: false,
        };
      });
      setSelectedCheckboxList(checkboxData);
    }
  }, [data]);

  const handleSingleCheckbox = (id) => {
    
    const checkboxData = selectedCheckboxList.map((checkbox) => {
      if (checkbox.id == id) {
        return {
          ...checkbox,
          selected: !checkbox.selected,
        };
      }
      return checkbox;
    });
    setSelectedCheckboxList(checkboxData);
    
    console.log(checkboxData)
  };

  const handleSelectAll = (checkValue) => {
    setSelectAllCheck(checkValue);
    if (checkValue) {
      setSelectedCheckboxList((values) =>
        values.map((checkbox) => ({ ...checkbox, selected: true }))
      );
      return;
    }
    setSelectedCheckboxList((values) =>
      values.map((checkbox) => ({ ...checkbox, selected: false }))
    );
  };

  return (
    <div className="col-md-12 mt-3">
      <div>
        <header className="row bg-primary text-white p-2  rounded-top shadow">
          <div className=" col-1 p-0 d-flex justify-content-between align-item-center">
            <div class="form-check">
              <input
                class="form-check-input  f-r-10 "
                type="checkbox"
                checked={selectAllCheck}
                value={selectAllCheck}
                onChange={() => handleSelectAll(!selectAllCheck)}
              />
            </div>
          </div>
          <div className=" col-2 p-0 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10 ">Name <i className="fas fa-sort mt-4px ms-1"></i></span>

            
          </div>

          <div className=" col-4 p-0 ps-1 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10 ">Key-Skills <i className="fas fa-sort mt-4px ms-1"></i></span>

            
          </div>
          <div className=" col-2  p-0 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10 ">Date <i className="fas fa-sort mt-4px ms-1"></i></span>

            
          </div>
          <div className=" col-3 p-0 d-flex justify-content-between align-item-center">
            <span className="d-flex f-r-10 ">Status <i className="fas fa-sort mt-4px ms-1"></i></span>

            
          </div>
        </header>
        <main>
          {loading ? (
            <Loading className="my-3" />
          ) : data && data.length ? (
            <>
              {data.map((profile, idx) => {
                const even = idx % 2 == 0;
                return (
                  <div
                    key={profile.id}
                    className={`row align-items-center p-2 ${
                      even ? "bg-light-blue" : "bg-table-striped"
                    }`}
                  >
                    <div className=" col-1 p-0 d-flex justify-content-between align-item-center">
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          checked={
                            selectedCheckboxList &&
                            selectedCheckboxList.length &&
                            selectedCheckboxList.filter(
                              (checkbox) => checkbox.id === profile.id
                            )[0].selected
                          }
                          value={
                            selectedCheckboxList &&
                            selectedCheckboxList.length &&
                            selectedCheckboxList.filter(
                              (checkbox) => checkbox.id === profile.id
                            )[0].id
                          }
                          id={profile?.id}
                          onChange={(e) => {
                            handleSingleCheckbox(e.target.value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="col-2 p-0">
                      <small>{profile?.name}</small>
                    </div>

                    <div className="col-3 p-0">
                      <small>{profile?.key_skills}</small>
                    </div>
                    <div className="col-3 p-0">
                      <small>
                        {profile?.created_at &&
                          moment(profile?.created_at).format(
                            "MMMM Do YYYY h:mm a"
                          )}
                      </small>
                    </div>
                    <div className="col-3 d-flex justify-content-between">
                      <div className="">
                        <small>{profile.status}</small>
                      </div>
                      {isEditable && (
                        <div className="">
                          <EditModal
                            profile={profile}
                            handleRowAPI={handleStudentRowAPI}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </>
          ) : (
            <div className="row justify-content-center align-items-center p-4 bg-light-blue">
              <div className="text-center font-bold text-sky-blue">
                No Students have been added here
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default StudentCVList;
