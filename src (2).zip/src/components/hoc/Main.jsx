import React from 'react'

const Main = ({ children }) => {
	return (

		<div className='col-lg-9 bg-white'>
			<div className='container rounded-4 pt-3 pb-7 bg-whit'>{children}</div>

		</div>
	);
};

export default Main
