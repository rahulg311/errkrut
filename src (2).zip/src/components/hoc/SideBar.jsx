import React from 'react'

const SideBar = ({children}) => {
    return (
        <div className='col-lg-3'>
            {children}
        </div>
    )
}

export default SideBar
