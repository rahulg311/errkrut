import React from 'react'

const Section = ({ children }) => {
	return (

		<div className='container'>
			<div className='row gx-2 gy-5'>{children}</div>

		</div>
	);
};

export default Section
