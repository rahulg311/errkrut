import React, { useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT } from '../../routes/api_routes';
import moment from 'moment';
import { getLoggedInUser } from '../../classes';
import Loading from '../common/Loading';

const PastPostJobs = () => {
	const {data,loading,error,doFetch}  = useFetch();

	useEffect(async () =>{
		const user=await getLoggedInUser();
		doFetch(END_POINT + `getall_jobs/${user.company_id}`);
		
	},[])

    return (
			<div className='container mt-4 bg-white mb-2 mx-0 px-0 mt-5'>
				{
					loading ? <Loading/> : <div className='row mt-2 px-0'>
					<div className='col-md-12 mb-4'>
						<h4 className='f-r-18'>Past Job Postings</h4>
					</div>
					{
					data?.data &&	data.data.map(job=>{
							return	<div className='row border-bottom py-2'>
									<div className='col-md-10 col-8'>
										<p className=''>{job.job_title}</p>
									</div>
									<div className='col-md-2 col-4 text-end'>
										<p className=''>{
											moment(job.created_at).format('MM/DD/YYYY')
										}</p>
									</div>
								</div>;
						})
					}
				</div>
				}
			</div>
		);
}

export default PastPostJobs
