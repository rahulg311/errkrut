import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getLoggedInUser, isJson } from '../../classes';
import { Recruiter_User_Type_ID } from '../../config/constants';
import { ifFileExists } from '../../store/actions/image';
const Profile = ({ data }) => {
	const [user, setUser] = useState({});
	const [isRecruiter, setIsRecruiter] = useState(false);

	const colors = ['bg-blue', 'bg-purple', 'bg-dark-pink', 'bg-greenesh-blue', 'bg-warning', 'bg-info'];

	useEffect(async () => {
		const user = await getLoggedInUser()
		setUser(user);

		if (user?.user_type == Recruiter_User_Type_ID) {
			setIsRecruiter(true);
		}
	}, [])

	return (
		<div>
			{data != null &&
				<div className='container bg-white mx-0 py-2 px-0 '>
					<div className='d-flex align-items-center justify-content-between mb-3'>
						<h4 className='f-r-18'>{data.CardTitle}</h4>
						{isRecruiter == true &&
							<Link to={`/edit-company-profile/${user.id}`}>
								<i class='lar la-edit text-primary h4'></i>
							</Link>
						}
					</div>
					<section className='row gy-5'>
						{data?.values && data?.values.map((value, index) => {
							if (value.title == 'Company Name') {
								return (
									<div className='col-12 d-flex mb-2 align-items-center'>
										<div className='me-3 mt-2 h-100'>
											{isJson(user?.logo) && JSON.parse(user?.logo)?.map((imgs) => {
												return <img
													src={(imgs) ? imgs : `/assets/imgs/dummy-logo.png`}
													className='img-fluid box-shadow br-5 h-70px'
												/>;
											})}
										</div>
										<div class=' '>
											<div className='d-flex align-items-center h-100'>
												<h6 className='font-bold'>{value.value}</h6>

											</div>
										</div>
									</div>
								);
							} else {
								return (

									<div className={`col-md-4 col-6`}>
										<div className={`p-3 h-100 overflow-hidden wmd rounded-3 text-white ${colors[index - 1]}`}>
											<h6 className='mb-3 f-r-14'>{value.title}</h6>
											{value.value && value.value.includes('http') ? (
												<a href={value.value} target='_blank' className="text-break text-white">
													{value.value}
												</a>
											) : (
												<p className='f-r-14'>{value.value}</p>
											)}
										</div>
									</div>
								);
							}
						})}
					</section>
				</div>
			}
		</div>
	);
};

export default Profile;