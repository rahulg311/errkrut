import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLoggedInUser } from '../../classes';
import { Recruiter_User_Type_ID } from '../../config/constants';

const HiringSector = ({ data }) => {
	const [user, setUser] = useState({});
	const [isRecruiter, setIsRecruiter] = useState(false);
	const colors = ['bg-blue', 'bg-purple', 'bg-dark-pink', 'bg-greenesh-blue', 'bg-warning', 'bg-info'];

	useEffect(async () => {
		const user = await getLoggedInUser();
		setUser(user);
		if (user?.user_type == Recruiter_User_Type_ID) {
			setIsRecruiter(true);
		}
	}, []);
	return (
		<div>
			<hr className='mt-5 mb-2' />
			<div className='container mt-5 mx-0 py-1 px-0 bg-white mb-2'>



				<div className='d-flex align-items-center justify-content-between mb-3'>
					<h4 className='f-r-12'>{data.CardTitle}</h4>

					{isRecruiter == true &&
						<Link to={`/edit-company-profile/${user.id}`}>
							<i class='lar la-edit text-primary h4'></i>
						</Link>
					}
				</div>

				<section className='row gy-5'>
					{data.values.map((value, index) => {
						return (

							<div className='col-md-4 col-6 h-100'>
								<div className={`cards h-100 p-3 rounded-3 text-white ${colors[index]}`}>

									<h6 className='mb-3'>{value.title}</h6>
									<p className=''> {value.value}</p>
								</div>
							</div>
						);
					})}
				</section>
			</div>
		</div>
	);
};

export default HiringSector;
