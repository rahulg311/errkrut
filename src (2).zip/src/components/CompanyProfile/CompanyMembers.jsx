import React, { useEffect } from 'react';
import useFetch from '../../hooks/useFetch';
import { END_POINT, GET_ALL_MEMBERS } from '../../routes/api_routes';
import moment from 'moment';
import { getLoggedInUser } from '../../classes';
import Loading from '../common/Loading';
import { Link } from 'react-router-dom';

const CompanyMembers = () => {
    const { data, loading, error, doFetch } = useFetch();

    useEffect(async () => {
        const user = await getLoggedInUser();
        doFetch(END_POINT + `${GET_ALL_MEMBERS}/${user.id}`);

    }, [])

    return (
        <div className='container mt-4 bg-white mb-2 mx-0 px-0 mt-5'>
            {
                loading ? <Loading /> : <div className='row mt-2 px-0'>
                    <div className='d-flex align-items-center justify-content-between mb-3'>
                        <h4 className='f-r-18'>Members</h4>

                        <Link to={`/add-member`}>
                            <i class='lar la-edit text-primary h4'></i>
                        </Link>

                    </div>
                    {

                        data?.data && data?.data.map(member => {
                            return <div>
                                <div className='d-flex'>
                                    <h5 className=''>{member.name}</h5>
                                    <h5 className='ms-auto'>{member.access_level}</h5>
                                </div>
                                <div class="border-dashed border-bottom-0 border-right-0 border-left-0 border-color-blue mb-3 f-0-9"></div>
                            </div>;
                        })
                    }
                </div>
            }
        </div>
    );
}

export default CompanyMembers;
