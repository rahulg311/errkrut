import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLoggedInUser } from '../../classes';
import { Recruiter_User_Type_ID } from '../../config/constants';

const Summary = ({ data }) => {
	const [user, setUser] = useState({});
	const [isRecruiter, setIsRecruiter] = useState(false);

	useEffect(async () => {
		const user = await getLoggedInUser();
		setUser(user);
		if (user?.user_type == Recruiter_User_Type_ID) {
			setIsRecruiter(true);
		}
	}, []);
	return (
		<div>
			<div className='d-flex justify-content-between align-items-center mt-5'>
				<h4 className='f-r-18'>{data.CardTitle}</h4>
				{isRecruiter == true &&
					<Link to={`/edit-company-profile/${user.id}`}>
						<i class='lar la-edit text-primary h4'></i>
					</Link>
				}
			</div>
			<div className='mt-5'>
				<p className="text-break">
					{data.values.map((value) => {
						return <p>{value.value}</p>;
					})}
				</p>
			</div>
		</div>
	);
};
export default Summary;
