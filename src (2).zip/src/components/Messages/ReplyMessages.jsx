import React, { Component } from 'react';


class ReplyMessages extends Component {
    
    render() {
        const { handleChange, addAttachment, sendMessage, attachedFile } = this.props;

        return (
            <div className="row pb-1 bg-white mt-3">
                <div className="col-md-12 col-12">
                    <header className='d-flex '>
                        <div className='me-3 mt-2 fw-bold f-Poppins-Light'>
                        Reply to message
                        </div>
                    </header>
                </div>
                <form onSubmit={(e) => sendMessage(e)}>
                   {/*} <div className='col-md-12 mt-2'>
                    <input
                            type='text'
                            className='form-control input-border'
                            onChange={(e) => handleChange(e)}
                            name='message_title'
                            required
                    /> 
                    </div>*/}
                    <div className='col-md-12 mt-2'>
                        <textarea
                            type='text'
                            className='form-control input-border'
                            onChange={(e) => handleChange(e)}
                            name='message_body'
                            required
                        ></textarea>
                    </div>
                    
                    <div className='col-md-12 d-flex justify-content-between mb-2 mt-2' >
                        <div>   
                            <label className="float-end" for={`attachment`} type="button">
                                <span className="text-primary cursor vertical-middle">Add Attechment</span>
                                <i class="las la-file-export f-1-1 text-primary cursor vertical-middle"></i>
                                {attachedFile && 
                                    <span className='m-2'>{attachedFile.name}</span>
                                }
                            </label>

                            <input type="file" style={{ display: "none" }} id={`attachment`} multiple
                                onChange={(e) => addAttachment(e)} 
                            />
                        </div>
                        <button type="submit" class="btn btn-outline-primary ps-5 pe-5 f-Poppins-Medium ">Send</button>
                        
                    </div>
                </form>
            </div>
        );
    }    
};

export default ReplyMessages;
