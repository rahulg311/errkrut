import { useEffect, useState } from "react";
import {
  END_POINT,
  STUDENT_LISTING,
  GET_COORDINATOR_LIST,
} from "../../routes/api_routes";
import useFetch from "../../hooks/useFetch";
import { getLoggedInUser } from "../../classes";
import StudentCVList from "../Campus/StudentCVList";
import { EditModal } from "../Campus/EditModal";
import CoordinatorList from "../Campus/CoordinatorList";

const ListModal = ({ title, type, is_modal, closeModal, handleSubmit }) => {
  const StudentListingAPI = useFetch();
  const CoordinatorListingAPI = useFetch();
  
  const [coordinatorCheckboxList, setCoordinatorCheckboxList] = useState([]);
  const [studentsCheckboxList, setStudentsCheckboxList] = useState([]);

  const handleStudentsCheckState = (data) => setStudentsCheckboxList(data);
  const handleCoordinatorCheckState = (data) => setCoordinatorCheckboxList(data);

  useEffect(() => {
    if (type === "students") {
      getStudentListing();
    } else {
      getCoordinatorListing();
    }
  }, []);
 
  const getStudentListing = async () => {
    const user = await getLoggedInUser();
    StudentListingAPI.doFetch(END_POINT + `${STUDENT_LISTING}/${user.id}`);
  };

  const getCoordinatorListing = async () => {
    const user = await getLoggedInUser();
    CoordinatorListingAPI.doFetch(
      END_POINT + `${GET_COORDINATOR_LIST}/${user.id}`
    );
  };

  const handleSubmitModal = () => {
    let selectedArray = [];
    if(type === "coordinator") {
      selectedArray = coordinatorCheckboxList.filter(checkboxData => checkboxData.selected);
    } else if(type === "students") {
      selectedArray = studentsCheckboxList.filter(checkboxData => checkboxData.selected);  
    }
    handleSubmit(type, selectedArray);
    closeModal();
  }

  return (
    is_modal && (
      <>
        <div className="modal fade-in" style={{ display: "block" }}>
          <div
            className="modal-dialog modal-dialog-centered modal-lg"
            role="document"
          >
            <div className="modal-content">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                }}
              >
                <div className="modal-header align-items-center d-flex justify-content-between border-0">
                  <div className="f-5 pe-4 poppins-semi-bold">{title}</div>
                  <span
                    classNameName="f-2 cursor"
                    onClick={(e) => closeModal()}
                  >
                    &times;
                  </span>
                </div>
                <div className="modal-body">
                  <div className="d-flex flex-column align-items-start">
                    {type === "students" ? (
                      <StudentCVList
                        data={StudentListingAPI?.data?.data}
                        loading={StudentListingAPI.loading}
                        setSelectedCheckboxList={handleStudentsCheckState}
                        selectedCheckboxList={studentsCheckboxList}
                      />
                    ) : (
                      <CoordinatorList
                        data={CoordinatorListingAPI?.data?.data}
                        loading={CoordinatorListingAPI.loading}
                        setSelectedCheckboxList={handleCoordinatorCheckState}
                        selectedCheckboxList={coordinatorCheckboxList}
                      />
                    )}
                  </div>
                </div>
                <div className="modal-footer border-0">
                  <button
                    type="button"
                    className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                    onClick={(e) => closeModal()}
                  >
                    Close
                  </button>
                  <button
                    onClick={handleSubmitModal}
                    className="btn btn-primary btn-sm ps-4 pe-4 font-bold poppins-bold"
                  >
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="modal-backdrop fade show"></div>
      </>
    )
  );
};

export default ListModal;
