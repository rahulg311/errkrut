import React from 'react';
import { Link } from 'react-router-dom';

const JobCard = ({ job }) => {
	return (
		<div className='cards position-relative mt-4 w-100 br-5 pt-3 pb-3 ps-4 pe-4 shadow  rounded-4 overflow-hidden'>
			<div className='d-md-flex align-items-center'>
				<div className='me-2 d-flex'>
					<img src='/assets/imgs/dummy-logo.png' className='img-fluid box-shadow br-5 h-60p' />
					<div className='ms-3'>
						<h5 className='font-bold mb-1'>Safdar azeem</h5>
						<p>Current designation</p>
					</div>
				</div>

				<div className='ms-auto mt-md-0  mt-2 d-flex align-items-center'>
					<p className='mb-0 me-3'>Status:Rejected</p>
					<div class='form-check'>
						<input
							class='form-check-input p-8px'
							type='checkbox'
							value=''
							id='flexCheckDefault'
						/>
					</div>
				</div>
			</div>
			<div>
				<h6 className='my-2 text-primary fw-bold '>Applied for UI UX</h6>
			</div>
			<div>
				<p className='my-2 text-primary fw-medium'>Portfolio 23.pdf</p>
			</div>

			<div className='pe-3'>
				<div className='row mt-2 mb-2'>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-6'>
								<p className='font-bold m-0 f-0-8 text-sky-blue'>
									<span className='me-1 vertical-middle'>
										<i class='las la-briefcase  text-sky-blue f-1-1'></i>
									</span>
									<span>Experience</span>
								</p>
							</div>
							<div className='col-md-6 ps-0'>
								<p className='m-0 f-0-8'>0 to 5 years</p>
							</div>

							{/* row */}
						</div>
					</div>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-6'>
								<p className='font-bold m-0 f-0-8 text-sky-blue'>
									<span className='me-1 vertical-middle'>
										<i class='las la-map-marker  text-sky-blue f-1-1'></i>
									</span>
									<span>Location</span>
								</p>
							</div>
							<div className='col-md-6 ps-0'>
								<p className='m-0 f-0-8'>pk</p>
							</div>
						</div>
					</div>
					<div className='col-md-4'>
						<div className='row'>
							<div className='col-md-5'>
								<p className='font-bold m-0 f-0-8 text-sky-blue'>
									<span className='me-1 vertical-middle'>
										<i class='las la-rupee-sign text-sky-blue f-1-1'></i>
									</span>
									<span>Salary</span>
								</p>
							</div>
							<div className='col-md-7'>
								<p className='m-0 f-0-8'>Not Disclosed</p>
							</div>
						</div>
						{/* row */}
					</div>
					{/* row */}
				</div>

				<div className='row mt-2 mb-2'>
					<div className='col-md-12'>
						<div className='row'>
							<div className='col-md-2'>
								<p className='font-bold m-0 f-0-8 text-sky-blue'>
									<span className='me-1 vertical-middle'>
										<i class='las la-briefcase  text-sky-blue f-1-1'></i>
									</span>
									<span>Skillset</span>
								</p>
							</div>
							<div className='col-md-9 ps-0'>
								<p className='m-0 f-0-8 text-break ms-md-0 ms-2 mt-md-0 mt-1'>
									React, JavaScript, and Angular
								</p>
							</div>
						</div>
					</div>
				</div>
				<div className='d-md-flex border-bottom pb-3 border-2'>
					<h6 className='me-2 mb-md-0 mb-1'>Summary</h6>
					<small>
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis, delectus. Quidem
						laudantium amet optio? Aliquid accusamus eos voluptatum quos, eaque esse expedita
						dicta autem neque, corporis tenetur nihil repellendus quasi.
					</small>
				</div>
			</div>
			<div className='d-md-flex mt-5 mb-2 align-items-center'>
				<div>
					<button className='btn btn-danger text-white btn-sm ps-4 pe-4'>Reject</button>
				</div>

				<div className='ms-auto mt-md-0 mt-2'>
					<Link className='btn btn-sm ps-4 pe-4 me-2 btn-border'>Save Profile</Link>

					<button className='btn btn-primary btn-sm ps-4 pe-4'>Call For interview</button>
				</div>
			</div>
		</div>
	);
};

export default JobCard;
