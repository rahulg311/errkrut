import { NavLink } from 'react-router-dom';
import { getValueFromArr } from '../../classes';


const QuestionariesModel = ({ is_modal, closeModal, jobState, jobData }) => {
    return (
        jobState.qmodel && <>
            <div className="modal fade-in" style={{ display: "block" }}>
                <div
                    className="modal-dialog modal-dialog-centered modal-lg"
                    role="document"
                >
                    <div className="modal-content">
                        <div className="modal-header align-items-center d-flex justify-content-between border-0">
                            <a
                                className="btn-sm ps-4 pe-4 poppins-medium"
                            >
                                Who can apply for the job
                            </a>
                            <span
                                classNameName="f-2 cursor"
                                onClick={(e) => closeModal()}
                            >&times;
                            </span>
                        </div>
                        <div className="modal-body">
                            <div className="d-flex flex-column align-items-start">
                                <div class="mb-1">
                                    <div className="d-flex ps-4 pe-4 flex-column justify-content-between">
                                        <label className="py-1">
                                            <b>Education Qualification : </b> {jobData?.q_education_qualification}
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-1">
                                    <div className="d-flex ps-4 pe-4 flex-column justify-content-between">
                                        <label className="py-1">
                                            <b>Skills Set : </b> {jobData?.q_skill_set}
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-1">
                                    <div className="d-flex ps-4 pe-4 flex-column justify-content-between">
                                        <label className="py-1">
                                            <b>Salary : </b> {jobData?.q_salary}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="modal-footer border-0">
                            <button
                                type="button"
                                className="btn bg-transparent btn-sm ps-4 pe-4 font-bold poppins-bold"
                                onClick={(e) => closeModal()}
                            >
                                Close
                            </button>
                            <NavLink to={`/apply-job/${jobData?.job_id}/${jobData?.job_title}/${jobData?.company_name}/${(jobData?.company_logo) ? btoa(getValueFromArr(jobData?.company_logo, 0)) : ''}`} className='btn btn-primary btn-sm text-light px-4'>
                                Apply Now
                            </NavLink>
                        </div>
                    </div>
                </div>
            </div>
            <div className="modal-backdrop fade show"></div>
        </>
    );
};

export default QuestionariesModel;
