import { NavLink } from 'react-router-dom';
import { getValueFromArr } from '../../classes';
import { useState } from 'react'


const ConfirmationModal = ({ closeModal, status, mdata, subFunction, skipQuiz }) => {
    const [smodal, setSecondConfirmation] = useState(false);
    return (
        <>
            {((status.start_test && !smodal) && <>
                <div className="modal fade-in" style={{ display: "block" }}>
                    <div
                        className="modal-dialog modal-dialog-centered modal-md"
                        role="document"
                    >
                        <div className="modal-content">
                            <div className="modal-body">
                                <div className="d-flex flex-column align-items-center">
                                    <div className="d-flex ps-4 pe-4 flex-column mt-4 text-center">
                                        <h4>{mdata.title} </h4>
                                        <p className='p-4 poppins-medium'>{mdata.message}</p>
                                    </div>
                                </div>
                                <div className="d-flex flex-column align-items-center">
                                    <div className="ps-4 pe-4 flex-column align-items-left">
                                        <button
                                            type="button"
                                            className="btn btn-default btn-sm  ps-4 pe-4 font-bold poppins-bold"
                                            onClick={(e) => closeModal()}
                                        >
                                            Close
                                        </button>
                                        {(mdata.link != '' ? <NavLink to={mdata.link} className='btn btn-primary ml-1 btn-sm text-light px-4'>
                                            {mdata.button}
                                        </NavLink> : <button onClick={() => { setSecondConfirmation(true) }} className='btn btn-primary ml-1 btn-sm text-light px-4'>
                                            {mdata.button}
                                        </button>)}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="modal-backdrop fade show"></div></>)}

            {(smodal && <><div className="modal fade-in" style={{ display: "block" }}>
                <div
                    className="modal-dialog modal-dialog-centered modal-md"
                    role="document"
                >
                    <div className="modal-content">
                        <div className="modal-body">
                            <div className="d-flex flex-column align-items-center">
                                <div className="d-flex ps-4 pe-4 flex-column mt-4 text-center">
                                    <h4>Are you sure you want to finish the quiz? </h4>
                                    <p className='p-4 poppins-medium'></p>
                                </div>
                            </div>
                            <div className="d-flex flex-column align-items-center">
                                <div className="ps-4 pe-4 flex-column align-items-left">
                                    <button
                                        type="button"
                                        className="btn btn-default btn-sm  ps-4 pe-4 font-bold poppins-bold"
                                        onClick={(e) => setSecondConfirmation(false)}
                                    >
                                        Close
                                    </button>
                                    <button onClick={() => { skipQuiz(); subFunction(); }} className='btn btn-primary ml-1 btn-sm text-light px-4'>
                                        {mdata.button}
                                    </button>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <div className="modal-backdrop fade show"></div></>)}
        </>
    );
};

export default ConfirmationModal;
