import { useState, useEffect } from 'react';
import axios from 'axios';
import { getLoggedInUser, getAuthToken } from '../classes';
function useFetch(url) {
	const [data, setData] = useState(null);
	const [loading, setLoading] = useState(null);
	const [error, setError] = useState(null);
	useEffect(async () => {
		let token = await getAuthToken();
		setLoading(true);
		setData(null);
		setError(null);
		axios
			.get(url, { headers: { 'Authorization': 'Bearer ' + token } })
			.then((res) => res.data)
			.then((result) => {
				setLoading(false);
				setError(null);
				setData(result);
			})
			.catch((err) => {
				setLoading(false);
				setData(null);
				setError('An error occurred. Awkward..');
			});
	}, [url]);

	const doFetch = async (url) => {
		let token = await getAuthToken();
		setLoading(true);
		setData(null);
		setError(null);
		axios
			.get(url, { headers: { 'Authorization': 'Bearer ' + token } })
			.then((res) => res.data)
			.then((result) => {
				setLoading(false);
				setError(null);
				setData(result);
			})
			.catch((err) => {
				setLoading(false);
				setData(null);
				setError('An error occurred. Awkward..');
			});
	};


	return { data, loading, error, doFetch };
}
export default useFetch;
