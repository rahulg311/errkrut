import { Component } from 'react';
import './assets/scss/bootstrap.scss';
import './assets/line-awesome-1.3.0/1.3.0/css/line-awesome.min.css';
import './assets/css/style.scss';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Routes } from './routes/routes';
import { APP_NAME } from './config/constants';

/* slick slider */
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
/* slick slider */

class App extends Component {


	componentDidMount() {
		document.title = APP_NAME
	}

	render() {
		return (
			<div className='App'>
				<Router>
					<Switch>

						{Routes.map((route, i) => (
							<Route
								key={i}
								exact={route.exact}
								path={route.path}
								component={route.component}
							/>
						))}


					</Switch>

				</Router>
			</div>
		);
	}
}

export default App;
