import MultiSelect from "../components/MultiSelect/MultiSelect";

export function parseArrayToHTML(elementObject, onChange, value) {



    if (elementObject && elementObject.name && elementObject.type) {

        //console.log(elementObject)

        switch (elementObject.type) {

            case "Text":
                return <input type="text" name={elementObject.name}  value={value} onChange={(e) => onChange(e, "dynamic")} class={elementObject.class} id={`id_${elementObject.id}`}/>
            case "Email":
                return <input type="email" name={elementObject.name} value={value} onChange={(e) => onChange(e, "dynamic")} class={elementObject.class} />
            case "Number":
                return <input type="number" name={elementObject.name} value={value} onChange={(e) => onChange(e, "dynamic")} class={elementObject.class} />

            case "Radio":

                let radioField = Object.keys(elementObject.attr_options).length != '' ? JSON.parse(elementObject.attr_options).map((optk, optv) => {

                    return <label class="me-2">
                        <input type="radio" name={elementObject.name} value={optk} onChange={(e) => onChange(e, "dynamic")} />
                        <span class="text-capitalize"> {optk} </span>
                    </label>;

                }) : '';

                return radioField;

            case "CheckBox":

                let checkField = Object.keys(elementObject.attr_options).length != '' ? JSON.parse(elementObject.attr_options).map((optk, optv) => {

                    return <label class="me-2">
                        <input type="checkbox" name={elementObject.name} value={optk} onChange={(e) => onChange(e, "dynamic")} class={elementObject.class} />
                        <span class="text-capitalize"> {optk} </span>
                    </label>;

                }) : '';

                return checkField;

            case "Dropdown":
                let arr = JSON.parse(elementObject.attr_options);

                let i = 0;

                let optField = Object.keys(elementObject.attr_options).length != '' ? arr.map((optk, optv) => {

                    console.log('dropwdown value', optv);

                    return <option value={optk} selected={(optk == value)?true:false}>{optk}</option>;

                    i++;

                }) : '';

                let SelectField = <select class={elementObject.class} name={elementObject.name} onChange={(e) => onChange(e, "dynamic")}>
                    <option value="" selected disabled className="text-capitalize">--Please Select {elementObject.name.replace(/_/g," ")}--</option>
                    {optField}
                </select>

                return SelectField;


            case "MultiSelect":

                if (Object.keys(elementObject.attr_options).length != '')
                    return <MultiSelect options={JSON.parse(elementObject.attr_options)} name={elementObject.name} handleChange={onChange} SelectedValues={value} />

                return;

            case "File":

                let fileField = <>
                    <label className="btn btn-primary btn-sm" for={`id${elementObject.name}`} type="button">
                        <span className="vertical-middle">{elementObject.title}</span>
                        <i class="las la-file-export f-1-1 vertical-middle"></i>
                    </label>
                    <input type="file" style={{ display: "none" }} id={`id${elementObject.name}`} multiple onChange={(e) => onChange(e, "dynamic")} name={elementObject.name} />

                </>
                    ;

                return (
                    <>

                        {value && Object.keys(value).forEach((file) => {

                            return <p>{file}</p>

                        })}
                        {fileField}

                    </>)
                    ;

            case "Textarea":

                return <textarea name={elementObject.name} value={value} onChange={(e) => onChange(e, "dynamic")} class={elementObject.class}>{value}</textarea>
        }

    }
}