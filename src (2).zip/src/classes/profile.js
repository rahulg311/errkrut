import { getLoggedInUser } from './index';

export const getFirstCharacterProfile = async () => {

    let user = await getLoggedInUser();

    //console.log('Peofileeeee: ', user)

    let res = '';

    if (user) {
        if (user.name) {
            res = user.name[0];
        } else if (user.email) {
            res = user.email[0];
        } else {
            res = user.mobile;
        }
    }

    //console.log(res);
    return res;
}
