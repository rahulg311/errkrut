import {
	Email_Validation_Regex,
	Mobile_Validation_Regex,
	Password_Validation_Regex,
	Password_Validation_Message,
	LettersOnly,
	Numbers_Only_Regex
} from '../config/constants';

export function validation(vali = { type: '', value: '', message: '', regex: null }) {
	let valiObj = { error: 0, message: '' };

	//required
	if (vali.type == 'required') {
		if (vali.value == '' || vali.value == null) {
			//console.log(vali.value);
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}

	//email validation
	if (vali.type == 'email') {
		if (!Email_Validation_Regex.test(String(vali.value).toLowerCase())) {
			//console.log(vali.value);
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}


	//letters only
	if (vali.type == 'letters_only') {
		if (!LettersOnly.test(vali.value)) {
			//console.log(vali.value);
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}


	//mobile validation
	if (vali.type == 'mobile') {
		if (!Mobile_Validation_Regex.test(vali.value)) {
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}

	//password validation
	if (vali.type == 'password') {
		if (!Password_Validation_Regex.test(vali.value)) {
			valiObj['error'] = 1;
			valiObj['message'] = Password_Validation_Message;
		}
	}

	//email or mobile validation
	if (vali.type == 'emailormobile') {
		if (!Email_Validation_Regex.test(String(vali.value).toLowerCase())) {
			console.log(vali.value);
			if (!Mobile_Validation_Regex.test(vali.value)) {
				valiObj['error'] = 1;
				valiObj['message'] = vali.message;
			}
		}
	}

	//numbers only
	if (vali.type == 'numbers_only') {
		if (!Numbers_Only_Regex.test(String(vali.value).toLowerCase())) {
			//console.log(vali.value);
			if (!Mobile_Validation_Regex.test(vali.value)) {
				valiObj['error'] = 1;
				valiObj['message'] = vali.message;
			}
		}
	}

	//checkbox validation
	if (vali.type == 'checkbox') {
		if (vali.value == 0 || vali.value == null) {
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}

	//regex validation
	if (vali.type == 'regex') {
		let regexpression = vali.regex;

		if (!regexpression.test(vali.value)) {
			valiObj['error'] = 1;
			valiObj['message'] = vali.message;
		}
	}

	return valiObj;
}

/* validate files */
export const filesValidation = (array) => {

	

}
/* validate files */
