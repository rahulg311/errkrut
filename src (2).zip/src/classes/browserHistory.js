export function routeChanged(path, props, is_replace = 0) {
    //let history = useHistory();

    if (is_replace) {
        props.history.replace(path);
    } else {
        props.history.push(path);
    }

}

export function routePushed(path, props, data = {}) {
    //console.log(props)
    props.history.push({
        pathname: path,
        //search: '?query=abc',
        state: data
    });
}