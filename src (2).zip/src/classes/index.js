import ReactHtmlParser from 'react-html-parser';

import { APP_Prefix, Campus_User_Type_ID, Recruiter_User_Type_ID } from '../config/constants';
import { notification } from './messages';

//html parser
export function htmlParser(htmlString) {
    return ReactHtmlParser(htmlString);
}

// Conver a string to slug
export const slugToText = slug => {
    var words = slug.split("_");

    for (var i = 0; i < words.length; i++) {
        var word = words[i];
        words[i] = word.charAt(0).toUpperCase() + word.slice(1);
    }

    return words.join(" ");
};


// Get query string of the url
export const getUrlVars = () => {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (
        m,
        key,
        value
    ) {
        vars[key] = value;
    });
    return vars;
};

export const getLoggedInUser = async () => {
    let authUser = await JSON.parse(localStorage.getItem(APP_Prefix + 'auth_profile'));
    if (authUser)
        return authUser;
}

export const isLoggedIn = () => {
    let token = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_token'));
    if (token)
        return true;
    return false;
}

export const isRecruiter = () => {
    let result = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_profile'));
    if (result?.id)
        if (result?.user_type == Recruiter_User_Type_ID)
            return true;
    return false;
}

export const isCampus = () => {
    let result = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_profile'));
    if (result?.id)
        if (result?.user_type == Campus_User_Type_ID)
            return true;
    return false;
}

export const setLoggedInUser = (data) => {
    localStorage.setItem(APP_Prefix + 'auth_profile', JSON.stringify(data));
    return true;
}

export const reSetLoggedInUser = (data) => {
    let user = JSON.parse(localStorage.getItem(APP_Prefix + 'auth_profile'));
    Object.keys(data).map((key) => {
        if (user[key])
            user[key] = data[key];
    });
    console.log(user)
    localStorage.setItem(APP_Prefix + 'auth_profile', JSON.stringify(user));
}

export const setLoggedInToken = (token) => {
    localStorage.setItem(APP_Prefix + 'auth_token', JSON.stringify(token));
    return true;
}

export const getAuthToken = async () => {
    let authToken = await JSON.parse(localStorage.getItem(APP_Prefix + 'auth_token'));
    if (authToken)
        return authToken;

    return false;
}

/* slugify */
export const convertToSlug = (Text) => {
    if(Text == undefined) {
        return '';
    }
    return Text.toLowerCase()
        .replace(/ /g, '-')
        .replace(/[^\w-]+/g, '');
}

/* logout */
export const logout = (props) => {
    //console.log('props :>> ', props);
    props.history?.push('/login');
    localStorage.setItem(APP_Prefix + 'auth_token', null);
    localStorage.setItem(APP_Prefix + 'auth_profile', null);
    if (props.history) {
        props.history.push('/login');
        let notify = notification({ type: 'success', message: 'Logout Successful.' });
        notify();
    }
}

/* shuffle array */

export const shuffleArray = (array) => {
    for (var i = array.length - 1; i > 0; i--) {

        // Generate random number
        var j = Math.floor(Math.random() * (i + 1));

        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    return array;
}


/* count object length */

export const ObjectLength = (object) => {
    var length = 0;
    for (var key in object) {
        if (object.hasOwnProperty(key)) {
            ++length;
        }
    }
    return length;
};


/* Mime icons */

export const MimeIcon = (url) => {

    let ext = url.split(/[#?]/)[0].split('.').pop().trim();

    if (['png', 'jpg', 'jpeg', 'gif'].includes(ext)) {
        return <i className="las la-photo-video"></i>;
    } else if (['pdf'].includes(ext)) {
        return <i className="las la-file-pdf text-danger"></i>;
    } else if (['doc', 'docs', 'xls'].includes(ext)) {
        return <i className="las la-file-word text-info"></i>;
    } else {
        return <i className="las la-file-alt"></i>;
    }

};

export const FileNameFromURL = (url) => {
    if (url)
        return url.substring(url.lastIndexOf('/') + 1);
    return;
}


export const ReadMore = (str, len) => {
    if(str === undefined){
        return '';
    }
    let res = str.substring(0, len);
    if (str.length > len) {
        res += '...';
    }
    return res;
}


export const isJson = (str) => {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

export const errorPrettifyObjArr = (arr, type = 'Array') => {

    if (type == 'Object') {
        if (Object.keys(arr).length > 0) {
            let s = Object.keys(arr).map((k) => {
                return arr[k];
            });
            return s.join(', ');
        }
    }

    if (type == 'Array') {
        return arr.join(', ');
    }

}

export const errorPrettify = (str) => {
    try {
        return JSON.parse(str).join(',');
    } catch (e) {
        return str;
    }
}

export const getValueFromArr = (arr, index) => {
    if (arr) {
        try {
            let array = JSON.parse(arr);
            return array[index];
        } catch (e) {
            return arr;
        }
    }
}


export const getObjFromArrBykey = (arr, obj) => {
    try {
        if (arr.length > 0) {
            let res = arr.find((v) => {
                if (v[obj.key] == obj.value)
                    return v;
            });
            return res;
        }
    } catch (e) {
        return;
    }
}

export const getIndexFromArr = (arr, value) => {
    arr = JSON.parse(arr);
    if (arr && arr.length > 0) {
        let index = arr.indexOf(value);
        return index;
    }
}

export const filterArray = (arr, value, is_exact = false) => {
    arr = JSON.parse(arr);
    arr.filter((s) => {
        if (is_exact)
            return s == value;
        if (is_exact == false)
            return s.indexOf(value) !== -1;
    });
}


export const formatTitle = (str) => {

    if (str) {
        str = str?.replace(/[_-]/g, " ");

        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    return str;

}

export const sumArray = (arr) => {
    if (arr && arr?.length > 0) {
        let total = 0;
        for (var i in arr) {
            total += parseInt(arr[i]);
        }
        return total;
    }
    return 0;
}


export const createErrors = (obj) => {
    let err = {};
    Object.keys(obj).map((fk) => {
        if (obj[fk].required) {
            if (obj[fk].value == '') {
                err[obj[fk].name] = formatTitle(obj[fk].name) + ' is required';
            }
        }
    });

    return err;
}