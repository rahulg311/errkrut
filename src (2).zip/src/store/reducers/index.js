import { combineReducers } from "redux";
import commonReducer from "./commonReducer";
import jobreducer from "./jobreducer";
import getJobs from "./getJobs";
import appliedcandidatesreducer from "./appliedcandidatesreducer";

// Aggreating all the reducers defined 
const rootReducer = combineReducers({
    common: commonReducer,
    jobreducer: jobreducer,
    getJobs: getJobs,
    appliedcandidatesreducer: appliedcandidatesreducer
});

export default rootReducer; 