import { END_POINT, OTP_RESEND } from '../../routes/api_routes';
import { OTP_RESEND_RESP } from '../../config/constants';

export const resendOTP = (formdata,id) => async (dispatch) => {
    try {

            console.log(formdata);

            const response = await fetch(END_POINT + OTP_RESEND, {
                method: 'POST',
                body: JSON.stringify(formdata),
                headers: {
					'Accept': 'application/json',
					//'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
            });
            
            const json = await response.json();

            await dispatch({ type: OTP_RESEND_RESP, data: json });

    } catch (e) {
        console.log(e);
    }
};
