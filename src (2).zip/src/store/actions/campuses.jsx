import { END_POINT, GetTopCampuses } from '../../routes/api_routes';
import { GET_TOP_CAMPUS } from '../../config/constants';
import Loading from '../../components/common/Loading';
import { getAuthToken } from '../../classes';

export const getCampuses = () => async (dispatch) => {
	try {
		<Loading className='text-center'></Loading>
		const token = await getAuthToken();
		const requestOptions = {
			method: 'GET',
			redirect: 'follow',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		};
		const response = await fetch(END_POINT + GetTopCampuses, requestOptions);
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_TOP_CAMPUS, data: json });
	} catch (e) {
		console.log(e);
	}
};
