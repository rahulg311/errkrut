import { errorPrettify, errorPrettifyObjArr, getLoggedInUser, getAuthToken } from '../../classes';
import { notification } from '../../classes/messages';
import { END_POINT, SaveBillingDetails, UpdateBillingDetails } from '../../routes/api_routes';
import { Recruiter_User_Type_ID, Candidate_User_Type_ID } from '../../config/constants';
export const saveBillingDetails = (payload, history) => async (dispatch) => {
	try {
		var formdata = new FormData();
		if (payload.id != undefined) {
			formdata.append('id', payload.id);
		}
		formdata.append('user_id', payload.user_id);
		formdata.append('name', payload.name);
		formdata.append('company_name', payload.company_name);
		formdata.append('gst_number', payload.gst_number);
		formdata.append('phone_number', payload.phone_number);
		formdata.append('email', payload.email);
		formdata.append('address_line1', payload.address_line1);
		formdata.append('address_line2', payload.address_line2);
		formdata.append('country', payload.country);
		formdata.append('state', payload.state);
		formdata.append('city', payload.city);
		formdata.append('zip', payload.zip);
		formdata.append('additional_information', payload.additional_information);
		let token = await getAuthToken();
		const response = await fetch(END_POINT + (payload.id != undefined ? UpdateBillingDetails : SaveBillingDetails), {
			method: 'POST',
			body: formdata,
			headers: { 'Authorization': 'Bearer ' + token },
		});
		const json = await response.json();
		if (json?.status == 'success') {
			if (payload.id == undefined) {
				payload['id'] = json?.data?.id;
			}

			let oldStorageData = JSON.parse(localStorage.getItem('BILLING-ADRESS'));

			let index = oldStorageData ? oldStorageData.findIndex(p => p.id == payload.id) : -1;

			if (index >= 0) {
				oldStorageData[index] = payload;
				localStorage.setItem('BILLING-ADRESS', JSON.stringify([...oldStorageData]))
			}
			else {
				oldStorageData
					? localStorage.setItem('BILLING-ADRESS', JSON.stringify([...oldStorageData, payload]))
					: localStorage.setItem('BILLING-ADRESS', JSON.stringify([payload]));
			}
			const user = await getLoggedInUser();
			let notify = notification({ type: 'success', message: json?.message });
			notify();
			if (payload.back != undefined) {
				console.log("payloadpayloadpayload");
				if (user.user_type == Recruiter_User_Type_ID) {
					history.push(`/recruiterAccount`);
				}
				else if (user.user_type == Candidate_User_Type_ID) {
					history.push(`/candidateAccount`);
				}
			}
			else {
				if (user.user_type == Recruiter_User_Type_ID) {
					history.push(`/checkout`);
				}
				else if (user.user_type == Candidate_User_Type_ID) {
					history.push(`/candidatecheckout`);
				}
				else {
					history.push(`/campus-checkout`);
				}
			}

		} else {
			let notify = notification({ type: 'error', message: errorPrettifyObjArr(json?.message, 'Array') });
			notify();
		}





	} catch (e) {
		console.log(e);
	}
};
