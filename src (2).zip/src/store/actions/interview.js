import { SCHEDULE_INTERVIEW_RESP } from "../../config/constants";
import { END_POINT, SCHEDULE_INTERVIEW } from "../../routes/api_routes";
import { getAuthToken } from '../../classes/index';


export const interviewSchedule = (formData) => async (dispatch) => {
    try {
        let token = await getAuthToken();
        const response = await fetch(END_POINT + SCHEDULE_INTERVIEW, {
            method: 'POST',
            body: formData,
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token,
			}
        });
        const json = await response.json();
        await dispatch({ type: SCHEDULE_INTERVIEW_RESP, data: json });
    } catch (e) {
        console.log(e);
    }
};