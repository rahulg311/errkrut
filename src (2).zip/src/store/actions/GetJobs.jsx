import { END_POINT, Get_top_jobs } from '../../routes/api_routes';
import { GET_JOBS } from '../../config/constants';
export const getJobs = (payload) => async (dispatch) => {
	try {
		var formdata = new FormData();
		formdata.append('skill', 'ui');
		formdata.append('designation', 'developer');
		formdata.append('location', 'delhi');

		const response = await fetch(END_POINT + Get_top_jobs, {
			method: 'POST',
			body: formdata,
		});
		const json = await response.json();        
		dispatch({ type: GET_JOBS, data: json.data });
	} catch (e) {
		console.log(e);
	}
};
