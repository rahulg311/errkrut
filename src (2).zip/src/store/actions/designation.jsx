import { GET_DESIGNATION_RESP } from "../../config/constants";
import { END_POINT, GET_DESIGNATION } from "../../routes/api_routes";

/* Get Locations */
export const getDesignation = () => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + GET_DESIGNATION, {
			method: 'GET',
			//body: JSON.stringify(formData) 
		});
		const json = await response.json();
		await dispatch({ type: GET_DESIGNATION_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* Get Locations */