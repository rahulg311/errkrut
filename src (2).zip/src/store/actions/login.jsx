import { END_POINT, ValidateOTP, LoginUser } from '../../routes/api_routes';
import { OTP_Resp, Login_Resp } from '../../config/constants';

export const login = (formData) => async (dispatch) => {
    try{
        const response = await fetch(END_POINT + LoginUser, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: { 'Content-Type': 'application/json' }
        });
        const json = await response.json();
        await dispatch({type: Login_Resp, data: json});
    }catch(e){
        console.log(e);
    }
}

export const validateOTP = (formData) => async (dispatch) => {
    try{
        const response = await fetch(END_POINT + ValidateOTP, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: { 'Content-Type': 'application/json' }
        });
        const json = await response.json();
        await dispatch({type: OTP_Resp, data: json});
    }catch(e){
        console.log(e);
    }
}