import { END_POINT, GetTopJobs, CreateJobs, EDIT_JOB, UPDATE_JOB, GET_ALL_JOBS, APPLY_JOB, JOB_DETAIL, GET_APPLIED_JOBS, LIKE_SAVE_JOB, JOB_STATUS, JOB_TYPES, JOB_TYPE_DETAILS, GET_JOB_DESC, GET_JOB_CATEGORIES, CHANGE_JOB_STATUS, GET_COMPANY_CATEGORY, GET_COMPANY_SUB_CATEGORY, GET_COUNTRY, GET_STATE, GET_CITY, GET_CITIES, GET_PROBABLE_CANDIDATES } from '../../routes/api_routes';
import { GET_TOP_JOBS, Add_Job_Resp, GET_JOB_FORM_DATA, EDIT_JOB_RESP, UPDATE_JOB_RESP, GET_ALL_JOBS_RESP, APPLY_JOB_RESP, JOB_DETAIL_RESP, GET_APPLIED_JOBS_RESP, LIKE_SAVE_JOB_RESP, JOB_STATUS_RESP, JOB_TYPES_RESP, JOB_TYPE_DETAILS_RESP, JOB_DESC_RESP, GET_JOB_CATEGORIES_RESP, CHANGE_JOB_STATUS_RESP, GET_COMPANY_CATEGORY_RESP, GET_COMPANY_SUB_CATEGORY_RESP, GET_COUNTRY_RESP, GET_STATE_RESP, GET_CITY_RESP, GET_CITIES_RESP, GET_PROBABLE_CANDIDATES_RESP } from '../../config/constants';
import { getAuthToken } from '../../classes/index';

/* Get Jobs */
export const getJobs = (formData = {}) => async (dispatch) => {
	try {

		let fdata = new FormData();

		if (formData) {

			Object.keys(formData).map((key) => {
				fdata.append(key, formData[key]);
			});

		}
		const response = await fetch(END_POINT + GetTopJobs, {
			method: 'POST',
			body: fdata
		});
		const json = await response.json();
		await dispatch({ type: GET_TOP_JOBS, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* Get Jobs */


/* GET all Jobs */

export const getAllJobs = (uri) => async (dispatch) => {
	try {

		if (isNaN(uri)) {
			const response = await fetch(END_POINT + GET_ALL_JOBS, {
				method: 'GET',
			});
			const json = await response.json();
			await dispatch({ type: GET_ALL_JOBS_RESP, data: json });
		}
		else {
			const response = await fetch(END_POINT + GET_ALL_JOBS + '/' + uri, {
				method: 'GET',
			});
			const json = await response.json();
			await dispatch({ type: GET_ALL_JOBS_RESP, data: json });
		}


	} catch (e) {
		//console.log(e);
	}
};

/* GET all Jobs */

/* GET Probable Candidate */

export const get_probable_candidate = (str) => async (dispatch) => {

	try {
		let token = await getAuthToken();
		const response = await fetch(END_POINT + GET_PROBABLE_CANDIDATES + '/' + str, {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_PROBABLE_CANDIDATES_RESP, data: json });
	} catch (e) {
		//console.log(e);
	}
};

/* GET Probable Candidate */


/* Create Job */
export const createJob = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			//console.log(token);

			console.log(formData)
			let fdata = new FormData();
			if (formData) {
				Object.keys(formData).map(k => fdata.append(k, formData[k]));
			}

			const response = await fetch(END_POINT + CreateJobs, {
				method: 'POST',
				body: fdata /*JSON.stringify(formData)  JSON.stringify({ user_id: 1 }) */,
				headers: {
					'Authorization': 'Bearer ' + token
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: Add_Job_Resp, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Create Job */


/* Get  Job Form Data */
export const getJobFormData = (formdata) => async (dispatch) => {
	console.log('job form data ', formdata)
	dispatch({ type: GET_JOB_FORM_DATA, data: formdata });
};
/* Get Job Form Data */


/* Edit Job */
export const editJob = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {


			const response = await fetch(END_POINT + EDIT_JOB, {
				method: 'POST',
				body: formData,
				headers: {
					'Authorization': 'Bearer ' + token,
				}
			});

			//console.log(response.text());

			const json = await response.json();


			await dispatch({ type: EDIT_JOB_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Edit Job */


/* Update Job */
export const updateJob = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();
		let fdata = new FormData();
		if (formData) {
			Object.keys(formData).map(k => fdata.append(k, formData[k]));
		}

		/* run api */

		if (token) {

			const response = await fetch(END_POINT + UPDATE_JOB, {
				method: 'POST',
				body: formData,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: UPDATE_JOB_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Update Job */


/* Apply Job */
export const applyForJob = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			const response = await fetch(END_POINT + APPLY_JOB, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			await dispatch({ type: APPLY_JOB_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Apply Job */


/* job detail */

export const jobDetail = (formData) => async (dispatch) => {
	try {

		/* run api */
		let token = await getAuthToken();
		const response = await fetch(END_POINT + JOB_DETAIL, {
			method: 'POST',
			body: JSON.stringify(formData),
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		});

		//console.log(response.text());

		const json = await response.json();

		console.log(json);

		await dispatch({ type: JOB_DETAIL_RESP, data: json });

		/* run api */


	} catch (e) {
		console.log(e);
	}


};

/* job detial */


/* candidte applied jobs */

export const getAppliedJobs = (formdata) => async (dispatch) => {
	try {
		let fdata = new FormData();
		if (formdata) {
			Object.keys(formdata).map(k => fdata.append(k, formdata[k]));
		}
		let token = await getAuthToken();
		const response = await fetch(END_POINT + GET_APPLIED_JOBS, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		//console.log(json);
		await dispatch({ type: GET_APPLIED_JOBS_RESP, data: json });
	} catch (e) {
		//console.log(e);
		await dispatch({ type: GET_APPLIED_JOBS_RESP, data: { status: 'error' } });
	}
};

/* candidte applied jobs */

/* like and save jobs */

export const likeAndSaveJob = (formdata) => async (dispatch) => {
	try {
		let token = await getAuthToken();
		let fdata = new FormData();
		if (formdata) {
			Object.keys(formdata).map(k => fdata.append(k, formdata[k]));
		}
		const response = await fetch(END_POINT + LIKE_SAVE_JOB, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		//console.log(json);
		await dispatch({ type: LIKE_SAVE_JOB_RESP, data: json });
	} catch (e) {
		//console.log(e);
	}
};

/* like and save jobs */


/* GET all Jobs Status */

export const getAllJobsStatus = (uri) => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + JOB_STATUS + '/' + uri, {
			method: 'GET',
		});
		const json = await response.json();
		//console.log(json);
		await dispatch({ type: JOB_STATUS_RESP, data: json });
	} catch (e) {
		//console.log(e);
		await dispatch({ type: JOB_STATUS_RESP, data: { status: 'error' } });
	}
};

/* GET all Jobs Status */



/* Get Job Types */

export const jobTypes = (formData) => async (dispatch) => {

	let token = await getAuthToken();

	if (token) {
		try {
			const response = await fetch(END_POINT + JOB_TYPES, {
				method: 'POST',
				body: formData,
				headers: {
					//'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});
			const json = await response.json();
			await dispatch({ type: JOB_TYPES_RESP, data: json });
		} catch (e) {
			await dispatch({ type: JOB_TYPES_RESP, data: { status: 'error' } });
		}
	}

}

/* Get JOb Types */

/* Get Job Type Details */

export const jobTypeDetails = (id) => async (dispatch) => {

	try {
		let token = await getAuthToken();

		const response = await fetch(END_POINT + JOB_TYPE_DETAILS + '/' + id, {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		await dispatch({ type: JOB_TYPE_DETAILS_RESP, data: json });
	} catch (e) {
		await dispatch({ type: JOB_TYPE_DETAILS_RESP, data: { status: 'error' } });
	}

}

/* Get JOb Type Details */


/* get job descriptions */

export const getJobDescriptions = (id = 0) => async (dispatch) => {

	try {
		let token = await getAuthToken();
		const response = await fetch(END_POINT + GET_JOB_DESC, {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: JOB_DESC_RESP, data: json });
	} catch (e) {
		await dispatch({ type: JOB_DESC_RESP, data: { status: 'error' } });
	}

}

/* get job descriptions */

/* get job categories */

export const getJobCategories = () => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_JOB_CATEGORIES, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_JOB_CATEGORIES_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_JOB_CATEGORIES_RESP, data: { status: 'error' } });
	}

}

/* get job categories */

/* get company category */
export const getCompanyCategories = () => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_COMPANY_CATEGORY, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_COMPANY_CATEGORY_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_COMPANY_CATEGORY_RESP, data: { status: 'error' } });
	}

}
/* get company category */

/* get company Sub category */
export const getCompanySubcategories = (id) => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_COMPANY_SUB_CATEGORY + '/' + id, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_COMPANY_SUB_CATEGORY_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_COMPANY_SUB_CATEGORY_RESP, data: { status: 'error' } });
	}

}
/* get company Sub category */

/* get country */
export const getCountry = (id) => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_COUNTRY, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_COUNTRY_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_COUNTRY_RESP, data: { status: 'error' } });
	}

}
/* get country */

/* get State */
export const getState = (id) => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_STATE + '/' + id, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_STATE_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_STATE_RESP, data: { status: 'error' } });
	}

}
/* get State */

/* get city */
export const getCity = (id) => async (dispatch) => {

	try {
		const response = await fetch(END_POINT + GET_CITY + '/' + id, {
			method: 'GET',
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_CITY_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_CITY_RESP, data: { status: 'error' } });
	}

}
/* get city */

/* get city */
export const getCities = (id) => async (dispatch) => {

	try {
		var formdata = new FormData();
		formdata.append('country_id', id);

		const response = await fetch(END_POINT + GET_CITIES, {
			method: 'POST',
			body: formdata,
			headers: {
				'Accept': 'application/json'
			}
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: GET_CITIES_RESP, data: json });
	} catch (e) {
		await dispatch({ type: GET_CITIES_RESP, data: { status: 'error' } });
	}

}
/* get city */

/* change job status */

export const changeJobStatus = (formdata) => async (dispatch) => {
	try {

		let fdata = new FormData();
		if (formdata) {
			Object.keys(formdata).map(k => fdata.append(k, formdata[k]));
		}
		const token = await getAuthToken();
		const response = await fetch(END_POINT + CHANGE_JOB_STATUS, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		//console.log(json);
		await dispatch({ type: CHANGE_JOB_STATUS_RESP, data: json });
	} catch (e) {
		//console.log(e);
	}
};

/* change job status */