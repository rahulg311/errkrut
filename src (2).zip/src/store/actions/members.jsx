import { END_POINT, GET_ALL_MEMBERS } from '../../routes/api_routes';
import { GET_ALL_MEMBERS_RESP, GET_TOP_COMPANY } from '../../config/constants';
import { getAuthToken } from '../../classes/index';

export const getMembers = (id) => async (dispatch) => {
	try {
		let token = await getAuthToken();
		const response = await fetch(END_POINT + GET_ALL_MEMBERS + '/' + id, {
			method: 'GET',
			headers: {
				'Authorization': 'Bearer ' + token
			}
		});
		const json = await response.json();
		await dispatch({ type: GET_ALL_MEMBERS_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
