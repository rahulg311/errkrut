
import {getAuthToken} from '../../classes/index';

import { Add_Question_Resp, GET_FILTER_QUES_RESP, Get_Question_Resp, GET_QUEST_ATTR_RESP } from '../../config/constants';

import { END_POINT, AddQuestion, GetQuestion, GET_QUEST_ATTR, GET_FILTER_QUES } from '../../routes/api_routes';

/* Add Question */
export const addQuestion = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			//console.log(token);

			//console.log(formData)

			const response = await fetch(END_POINT + AddQuestion, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			
			await dispatch({ type: Add_Question_Resp, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Add Question */



/* Get Question */
export const getQuestion = (id) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			//console.log(token);

			const response = await fetch(END_POINT + GetQuestion + '/' + id, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			
			await dispatch({ type: Get_Question_Resp, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Get Question */


/* Get Question Attribute */
export const getQuestionAttr = () => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			//console.log(token);

			const response = await fetch(END_POINT + GET_QUEST_ATTR, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
				}
			});

			const json = await response.json();
			
			await dispatch({ type: GET_QUEST_ATTR_RESP, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Get Question Attribute */


/* Get Filter Question */
export const getFilterQuestions = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			//console.log(token);

			const response = await fetch(END_POINT + GET_FILTER_QUES, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			
			await dispatch({ type: GET_FILTER_QUES_RESP, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Get Filter Question */
