import {
	SelectFeatures,
} from '../../config/constants';

export const selectFeatures = (plan) => async (dispatch) => {
	dispatch({ type: SelectFeatures, data: plan });
};