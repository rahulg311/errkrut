import { END_POINT, GetTopJobs } from '../../routes/api_routes';
import { GET_SEARCH_RESP, SEARCH_DATA } from '../../config/constants';

export const searchDetail = (formData) => async (dispatch) => {
    try {

        let fdata = new FormData();

        Object.keys(formData).map((key) => {
            if (formData[key])
                fdata.append(key, formData[key]);
        });

        console.log(fdata)

        const response = await fetch(END_POINT + GetTopJobs, {
            method: 'POST',
            body: fdata,
            headers: {
                'Accept': 'application/json'
            }
        });
        const json = await response.json();
        await dispatch({ type: GET_SEARCH_RESP, data: json });
    } catch (e) {
        console.log(e);
    }
};

export const searchUpdate = (data) => async (dispatch) => {
    await dispatch({ type: SEARCH_DATA, data: data });
}