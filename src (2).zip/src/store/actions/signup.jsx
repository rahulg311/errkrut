import {
	END_POINT,
	ValidateOTPSignup,
	SubmitSignup,
	Register,
	Register_Resp,
	SOCIAL_LOGIN,
	GET_COMPANY_CATEGORY,
	GET_COMPANY_SUB_CATEGORY,
	GET_COUNTRY_CATEGORY,
	GET_STATE_CATEGORY,
	GET_CITY_CATEGORY,
	DELETE_USER,
	CHECK_SITE
} from '../../routes/api_routes';
import { GET_COMPANY_CATEGORY_RESP, GET_COMPANY_SUB_CATEGORY_RESP, GET_COUNTRY_CATEGORY_RESP,
	GET_STATE_CATEGORY_RESP, GET_CITY_CATEGORY_RESP, OTP_Validate_Resp, Signup_Submit_Resp, SOCIAL_LOGIN_RESP,
	DELETE_USER_CONFIRMATION, SITE_DATA, GET_COUNTRY_CATEGORY_P_RESP, GET_STATE_CATEGORY_P_RESP,
	GET_CITY_CATEGORY_P_RESP } from '../../config/constants';
import { getAuthToken, getLoggedInUser } from '../../classes/index';

export const validateOTPSignup = (formData) => async (dispatch) => {
	try {
		console.log(formData);

		const response = await fetch(END_POINT + ValidateOTPSignup, {
			method: 'POST',
			// body: JSON.stringify({text: text, otp: otp, otp_id: otp_id}) // body data type must match "Content-Type" header
			body: formData,
		});

		const json = await response.json();
		console.log(json, 'validation data....');
		//console.log(json.data.id, "validation data....")
		//console.log(json.data.token, "validation token....")
		//this.setState({ id: json.data.id, token: json.data.token })
		await dispatch({ type: OTP_Validate_Resp, data: json });
	} catch (e) {
		console.log(e);
	}
};

//signup submit

export const submitSignup = (formData) => async (dispatch) => {
	try {
		console.log(formData);

		let fdata = new FormData();

		Object.keys(formData).map((k => {

			if (formData[k] instanceof File || formData[k] instanceof FileList) {

				for (let i = 0; i < formData[k].length; i++) {
					fdata.append(k, formData[k][i])
				}

			} else {
				fdata.append(k, formData[k]);
			}

		}));

		const response = await fetch(END_POINT + SubmitSignup, {
			method: 'POST',
			// body: JSON.stringify({text: text, otp: otp, otp_id: otp_id}) // body data type must match "Content-Type" header
			body: fdata/* JSON.stringify(formData) */,
			headers: {
				/* 'Content-Type': 'application/json',
				'Accept': 'application/json' */
			},
		});
		console.log(response);
		const json = await response.json();
		console.log(json);

		await dispatch({ type: Signup_Submit_Resp, data: json });
	} catch (e) {
		console.log(e);
	}
};

//get signup otp

export const getSignupOTP = (formData) => async (dispatch) => {
	try {
		console.log(formData);

		const response = await fetch(END_POINT + Register, {
			method: 'POST',
			body: JSON.stringify(formData),
			headers: { 'Content-Type': 'application/json' },
		});
		console.log(response);
		const json = await response.json();
		console.log(json);

		await dispatch({ type: Register_Resp, data: json });
	} catch (e) {
		console.log(e);
	}
};


/* social login */

export const socialLogin = async (formData) => {
	try {
		//console.log(formData);

		const response = await fetch(END_POINT + SOCIAL_LOGIN, {
			method: 'POST',
			// body: JSON.stringify({text: text, otp: otp, otp_id: otp_id}) // body data type must match "Content-Type" header
			body: JSON.stringify(formData),
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		return json;

		//await dispatch({ type: SOCIAL_LOGIN_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};

/* social login */


/* get company category */

export const getCompanyCategory = () => async (dispatch) => {
	try {
		//console.log(formData);

		const response = await fetch(END_POINT + GET_COMPANY_CATEGORY, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_COMPANY_CATEGORY_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};

/* get company category */

/* get company sub category */

export const getCompSubCategory = (id) => async (dispatch) => {
	try {
		//console.log(formData);

		const response = await fetch(END_POINT + GET_COMPANY_SUB_CATEGORY + '/' + id, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_COMPANY_SUB_CATEGORY_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};

/* get company sub category */

/* get country category */
export const getCountryCategory = () => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + GET_COUNTRY_CATEGORY, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_COUNTRY_CATEGORY_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* get country category */

/* get state category */
export const getStateCategory = (country_id) => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + GET_STATE_CATEGORY + `/${country_id}`, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_STATE_CATEGORY_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* get state category */

/* get city category */
export const getCityCategory = (state_id) => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + GET_CITY_CATEGORY + `/${state_id}`, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_CITY_CATEGORY_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};


/* get city category */


/* Delete User */
export const deleteAccount = (user_id) => async (dispatch) => {

	let token = await getAuthToken();

	try {
		console.log(user_id)
		const response = await fetch(END_POINT + DELETE_USER + `/${user_id}`, {
			method: 'GET',
			headers: {
				'Content-Type': 'application/json',
				'Accept': 'application/json',
				'Authorization': 'Bearer ' + token,
			},
		});
		console.log(response);
		const json = await response.json();

		await dispatch({ type: DELETE_USER_CONFIRMATION, data: json });
	} catch (e) {
		console.log(e);
	}
};


export const checkSite = () => async (dispatch) => {
	let token = await getAuthToken();
	const result = await getLoggedInUser();
	console.log(result);
	const response = await fetch(END_POINT + CHECK_SITE + '/' + result.company_id, {
		method: 'GET',
		headers: {
			'Accept': 'application/json',
			'Authorization': 'Bearer ' + token
		}
	});

	const json = await response.json();

	return dispatch({ type: SITE_DATA, data: json });
}

/* get country category */
export const getCountryPCategory = () => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + GET_COUNTRY_CATEGORY, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_COUNTRY_CATEGORY_P_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* get country category */

/* get state category */
export const getStatePCategory = (country_id) => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + GET_STATE_CATEGORY + `/${country_id}`, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_STATE_CATEGORY_P_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* get state category */

/* get city category */
export const getCityPCategory = (state_id) => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + GET_CITY_CATEGORY + `/${state_id}`, {
			method: 'GET',
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();

		await dispatch({ type: GET_CITY_CATEGORY_P_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};


/* get city category */