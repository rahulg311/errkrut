import { END_POINT, GET_TEMPLATE, CREATE_TEMPLATE, GET_USER_TEMPLATE, GET_SINGLE_TEMPLATE } from '../../routes/api_routes';
import { GET_TEMPLATE_RESP, CREATE_TEMPLATE_RESP, GET_SINGLE_TEMPLATE_RESP } from '../../config/constants';
import { getAuthToken } from '../../classes/index';

/* Get Template */
export const getTemplate = (id) => async (dispatch) => {
	try {
		let token = await getAuthToken();

		/* run api */

		if (token) {
			const response = await fetch(END_POINT + GET_TEMPLATE + '/' + id, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});
			const json = await response.json();
			console.log(json);
			await dispatch({ type: GET_TEMPLATE_RESP, data: json });
		}
	} catch (e) {
		console.log(e);
	}
};
/* Get Template */



/* Create Template */
export const createTemplate = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			console.log(token);

			console.log(formData)

			const response = await fetch(END_POINT + CREATE_TEMPLATE, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: CREATE_TEMPLATE_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Create Template */


/* GET Single Template */
export const getSingleTemplate = (id) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			console.log(token);

			const response = await fetch(END_POINT + GET_SINGLE_TEMPLATE + '/' + id, {
				method: 'GET',
				//body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: GET_SINGLE_TEMPLATE_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Get Single Template */