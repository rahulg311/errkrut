/* Change Password */

import { getAuthToken } from "../../classes";
import { CHANGE_PASS_RESP } from "../../config/constants";
import { CHANGE_PASSWORD, END_POINT } from "../../routes/api_routes";


export const changePassword = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

            let fdata = new FormData();
            Object.keys(formData).map((key) => {
                fdata.append(key, formData[key]);
            });

			const response = await fetch(END_POINT + CHANGE_PASSWORD, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token
				}
			});

			const json = await response.json();
			
			await dispatch({ type: CHANGE_PASS_RESP, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Change Password */