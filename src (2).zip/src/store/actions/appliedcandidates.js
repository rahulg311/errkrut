/* appliedCandidates  */

import { getAuthToken } from "../../classes";
import {  GET_COMPANY_APPLIED_JOBS_RESP } from "../../config/constants";
import {  END_POINT, GET_COMPANY_APPLIED_JOBS } from "../../routes/api_routes";

export const appliedCandidates = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

            let fdata = new FormData();
            Object.keys(formData).map((key) => {
                fdata.append(key, formData[key]);
            });

			const response = await fetch(END_POINT + GET_COMPANY_APPLIED_JOBS, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token
				}
			});

			const json = await response.json();
			
			await dispatch({ type: GET_COMPANY_APPLIED_JOBS_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* appliedCandidates */