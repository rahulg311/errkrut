import { END_POINT, GET_LETTER, CREATE_LETTER, GET_LETTER_INTENT, GET_OFFER_LETTERS } from '../../routes/api_routes';
import { GET_LETTER_RESP, CREATE_LETTER_RESP, GET_LETTER_INTENT_RESP, GET_OFFER_LETTERS_RESP } from '../../config/constants';
import { getAuthToken } from '../../classes/index';

/* Get Letter */
export const getLetter = () => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + GET_LETTER, {
			method: 'POST',
		});
		const json = await response.json();
		await dispatch({ type: GET_LETTER_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* Get Letter */


/* Get Letter of Intent */
export const getLetterIntent = (id) => async (dispatch) => {
	try {
		let token = await getAuthToken();

		if (token) {

			const response = await fetch(END_POINT + GET_LETTER_INTENT + '/' + id, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});
			const json = await response.json();
			await dispatch({ type: GET_LETTER_INTENT_RESP, data: json });

		}
	} catch (e) {
		console.log(e);
	}
};
/* Get Letter of Intent*/



/* Create Letter */
export const createLetter = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			console.log(token);

			console.log(formData)

			const response = await fetch(END_POINT + CREATE_LETTER, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: CREATE_LETTER_RESP, data: json });
		}





		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Create Letter */


/* Get Offer Letters */
export const getOfferLetters = (id) => async (dispatch) => {
	try {
		let token = await getAuthToken();

		if (token) {

			const response = await fetch(END_POINT + GET_OFFER_LETTERS + '/' + id, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});
			const json = await response.json();
			await dispatch({ type: GET_OFFER_LETTERS_RESP, data: json });

		}
	} catch (e) {
		console.log(e);
	}
};
/* Get Offer Letters*/