import { END_POINT, GetTopCompanies } from '../../routes/api_routes';
import { GET_TOP_COMPANY } from '../../config/constants';
import Loading from '../../components/common/Loading';

export const getCompanies = () => async (dispatch) => {
	try {
		<Loading className='text-center'></Loading>
		const response = await fetch(END_POINT + GetTopCompanies, {
			method: 'POST',
		});
		const json = await response.json();
		await dispatch({ type: GET_TOP_COMPANY, data: json });
	} catch (e) {
		console.log(e);
	}
};
