import { END_POINT, GetPlans, GET_CURRENT_PLAN_FEATURES } from '../../routes/api_routes';
import { APP_Prefix, GET_CURRENT_PLAN_FEATURES_RESP, GET_PLANS } from '../../config/constants';
import { getAuthToken, getLoggedInUser } from '../../classes';

export const getPlansAction = () => async (dispatch) => {
	try {
		let token = await getAuthToken();
		let user = await getLoggedInUser();
		if (token) {
			const response = await fetch(END_POINT + GetPlans + "/" + user.user_type, {
				headers: {
					'Authorization': 'Bearer ' + token
				}
			});
			const json = await response.json();
			await dispatch({ type: GET_PLANS, data: json });
		}
	} catch (e) {
		console.log(e);
	}
};

export const getCurrPlanFeatures = async (formData) => {
	try {
		let token = await getAuthToken();

		if (token) {
			const response = await fetch(END_POINT + GET_CURRENT_PLAN_FEATURES, {
				method: 'POST',
				body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});
			const json = await response.json();
			return json;
		}
	} catch (e) {
		console.log(e);
	}
};