import {
	END_POINT,
	GET_SKILLS
} from '../../routes/api_routes';
import { GET_SKILLS_FILTER_RESP, GET_SKILLS_RESP } from '../../config/constants';


/* social login */

export const getSkills = (type) => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + GET_SKILLS, {
			method: 'POST',
			//body: JSON.stringify(),
			headers: { 'Content-Type': 'application/json' },
		});
		//console.log(response);
		const json = await response.json();
		console.log(json);

		if(type == 'filter'){
			await dispatch({ type: GET_SKILLS_FILTER_RESP, data: json });
		}else{
			await dispatch({ type: GET_SKILLS_RESP, data: json });
		}
		
	} catch (e) {
		console.log(e);
	}
};

/* social login */