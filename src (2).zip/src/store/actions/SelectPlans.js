import { END_POINT, SelectPlan } from '../../routes/api_routes';
import { SELECTPLAN } from '../../config/constants';
export const SelectPlanlanAction = (payload,history,plan) => async (dispatch) => {
	try {	
		const response = await fetch(END_POINT + SelectPlan, {
			method: 'POST',
			body: JSON.stringify(payload),
			headers: { 'Content-Type': 'application/json' },
		});
		const json=await response.json();
		
		if (json.status == 'success') {
			history.push(`/expend-plan/${plan.id}`);
		}	
		
		dispatch({type:SELECTPLAN,data:plan})
} catch (e) {
		console.log(e);
	}
};
