import { END_POINT, ValidateOTPSignup, FORGOT_PASSWORD, UPDATE_PASSWORD } from '../../routes/api_routes';
import { OTP_Validate_Resp, Forgot_Password_Resp, Update_Password_Resp } from '../../config/constants';

export const forgot_password = (formData) => async (dispatch) => {
    try{
        const response = await fetch(END_POINT + FORGOT_PASSWORD, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: { 'Content-Type': 'application/json' }
        });
        const json = await response.json();
        await dispatch({type: Forgot_Password_Resp, data: json});
    }catch(e){
        console.log(e);
    }
}

export const validateOTP = (formData) => async (dispatch) => {
    try{
        const response = await fetch(END_POINT + ValidateOTPSignup, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: { 'Content-Type': 'application/json' }
        });
        const json = await response.json();
        console.log(json)
        await dispatch({type: OTP_Validate_Resp, data: json});
    }catch(e){
        console.log(e);
    }
}

export const change_password = (formData) => async (dispatch) => {
    try{
        const response = await fetch(END_POINT + UPDATE_PASSWORD, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: { 'Content-Type': 'application/json' }
        });
        const json = await response.json();
        await dispatch({type: Update_Password_Resp, data: json});
    }catch(e){
        console.log(e);
    }
}