import { EDIT_PROFILE, END_POINT, GetProfile, GET_CAND_PROFILE_CARDS, UpdateProfile } from '../../routes/api_routes';
import { EDIT_PROFILE_RESP, GET_CAND_PROFILE_CARDS_RESP, GET_USER_PROFILE_RESP, Update_Profile_Resp } from '../../config/constants';
import { getAuthToken } from '../../classes/index';

export const getProfile = (id) => async (dispatch) => {
    try {

        let token = await getAuthToken();

        if (token) {

            const response = await fetch(END_POINT + GetProfile + `/${id}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                }
            });

            const json = await response.json();

            await dispatch({ type: GET_USER_PROFILE_RESP, data: json });

        }
    } catch (e) {
        console.log(e);
    }
};


export const updateProfile = (formdata) => async (dispatch) => {
    try {

        let token = await getAuthToken();

        if (token) {

            console.log(formdata);

            let fmData = new FormData();

            Object.keys(formdata).map((k) => {


                if (formdata[k] != '') {

                    if (formdata[k] instanceof File || formdata[k] instanceof FileList) {

                        console.log('filess', formdata[k])

                        for (let i = 0; i < formdata[k].length; i++) {
                            fmData.append(k, formdata[k][i])
                        }

                    } else {
                        fmData.append(k, formdata[k]);
                    }

                }

                console.log('Form data here  ', fmData.get(k));

            });



            const response = await fetch(END_POINT + UpdateProfile, {
                method: 'POST',
                body: fmData,
                headers: {
                    //'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    //'Content-Type': 'application/json'
                    //"Content-Type": "multipart/form-data"
                }
            });

            const json = await response.json();

            await dispatch({ type: Update_Profile_Resp, data: json });

        }
    } catch (e) {
        console.log(e);
    }
};

/* get profile cards */
export const getProfileCards = (id) => async (dispatch) => {
    try {

        let token = await getAuthToken();

        if (token) {

            const response = await fetch(END_POINT + GET_CAND_PROFILE_CARDS + `/${id}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                }
            });

            const json = await response.json();

            await dispatch({ type: GET_CAND_PROFILE_CARDS_RESP, data: json });

        }
    } catch (e) {
        console.log(e);
    }
};
/* get profile cards */

/* edit profile */
export const editProfile = (id) => async (dispatch) => {
    try {

        let token = await getAuthToken();

        if (token) {

            const response = await fetch(END_POINT + EDIT_PROFILE + `/${id}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                }
            });

            const json = await response.json();

            await dispatch({ type: EDIT_PROFILE_RESP, data: json });

        }
    } catch (e) {
        console.log(e);
    }
};
/* edit profile */

