
import { END_POINT, CreateQuiz, UpdateQuiz, GET_ALL_QUIZ, EDIT_QUIZ, ATTEMPT_QUIZ, SELECT_ANSWER, START_QUIZ, FINAL_SUBMIT, GET_QUIZ_STATUS, SKIP_QUESTIONS, SEND_ANSWER, ASSESSMENT_FINAL_SUBMIT, ASSESSMENT_SELECT_ANSWER, ASSESSMENT_START_QUIZ, ASSESSMENT_ATTEMPT_QUIZ, ASSESSMENT_SKIP_QUESTIONS, ASSESSMENT_GET_QUIZ_STATUS } from '../../routes/api_routes';
import { ATTEMPT_QUIZ_RESP, EDIT_QUIZ_RESP, FINAL_SUBMIT_RESP, GET_CREATE_QUIZ_RESP, GET_UPDATE_QUIZ_RESP, GET_QUIZ_RESP, GET_QUIZ_STATUS_RESP, SELECT_ANSWER_RESP, SKIP_QUESTIONS_RESP, START_QUIZ_RESP, SEND_ANSWER_RESP } from '../../config/constants';

import { getAuthToken } from '../../classes/index';
import { notification } from '../../classes/messages';

/* Create Quiz */
export const createQuiz = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* let formData = {
			"company_id":1,
			"title":"ffds",
			"duration":"2",
			"evaluation":"1",
			"quiz_retake":1,
			"name":null,
			"instruction":"sdfdsdf",
			"quiz_failed_message":"asf",
			"per_page_questions":"2",
			"randomize_section_questions":1,
			"quiz_instructions":"dsf",
			"quiz_success_message":"aff",
			"show_result":1,
			"check_answer":1,
			"dynamic_quiz":1,
			"partial_marking":1,
			"passing_marks":"2",
			"randomize_questions":1,
			"randomize_options":1,
			"negative_marking":1,
			"correct_marks":"2",
			"incorrect_marks":"2",
			"sections":[
			   {
				  "section_title":"dad",
				  "number_of_questions":"22",
				  "added_questions":[
					 44,
					 45,
					 46
				  ]
			   }
			]
		 } */

		let fdata = new FormData;

		Object.keys(formData).map((key) => {

			if (key == 'sections') {
				fdata.append(key, JSON.stringify(formData[key]));
			} else {
				fdata.append(key, formData[key]);
			}
			console.log(key);
			console.log(fdata.get(key));
		});



		/* run api */

		if (token) {

			const response = await fetch(END_POINT + CreateQuiz, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			console.log(response);

			const json = await response.json();

			console.log(json);

			await dispatch({ type: GET_CREATE_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};
/* Create Quiz */

// Update Quiz
export const updateQuiz = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();
		let fdata = new FormData;

		Object.keys(formData).map((key) => {

			if (key == 'sections') {
				fdata.append(key, JSON.stringify(formData[key]));
			} else {
				fdata.append(key, formData[key]);
			}
			console.log(key);
			console.log(fdata.get(key));
		});



		/* run api */

		if (token) {

			const response = await fetch(END_POINT + UpdateQuiz, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			console.log(response);

			const json = await response.json();

			console.log(json);

			await dispatch({ type: GET_UPDATE_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

// End Quiz

/* Get Quiz Status */

export const getQuizStatus = (id) => async (dispatch) => {
	try {
		let token = await getAuthToken();
		if (true) {

			const response = await fetch(END_POINT + GET_QUIZ_STATUS + '/' + id, {
				method: 'GET',
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			const json = await response.json();

			await dispatch({ type: GET_QUIZ_STATUS_RESP, data: json });
		}
	} catch (e) {
		console.log(e);
	}
};

/* Get Quiz Status */

/* skip quiz questions */

export const skipQuizQuestions = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		/* run api */

		if (true) {

			const response = await fetch(END_POINT + SKIP_QUESTIONS, {
				method: 'POST',
				body: formData,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();

			console.log(json);

			await dispatch({ type: SKIP_QUESTIONS_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* skip quiz questions */

/* Get Quiz */
export const getQuiz = (id, type) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {
			let Qtype = '?type=' + type;

			const response = await fetch(END_POINT + GET_ALL_QUIZ + '/' + id + Qtype, {
				method: 'GET',
				//body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			//console.log(response.text());

			const json = await response.json();

			console.log(json);

			await dispatch({ type: GET_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Get Quiz */

/* Edit Job */
export const editQuiz = (id) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		/* run api */

		if (token) {

			const response = await fetch(END_POINT + EDIT_QUIZ + '/' + id, {
				method: 'GET',
				//body: JSON.stringify(formData),
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			await dispatch({ type: EDIT_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
	}


};
/* Edit Quiz */


/* attempt quiz */

export const attemptQuiz = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		let fdata = new FormData();
		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		if (true) {

			const response = await fetch(END_POINT + ATTEMPT_QUIZ, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();

			console.log(json);

			await dispatch({ type: ATTEMPT_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* attempt quiz */


/* start quiz */

export const startQuiz = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		let fdata = new FormData();

		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		if (true) {

			const response = await fetch(END_POINT + START_QUIZ, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			console.log(json);

			await dispatch({ type: START_QUIZ_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* start quiz */


/* select answer */

export const selectAnswer = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		let fdata = new FormData();

		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		if (true) {

			const response = await fetch(END_POINT + SELECT_ANSWER, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();

			console.log(json);

			await dispatch({ type: SELECT_ANSWER_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* select answer */
/* send answer */

export const sendAnswer = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		let fdata = new FormData();

		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		if (token) {

			const response = await fetch(END_POINT + SEND_ANSWER, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();

			console.log(json);

			await dispatch({ type: SEND_ANSWER_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* sendAnswer answer */


/* final submit */

export const finalSubmit = (formData) => async (dispatch) => {
	try {

		let token = await getAuthToken();

		console.log(formData);

		let fdata = new FormData();

		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		if (true) {
			const response = await fetch(END_POINT + FINAL_SUBMIT, {
				method: 'POST',
				body: fdata,
				headers: {
					'Accept': 'application/json',
					'Authorization': 'Bearer ' + token,
					//'Content-Type': 'application/json'
				}
			});

			const json = await response.json();
			console.log(json);

			await dispatch({ type: FINAL_SUBMIT_RESP, data: json });
		}

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* final submit */

/* Assessment Functions */

export const assessmentSkipQuizQuestions = (formData) => async (dispatch) => {
	try {

		/* run api */

		const response = await fetch(END_POINT + ASSESSMENT_SKIP_QUESTIONS, {
			method: 'POST',
			body: formData,
			headers: {
				'Accept': 'application/json',
				//'Content-Type': 'application/json'
			}
		});

		const json = await response.json();

		console.log(json);

		await dispatch({ type: SKIP_QUESTIONS_RESP, data: json });

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

export const assessmentGetQuizStatus = (id) => async (dispatch) => {
	try {

		const response = await fetch(END_POINT + ASSESSMENT_GET_QUIZ_STATUS + '/' + id, {
			method: 'GET',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			}
		});

		const json = await response.json();

		await dispatch({ type: GET_QUIZ_STATUS_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};

export const assessmentAttemptQuiz = (formData) => async (dispatch) => {
	try {

		let fdata = new FormData();
		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */

		const response = await fetch(END_POINT + ASSESSMENT_ATTEMPT_QUIZ, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				//'Content-Type': 'application/json'
			}
		});

		const json = await response.json();


		await dispatch({ type: ATTEMPT_QUIZ_RESP, data: json });

		/* run api */


	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

export const assessmentStartQuiz = (formData) => async (dispatch) => {
	try {
		let fdata = new FormData();

		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});

		/* run api */
		const response = await fetch(END_POINT + ASSESSMENT_START_QUIZ, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				//'Content-Type': 'application/json'
			}
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: START_QUIZ_RESP, data: json });

		/* run api */
	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

export const assessmentSelectAnswer = (formData) => async (dispatch) => {
	try {
		let fdata = new FormData();
		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});
		/* run api */

		const response = await fetch(END_POINT + ASSESSMENT_SELECT_ANSWER, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				//'Content-Type': 'application/json'
			}
		});
		const json = await response.json();
		console.log(json);
		await dispatch({ type: SELECT_ANSWER_RESP, data: json });
		/* run api */
	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

export const assessmentFinalSubmit = (formData) => async (dispatch) => {
	try {
		let fdata = new FormData();
		Object.keys(formData).map((key) => {
			fdata.append(key, formData[key]);
		});
		/* run api */
		const response = await fetch(END_POINT + ASSESSMENT_FINAL_SUBMIT, {
			method: 'POST',
			body: fdata,
			headers: {
				'Accept': 'application/json',
				//'Content-Type': 'application/json'
			}
		});
		const json = await response.json();
		await dispatch({ type: FINAL_SUBMIT_RESP, data: json });
		/* run api */
	} catch (e) {
		console.log(e);
		if (e) {
			let notify = notification({ message: 'Unexpected Error Found!', type: 'error' });
			notify();
		}
	}


};

/* End Assessment Functions */


/* Dispatch Quiz Result */
export const dispatchQuizResult = (data) => async (dispatch) => {
	dispatch(data);
};
/* Dispatch Quiz Result */
