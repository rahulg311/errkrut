
export const ifFileExists = (url) => () => {
    fetch(url)
        .then(function (response) {
            // console.log(url + " -> " + response.ok);
            if (response.ok) {
                return response.text();
            }
            throw new Error('Error message.');
        })
        .then(function (data) {
            console.log("data: ", data);
        }.bind(this))
        .catch(function (err) {
            console.log("failed to load ", url, err.message);
        });
};
