import { GET_LOCATION_RESP } from "../../config/constants";
import { END_POINT, GET_LOCATIONS } from "../../routes/api_routes";

/* Get Locations */
export const getLocations = () => async (dispatch) => {
	try {
		const response = await fetch(END_POINT + GET_LOCATIONS, {
			method: 'GET',
			//body: JSON.stringify(formData) 
		});
		const json = await response.json();
		await dispatch({ type: GET_LOCATION_RESP, data: json });
	} catch (e) {
		console.log(e);
	}
};
/* Get Locations */